<?php
if (!isset($_GET['id'])) {
    die('Voucher não especificado.');
}

require_once 'functions.php';
$configGeral = carregarConfigGeral(); // Carrega as configurações gerais

$voucher_id = $_GET['id'];
$keys_vouchers = ['id', 'codigo', 'valor', 'status', 'data_criacao', 'agendamento_id_uso', 'data_validade'];
$vouchersArr = lerDados('vouchers.txt', $keys_vouchers);
$voucher = $vouchersArr[$voucher_id] ?? null;

if (!$voucher) {
    die('Voucher não encontrado.');
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Voucher de Presente - <?= htmlspecialchars($configGeral['nome_barbearia']) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Montserrat', sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; background-color: #f0f0f0; }
        .voucher-card { width: 500px; height: 280px; background: #fff; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); display: flex; flex-direction: column; justify-content: space-between; padding: 30px; box-sizing: border-box; background-image: linear-gradient(135deg, #111 10%, #333 100%); color: #fff; position: relative; overflow: hidden; }
        .voucher-card::before { content: ''; position: absolute; top: -100px; left: -100px; width: 250px; height: 250px; background: rgba(255, 255, 255, 0.05); border-radius: 50%; }
        .header { display: flex; justify-content: space-between; align-items: flex-start; }
        .header h1 { font-family: 'Playfair Display', serif; margin: 0; font-size: 2rem; }
        .header .logo { font-weight: bold; font-size: 1.2rem; }
        .main-content { text-align: center; }
        .main-content .code-label { font-size: 0.9rem; letter-spacing: 1px; text-transform: uppercase; color: #ccc; }
        .main-content .code { font-size: 1.8rem; font-weight: 700; background: rgba(255, 255, 255, 0.1); padding: 10px 20px; border-radius: 8px; margin-top: 5px; display: inline-block; letter-spacing: 2px; border: 1px dashed #777; }
        .footer { display: flex; justify-content: space-between; align-items: flex-end; }
        .footer .value-label { font-size: 1rem; color: #ccc; }
        .footer .value { font-size: 2.5rem; font-weight: 700; line-height: 1; }
        .footer .validity { font-size: 0.8rem; text-align: right; }
        .no-print { position: fixed; top: 20px; left: 20px; display:flex; gap: 10px; }
        .no-print button { padding: 10px 15px; border: none; border-radius: 5px; background-color: #333; color: #fff; cursor: pointer; }
        @media print { body { background-color: #fff; } .voucher-card { box-shadow: none; margin: 0; -webkit-print-color-adjust: exact; color-adjust: exact; } .no-print { display: none; } }
    </style>
</head>
<body onload="window.print()">
    <div class="no-print">
        <button onclick="window.print()">Imprimir</button>
        <button onclick="window.close()">Fechar</button>
    </div>
    <div class="voucher-card">
        <div class="header">
            <span class="logo"><?= htmlspecialchars($configGeral['nome_barbearia']) ?></span>
            <h1>Vale-Presente</h1>
        </div>
        <div class="main-content">
            <span class="code-label"><?= htmlspecialchars($configGeral['voucher_instrucao'] ?? 'Use esse voucher no agendamento do site') ?></span>
            <div class="code"><?= htmlspecialchars($voucher['codigo']) ?></div>
        </div>
        <div class="footer">
            <div class="value-container">
                <span class="value-label">Valor</span>
                <div class="value">R$ <?= htmlspecialchars(number_format((float)$voucher['valor'], 2, ',', '.')) ?></div>
            </div>
            <div class="validity">
                <?php if (!empty($voucher['data_validade'])): ?>
                    Válido até: <?= htmlspecialchars(date('d/m/Y', strtotime($voucher['data_validade']))) ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>