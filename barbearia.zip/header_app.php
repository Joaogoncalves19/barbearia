<?php
// barbearia/header_app.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Garante que $configGeral esteja disponível
if (!isset($configGeral)) {
    // Tenta carregar se não estiver definido
    if (file_exists('functions.php')) {
        require_once 'functions.php';
        $configGeral = carregarConfigGeral();
    } elseif (file_exists('../functions.php')) {
        require_once '../functions.php';
        $configGeral = carregarConfigGeral();
    }
}

// Define o título padrão se não foi passado pela página
$pageTitle = isset($pageTitle) ? $pageTitle : ($configGeral['nome_barbearia'] ?? 'Barbearia');
?>
<style>
    /* Estilos do Header Fixo Moderno (Glassmorphism) */
    :root {
        --header-height: 110px; 
        --header-bg: rgba(255, 255, 255, 0.95); /* Fundo quase sólido */
        --header-shadow: 0 4px 20px rgba(0,0,0,0.05);
        --header-text: var(--primary-color, #333);
        --header-subtext: #6c757d; /* Cor cinza para o nome da barbearia */
        --header-icon: var(--secondary-color, #007bff);
    }

    body {
        /* Adiciona padding no topo para o conteúdo não ficar escondido atrás do header fixo */
        padding-top: calc(var(--header-height) + 20px) !important; 
    }

    .app-header {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: var(--header-height);
        background-color: var(--header-bg);
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        box-shadow: var(--header-shadow);
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0 15px;
        z-index: 10000; /* Garante que fique acima de tudo */
        transition: all 0.3s ease;
    }

    /* Layout Flex em 3 partes: Esquerda, Centro, Direita */
    .app-header-left, .app-header-right {
        flex: 1; /* Ocupa as laterais */
        display: flex;
        align-items: center;
    }
    
    .app-header-left {
        justify-content: flex-start;
    }
    
    .app-header-right {
        justify-content: flex-end;
        /* gap removido pois não teremos itens aqui */
    }

    .app-header-center {
        flex: 4; /* Ocupa o espaço central */
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: left;
    }

    /* Link do Logo */
    .logo-link {
        display: flex;
        align-items: center;
        margin-right: 15px; /* Espaço entre logo e texto */
        text-decoration: none;
        flex-shrink: 0;
        transition: opacity 0.2s;
        height: 90px;
    }
    .logo-link:hover {
        opacity: 0.8;
    }

    .header-logo {
        height: 90px; 
        width: 90px;
        object-fit: cover;
        border-radius: 50%;
        border: 3px solid rgba(0,0,0,0.05);
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        display: block;
    }

    /* Container para os textos ao lado do logo */
    .header-text-group {
        display: flex;
        flex-direction: column;
        justify-content: center;
        line-height: 1.2;
        overflow: hidden; 
        max-width: 100%;
    }

    .app-page-title {
        font-size: 1.2rem;
        font-weight: 800; 
        color: var(--header-text);
        margin: 0;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .app-barbershop-name {
        font-size: 0.85rem;
        color: var(--header-subtext);
        font-weight: 500;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        max-width: 100%;
    }

    /* Botão Voltar (Esquerda) */
    .btn-header {
        background: none;
        border: none;
        font-size: 1.5rem;
        color: var(--header-text);
        cursor: pointer;
        padding: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        transition: background 0.2s;
        text-decoration: none;
        width: 55px;
        height: 55px;
    }
    
    .btn-header:hover {
        background-color: rgba(0,0,0,0.05);
    }

    /* Ajuste responsivo para telas muito pequenas */
    @media (max-width: 380px) {
        .header-logo { height: 60px; width: 60px; } 
        .logo-link { height: 60px; margin-right: 10px; }
        :root { --header-height: 80px; }
        .app-page-title { font-size: 1rem; }
        .app-barbershop-name { font-size: 0.75rem; }
    }

    /* Correção para containers globais quando usados com header fixo */
    .container {
        margin-top: 0 !important;
    }
</style>

<header class="app-header">
    <div class="app-header-left">
        <?php if (isset($backLink) && $backLink): ?>
            <a href="<?= htmlspecialchars($backLink) ?>" class="btn-header" title="Voltar">
                <i class="fas fa-chevron-left"></i>
            </a>
        <?php else: ?>
            <button onclick="if(document.referrer.indexOf(window.location.hostname) !== -1) { history.back(); } else { window.location.href = 'index.php'; }" class="btn-header" title="Voltar">
                <i class="fas fa-chevron-left"></i>
            </button>
        <?php endif; ?>
    </div>

    <div class="app-header-center">
        <?php if (!empty($configGeral['logo_path']) && file_exists($configGeral['logo_path'])): ?>
            <a href="index.php" class="logo-link" title="Ir para o Início">
                <img src="<?= htmlspecialchars($configGeral['logo_path']) ?>" alt="Logo" class="header-logo">
            </a>
        <?php endif; ?>
        
        <div class="header-text-group">
            <h1 class="app-page-title"><?= htmlspecialchars($pageTitle) ?></h1>
            <span class="app-barbershop-name"><?= htmlspecialchars($configGeral['nome_barbearia']) ?></span>
        </div>
    </div>

    <div class="app-header-right">
        </div>
</header>