<?php
session_start();
date_default_timezone_set('America/Sao_Paulo');

if (!isset($_SESSION['barbeiro_loggedin'])) {
    header('Location: login.php');
    exit;
}

require_once 'functions.php';

$agendamento_id = $_GET['id'] ?? null;
if (!$agendamento_id) {
    header('Location: painel_barbeiro.php?error=agendamento_invalido');
    exit;
}

// --- CORREÇÃO: Definição completa das colunas para evitar perda de dados ---
$keys_agendamentos = [
    'id', 'nome', 'email', 'telefone', 'barbeiro_id', 'servicos_ids', 
    'data', 'hora', 'status', 'desconto_aplicado', 'tipo_desconto', 
    'observacoes', 'produtos_vendidos', 'plano_provisorio'
];
$agendamentosArr = lerDados('agendamentos.txt', $keys_agendamentos);
// --- FIM DA CORREÇÃO ---

$agendamento_atual = $agendamentosArr[$agendamento_id] ?? null;
$barbeiro_id_logado = $_SESSION['barbeiro_id'];

if (!$agendamento_atual || $agendamento_atual['barbeiro_id'] !== $barbeiro_id_logado) {
    header('Location: painel_barbeiro.php?error=permissao_negada');
    exit;
}

$servicosArr = lerDados('servicos.txt', ['id', 'nome', 'valor']);
$combosArr = lerDados('combos.txt', ['id', 'nome']);
$barbeirosArr = lerDados('barbeiros.txt', ['id', 'nome', 'foto']);

$servicos_agendamento_nomes = [];
$ids = explode(',', $agendamento_atual['servicos_ids']);
foreach ($ids as $sid) {
    $sid = trim($sid);
    if(isset($servicosArr[$sid])) $servicos_agendamento_nomes[] = $servicosArr[$sid]['nome'];
    elseif(isset($combosArr[$sid])) $servicos_agendamento_nomes[] = $combosArr[$sid]['nome'] . " (Combo)";
    else $servicos_agendamento_nomes[] = '?';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nova_data = $_POST['reagendar_data'];
    $novo_horario = $_POST['reagendar_horario'];

    $agendamento_original = $agendamentosArr[$agendamento_id];
    $agendamentosArr[$agendamento_id]['status'] = 'cancelado';
    
    $novo_agendamento_id = uniqid('ag-');
    $novo_agendamento = $agendamento_original;
    $novo_agendamento['id'] = $novo_agendamento_id;
    $novo_agendamento['data'] = $nova_data;
    $novo_agendamento['hora'] = $novo_horario;
    $novo_agendamento['status'] = 'aprovado';
    
    $agendamentosArr[$novo_agendamento_id] = $novo_agendamento;

    salvarDados('agendamentos.txt', $agendamentosArr, $keys_agendamentos);

    $configAgendamentoEmail = carregarConfigAgendamento();
    if (filter_var($novo_agendamento['email'], FILTER_VALIDATE_EMAIL) && ($configAgendamentoEmail['notif_aprovacao'] ?? 0) == 1) {
        $dados_email = [
            'nome_cliente' => $novo_agendamento['nome'],
            'data_agendamento' => date('d/m/Y', strtotime($nova_data)),
            'hora_agendamento' => $novo_horario,
            'servicos' => $servicos_agendamento_nomes,
            'barbeiro' => $barbeirosArr[$novo_agendamento['barbeiro_id']]['nome'] ?? 'Não especificado',
            'tipo_desconto' => $novo_agendamento['tipo_desconto'] ?? '' // <--- CORREÇÃO APLICADA
        ];
        enviarEmail($novo_agendamento['email'], 'Seu Agendamento foi Reagendado!', 'aprovado', $dados_email);
    }
    
    $cliente = getClientePorEmailTelefoneOuCPF($agendamento_original['email']);
    if ($cliente) {
        criarNotificacao($cliente['id'], "Seu agendamento foi REAGENDADO para ".date('d/m/Y', strtotime($nova_data))." às ".$novo_horario.".");
    }
    
    $_SESSION['agendamento_sucesso'] = "Agendamento de ".htmlspecialchars($agendamento_original['nome'])." reagendado com sucesso!";
    header('Location: painel_barbeiro.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Reagendar Horário</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/custom_theme.css.php">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <style>
        body { background-color: #f4f4f9; }
        .container { max-width: 100%; padding: 15px; margin: 0; box-shadow: none; border-radius: 0; }
        .header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; }
        .header h2 { font-size: 1.2rem; margin: 0; }
        .info-card { background: #fff; border: 1px solid #e0e0e0; border-radius: 10px; padding: 15px; margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
        .info-card p { margin: 5px 0; font-size: 0.95rem; color: #555; }
        .info-card strong { color: #333; }
        
        .alert-vip { color: #856404; background-color: #fff3cd; border-color: #ffeeba; padding: 10px; border-radius: 5px; margin-bottom: 10px; font-size: 0.9em; border: 1px solid #ffeeba; }

        .flatpickr-mobile { width: 100%; padding: 12px; border: 1px solid #ccc; border-radius: 8px; font-size: 1rem; -webkit-appearance: none; background: #fff; }
        
        .horario-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-top: 10px; }
        .horario-grid button { padding: 10px; font-size: 0.9rem; border-radius: 6px; border: 1px solid #ddd; background: #fff; color: #333; }
        .horario-grid button.disponivel { background: #fff; border-color: var(--secondary-color); color: var(--secondary-color); }
        .horario-grid button.selecionado { background: var(--secondary-color); color: #fff; border-color: var(--secondary-color); }
        
        .btn-voltar { background: transparent; color: #333; border: 1px solid #ccc; padding: 8px 12px; border-radius: 6px; text-decoration: none; font-size: 0.9rem; }
    </style>
</head>
<body class="admin-page">
    <div class="container">
        <div class="header">
            <h2>Reagendar</h2>
            <a href="painel_barbeiro.php" class="btn-voltar"><i class="fa fa-arrow-left"></i> Voltar</a>
        </div>

        <div class="info-card">
            <p><strong>Cliente:</strong> <?= htmlspecialchars($agendamento_atual['nome']) ?></p>
            <p><strong>Atual:</strong> <?= htmlspecialchars(date('d/m/Y', strtotime($agendamento_atual['data']))) ?> às <?= htmlspecialchars($agendamento_atual['hora']) ?></p>
            <p><strong>Serviços:</strong> <?= htmlspecialchars(implode(', ', $servicos_agendamento_nomes)) ?></p>
            
            <?php if (($agendamento_atual['tipo_desconto'] ?? '') === 'adesao_plano'): ?>
                <div class="alert-vip" style="margin-top: 10px;">
                    <i class="fa fa-crown"></i> <strong>Atenção:</strong> Contém Adesão VIP. O status de adesão será mantido.
                </div>
            <?php endif; ?>
        </div>

        <form id="form-reagendamento" method="POST">
            <div class="form-group">
                <label for="reagendar_data_mobile">Nova Data</label>
                <input type="text" id="reagendar_data_mobile" class="flatpickr-mobile" placeholder="Toque para selecionar a data" required>
                <input type="hidden" name="reagendar_data" id="reagendar_data">
            </div>
            
            <div class="form-group">
                <label>Novo Horário</label>
                <div class="horario-grid" id="reagendar_horarios-container">Selecione uma data acima.</div>
                <input type="hidden" name="reagendar_horario" id="reagendar_horario" required>
                <div id="reagendar_erro_horario" class="erro"></div>
            </div>
            
            <button type="submit" class="btn-primary" style="width:100%; margin-top: 20px; padding: 15px; font-size: 1rem;">Confirmar Reagendamento</button>
        </form>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://npmcdn.com/flatpickr/dist/l10n/pt.js"></script>
    <script>
        const barbeiroId = '<?= htmlspecialchars($barbeiro_id_logado) ?>';
        const servicosIds = '<?= htmlspecialchars($agendamento_atual['servicos_ids']) ?>';
        
        document.addEventListener('DOMContentLoaded', function() {
            const dataInput = document.getElementById('reagendar_data_mobile');
            const dataHidden = document.getElementById('reagendar_data');
            const horarioHidden = document.getElementById('reagendar_horario');
            const containerHorarios = document.getElementById('reagendar_horarios-container');
            const erroHorario = document.getElementById('reagendar_erro_horario');

            flatpickr(dataInput, {
                locale: "pt",
                minDate: "today",
                dateFormat: "Y-m-d",
                altInput: true,
                altFormat: "j \\d\\e F, Y",
                disableMobile: "true",
                onChange: function(selectedDates, dateStr, instance) {
                    dataHidden.value = dateStr;
                    buscarHorarios(dateStr);
                }
            });

            async function buscarHorarios(data) {
                containerHorarios.innerHTML = '<p style="grid-column: 1/-1; text-align: center; color: #666;">Carregando...</p>';
                horarioHidden.value = '';
                erroHorario.textContent = '';

                try {
                    const url = `get_horarios.php?barbeiro_id=${barbeiroId}&data=${data}&itens_selecionados=${servicosIds}`;
                    const response = await fetch(url);
                    const horarios = await response.json();

                    containerHorarios.innerHTML = '';

                    if (horarios.error || horarios.length === 0) {
                        containerHorarios.innerHTML = '<p style="grid-column: 1/-1; text-align: center; color: #dc3545;">Sem horários livres.</p>';
                        return;
                    }

                    horarios.forEach(h => {
                        const btn = document.createElement('button');
                        btn.type = 'button';
                        btn.className = 'disponivel';
                        btn.textContent = h;
                        
                        btn.addEventListener('click', function() {
                            const selecionadoPrev = containerHorarios.querySelector('.selecionado');
                            if (selecionadoPrev) selecionadoPrev.classList.remove('selecionado');
                            
                            this.classList.add('selecionado');
                            horarioHidden.value = h;
                        });
                        
                        containerHorarios.appendChild(btn);
                    });

                } catch (e) {
                    containerHorarios.innerHTML = '<p style="grid-column: 1/-1; text-align: center; color: red;">Erro ao carregar.</p>';
                }
            }
            
            document.getElementById('form-reagendamento').addEventListener('submit', function(e) {
                if(!horarioHidden.value) {
                    e.preventDefault();
                    erroHorario.textContent = "Por favor, selecione um horário.";
                }
            });
        });
    </script>
</body>
</html>