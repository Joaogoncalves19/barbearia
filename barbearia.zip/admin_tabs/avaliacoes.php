<?php
// admin_tabs/avaliacoes.php
// Contém o HTML da aba "Avaliações".
// Variáveis como $media_geral_avaliacoes, $distribuicao_notas, $avaliacoesPaginadas, etc. vêm do admin_data.php
// $agendamentosPendentesDeAvaliacao (NOVO) também vem do admin_data.php
// $avaliacoesDestacadasArr e $respostasAvaliacoesArr (NOVOS) também vêm do admin_data.php

// --- INÍCIO: Novos Cálculos para o Card de Sentimento ---
$totalSentimentos = $sentimentoGeral['positivo_count'] + $sentimentoGeral['neutro_count'] + $sentimentoGeral['negativo_count'];
$percentualPositivo = ($totalSentimentos > 0) ? round(($sentimentoGeral['positivo_count'] / $totalSentimentos) * 100) : 0;
// --- FIM: Novos Cálculos ---
?>

<h3>Painel de Avaliações</h3>
<?php if(isset($_GET['success_av'])): ?><p class="mensagem">Ação concluída com sucesso! <?= isset($_GET['total']) ? htmlspecialchars($_GET['total']) : '' ?></p><?php endif; ?>

<div class="config-section">
    <h4><i class="fa fa-star-half-alt"></i> Lembrete de Avaliação (Manual)</h4>
    <p style="font-size: 0.9em; color: #666;">Envie um e-mail para clientes que concluíram um serviço mas ainda não deixaram uma avaliação.</p>
    
    <?php
    // $agendamentosPendentesDeAvaliacao é calculado em admin_data.php
    $totalPendentes = count($agendamentosPendentesDeAvaliacao);
    ?>

    <?php if ($totalPendentes > 0): ?>
        <form method="POST" class="admin-form" action="admin.php" onsubmit="return confirm('Tem certeza que deseja enviar um lembrete de avaliação para <?= $totalPendentes ?> cliente(s)?');">
            <input type="hidden" name="action" value="enviar_lembretes_avaliacao">
            <p>Foram encontrados <strong><?= $totalPendentes ?></strong> agendamento(s) concluído(s) e sem avaliação.</p>
            
            <button type="submit" class="btn-primary" style="width: auto; padding: 12px 20px;">
                <i class="fa fa-paper-plane"></i> Enviar <?= $totalPendentes ?> Lembrete(s) Agora
            </button>
        </form>
    <?php else: ?>
        <p class="mensagem" style="background-color: #d4edda; border-color: #c3e6cb; text-align: left;">
            <i class="fa fa-check-circle"></i> Ótimo! Nenhum agendamento concluído está pendente de avaliação.
        </p>
    <?php endif; ?>
</div>

<div class="dashboard">
    <div class="dash-card">
        <div class="dash-card-icon"><i class="fa fa-star"></i></div>
        <div class="dash-card-content">
            <h4>Média Geral</h4>
            <div class="value"><?= $media_geral_avaliacoes ?> / 5</div>
        </div>
    </div>
    <div class="dash-card">
        <div class="dash-card-icon"><i class="fa fa-comments"></i></div>
        <div class="dash-card-content">
            <h4>Total de Avaliações</h4>
            <div class="value"><?= count($avaliacoesArr) ?></div>
        </div>
    </div>
    <div class="dash-card">
        <div class="dash-card-icon" style="color: var(--success-color); background-color: #d4edda;"><i class="fa fa-thumbs-up"></i></div>
        <div class="dash-card-content">
            <h4>Sentimento Positivo</h4>
            <div class="value"><?= $percentualPositivo ?>%</div>
        </div>
    </div>
</div>
<div class="relatorios-grid" style="margin-top: 30px; grid-template-columns: 1fr 1fr;">
    <div class="chart-container" style="height: 300px;"><canvas id="sentimentoGeralChart"></canvas></div>
    <div class="chart-container" style="height: 300px;"><canvas id="mediaPorBarbeiroChart"></canvas></div>
</div>
<h3 style="margin-top: 30px;">Últimas Avaliações Recebidas</h3>
<form method="GET" class="dashboard-filter" style="margin-bottom: 20px;">
    <input type="hidden" name="tab" value="avaliacoes">
    <select name="filtro_barbeiro_av" onchange="this.form.submit()">
        <option value="">Filtrar por Barbeiro</option>
        <?php foreach($barbeirosArr as $id => $b): ?>
        <option value="<?= $id ?>" <?= $filtro_barbeiro_av == $id ? 'selected' : '' ?>><?= htmlspecialchars($b['nome']) ?></option>
        <?php endforeach; ?>
    </select>
    <select name="filtro_nota_av" onchange="this.form.submit()">
        <option value="">Filtrar por Nota</option>
        <?php for($i=5; $i>=1; $i--): ?>
        <option value="<?= $i ?>" <?= $filtro_nota_av == $i ? 'selected' : '' ?>><?= $i ?> Estrela(s)</option>
        <?php endfor; ?>
    </select>
    <a href="?tab=avaliacoes" class="btn" style="background: #6c757d;">Limpar</a>
</form>

<?php if (empty($avaliacoesPaginados)): ?>
    <p style="text-align:center; padding: 20px; background: #f9f9f9; border-radius: 8px;">Nenhuma avaliação encontrada para os filtros selecionados.</p>
<?php else: ?>
    <?php 
    // Loop principal para exibir os cards de avaliação
    foreach ($avaliacoesPaginados as $av_id => $av): 
        $cliente = $clientesArr[$av['cliente_id']] ?? null; 
        $foto_cliente = ($cliente && !empty($cliente['foto_perfil']) && file_exists($cliente['foto_perfil'])) ? $cliente['foto_perfil'] : 'uploads/default-profile.jpg';
        
        // --- INÍCIO: NOVOS DADOS PARA O CARD ---
        $agendamento_original = $agendamentosArr[$av['agendamento_id']] ?? null;
        $servicosNomes = [];
        if ($agendamento_original) {
            
            // --- CORREÇÃO APLICADA: Verifica Serviços E Combos ---
            // Adicionado $combosArr ao escopo do 'use'
            $servicosNomes = array_map(function($sid) use ($servicosArr, $combosArr) {
                $sid = trim($sid);
                // Verifica se é um Serviço Individual
                if (isset($servicosArr[$sid])) {
                    return $servicosArr[$sid]['nome'];
                } 
                // Verifica se é um Combo
                elseif (isset($combosArr[$sid])) {
                    return $combosArr[$sid]['nome'] . ' (Combo)';
                }
                // Se não encontrar nenhum
                return '?';
            }, explode(',', $agendamento_original['servicos_ids']));
            // --- FIM DA CORREÇÃO ---

        }
        
        $is_destacada = isset($avaliacoesDestacadasArr[$av_id]);
        $resposta = $respostasAvaliacoesArr[$av_id] ?? null;
        // --- FIM: NOVOS DADOS PARA O CARD ---
    ?>
    <div class="avaliacao-card-admin <?= $is_destacada ? 'avaliacao-destacada' : '' ?>">
        <div class="avaliacao-header">
            <div class="avaliacao-cliente-info">
                <img src="<?= htmlspecialchars($foto_cliente) ?>" alt="Foto Cliente">
                <div>
                    <a href="#" class="nome-cliente" data-modal-target="#modal-cliente-detalhes" data-id="<?= htmlspecialchars($av['cliente_id']) ?>"><?= htmlspecialchars($cliente['nome'] ?? 'Cliente não encontrado') ?></a>
                    <small style="display: block; color: #666;">avaliou <?= htmlspecialchars($barbeirosArr[$av['barbeiro_id']]['nome'] ?? 'N/A') ?></small>
                </div>
            </div>
            <div class="avaliacao-rating"><?= str_repeat('★', (int)$av['rating']) . str_repeat('☆', 5 - (int)$av['rating']) ?></div>
        </div>
        
        <?php if (!empty($servicosNomes)): ?>
            <div class="avaliacao-servicos-contexto">
                <strong>Serviços Avaliados:</strong> <?= htmlspecialchars(implode(', ', $servicosNomes)) ?>
            </div>
        <?php endif; ?>
        <?php if(!empty($av['comment'])): ?>
            <p class="avaliacao-comment">"<?= htmlspecialchars($av['comment']) ?>"</p>
        <?php endif; ?>
        
        <?php if($resposta): ?>
            <div class="avaliacao-resposta-admin">
                <strong><i class="fa fa-check-circle"></i> Resposta da Barbearia:</strong>
                <p>"<?= htmlspecialchars($resposta['texto_resposta']) ?>"</p>
                <small>Respondido em <?= date('d/m/Y', strtotime($resposta['timestamp'])) ?></small>
            </div>
        <?php endif; ?>
        <div class="avaliacao-footer-actions">
            <div class="btn-group">
                <a href="?action=toggle_destaque_avaliacao&id=<?= $av_id ?>&tab=avaliacoes" 
                   class="btn <?= $is_destacada ? 'btn-editar' : 'btn-info' ?>" 
                   style="<?= $is_destacada ? 'background-color: var(--warning-color); color: #212529;' : 'background-color: #17a2b8;' ?>">
                   <i class="fa <?= $is_destacada ? 'fa-star-slash' : 'fa-star' ?>"></i> <?= $is_destacada ? 'Remover Destaque' : 'Destacar no Site' ?>
                </a>
                
                <button class="btn btn-aprovar" 
                        data-modal-target="#modal-responder-avaliacao" 
                        data-id_avaliacao="<?= $av_id ?>" 
                        data-resposta_existente="<?= htmlspecialchars($resposta['texto_resposta'] ?? '') ?>">
                    <i class="fa fa-comment-dots"></i> <?= $resposta ? 'Editar Resposta' : 'Responder' ?>
                </button>
                
                <?php if ($agendamento_original): ?>
                <button class="btn" 
                        style="background-color: var(--primary-color);" 
                        data-modal-target="#modal-ver-agendamento" 
                        data-agendamento-id="<?= $av['agendamento_id'] ?>">
                    <i class="fa fa-receipt"></i> Ver Agendamento
                </button>
                <?php endif; ?>
                
                <a href="?action=excluir_avaliacao&id=<?= $av_id ?>&tab=avaliacoes" 
                   class="btn btn-excluir" 
                   onclick="return confirm('Tem certeza que deseja excluir esta avaliação?')">
                   <i class="fa fa-trash"></i> Excluir
                </a>
            </div>
            <span class="avaliacao-data"><?= htmlspecialchars(date('d/m/Y H:i', strtotime($av['timestamp']))) ?></span>
        </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<div class="pagination"><?php for ($i = 1; $i <= $avaliacoes_totalPages; $i++): ?><a href="?tab=avaliacoes&av_page=<?= $i ?>&filtro_barbeiro_av=<?= urlencode($filtro_barbeiro_av) ?>&filtro_nota_av=<?= urlencode($filtro_nota_av) ?>" class="<?= ($i == $avaliacoes_currentPage ? 'current' : '') ?>"><?= $i ?></a><?php endfor; ?></div>