<?php
// admin_tabs/servicos.php
// Contém o HTML da aba "Serviços", incluindo as sub-abas de Serviços Individuais, Combos, Categorias e PLANOS.
// Variáveis como $servicosArr, $combosArr, $categoriasArr e $planosArr vêm do admin_data.php
?>

<div class="sub-tab">
    <button class="sub-tab-btn active" data-subtab="servicos-individuais">Serviços Individuais</button>
    <button class="sub-tab-btn" data-subtab="combos">Combos</button>
    <button class="sub-tab-btn" data-subtab="categorias">Categorias</button>
    <button class="sub-tab-btn" data-subtab="planos">Planos de Assinatura</button> </div>

<div id="servicos-individuais" class="sub-tabcontent active">
    <h3>Gerenciar Serviços Individuais</h3>
    <button class="btn btn-add" data-modal-target="#modal-servico"><i class="fa fa-plus"></i> Adicionar Serviço</button>
    <table>
        <thead>
            <tr>
                <th>Nome</th>
                <th>Valor</th>
                <th>Duração</th>
                <th>Categoria</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($servicosArr as $s): ?>
            <tr>
                <td data-label="Nome"><?= htmlspecialchars($s['nome']) ?></td>
                <td data-label="Valor">R$<?= htmlspecialchars(number_format((float)$s['valor'], 2, ',', '.')) ?></td>
                <td data-label="Duração">
                    <?php 
                        $slots = (int)($s['slots'] ?? 1);
                        if ($slots <= 0) $slots = 1;
                        echo $slots . ' slot' . ($slots > 1 ? 's' : '') . ' (' . ($slots * 30) . ' min)';
                    ?>
                </td>
                <td data-label="Categoria">
                    <?= htmlspecialchars($categoriasArr[$s['categoria_id']]['nome'] ?? 'Sem Categoria') ?>
                </td>
                <td data-label="Ações">
                    <div class="btn-group">
                        <button class="btn btn-editar" data-modal-target="#modal-servico" data-id="<?= $s['id'] ?>" data-type="servico"><i class="fa fa-edit"></i> Editar</button>
                        <a href="?action=excluir_servico&id=<?= $s['id'] ?>" class="btn btn-excluir" onclick="return confirm('Excluir serviço?')"><i class="fa fa-trash"></i> Excluir</a>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div id="combos" class="sub-tabcontent">
    <h3>Gerenciar Combos Promocionais</h3>
    <button class="btn btn-add" data-modal-target="#modal-combo"><i class="fa fa-plus"></i> Criar Novo Combo</button>
    <table>
        <thead>
            <tr>
                <th>Nome do Combo</th>
                <th>Serviços Incluídos</th>
                <th>Valor do Combo</th>
                <th>Categoria</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
        <?php if(empty($combosArr)): ?>
            <tr><td colspan="5" style="text-align:center;">Nenhum combo criado.</td></tr>
        <?php else: ?>
            <?php foreach ($combosArr as $c): ?>
            <tr>
                <td data-label="Nome"><?= htmlspecialchars($c['nome']) ?></td>
                <td data-label="Serviços">
                    <ul class="combo-servicos-lista">
                        <?php 
                        $servicosDoCombo = getServicesFromCombo($c, $servicosArr); 
                        foreach($servicosDoCombo as $serv) { 
                            echo '<li>' . htmlspecialchars($serv['nome']) . '</li>'; 
                        } 
                        ?>
                    </ul>
                </td>
                <td data-label="Valor">R$<?= htmlspecialchars(number_format((float)$c['valor'], 2, ',', '.')) ?></td>
                <td data-label="Categoria">
                    <?= htmlspecialchars($categoriasArr[$c['categoria_id']]['nome'] ?? 'Sem Categoria') ?>
                </td>
                <td data-label="Ações">
                    <div class="btn-group">
                        <button class="btn btn-editar" data-modal-target="#modal-combo" data-id="<?= $c['id'] ?>" data-type="combo"><i class="fa fa-edit"></i> Editar</button>
                        <a href="?action=excluir_combo&id=<?= $c['id'] ?>" class="btn btn-excluir" onclick="return confirm('Excluir combo?')"><i class="fa fa-trash"></i> Excluir</a>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<div id="categorias" class="sub-tabcontent">
    <h3>Gerenciar Categorias de Serviços</h3>
    <p style="font-size: 0.9em; color: #666;">Use categorias para organizar seus serviços e combos na página de agendamento. Use o campo "Ordem" para definir a sequência (menores primeiro).</p>
    <button class="btn btn-add" data-modal-target="#modal-categoria"><i class="fa fa-plus"></i> Adicionar Nova Categoria</button>
    <table>
        <thead>
            <tr>
                <th>Nome da Categoria</th>
                <th>Ordem</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            // Ordena as categorias pela 'ordem' antes de exibir
            $categoriasOrdenadas = $categoriasArr;
            uasort($categoriasOrdenadas, fn($a, $b) => (int)($a['ordem'] ?? 99) <=> (int)($b['ordem'] ?? 99));
            
            if(empty($categoriasOrdenadas)): 
            ?>
                <tr><td colspan="3" style="text-align:center;">Nenhuma categoria criada.</td></tr>
            <?php else: ?>
                <?php foreach($categoriasOrdenadas as $cat): ?>
                <tr>
                    <td data-label="Nome"><?= htmlspecialchars($cat['nome']) ?></td>
                    <td data-label="Ordem"><?= htmlspecialchars($cat['ordem'] ?? '10') ?></td>
                    <td data-label="Ações">
                        <div class="btn-group">
                            <button class="btn btn-editar" data-modal-target="#modal-categoria" data-id="<?= $cat['id'] ?>" data-type="categoria"><i class="fa fa-edit"></i> Editar</button>
                            <a href="?action=excluir_categoria&id=<?= $cat['id'] ?>&tab=servicos&subtab=categorias" class="btn btn-excluir" onclick="return confirm('Atenção: Excluir esta categoria irá desassociá-la de todos os serviços e combos. Deseja continuar?')"><i class="fa fa-trash"></i> Excluir</a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div id="planos" class="sub-tabcontent">
    <h3>Planos de Assinatura (Recorrência)</h3>
    <p style="font-size:0.9em; color:#666;">Crie planos onde o cliente paga um valor mensal fixo e tem acesso ilimitado aos serviços selecionados.</p>
    
    <button class="btn btn-add" data-modal-target="#modal-plano" data-type="novo_plano"><i class="fa fa-plus"></i> Criar Novo Plano</button>
    
    <table>
        <thead>
            <tr>
                <th>Nome do Plano</th>
                <th>Serviços Inclusos</th>
                <th>Valor Mensal</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
        <?php if(empty($planosArr)): ?>
            <tr><td colspan="4" style="text-align:center;">Nenhum plano criado.</td></tr>
        <?php else: ?>
            <?php foreach ($planosArr as $p): ?>
            <tr>
                <td><strong><?= htmlspecialchars($p['nome']) ?></strong></td>
                <td>
                    <?php 
                    $nomesServicos = [];
                    $ids = explode(',', $p['servicos_ids']);
                    foreach($ids as $sid) {
                        if(isset($servicosArr[trim($sid)])) $nomesServicos[] = $servicosArr[trim($sid)]['nome'];
                    }
                    echo implode(', ', $nomesServicos);
                    ?>
                </td>
                <td>R$ <?= number_format((float)$p['valor'], 2, ',', '.') ?></td>
                <td>
                    <div class="btn-group">
                        <button class="btn btn-editar" 
                                data-modal-target="#modal-plano" 
                                data-id="<?= $p['id'] ?>" 
                                data-type="plano"
                                data-nome="<?= htmlspecialchars($p['nome']) ?>"
                                data-valor="<?= htmlspecialchars($p['valor']) ?>"
                                data-servicos="<?= htmlspecialchars($p['servicos_ids']) ?>">
                            <i class="fa fa-edit"></i> Editar
                        </button>

                        <a href="?action=excluir_plano&id=<?= $p['id'] ?>&tab=servicos&subtab=planos" class="btn btn-excluir" onclick="return confirm('Excluir este plano? Assinaturas ativas não serão canceladas, mas o plano sumirá do agendamento.')"><i class="fa fa-trash"></i> Excluir</a>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<div id="modal-plano" class="modal-overlay">
    <div class="modal-content">
        <button class="modal-close">&times;</button>
        <h3>Novo Plano de Assinatura</h3>
        <form method="post" action="admin.php">
            <input type="hidden" name="action" value="salvar_plano">
            <input type="hidden" name="id" value="">
            
            <div class="form-group">
                <label>Nome do Plano (ex: Vip Mensal)</label>
                <input type="text" name="nome" required placeholder="Nome que aparecerá no agendamento">
            </div>
            <div class="form-group">
                <label>Valor Mensal (R$)</label>
                <input type="number" name="valor" step="0.01" required placeholder="0.00">
            </div>
            <div class="form-group">
                <label>Serviços Inclusos (Ilimitados)</label>
                <p style="font-size:0.85em; color:#666; margin-bottom:10px;">Selecione os serviços que o cliente poderá fazer sem custo adicional.</p>
                <div style="max-height: 200px; overflow-y: auto; border: 1px solid var(--border-color); padding: 15px; border-radius: 8px; background: #f8f9fa;">
                    <?php foreach ($servicosArr as $s): ?>
                        <div style="margin-bottom: 8px; display: flex; align-items: center;">
                            <input type="checkbox" name="plano_servicos_ids[]" value="<?= $s['id'] ?>" id="plano_sv_<?= $s['id'] ?>" style="width: auto; margin-right: 10px;">
                            <label for="plano_sv_<?= $s['id'] ?>" style="margin:0; cursor:pointer;"><?= htmlspecialchars($s['nome']) ?> (R$ <?= $s['valor'] ?>)</label>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <button type="submit" class="btn-primary">Salvar Plano</button>
        </form>
    </div>
</div>