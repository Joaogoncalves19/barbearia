<?php
// admin_tabs/dashboard.php
// Este arquivo contém apenas o HTML e a lógica de exibição da aba Dashboard.
// Todas as variáveis (ex: $receitaTotal, $rankingServicosIds) são fornecidas pelo admin_data.php
?>

<div class="dashboard-filter-header">
    <h3>Visão Geral do Período</h3>
    <div class="dashboard-filter">
        <form method="GET" class="dashboard-filter">
            <input type="hidden" name="tab" value="dashboard">
            <input type="date" name="data_inicio" value="<?= htmlspecialchars($data_inicio_filtro) ?>">
            <input type="date" name="data_fim" value="<?= htmlspecialchars($data_fim_filtro) ?>">
            <button type="submit" class="btn-filtrar">Filtrar</button>
        </form>
    </div>
</div>
<p class="dashboard-periodo">Exibindo dados de: <strong><?= htmlspecialchars(date('d/m/Y', strtotime($data_inicio_filtro))) ?></strong> a <strong><?= htmlspecialchars(date('d/m/Y', strtotime($data_fim_filtro))) ?></strong></p>

<div class="dashboard" id="dashboard-grid">
    <div class="dash-card">
        <div class="dash-card-icon"><i class="fa fa-dollar-sign"></i></div>
        <div class="dash-card-content">
            <h4>Receita Bruta</h4>
            <div class="value">R$<?= htmlspecialchars(number_format($receitaTotal, 2, ',', '.')) ?></div>
            <?php if ($receitaPlanos > 0): ?>
                <div class="sub-value" style="color: #6c757d; font-weight: normal; font-size: 0.85em;">
                    (Planos: R$ <?= number_format($receitaPlanos, 2, ',', '.') ?>)
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="dash-card">
        <div class="dash-card-icon"><i class="fa fa-tags"></i></div>
        <div class="dash-card-content">
            <h4>Total em Descontos</h4>
            <div class="value">R$<?= htmlspecialchars(number_format($totalDescontos, 2, ',', '.')) ?></div>
            
            <?php if ($economiaVIP > 0 || $totalDescontosMkt > 0): ?>
                <div class="sub-value" style="color: #6c757d; font-weight: normal; font-size: 0.85em; line-height: 1.4;">
                    <?php if ($economiaVIP > 0): ?>
                        <span style="color: #28a745;">VIP: R$ <?= number_format($economiaVIP, 2, ',', '.') ?></span>
                    <?php endif; ?>
                    
                    <?php if ($economiaVIP > 0 && $totalDescontosMkt > 0): ?> | <?php endif; ?>
                    
                    <?php if ($totalDescontosMkt > 0): ?>
                        <span style="color: #e0a800;">Mkt: R$ <?= number_format($totalDescontosMkt, 2, ',', '.') ?></span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="dash-card">
        <div class="dash-card-icon" style="color: #6f42c1; background-color: #f3e5f5;"><i class="fa fa-crown"></i></div>
        <div class="dash-card-content">
            <h4>Assinantes Ativos</h4>
            <div class="value"><?= $totalAssinantesAtivos ?></div>
            <div class="sub-value" style="color: #6c757d; font-weight: normal; font-size: 0.85em;">
                Clientes VIP
            </div>
        </div>
    </div>

    <div class="dash-card">
        <div class="dash-card-icon"><i class="fa fa-receipt"></i></div>
        <div class="dash-card-content">
            <h4>Ticket Médio</h4>
            <div class="value">R$<?= htmlspecialchars(number_format($ticketMedio, 2, ',', '.')) ?></div>
        </div>
    </div>

    <div class="dash-card">
        <div class="dash-card-icon"><i class="fa fa-box"></i></div>
        <div class="dash-card-content">
            <h4>Venda de Produtos</h4>
            <div class="value">R$<?= htmlspecialchars(number_format($totalProdutos, 2, ',', '.')) ?></div>
        </div>
    </div>

    <div class="dash-card">
        <div class="dash-card-icon" style="color: var(--success-color); background-color: #d4edda;"><i class="fa fa-calendar-check"></i></div>
        <div class="dash-card-content">
            <h4>Concluídos</h4>
            <div class="value"><?= $contagemStatus['concluido'] ?></div>
        </div>
    </div>
    <div class="dash-card">
        <div class="dash-card-icon" style="color: var(--error-color); background-color: #f8d7da;"><i class="fa fa-calendar-times"></i></div>
        <div class="dash-card-content">
            <h4>Cancelados</h4>
            <div class="value"><?= $contagemStatus['cancelado'] ?></div>
        </div>
    </div>
     <div class="dash-card">
        <div class="dash-card-icon" style="color: var(--warning-color); background-color: #fff3cd;"><i class="fa fa-clock"></i></div>
        <div class="dash-card-content">
            <h4>Pendentes</h4>
            <div class="value"><?= $contagemStatus['pendente'] ?></div>
        </div>
    </div>
    <div class="dash-card">
        <div class="dash-card-icon"><i class="fa fa-chart-pie"></i></div>
        <div class="dash-card-content">
            <h4>Taxa de Ocupação</h4>
            <div class="value"><?= htmlspecialchars($taxaOcupacaoMedia) ?>%</div>
        </div>
    </div>

    <div class="dash-card dash-card-list chart-container-dashboard">
        <h4><i class="fa fa-users"></i> Novos Clientes vs. Recorrentes</h4>
        <div class="chart-container" style="height: 250px;"><canvas id="novosRecorrentesChart"></canvas></div>
    </div>
    
    <div class="dash-card dash-card-list">
        <h4><i class="fa fa-trophy"></i> Top Barbeiro (Receita)</h4>
        <div class="dash-card-content" style="text-align: center; margin-top: 20px;">
            <div class="value"><?= htmlspecialchars($melhorBarbeiro['nome']) ?></div>
            <div class="sub-value">R$ <?= number_format($melhorBarbeiro['valor'], 2, ',', '.') ?></div>
        </div>
         <h4 style="margin-top: 25px;"><i class="fa fa-star"></i> Média de Avaliações</h4>
         <div class="dash-card-content" style="text-align: center; margin-top: 20px;">
             <div class="value"><?= $mediaAvaliacoes ?> / 5</div>
             <div class="sub-value" style="color: #6c757d; font-size: 0.9em;"><?= $totalAvaliacoes ?> avaliações</div>
         </div>
    </div>

    <div class="dash-card dash-card-list">
        <h4><i class="fa fa-fire"></i> Top 5 Serviços</h4>
        <ul class="ranking-lista">
            <?php if(empty($rankingServicosIds)): ?>
                <li>Nenhum serviço para exibir.</li>
            <?php else: ?>
                <?php foreach($rankingServicosIds as $sid => $count): ?>
                <li>
                    <span><?= htmlspecialchars($servicosArr[$sid]['nome']) ?></span> 
                    <strong><?= $count ?></strong>
                </li>
                <?php endforeach; ?>
            <?php endif; ?>
        </ul>
    </div>

    <div class="dash-card dash-card-list aniversariantes">
        <h4><i class="fa fa-birthday-cake"></i> Aniversariantes do Mês</h4>
        <?php if(empty($aniversariantesDoMes)): ?>
            <p>Nenhum aniversariante este mês.</p>
        <?php else: ?>
            <ul class="aniversariantes-lista">
                <?php foreach($aniversariantesDoMes as $cli): ?>
                <li>
                    <div class="aniversariante-info">
                        <span class="aniversariante-nome"><i class="fa fa-gift" style="color: var(--primary-color); margin-right: 8px;"></i> <?= htmlspecialchars(date('d/m', strtotime($cli['data_nascimento']))) ?> - <?= htmlspecialchars($cli['nome']) ?></span>
                        <div class="aniversariante-contato">
                            <span><i class="fa fa-envelope"></i> <?= htmlspecialchars($cli['email']) ?></span>
                            <span><i class="fa fa-phone"></i> <?= htmlspecialchars($cli['telefone']) ?></span>
                        </div>
                    </div>
                </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
</div>