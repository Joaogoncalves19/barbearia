<?php
// admin_tabs/agendamentos.php

// --- CORREÇÃO: Captura variáveis GET explicitamente ---
$view = $_GET['view'] ?? 'today';
$view_mode = $_GET['view_mode'] ?? 'list';
$filtro_data_agendamento = $_GET['filtro_data'] ?? '';
$filtro_barbeiro = $_GET['filtro_barbeiro'] ?? '';
$filtro_status = $_GET['filtro_status'] ?? '';
$currentPage = (int)($_GET['page'] ?? 1);

// Garante variáveis de dados
$agendamentosPendentes = $agendamentosPendentes ?? [];
$agendamentosPaginados = $agendamentosPaginados ?? [];
$agendamentosAgrupadosPorBarbeiro = $agendamentosAgrupadosPorBarbeiro ?? [];
$barbeirosArr = $barbeirosArr ?? [];
$servicosArr = $servicosArr ?? [];
$combosArr = $combosArr ?? [];
$planosArr = $planosArr ?? [];
$clientesArr = $clientesArr ?? [];
$totalPages = $totalPages ?? 1;

// --- HELPER PARA LINKS ---
$base_query_params = [
    'tab' => 'agendamentos',
    'view' => $view,
    'filtro_data' => $filtro_data_agendamento,
    'filtro_barbeiro' => $filtro_barbeiro,
    'filtro_status' => $filtro_status,
    'page' => $currentPage
];

// Query params para os botões de modo de visualização
$list_query_params = $base_query_params; $list_query_params['view_mode'] = 'list';
$link_list_view = 'admin.php?' . http_build_query($list_query_params);

$card_query_params = $base_query_params; $card_query_params['view_mode'] = 'card';
$link_card_view = 'admin.php?' . http_build_query($card_query_params);

$grouped_query_params = $base_query_params; $grouped_query_params['view_mode'] = 'grouped'; unset($grouped_query_params['page']); 
$link_grouped_view = 'admin.php?' . http_build_query($grouped_query_params);

// Data para imprimir: se tiver filtro, usa ele, se não, hoje
$data_para_imprimir = !empty($filtro_data_agendamento) ? $filtro_data_agendamento : ($view === 'today' ? date('Y-m-d') : '');
$data_label_imprimir = !empty($data_para_imprimir) ? date('d/m/Y', strtotime($data_para_imprimir)) : 'Todos';
$link_imprimir_agenda = "imprimir_agenda_dia.php?data=" . htmlspecialchars($data_para_imprimir);

// --- FUNÇÃO HELPER LOCAL: ENCONTRAR CLIENTE (CORREÇÃO DO ERRO) ---
if (!function_exists('findClienteId')) {
    function findClienteId($ag, $clientesArr) {
        if (isset($ag['cliente_id_encontrado']) && $ag['cliente_id_encontrado']) {
            return $ag['cliente_id_encontrado'];
        }
        // Tenta encontrar por email ou telefone
        foreach ($clientesArr as $cid => $c) {
            if ($c['email'] === $ag['email'] || 
               (isset($c['telefone']) && isset($ag['telefone']) && 
                limparTelefone($c['telefone']) === limparTelefone($ag['telefone']))) {
                return $cid;
            }
        }
        return null;
    }
}

// --- FUNÇÕES DE RENDERIZAÇÃO (Mantidas) ---
if (!function_exists('renderAgendamentoDetalhes')) {
    function renderAgendamentoDetalhes($ag, $servicosArr, $planosArr, $combosArr) {
        $servicosIds = isset($ag['servicos_ids']) ? explode(',', $ag['servicos_ids']) : [];
        $servicoNomes = [];
        foreach($servicosIds as $sid) {
            $sid = trim($sid);
            if(isset($servicosArr[$sid])) {
                $servicoNomes[] = $servicosArr[$sid]['nome'];
            } elseif(isset($combosArr[$sid])) {
                $servicoNomes[] = $combosArr[$sid]['nome'] . " (Combo)";
            } else {
                $servicoNomes[] = '?';
            }
        }
        
        $desconto_valor = (float) ($ag['desconto_aplicado'] ?? 0);
        $tipo_desconto = $ag['tipo_desconto'] ?? '';
        $observacoes = $ag['observacoes'] ?? '';
        $produtos_vendidos = !empty($ag['produtos_vendidos']) ? json_decode($ag['produtos_vendidos'], true) : [];
        $plano_provisorio_id = $ag['plano_provisorio'] ?? ''; 
        
        echo htmlspecialchars(implode(', ', $servicoNomes));

        if ($tipo_desconto === 'adesao_plano' && !empty($plano_provisorio_id)) {
            $nomePlano = $planosArr[$plano_provisorio_id]['nome'] ?? 'Plano';
            echo "<div class='detalhes-extra' style='border-left: 3px solid #6f42c1; background-color: #f3e5f5; color: #4a148c; padding: 5px; margin-top: 5px; border-radius: 4px; font-size: 0.9em;'>
                    <i class='fa fa-crown'></i> <strong>Adesão:</strong> {$nomePlano}<br>
                    <small>Valor inclui assinatura.</small>
                  </div>";
        }
        elseif ($tipo_desconto === 'assinatura_vip' || $tipo_desconto === 'assinatura') {
            echo "<div class='detalhes-extra' style='border-left: 3px solid #28a745; background-color: #e8f5e9; color: #155724; padding: 5px; margin-top: 5px; border-radius: 4px; font-size: 0.9em;'>
                    <i class='fa fa-check-circle'></i> <strong>VIP:</strong> Incluso no plano.
                  </div>";
        }

        if (!empty($produtos_vendidos)) {
            echo "<div class='produtos-vendidos' style='font-size:0.85em; color:#666; margin-top:5px;'><strong>Produtos:</strong><ul>";
            foreach($produtos_vendidos as $p) {
                echo "<li>" . htmlspecialchars($p['nome']) . " - R$" . number_format($p['valor'], 2, ',', '.') . "</li>";
            }
            echo "</ul></div>";
        }
        
        if ($desconto_valor > 0 && $tipo_desconto !== 'adesao_plano' && $tipo_desconto !== 'assinatura_vip' && $tipo_desconto !== 'assinatura') { 
            $icon = 'fa-tag'; 
            if ($tipo_desconto === 'fidelidade') $icon = 'fa-star'; 
            if ($tipo_desconto === 'aniversario') $icon = 'fa-birthday-cake'; 
            if ($tipo_desconto === 'voucher') $icon = 'fa-gift'; 
            if ($tipo_desconto === 'indicacao') $icon = 'fa-user-plus'; 
            
            echo "<div class='detalhes-extra desconto-info' style='color:#28a745; font-size:0.9em; margin-top:5px;'>
                    <i class='fa {$icon}'></i> Desconto (" . ucfirst($tipo_desconto) . "): R$" . number_format($desconto_valor, 2, ',', '.') . "
                  </div>";
        }
        
        if (!empty($observacoes)) {
            echo "<div class='detalhes-extra observacao-cliente' style='color:#856404; font-size:0.9em; margin-top:5px; background:#fff3cd; padding:4px; border-radius:4px;'>
                    <i class='fa fa-comment-dots'></i> " . htmlspecialchars($observacoes) . "
                  </div>";
        }
    }
}

if (!function_exists('renderAgendamentoActions')) {
    function renderAgendamentoActions($ag) {
        ?>
        <div class="btn-group">
            <?php if ($ag['status'] === 'pendente'): ?>
                <a href="?action=aprovar&id=<?= $ag['id'] ?>" class="btn btn-aprovar" title="Aprovar"><i class="fa fa-check"></i></a>
                <a href="?action=rejeitar&id=<?= $ag['id'] ?>" class="btn btn-rejeitar" onclick="return confirm('Tem certeza que deseja cancelar este agendamento?')" title="Cancelar"><i class="fa fa-times-circle"></i></a>
            <?php endif; ?>
            <?php if ($ag['status'] === 'aprovado'): ?>
                <?php $isAdesao = ($ag['tipo_desconto'] ?? '') === 'adesao_plano'; ?>
                <a href="?action=concluir&id=<?= $ag['id'] ?>" class="btn btn-cadastrar" title="<?= $isAdesao ? 'Concluir e Ativar Assinatura' : 'Marcar como Concluído' ?>" <?= $isAdesao ? "onclick=\"return confirm('Este agendamento contém uma ADESÃO DE PLANO. Ao concluir, a assinatura será ativada por 1 mês. O pagamento foi recebido?')\"" : "" ?>>
                    <i class="fa <?= $isAdesao ? 'fa-crown' : 'fa-check-double' ?>"></i>
                </a>
                <a href="?action=rejeitar&id=<?= $ag['id'] ?>" class="btn btn-rejeitar" onclick="return confirm('Tem certeza que deseja cancelar este agendamento?')" title="Cancelar"><i class="fa fa-times-circle"></i></a>
            <?php endif; ?>
            <button class="btn btn-info" data-modal-target="#modal-add-produto" data-id="<?= htmlspecialchars($ag['id']) ?>" title="Adicionar Produto"><i class="fa fa-plus"></i></button>
            <button class="btn btn-editar reagendar-btn" data-modal-target="#modal-reagendamento" data-id="<?= htmlspecialchars($ag['id']) ?>" data-barbeiro-id="<?= htmlspecialchars($ag['barbeiro_id']) ?>" data-servicos-ids="<?= htmlspecialchars($ag['servicos_ids']) ?>" title="Reagendar"><i class="fa fa-calendar-alt"></i></button>
            <a href="?action=excluir_agendamento&id=<?= $ag['id'] ?>" class="btn btn-excluir" onclick="return confirm('Excluir permanentemente?')" title="Excluir"><i class="fa fa-trash"></i></a>
        </div>
        <?php
    }
}

if (!function_exists('getVipBadge')) {
    function getVipBadge($ag) {
        $tipo = $ag['tipo_desconto'] ?? '';
        if ($tipo === 'adesao_plano') {
            return '<span title="Adesão de Plano" style="background-color: #6f42c1; color: white; padding: 3px 8px; border-radius: 12px; font-size: 0.75em; margin-left: 8px; vertical-align: middle; display: inline-block; font-weight: bold;"><i class="fa fa-crown"></i> Adesão VIP</span>';
        } elseif ($tipo === 'assinatura_vip' || $tipo === 'assinatura') {
            return '<span title="Cliente VIP" style="background-color: #28a745; color: white; padding: 3px 8px; border-radius: 12px; font-size: 0.75em; margin-left: 8px; vertical-align: middle; display: inline-block; font-weight: bold;"><i class="fa fa-check-circle"></i> VIP</span>';
        }
        return '';
    }
}

if (!function_exists('getClickableClientName')) {
    function getClickableClientName($ag) {
        $nome = htmlspecialchars($ag['nome']);
        $id_cliente = $ag['cliente_id_encontrado'] ?? null;
        if (!empty($id_cliente)) {
            return '<a href="#" class="btn-link" data-modal-target="#modal-cliente-detalhes" data-id="'.htmlspecialchars($id_cliente).'" title="Ver Detalhes do Cliente">' . $nome . '</a>';
        }
        return '<span>' . $nome . '</span>';
    }
}

// --- MENSAGENS ---
if(isset($_GET['success_msg'])): ?><p class="mensagem"><?= htmlspecialchars($_GET['success_msg']) ?></p><?php endif; ?>
<?php if(isset($_GET['error_msg'])): ?><p class="mensagem erro"><?= htmlspecialchars($_GET['error_msg']) ?></p><?php endif; ?>

<?php if (!empty($agendamentosPendentes)): ?>
<div class="pending-section">
    <h3><i class="fa fa-clock"></i> Agendamentos Pendentes de Aprovação</h3>
    <table>
        <thead><tr><th>Nome</th><th>Data/Hora</th><th>Barbeiro</th><th>Ações</th></tr></thead>
        <tbody>
            <?php foreach ($agendamentosPendentes as $ag): 
                // Enriquecimento local para pendentes
                $ag['cliente_id_encontrado'] = findClienteId($ag, $clientesArr);
            ?>
            <tr>
                <td><?= getClickableClientName($ag) ?><?= getVipBadge($ag) ?></td>
                <td><?= htmlspecialchars(date('d/m/Y', strtotime($ag['data']))) ?> às <?= htmlspecialchars($ag['hora']) ?></td>
                <td><?= htmlspecialchars($barbeirosArr[$ag['barbeiro_id']]['nome'] ?? 'N/A') ?></td>
                <td><div class="btn-group"><a href="?action=aprovar&id=<?= $ag['id'] ?>" class="btn btn-aprovar"><i class="fa fa-check"></i></a><a href="?action=rejeitar&id=<?= $ag['id'] ?>" class="btn btn-rejeitar"><i class="fa fa-times"></i></a></div></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<div class="view-controls-container">
    <div class="header-buttons">
        <button class="btn btn-add" data-modal-target="#modal-agendamento-manual"><i class="fa fa-plus"></i> Agendamento Manual</button>
        <a href="<?= $link_imprimir_agenda ?>" target="_blank" class="btn btn-info"><i class="fa fa-print"></i> Imprimir Agenda (<?= $data_label_imprimir ?>)</a>
        <a href="admin.php?action=enviar_lembretes_amanha&tab=agendamentos" class="btn" style="background-color: var(--warning-color); color: #212529;" onclick="return confirm('Enviar lembretes para amanhã?')"><i class="fa fa-paper-plane"></i> Enviar Lembretes (Amanhã)</a>
    </div>
    <div class="view-mode-toggle">
        <a href="<?= $link_list_view ?>" class="btn <?= $view_mode === 'list' ? 'active' : '' ?>"><i class="fa fa-list"></i></a>
        <a href="<?= $link_card_view ?>" class="btn <?= $view_mode === 'card' ? 'active' : '' ?>"><i class="fa fa-th-large"></i></a>
        <a href="<?= $link_grouped_view ?>" class="btn <?= $view_mode === 'grouped' ? 'active' : '' ?>"><i class="fa fa-user-tag"></i></a>
    </div>
</div>

<div class="view-controls">
    <form method="GET" class="filters" style="width: 100%;">
        <input type="hidden" name="tab" value="agendamentos">
        <input type="hidden" name="view_mode" value="<?= htmlspecialchars($view_mode) ?>">
        
        <div class="filter-btn-group">
            <a href="?tab=agendamentos&view=today&view_mode=<?= $view_mode ?>" class="btn filter-btn <?= ($view === 'today') ? 'active' : '' ?>">Hoje</a>
            <a href="?tab=agendamentos&view=future&view_mode=<?= $view_mode ?>" class="btn filter-btn <?= ($view === 'future') ? 'active' : '' ?>">Próximos</a>
            <a href="?tab=agendamentos&view=all&view_mode=<?= $view_mode ?>" class="btn filter-btn <?= ($view === 'all') ? 'active' : '' ?>">Todos</a>
        </div>
        
        <div class="form-group" style="margin-bottom: 0;">
            <input type="date" name="filtro_data" value="<?= htmlspecialchars($filtro_data_agendamento) ?>" onchange="this.form.submit()" placeholder="Filtrar Data">
        </div>
        <div class="form-group" style="margin-bottom: 0;">
            <select name="filtro_barbeiro"><option value="">Barbeiros</option><?php foreach($barbeirosArr as $id => $b): ?><option value="<?= $id ?>" <?= $filtro_barbeiro == $id ? 'selected' : '' ?>><?= htmlspecialchars($b['nome']) ?></option><?php endforeach; ?></select>
        </div>
        <div class="form-group" style="margin-bottom: 0;">
            <select name="filtro_status"><option value="">Status</option><option value="pendente" <?= $filtro_status=='pendente'?'selected':'' ?>>Pendente</option><option value="aprovado" <?= $filtro_status=='aprovado'?'selected':'' ?>>Aprovado</option><option value="concluido" <?= $filtro_status=='concluido'?'selected':'' ?>>Concluído</option><option value="cancelado" <?= $filtro_status=='cancelado'?'selected':'' ?>>Cancelado</option></select>
        </div>
        <button type="submit" class="btn-primary" style="padding: 10px 15px; margin-top: 0;">Filtrar</button>
    </form>
</div>

<?php switch($view_mode): 
    case 'card': ?>
        <div class="agendamentos-card-grid">
            <?php if (empty($agendamentosPaginados)): ?><p style="text-align:center; grid-column: 1/-1;">Nenhum agendamento.</p><?php else: ?>
                <?php foreach ($agendamentosPaginados as $ag): 
                    // CORREÇÃO: Busca o ID do cliente e a foto corretamente
                    $cliente_id = findClienteId($ag, $clientesArr);
                    $ag['cliente_id_encontrado'] = $cliente_id;
                    
                    $foto_cliente = ($cliente_id && isset($clientesArr[$cliente_id]['foto_perfil'])) 
                        ? $clientesArr[$cliente_id]['foto_perfil'] 
                        : 'uploads/default-profile.jpg';
                    if (!file_exists($foto_cliente)) $foto_cliente = 'uploads/default-profile.jpg';
                    
                    $valor_total_servicos = 0;
                    foreach(explode(',', $ag['servicos_ids']) as $sid) { 
                        $sid = trim($sid);
                        if(isset($servicosArr[$sid])) { 
                            $valor_total_servicos += (float)$servicosArr[$sid]['valor']; 
                        } elseif(isset($combosArr[$sid])) {
                            $valor_total_servicos += (float)$combosArr[$sid]['valor'];
                        }
                    }
                    $produtos_vendidos = !empty($ag['produtos_vendidos']) ? json_decode($ag['produtos_vendidos'], true) : [];
                    $valor_total_produtos = array_sum(array_column($produtos_vendidos, 'valor'));
                    $valor_final = $valor_total_servicos + $valor_total_produtos - (float)($ag['desconto_aplicado'] ?? 0);
                ?>
                <div class="agendamento-card-admin">
                    <div class="agendamento-card-header">
                        <div class="cliente-info">
                            <img src="<?= htmlspecialchars($foto_cliente) ?>" alt="Foto">
                            <div><?= getClickableClientName($ag) ?><?= getVipBadge($ag) ?></div>
                        </div>
                        <span class="status-span status-<?= htmlspecialchars($ag['status']) ?>"><?= ucfirst($ag['status']) ?></span>
                    </div>
                    <div class="agendamento-card-body">
                        <p><i class="fa fa-calendar"></i> <?= date('d/m/Y', strtotime($ag['data'])) ?> - <?= $ag['hora'] ?></p>
                        <p><i class="fa fa-user"></i> <?= $barbeirosArr[$ag['barbeiro_id']]['nome'] ?? '?' ?></p>
                        <p><i class="fa fa-dollar-sign"></i> R$ <?= number_format($valor_final, 2, ',', '.') ?></p>
                        <div class="agendamento-card-servicos"><?php renderAgendamentoDetalhes($ag, $servicosArr, $planosArr, $combosArr); ?></div>
                    </div>
                    <div class="agendamento-card-footer"><?php renderAgendamentoActions($ag); ?></div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    <?php break; ?>

    <?php case 'grouped': ?>
        <?php if (empty($agendamentosAgrupadosPorBarbeiro)): ?><p style="text-align:center;">Nenhum agendamento.</p><?php else: ?>
            <?php foreach ($agendamentosAgrupadosPorBarbeiro as $bid => $agendamentos): ?>
                <div class="agendamento-group-wrapper">
                    <h4><?= $barbeirosArr[$bid]['nome'] ?? 'Barbeiro' ?> (<?= count($agendamentos) ?>)</h4>
                    <div class="agendamentos-card-grid">
                        <?php foreach ($agendamentos as $ag): 
                            // CORREÇÃO: Enriquece dados
                            $ag['cliente_id_encontrado'] = findClienteId($ag, $clientesArr);
                            
                            $valor_total = 0;
                            foreach(explode(',', $ag['servicos_ids']) as $sid) { 
                                $sid = trim($sid);
                                if(isset($servicosArr[$sid])) { $valor_total += $servicosArr[$sid]['valor']; } 
                                elseif(isset($combosArr[$sid])) { $valor_total += $combosArr[$sid]['valor']; }
                            }
                            $valor_final = $valor_total - ($ag['desconto_aplicado'] ?? 0);
                        ?>
                        <div class="agendamento-card-admin">
                            <div class="agendamento-card-header">
                                <div><?= getClickableClientName($ag) ?><?= getVipBadge($ag) ?></div>
                                <span class="status-span status-<?= $ag['status'] ?>"><?= $ag['status'] ?></span>
                            </div>
                            <div class="agendamento-card-body">
                                <p><?= $ag['hora'] ?> - R$ <?= number_format($valor_final, 2, ',', '.') ?></p>
                                <div class="agendamento-card-servicos"><?php renderAgendamentoDetalhes($ag, $servicosArr, $planosArr, $combosArr); ?></div>
                            </div>
                            <div class="agendamento-card-footer"><?php renderAgendamentoActions($ag); ?></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    <?php break; ?>

    <?php default: ?>
        <table id="agendamentos-table">
            <thead><tr><th>Cliente</th><th>Data</th><th>Barbeiro</th><th>Serviços</th><th>Valor</th><th>Status</th><th>Ações</th></tr></thead>
            <tbody>
            <?php if (empty($agendamentosPaginados)): ?><tr><td colspan="7" style="text-align:center;">Nenhum agendamento.</td></tr><?php else: ?>
                <?php foreach ($agendamentosPaginados as $ag): 
                    // CORREÇÃO: Enriquece dados
                    $ag['cliente_id_encontrado'] = findClienteId($ag, $clientesArr);
                    
                    $valor_total = 0;
                    foreach(explode(',', $ag['servicos_ids']) as $sid) { 
                        $sid = trim($sid);
                        if(isset($servicosArr[$sid])) { $valor_total += $servicosArr[$sid]['valor']; } 
                        elseif(isset($combosArr[$sid])) { $valor_total += $combosArr[$sid]['valor']; }
                    }
                    $valor_final = $valor_total - ($ag['desconto_aplicado'] ?? 0);
                ?>
                <tr>
                    <td data-label="Cliente"><?= getClickableClientName($ag) ?><?= getVipBadge($ag) ?></td>
                    <td data-label="Data"><?= date('d/m/Y', strtotime($ag['data'])) ?> - <?= $ag['hora'] ?></td>
                    <td data-label="Barbeiro"><?= htmlspecialchars($barbeirosArr[$ag['barbeiro_id']]['nome'] ?? '?') ?></td>
                    <td data-label="Serviços"><?php renderAgendamentoDetalhes($ag, $servicosArr, $planosArr, $combosArr); ?></td>
                    <td data-label="Valor">R$<?= number_format($valor_final, 2, ',', '.') ?></td>
                    <td data-label="Status"><span class="status-<?= $ag['status'] ?>"><?= ucfirst($ag['status']) ?></span></td>
                    <td data-label="Ações"><?php renderAgendamentoActions($ag); ?></td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    <?php break; ?>
<?php endswitch; ?>

<?php if ($view_mode !== 'grouped' && $totalPages > 1): ?>
    <div class="pagination">
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <a href="?tab=agendamentos&view=<?= $view ?>&view_mode=<?= $view_mode ?>&filtro_data=<?= urlencode($filtro_data_agendamento) ?>&filtro_barbeiro=<?= urlencode($filtro_barbeiro) ?>&filtro_status=<?= urlencode($filtro_status) ?>&page=<?= $i ?>" class="<?= ($i == $currentPage ? 'current' : '') ?>"><?= $i ?></a>
        <?php endfor; ?>
    </div>
<?php endif; ?>