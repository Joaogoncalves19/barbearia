<?php
// admin_tabs/clientes.php
// Contém o HTML da aba "Clientes".
// Variáveis como $clientesPaginados e $estatisticas_clientes vêm do admin_data.php
// $planosArr também está disponível (carregado no admin_data.php)
?>

<h3>Gerenciar Clientes</h3>
<div class="view-controls">
    <button class="btn btn-add" data-modal-target="#modal-cliente"><i class="fa fa-plus"></i> Adicionar Cliente</button>
    <form method="GET" class="filters">
        <input type="hidden" name="tab" value="clientes">
        <input type="text" id="busca-cliente" name="busca_cliente" placeholder="Buscar por nome, e-mail, etc..." value="<?= htmlspecialchars($busca_cliente) ?>" style="padding: 10px; border: 1px solid #ccc; border-radius: 6px; width: 300px;">
        <button type="submit" class="btn btn-primary" style="padding: 10px 15px;">Buscar</button>
    </form>
</div>

<div class="clientes-grid-visual" style="grid-template-columns: repeat(auto-fit, minmax(450px, 1fr)); gap: 20px;">
    <?php if (empty($clientesPaginados)): ?>
        <p style="text-align:center; padding: 20px; background: #f9f9f9; border-radius: 8px; grid-column: 1 / -1;">Nenhum cliente encontrado.</p>
    <?php else: ?>
        <?php foreach ($clientesPaginados as $id => $c): 
            // Define a foto padrão caso o cliente não tenha uma
            $foto_cliente = (!empty($c['foto_perfil']) && file_exists($c['foto_perfil'])) ? $c['foto_perfil'] : 'uploads/default-profile.jpg';
            $stats = $estatisticas_clientes[$id];

            // Lógica de Status (Ativo/Inativo)
            $status_cliente = $c['status'] ?? 'ativo';
            if (empty($status_cliente)) { $status_cliente = 'ativo'; }
            $is_inativo = ($status_cliente === 'inativo');
            
            $toggle_link = "?action=toggle_cliente_status&id=" . htmlspecialchars($c['id']) . "&tab=clientes";
            $toggle_texto = $is_inativo ? "Ativar" : "Desativar";
            $toggle_icon = $is_inativo ? "fa-check-circle" : "fa-ban";
            $toggle_class = $is_inativo ? "btn-aprovar" : "btn-rejeitar";

            // Lógica de Assinatura
            $assinatura = getAssinaturaCliente($id);
            $is_assinante = ($assinatura && $assinatura['status'] === 'ativo');
            $dias_restantes = 0;
            $plano_nome = '';
            
            if($is_assinante) {
                $dias_restantes = ceil((strtotime($assinatura['data_fim']) - time()) / (60 * 60 * 24));
                // Busca o nome do plano
                $plano_nome = $planosArr[$assinatura['plano_id']]['nome'] ?? 'Plano Desconhecido';
            }
        ?>
        <div class="cliente-card-visual">
            <div class="cliente-card-header">
                <div class="cliente-foto">
                    <img src="<?= htmlspecialchars($foto_cliente) ?>" alt="Foto de <?= htmlspecialchars($c['nome']) ?>">
                </div>
                <div class="cliente-info">
                    <h4>
                        <?= htmlspecialchars($c['nome']) ?>
                        
                        <?php if ($is_inativo): ?>
                            <span class="status-cancelado" style="font-size: 0.7em; vertical-align: middle; margin-left: 10px; padding: 3px 6px; border-radius: 4px; opacity: 0.8;">INATIVO</span>
                        <?php elseif ($is_assinante): ?>
                            <span class="status-aprovado" style="font-size: 0.7em; vertical-align: middle; margin-left: 10px; padding: 3px 6px; border-radius: 4px; background-color: #d4edda; color: #155724;">
                                <i class="fa fa-crown"></i> VIP
                            </span>
                        <?php else: ?>
                            <span class="status-aprovado" style="font-size: 0.7em; vertical-align: middle; margin-left: 10px; padding: 3px 6px; border-radius: 4px;">ATIVO</span>
                        <?php endif; ?>
                    </h4>
                    <p><i class="fa fa-envelope"></i> <?= htmlspecialchars($c['email']) ?></p>
                    <p><i class="fa fa-phone"></i> <?= htmlspecialchars($c['telefone']) ?></p>
                    
                    <?php if ($is_assinante): ?>
                        <p style="color: var(--success-color); font-weight: bold; font-size: 0.85em; margin-top: 5px;">
                            <?= htmlspecialchars($plano_nome) ?> (Vence em <?= $dias_restantes ?> dias)
                        </p>
                    <?php endif; ?>
                </div>
            </div>
            <ul class="cliente-stats-lista">
                <li><i class="fa fa-dollar-sign"></i> Gasto Total <span>R$ <?= number_format($stats['gasto_total'], 2, ',', '.') ?></span></li>
                <li><i class="fa fa-calendar-check"></i> Total de Visitas <span><?= $stats['total_agendamentos'] ?></span></li>
                <li><i class="fa fa-star"></i> Pontos de Fidelidade <span><?= $stats['pontos_fidelidade'] ?></span></li>
                <li><i class="fa fa-clock"></i> Última Visita <span><?= $stats['ultima_visita'] ?></span></li>
            </ul>
            <div class="barbeiro-card-actions">
                <button class="btn" data-modal-target="#modal-cliente-detalhes" data-id="<?= $c['id'] ?>" style="background-color: var(--primary-color);"><i class="fa fa-history"></i> Detalhes</button>
                
                <button type="button" class="btn" style="background-color: <?= $is_assinante ? '#28a745' : '#6f42c1' ?>; color: white;" 
                        data-modal-target="#modal-assinatura" 
                        data-id="<?= $c['id'] ?>" 
                        data-nome="<?= htmlspecialchars($c['nome']) ?>"
                        data-plano="<?= $is_assinante ? $assinatura['plano_id'] : '' ?>"
                        title="<?= $is_assinante ? 'Gerenciar/Renovar Assinatura' : 'Ativar Nova Assinatura' ?>">
                    <i class="fa <?= $is_assinante ? 'fa-sync' : 'fa-crown' ?>"></i> <?= $is_assinante ? 'Gerenciar' : 'Assinar' ?>
                </button>

                <button class="btn btn-editar" data-modal-target="#modal-cliente" data-id="<?= $c['id'] ?>" data-type="cliente"><i class="fa fa-edit"></i> Editar</button>
                
                <a href="<?= htmlspecialchars($toggle_link) ?>" class="btn <?= htmlspecialchars($toggle_class) ?>" onclick="return confirm('Tem certeza que deseja alterar o status deste cliente?')" title="<?= $toggle_texto ?>">
                    <i class="fa <?= htmlspecialchars($toggle_icon) ?>"></i>
                </a>

                <a href="?action=excluir_cliente&id=<?= $c['id'] ?>&tab=clientes" class="btn btn-excluir" onclick="return confirm('ATENÇÃO: Excluir um cliente apagará todo o histórico dele (agendamentos, notas, fidelidade). Esta ação é irreversível. Deseja continuar?')" title="Excluir Cliente">
                    <i class="fa fa-trash"></i>
                </a>
            </div>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<div class="pagination"><?php for ($i = 1; $i <= $clientes_totalPages; $i++): ?><a href="?tab=clientes&cli_page=<?= $i ?>&busca_cliente=<?= urlencode($busca_cliente) ?>" class="<?= ($i == $clientes_currentPage ? 'current' : '') ?>"><?= $i ?></a><?php endfor; ?></div>

<div id="modal-assinatura" class="modal-overlay">
    <div class="modal-content">
        <button class="modal-close">&times;</button>
        <h3>Gerenciar Assinatura VIP</h3>
        <p>Cliente: <strong id="nome-cliente-assinatura" style="color: var(--primary-color);"></strong></p>
        
        <form method="post" action="admin.php">
            <input type="hidden" name="action" value="ativar_assinatura">
            <input type="hidden" name="cliente_id" id="id-cliente-assinatura">
            
            <div class="form-group">
                <label>Status da Assinatura</label>
                <select name="status_assinatura" required>
                    <option value="ativo">Ativa (Vigente)</option>
                    <option value="inativo">Inativa (Cancelada/Pausada)</option>
                </select>
            </div>

            <div class="form-group">
                <label>Escolha o Plano</label>
                <select name="plano_id" id="plano-assinatura-select" required>
                    <option value="">Selecione...</option>
                    <?php if(!empty($planosArr)): ?>
                        <?php foreach ($planosArr as $p): ?>
                            <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['nome']) ?> - R$ <?= number_format((float)$p['valor'], 2, ',', '.') ?></option>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <option value="" disabled>Nenhum plano cadastrado</option>
                    <?php endif; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>Duração (Dias)</label>
                <input type="number" name="dias_validade" min="1" value="30" required placeholder="Ex: 30, 60, 365...">
                <p style="font-size: 0.8em; color: #666; margin-top: 5px;">
                    Define quantos dias a assinatura será válida a partir de hoje (ou renova a partir do vencimento atual se já existir).
                </p>
            </div>
            
            <button type="submit" class="btn-primary">Salvar Assinatura</button>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const btnsAssinatura = document.querySelectorAll('[data-modal-target="#modal-assinatura"]');
    btnsAssinatura.forEach(btn => {
        btn.addEventListener('click', () => {
            document.getElementById('id-cliente-assinatura').value = btn.dataset.id;
            document.getElementById('nome-cliente-assinatura').textContent = btn.dataset.nome;
            
            // Pré-seleciona o plano se já existir
            const planoSelect = document.getElementById('plano-assinatura-select');
            if(btn.dataset.plano) {
                planoSelect.value = btn.dataset.plano;
            } else {
                planoSelect.value = "";
            }
        });
    });
});
</script>