<?php
// admin_tabs/landingpage.php
// Contém o HTML da aba "Landing Page".
// A variável $landingConfig é fornecida pelo admin_data.php
?>

<h3>Personalizar Página Inicial</h3>
<?php if(isset($_GET['success'])): ?><p class="mensagem">Alterações salvas com sucesso!</p><?php endif; ?>

<form method="POST" class="admin-form" action="admin.php" enctype="multipart/form-data">
    <input type="hidden" name="action" value="salvar_landing_page">

    <button type="button" class="accordion-button active"><i class="fa fa-video"></i> Estilo e Mídia</button>
    <div class="accordion-panel" style="max-height: 100%;">
        
        <div class="form-group">
            <label>Vídeo de Fundo (.mp4 ou .webm)</label>
            <input type="hidden" name="hero_video_path_atual" value="<?= htmlspecialchars($landingConfig['hero_video_path']) ?>">
            
            <input type="file" name="hero_video_file" accept="video/mp4,video/webm">
            
            <?php if (!empty($landingConfig['hero_video_path']) && file_exists($landingConfig['hero_video_path'])): ?>
                <p style="font-size:0.9em; color: #333; margin-top: 10px;">
                    Vídeo atual: <code><?= htmlspecialchars($landingConfig['hero_video_path']) ?></code>
                </p>
            <?php endif; ?>
            <p style="font-size:0.8em; color: #666; margin-top: 5px;">
                Envie um novo vídeo para substituir o atual (MP4 ou WebM). 
                <strong>Importante:</strong> Use vídeos curtos e leves (abaixo de 10MB) para não deixar o site lento.
            </p>
        </div>
    </div>
    
    <button type="button" class="accordion-button"><i class="fa fa-home"></i> Seção Principal (Hero)</button>
    <div class="accordion-panel">
        <div class="form-group"><label>Título Principal</label><input type="text" name="hero_title" value="<?= htmlspecialchars($landingConfig['hero_title']) ?>"></div>
        <div class="form-group"><label>Subtítulo</label><input type="text" name="hero_subtitle" value="<?= htmlspecialchars($landingConfig['hero_subtitle']) ?>"></div>
        <div class="form-group"><label>Texto do Botão Principal (Agendar)</label><input type="text" name="hero_cta_button" value="<?= htmlspecialchars($landingConfig['hero_cta_button']) ?>"></div>
        <div class="form-group"><label>Texto do Botão Secundário</label><input type="text" name="hero_secondary_button" value="<?= htmlspecialchars($landingConfig['hero_secondary_button']) ?>"></div>
    </div>

    <button type="button" class="accordion-button"><i class="fa fa-info-circle"></i> Seção "Sobre"</button>
    <div class="accordion-panel">
        <div class="form-group"><label>Título da Seção "Sobre"</label><input type="text" name="about_title" value="<?= htmlspecialchars($landingConfig['about_title']) ?>"></div>
        <div class="form-group"><label>Texto da Seção "Sobre"</label><textarea name="about_text" rows="5"><?= htmlspecialchars($landingConfig['about_text']) ?></textarea></div>
        <div class="form-grid">
            <div class="form-group"><label>Stat 1 - Número</label><input type="text" name="stat1_number" value="<?= htmlspecialchars($landingConfig['stat1_number']) ?>"></div>
            <div class="form-group"><label>Stat 1 - Texto</label><input type="text" name="stat1_label" value="<?= htmlspecialchars($landingConfig['stat1_label']) ?>"></div>
            <div class="form-group"><label>Stat 2 - Número</label><input type="text" name="stat2_number" value="<?= htmlspecialchars($landingConfig['stat2_number']) ?>"></div>
            <div class="form-group"><label>Stat 2 - Texto</label><input type="text" name="stat2_label" value="<?= htmlspecialchars($landingConfig['stat2_label']) ?>"></div>
            <div class="form-group"><label>Stat 3 - Número</label><input type="text" name="stat3_number" value="<?= htmlspecialchars($landingConfig['stat3_number']) ?>"></div>
            <div class="form-group"><label>Stat 3 - Texto</label><input type="text" name="stat3_label" value="<?= htmlspecialchars($landingConfig['stat3_label']) ?>"></div>
        </div>
    </div>
    
    <button type="button" class="accordion-button"><i class="fa fa-concierge-bell"></i> Títulos das Outras Seções</button>
    <div class="accordion-panel">
        <div class="form-group"><label>Título da Seção "Serviços"</label><input type="text" name="services_title" value="<?= htmlspecialchars($landingConfig['services_title']) ?>"></div>
        <div class="form-group"><label>Título da Seção "Equipe"</label><input type="text" name="team_title" value="<?= htmlspecialchars($landingConfig['team_title']) ?>"></div>
        <div class="form-group"><label>Título da Seção "Barbeiro em Destaque"</label><input type="text" name="featured_title" value="<?= htmlspecialchars($landingConfig['featured_title']) ?>"></div>
        <div class="form-group"><label>Subtítulo da Seção "Barbeiro em Destaque"</label><input type="text" name="featured_subtitle" value="<?= htmlspecialchars($landingConfig['featured_subtitle']) ?>"></div>
        <div class="form-group"><label>Título da Seção "Avaliações"</label><input type="text" name="testimonials_title" value="<?= htmlspecialchars($landingConfig['testimonials_title']) ?>"></div>
    </div>

    <button type="button" class="accordion-button"><i class="fa fa-bullhorn"></i> Seção de Chamada para Ação (CTA)</button>
    <div class="accordion-panel">
        <div class="form-group"><label>Título da Seção CTA</label><input type="text" name="cta_title" value="<?= htmlspecialchars($landingConfig['cta_title']) ?>"></div>
        <div class="form-group"><label>Texto da Seção CTA</label><input type="text" name="cta_text" value="<?= htmlspecialchars($landingConfig['cta_text']) ?>"></div>
        <div class="form-group"><label>Texto do Botão CTA</label><input type="text" name="cta_button" value="<?= htmlspecialchars($landingConfig['cta_button']) ?>"></div>
    </div>

    <button type="button" class="accordion-button"><i class="fa fa-map-marker-alt"></i> Seção de Contato</button>
    <div class="accordion-panel">
        <div class="form-group"><label>Título da Seção de Contato</label><input type="text" name="contact_title" value="<?= htmlspecialchars($landingConfig['contact_title']) ?>"></div>
    </div>
    
    <button type="button" class="accordion-button"><i class="fa fa-file-contract"></i> Textos Legais (Modais)</button>
    <div class="accordion-panel">
         <p style="font-size:0.9em; margin-bottom: 15px;">Você pode usar tags HTML básicas aqui, como &lt;p&gt;, &lt;h3&gt;, &lt;ul&gt;, &lt;li&gt;, &lt;strong&gt;.</p>
        <div class="form-group"><label>Termos de Uso</label><textarea name="terms_of_use" rows="10"><?= htmlspecialchars($landingConfig['terms_of_use']) ?></textarea></div>
        <div class="form-group"><label>Política de Privacidade</label><textarea name="privacy_policy" rows="10"><?= htmlspecialchars($landingConfig['privacy_policy']) ?></textarea></div>
    </div>

    <button type="submit" class="btn-primary" style="margin-top: 25px; width: 100%; padding: 15px; font-size: 1.1rem;">Salvar Alterações da Landing Page</button>
</form>