<?php
// admin_tabs/barbeiros.php
// Contém o HTML da aba "Barbeiros".
// Variáveis como $barbeirosPaginados e $horariosTrabalhoRaw vêm do admin_data.php
?>

<div class="view-controls" style="justify-content: space-between;">
    <h3>Gerenciar Barbeiros</h3>
    <div class="header-buttons"><button class="btn btn-add" data-modal-target="#modal-barbeiro"><i class="fa fa-plus"></i> Adicionar Barbeiro</button></div>
</div>
<div class="barbeiros-grid">
    <?php foreach ($barbeirosPaginados as $id => $b): ?>
        <?php
            // Define o status.
            $status_barbeiro = $b['status'] ?? 'ativo';
            if(empty($status_barbeiro)) $status_barbeiro = 'ativo';
            
            $is_inativo = ($status_barbeiro === 'inativo');
            $card_style = $is_inativo ? 'style="opacity: 0.6;"' : '';
        ?>
        <div class="barbeiro-card" <?= $card_style ?>> <div class="barbeiro-card-header">
                <img src="<?= htmlspecialchars($b['foto']) ?>" alt="<?= htmlspecialchars($b['nome']) ?>">
                <h4>
                    <?= htmlspecialchars($b['nome']) ?>
                    
                    <?php if ($is_inativo): ?>
                        <span class="status-cancelado" style="font-size: 0.7em; vertical-align: middle; margin-left: 10px; padding: 3px 6px; border-radius: 4px;">INATIVO</span>
                    <?php else: ?>
                        <span class="status-aprovado" style="font-size: 0.7em; vertical-align: middle; margin-left: 10px; padding: 3px 6px; border-radius: 4px;">ATIVO</span>
                    <?php endif; ?>
                </h4>
            </div>
            <div class="barbeiro-card-stats">
                <div><div class="stat-value"><?= $estatisticas_barbeiros[$id]['concluidos'] ?></div><div class="stat-label">Concluídos</div></div>
                <div><div class="stat-value">R$<?= number_format($estatisticas_barbeiros[$id]['receita'], 2, ',', '.') ?></div><div class="stat-label">Receita</div></div>
                <div><div class="stat-value"><i class="fa fa-star" style="color: var(--warning-color);"></i> <?= $estatisticas_barbeiros[$id]['media_avaliacoes'] ?></div><div class="stat-label">Média</div></div>
            </div>
            <div class="barbeiro-card-actions">
                <button class="btn" data-modal-target="#modal-barbeiro-detalhes" data-id="<?= $id ?>" style="background-color: var(--primary-color);"><i class="fa fa-eye"></i> Detalhes</button>
                
                <button class="btn btn-info" 
                        data-modal-target="#modal-bloqueio-horarios" 
                        data-id="<?= $id ?>" 
                        data-nome="<?= htmlspecialchars($b['nome']) ?>">
                    <i class="fa fa-calendar-alt"></i> Agenda
                </button>
                
                <button class="btn btn-editar" data-modal-target="#modal-barbeiro" data-id="<?= $b['id'] ?>" data-type="barbeiro"><i class="fa fa-edit"></i> Editar</button>
                <a href="?action=excluir_barbeiro&id=<?= $b['id'] ?>" class="btn btn-excluir" onclick="return confirm('Excluir barbeiro?')"><i class="fa fa-trash"></i></a>
            </div>
        </div>
    <?php endforeach; ?>
</div>
<div class="pagination"><?php for ($i = 1; $i <= $barbeiros_totalPages; $i++): ?><a href="?tab=barbeiros&bar_page=<?= $i ?>" class="<?= ($i == $barbeiros_currentPage ? 'current' : '') ?>"><?= $i ?></a><?php endfor; ?></div>

<h3 style="margin-top: 40px; border-bottom: 2px solid var(--secondary-color); padding-bottom: 10px;">
    <i class="fa fa-clock"></i> Definir Grade de Horários
</h3>

<div class="config-section" style="background: #fff; border: 1px solid var(--border-color);">
    <div class="form-group" style="max-width: 400px; margin-bottom: 20px;">
        <label>Selecione o Barbeiro para Configurar:</label>
        <select id="select-barbeiro-grade" style="font-size: 1.1em; padding: 10px;">
            <option value="">-- Selecione --</option>
            <?php foreach($barbeirosArr as $id => $b): ?>
                <option value="<?= htmlspecialchars($id) ?>"><?= htmlspecialchars($b['nome']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <div id="container-grade-horarios" style="display: none;">
        <form method="POST" action="admin.php" class="admin-form" style="display: block;">
            <input type="hidden" name="action" value="salvar_semana_horarios">
            <input type="hidden" name="barbeiro_id" id="input_barbeiro_id_grade">

            <div style="display: flex; justify-content: flex-end; margin-bottom: 10px;">
                <button type="button" id="btn-replicar-horarios" class="btn btn-info" style="font-size: 0.9em;">
                    <i class="fa fa-copy"></i> Copiar Segunda para a Semana Toda
                </button>
            </div>

            <table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="background: #f8f9fa;">
                        <th style="padding: 12px; text-align: center; width: 60px;">Ativo</th>
                        <th style="padding: 12px;">Dia da Semana</th>
                        <th style="padding: 12px;">Entrada</th>
                        <th style="padding: 12px;">Saída</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    // Ordem: Domingo (0) a Sábado (6). Mas geralmente exibimos Seg-Sex primeiro.
                    // Vamos exibir na ordem lógica: Seg (1) a Sab (6), depois Dom (0)
                    $ordemDias = [1, 2, 3, 4, 5, 6, 0];
                    foreach($ordemDias as $diaNum): 
                        $diaNome = $dias_semana_texto[$diaNum];
                    ?>
                    <tr style="border-bottom: 1px solid #eee;">
                        <td style="text-align: center; vertical-align: middle;">
                            <div class="checkbox-wrapper" style="justify-content: center;">
                                <input type="checkbox" name="horarios[<?= $diaNum ?>][ativo]" id="dia_ativo_<?= $diaNum ?>" value="1" style="width: 20px; height: 20px;">
                            </div>
                        </td>
                        <td style="vertical-align: middle;">
                            <label for="dia_ativo_<?= $diaNum ?>" style="margin: 0; cursor: pointer; font-weight: bold;"><?= $diaNome ?></label>
                        </td>
                        <td>
                            <input type="time" name="horarios[<?= $diaNum ?>][inicio]" class="time-input-start" id="inicio_<?= $diaNum ?>" style="width: 100%;">
                        </td>
                        <td>
                            <input type="time" name="horarios[<?= $diaNum ?>][fim]" class="time-input-end" id="fim_<?= $diaNum ?>" style="width: 100%;">
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <div style="margin-top: 20px; text-align: right;">
                <button type="submit" class="btn-primary" style="padding: 15px 30px; font-size: 1.1em;">
                    <i class="fa fa-save"></i> Salvar Grade Completa
                </button>
            </div>
        </form>
    </div>
    
    <div id="aviso-selecao-grade" style="text-align: center; padding: 40px; color: #666; font-style: italic;">
        <i class="fa fa-arrow-up"></i> Selecione um barbeiro acima para editar seus horários.
    </div>
</div>