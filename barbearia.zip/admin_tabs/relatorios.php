<?php
// admin_tabs/relatorios.php
// Contém o HTML da aba "Relatórios" e suas sub-abas.
// As variáveis vêm do admin_data.php
?>

<div class="dashboard-filter-header">
    <h3>Relatórios Avançados</h3>
    <div class="filters" style="display: flex; gap: 15px; align-items: center;">
        <form method="GET" class="dashboard-filter">
            <input type="hidden" name="tab" value="relatorios">
            <input type="date" name="data_inicio" value="<?= htmlspecialchars($data_inicio_filtro) ?>">
            <input type="date" name="data_fim" value="<?= htmlspecialchars($data_fim_filtro) ?>">
            <button type="submit" class="btn-filtrar">Gerar Relatório</button>
        </form>
        <a href="imprimir_relatorio.php?data_inicio=<?= $data_inicio_filtro ?>&data_fim=<?= $data_fim_filtro ?>" 
           target="_blank" class="btn btn-info btn-print">
           <i class="fa fa-print"></i> Imprimir
        </a>
    </div>
</div>
<p class="dashboard-periodo">Exibindo dados de: <strong><?= htmlspecialchars(date('d/m/Y', strtotime($data_inicio_filtro))) ?></strong> a <strong><?= htmlspecialchars(date('d/m/Y', strtotime($data_fim_filtro))) ?></strong></p>

<div class="sub-tab">
    <button class="sub-tab-btn active" data-subtab="financeiro"><i class="fa fa-dollar-sign"></i> Financeiro</button>
    <button class="sub-tab-btn" data-subtab="operacional"><i class="fa fa-chart-bar"></i> Operacional</button>
    <button class="sub-tab-btn" data-subtab="assinaturas"><i class="fa fa-crown"></i> Assinaturas</button>
    <button class="sub-tab-btn" data-subtab="crm"><i class="fa fa-users"></i> Clientes (CRM)</button>
</div>

<div id="financeiro" class="sub-tabcontent active">
    <div class="relatorios-grid">
        <div class="dash-card" style="background-color: #d4edda; border-color: #c3e6cb;">
            <div class="dash-card-icon" style="color: #155724; background-color: #c3e6cb;"><i class="fa fa-dollar-sign"></i></div>
            <div class="dash-card-content">
                <h4>Receita Bruta Total</h4>
                <div class="value" style="color: #155724;">R$<?= htmlspecialchars(number_format($receitaTotal, 2, ',', '.')) ?></div>
            </div>
        </div>
        <div class="dash-card">
            <div class="dash-card-icon" style="color: #6f42c1; background-color: #e2d2f7;"><i class="fa fa-hand-holding-usd"></i></div>
            <div class="dash-card-content">
                <h4>Receita de Assinaturas (Planos)</h4>
                <div class="value" style="color: #4a148c;">R$<?= htmlspecialchars(number_format($receitaPlanos, 2, ',', '.')) ?></div>
                <small>(No período selecionado)</small>
            </div>
        </div>
        <div class="dash-card" style="background-color: #fff3cd; border-color: #ffeeba;">
            <div class="dash-card-icon" style="color: #856404; background-color: #ffeeba;"><i class="fa fa-tags"></i></div>
            <div class="dash-card-content">
                <h4>Total em Descontos</h4>
                <div class="value" style="color: #856404;">R$<?= htmlspecialchars(number_format($totalDescontos, 2, ',', '.')) ?></div>
            </div>
        </div>
    </div>
    
    <div class="relatorios-grid" style="margin-top: 25px;">
        <div class="chart-container"><canvas id="receitaVsDespesaChart"></canvas></div>
        <div class="chart-container"><canvas id="analiseDescontosChart"></canvas></div>
        
        <div class="dash-card dash-card-list">
            <h4><i class="fa fa-trophy"></i> Top 5 Clientes (por Gasto)</h4>
             <?php if(empty($topClientes)): ?> <p>Nenhum dado de cliente para exibir.</p>
             <?php else: ?>
                <table style="text-align:left; font-size: 0.9em;"><thead><tr><th>Cliente (Telefone)</th><th>Gasto Total</th></tr></thead>
                <tbody>
                    <?php foreach($topClientes as $nome => $valor): ?>
                    <tr>
                        <td><?= htmlspecialchars($nome) ?></td>
                        <td>R$ <?= number_format($valor, 2, ',', '.') ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody></table>
             <?php endif; ?>
        </div>
        <div class="dash-card dash-card-list">
            <h4><i class="fa fa-box"></i> Ranking de Venda de Produtos</h4>
            <?php if(empty($vendasProdutos)): ?> <p>Nenhum produto vendido no período.</p>
            <?php else: ?>
                <table style="text-align:left; font-size: 0.9em;"><thead><tr><th>Produto</th><th>Qtd</th><th>Receita</th></tr></thead>
                <tbody><?php foreach($vendasProdutos as $nome => $dados): ?><tr><td><?= htmlspecialchars($nome) ?></td><td><?= $dados['quantidade'] ?></td><td>R$<?= number_format($dados['receita'], 2, ',', '.') ?></td></tr><?php endforeach; ?></tbody></table>
            <?php endif; ?>
        </div>
    </div>
</div>

<div id="assinaturas" class="sub-tabcontent">
    <div class="relatorios-grid">
        <div class="dash-card" style="border-left: 5px solid #28a745;">
            <div class="dash-card-icon" style="color: #28a745; background-color: #d4edda;"><i class="fa fa-users"></i></div>
            <div class="dash-card-content">
                <h4>Assinantes Ativos Totais</h4>
                <div class="value"><?= $totalAssinantesAtivos ?></div>
            </div>
        </div>
        <div class="dash-card" style="border-left: 5px solid #6f42c1;">
            <div class="dash-card-icon" style="color: #6f42c1; background-color: #f3e5f5;"><i class="fa fa-money-bill-wave"></i></div>
            <div class="dash-card-content">
                <h4>MRR (Receita Mensal Recorrente)</h4>
                <div class="value">R$ <?= number_format($mrrAtual, 2, ',', '.') ?></div>
                <small>Valor mensal projetado dos ativos</small>
            </div>
        </div>
        <div class="dash-card" style="border-left: 5px solid #17a2b8;">
            <div class="dash-card-icon" style="color: #17a2b8; background-color: #d1ecf1;"><i class="fa fa-user-plus"></i></div>
            <div class="dash-card-content">
                <h4>Novas Assinaturas</h4>
                <div class="value"><?= $novasAssinaturasPeriodo ?></div>
                <small>(No período selecionado)</small>
            </div>
        </div>
    </div>

    <div class="relatorios-grid" style="margin-top: 30px;">
        <div class="chart-container">
            <h4>Popularidade dos Planos (Ativos)</h4>
            <canvas id="planosPopularesChart"></canvas>
        </div>
        <div class="chart-container">
            <h4>Composição da Receita</h4>
            <canvas id="fontesReceitaChart"></canvas>
        </div>
    </div>

    <div class="relatorios-grid" style="margin-top: 30px;">
        <div class="dash-card dash-card-list">
            <h4 style="color: #dc3545;"><i class="fa fa-clock"></i> Vencendo em Breve (7 Dias)</h4>
            <?php if(empty($assinaturasVencendo)): ?>
                <p style="padding: 10px; color: #666;">Nenhuma assinatura prestes a vencer.</p>
            <?php else: ?>
                <table style="width:100%;">
                    <thead><tr><th>Cliente</th><th>Plano</th><th>Vence em</th></tr></thead>
                    <tbody>
                        <?php foreach($assinaturasVencendo as $sub): ?>
                        <tr>
                            <td><?= htmlspecialchars($sub['nome_cliente']) ?></td>
                            <td><?= htmlspecialchars($sub['nome_plano']) ?></td>
                            <td style="color: #dc3545; font-weight: bold;"><?= date('d/m/Y', strtotime($sub['data_fim'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        
        <div class="dash-card dash-card-list">
            <h4><i class="fa fa-star"></i> Benefícios VIP Utilizados</h4>
            <div class="dash-card-content" style="padding: 10px;">
                <div class="value" style="font-size: 1.5rem;">R$ <?= number_format($economiaVIP, 2, ',', '.') ?></div>
                <p style="font-size: 0.9em; color: #666;">Total que os clientes VIP economizaram em serviços (desconto de 100%) neste período.</p>
            </div>
        </div>
    </div>
</div>

<div id="operacional" class="sub-tabcontent">
    <div class="relatorios-grid">
         <div class="chart-container"><canvas id="ocupacaoBarbeiroChart"></canvas></div>
         <div class="chart-container"><canvas id="agendamentosPorDiaSemanaChart"></canvas></div>
         <div class="chart-container" style="grid-column: 1 / -1;"><canvas id="horariosPicoChart"></canvas></div>
         
         <div class="dash-card dash-card-list">
            <h4><i class="fa fa-link"></i> Serviços Mais Combinados</h4>
            <?php if(empty($servicosMaisCombinados)): ?> <p>Nenhuma combinação de serviços encontrada.</p>
            <?php else: ?>
                <table style="text-align:left; font-size: 0.9em;"><thead><tr><th>Combinação</th><th>Ocorrências</th></tr></thead>
                <tbody><?php foreach($servicosMaisCombinados as $combo): ?><tr><td><?= htmlspecialchars($combo['combinacao']) ?></td><td><?= $combo['ocorrencias'] ?></td></tr><?php endforeach; ?></tbody></table>
            <?php endif; ?>
        </div>
    </div>
</div>

<div id="crm" class="sub-tabcontent">
    <div class="relatorios-grid">
         <div class="dash-card"><h4><i class="fa fa-heartbeat"></i> Frequência Média de Visitas</h4><div class="value"><?= $frequenciaMedia ?> dias</div><p style="font-size:0.8em;">(Média de dias entre agendamentos concluídos por cliente)</p></div>
         
         <div class="dash-card dash-card-list">
            <h4><i class="fa fa-trophy"></i> Top 5 Clientes (por Gasto)</h4>
            <?php if(empty($topClientes)): ?> <p>Nenhum dado de cliente para exibir.</p>
             <?php else: ?>
                <ul class="ranking-lista">
                    <?php foreach($topClientes as $nome => $valor): ?>
                    <li><span><?= htmlspecialchars($nome) ?></span> <strong>R$ <?= number_format($valor, 2, ',', '.') ?></strong></li>
                    <?php endforeach; ?>
                </ul>
             <?php endif; ?>
         </div>
         
         <div class="dash-card dash-card-list">
            <h4><i class="fa fa-user-slash"></i> Clientes em Risco</h4>
            <p style="font-size:0.9em;">(Clientes recorrentes sem agendar há > 90 dias)</p>
             <?php if(empty($clientesEmRisco)): ?> <p>Nenhum cliente em risco.</p>
             <?php else: ?>
                 <ul class="aniversariantes-lista"><?php foreach($clientesEmRisco as $cli): ?><li><div class="aniversariante-info"><div class="aniversariante-nome"><?= htmlspecialchars($cli['nome']) ?></div><small>Última visita: <?= $cli['ultimo_agendamento'] ?></small></div></li><?php endforeach; ?></ul>
             <?php endif; ?>
         </div>
         <div class="chart-container"><canvas id="novosClientesChart"></canvas></div>
    </div>
</div>