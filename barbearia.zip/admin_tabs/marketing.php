<?php
// admin_tabs/marketing.php
// Contém o HTML da aba "Marketing".
// Variáveis como $configIndicacao, $configAniversario, $cupoesArr, etc. vêm do admin_data.php
?>

<h3>Ferramentas de Marketing</h3>
<?php if(isset($_GET['success'])): ?><p class="mensagem">Ação concluída com sucesso! <?= isset($_GET['total']) ? htmlspecialchars($_GET['total']) : '' ?></p><?php endif; ?>
<?php if(isset($_GET['error'])): ?><p class="mensagem erro"><?= htmlspecialchars($_GET['error']) ?></p><?php endif; ?>

<div class="config-section">
    <h4><i class="fa fa-paper-plane"></i> Campanha de E-mail Marketing (Newsletter)</h4>
    <p style="font-size: 0.9em; color: #666;">Envie um e-mail em massa para seus clientes. Você pode usar HTML básico (ex: &lt;p&gt;, &lt;strong&gt;, &lt;br&gt;) no corpo da mensagem.</p>
    <form method="POST" class="admin-form" action="admin.php" onsubmit="return confirm('Tem certeza que deseja enviar este e-mail para o grupo selecionado?');">
        <input type="hidden" name="action" value="enviar_newsletter">
        <div class="form-grid">
            <div class="form-group">
                <label>Destinatários</label>
                <select name="destinatarios" required>
                    <option value="ativos">Apenas Clientes Ativos (Status: Ativo)</option>
                    <option value="todos">Todos os Clientes (Inclui inativos)</option>
                </select>
            </div>
            <div class="form-group">
                <label>Assunto</label>
                <input type="text" name="assunto" required>
            </div>
        </div>
        <div class="form-group" style="width: 100%;">
            <label>Corpo do E-mail</label>
            <textarea name="corpo_email" rows="10" placeholder="Escreva sua mensagem aqui... (Ex: Olá, {nome_cliente}! Temos uma novidade...)"></textarea>
            <small>Use <strong>{nome_cliente}</strong> para personalizar o e-mail com o nome do cliente.</small>
        </div>
        <button type="submit" class="btn-primary" style="width: 100%; padding: 15px;">Enviar Campanha Agora</button>
    </form>
</div>

<div class="config-section">
    <h4><i class="fa fa-user-clock"></i> Reativação de Clientes Ausentes (Manual)</h4>
    <p style="font-size: 0.9em; color: #666;">Envie um e-mail com um cupom de incentivo para clientes que não agendam há 90 dias ou mais (clientes recorrentes em risco).</p>
    
    <?php
    // $clientesEmRisco é calculado em admin_data.php
    $totalClientesEmRisco = count($clientesEmRisco);
    
    // Filtra cupons para mostrar apenas os válidos
    $hoje = date('Y-m-d');
    $cupoesValidos = array_filter($cupoesArr, function($c) use ($hoje) {
        return isset($c['data_validade']) && $c['data_validade'] >= $hoje &&
               isset($c['usos_atuais']) && isset($c['usos_maximos']) && (int)$c['usos_atuais'] < (int)$c['usos_maximos'];
    });
    ?>

    <?php if ($totalClientesEmRisco > 0): ?>
        <form method="POST" class="admin-form" action="admin.php" onsubmit="return confirm('Tem certeza que deseja enviar este e-mail de reativação para <?= $totalClientesEmRisco ?> cliente(s)?');">
            <input type="hidden" name="action" value="enviar_reativacao">
            <div class="form-group" style="width: 100%;">
                <label>Cupom de Incentivo</label>
                <?php if (empty($cupoesValidos)): ?>
                    <p class="erro" style="text-align: left; margin: 0; padding: 10px; background: #f8d7da; border-radius: 8px;">Você não tem nenhum cupom válido. Crie um cupom (abaixo) antes de enviar a campanha.</p>
                <?php else: ?>
                    <select name="cupom_id" required>
                        <option value="">Selecione um cupom válido...</option>
                        <?php foreach ($cupoesValidos as $cupom): ?>
                            <option value="<?= htmlspecialchars($cupom['id']) ?>">
                                <?= htmlspecialchars($cupom['codigo']) ?> (<?= htmlspecialchars($cupom['desconto_percentual']) ?>%)
                            </option>
                        <?php endforeach; ?>
                    </select>
                <?php endif; ?>
            </div>
            
            <button type="submit" class="btn-primary" style="width: 100%; padding: 15px; background-color: var(--warning-color); color: #212529;" <?= empty($cupoesValidos) ? 'disabled' : '' ?>>
                <i class="fa fa-paper-plane"></i> Enviar Reativação para <?= $totalClientesEmRisco ?> Cliente(s)
            </button>
        </form>
    <?php else: ?>
        <p class="mensagem" style="background-color: #d4edda; border-color: #c3e6cb; text-align: left;">
            <i class="fa fa-check-circle"></i> Parabéns! Nenhum cliente recorrente foi classificado como "em risco" (ausente há mais de 90 dias).
        </p>
    <?php endif; ?>
</div>
<div class="config-section">
    <h4><i class="fa fa-users"></i> Programa "Indique um Amigo"</h4>
    <form method="POST" class="admin-form">
        <input type="hidden" name="action" value="salvar_config_indicacao">
        <div class="form-group">
            <label>Status do Programa</label>
            <select name="indicacao_ativado">
                <option value="1" <?= ($configIndicacao['ativado'] ?? 0) == 1 ? 'selected' : '' ?>>Ativado</option>
                <option value="0" <?= ($configIndicacao['ativado'] ?? 0) == 0 ? 'selected' : '' ?>>Desativado</option>
            </select>
        </div>
        <div class="form-group">
            <label>Pontos para quem indica</label>
            <input type="number" name="pontos_indicacao" value="<?= $configIndicacao['pontos_indicacao'] ?? 1 ?>" required>
        </div>
        <div class="form-group">
            <label>Desconto para novo cliente (%)</label>
            <input type="number" name="desconto_novo_cliente" value="<?= $configIndicacao['desconto_novo_cliente'] ?? 10 ?>" required>
        </div>
        <button type="submit" class="btn-primary">Salvar</button>
    </form>
</div>

<div class="config-section">
    <h4><i class="fa fa-birthday-cake"></i> Campanha de Aniversário</h4>
    <form method="POST" class="admin-form">
        <input type="hidden" name="action" value="salvar_config_aniversario">
        <div class="form-group">
            <label>Status da Campanha</label>
            <select name="aniversario_ativado">
                <option value="1" <?= ($configAniversario['ativado'] ?? 0) == 1 ? 'selected' : '' ?>>Ativada</option>
                <option value="0" <?= ($configAniversario['ativado'] ?? 0) == 0 ? 'selected' : '' ?>>Desativada</option>
            </select>
        </div>
        <div class="form-group">
            <label>Desconto de Aniversário (%)</label>
            <input type="number" name="desconto_percentual" value="<?= $configAniversario['desconto_percentual'] ?? 15 ?>" required>
        </div>
        <button type="submit" class="btn-primary">Salvar</button>
    </form>
</div>

<div class="config-section">
    <h4><i class="fa fa-tag"></i> Cupões de Desconto</h4>
    <button class="btn btn-add" data-modal-target="#modal-cupom"><i class="fa fa-plus"></i> Criar Cupom</button>
    <table>
        <thead>
            <tr>
                <th>Código</th>
                <th>Desconto</th>
                <th>Validade</th>
                <th>Uso</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($cupoesArr as $c): ?>
            <tr>
                <td data-label="Código"><?= htmlspecialchars($c['codigo']) ?></td>
                <td data-label="Desconto"><?= htmlspecialchars($c['desconto_percentual']) ?>%</td>
                <td data-label="Validade"><?= htmlspecialchars(date('d/m/Y', strtotime($c['data_validade']))) ?></td>
                <td data-label="Uso"><?= htmlspecialchars($c['usos_atuais']) ?> / <?= htmlspecialchars($c['usos_maximos']) ?></td>
                <td data-label="Ações">
                    <div class="btn-group">
                        <button class="btn btn-editar" data-modal-target="#modal-cupom" data-id="<?= $c['id'] ?>" data-type="cupom"><i class="fa fa-edit"></i> Editar</button>
                        <a href="?action=excluir_cupom&id=<?= $c['id'] ?>" class="btn btn-excluir" onclick="return confirm('Excluir cupom?')"><i class="fa fa-trash"></i> Excluir</a>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div class="config-section">
    <h4><i class="fa fa-gift"></i> Vouchers de Presente</h4>
    <?php if(isset($_GET['voucher_success'])): ?><p class="mensagem">Voucher gerado com sucesso!</p><?php endif; ?>
    <form method="POST" class="admin-form" style="display: flex; gap: 15px; align-items: flex-end;">
        <input type="hidden" name="action" value="gerar_voucher">
        <div class="form-group" style="flex-grow: 1;">
            <label for="valor_voucher">Valor do Voucher (R$)</label>
            <input type="number" name="valor_voucher" step="0.01" min="1" required placeholder="Ex: 50.00">
        </div>
        <button type="submit" class="btn-primary">Gerar Voucher</button>
    </form>
    <table style="margin-top: 20px;">
        <thead>
            <tr>
                <th>Código</th>
                <th>Valor</th>
                <th>Validade</th>
                <th>Status</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php if(empty($vouchersArr)): ?>
                <tr><td colspan="5" style="text-align:center;">Nenhum voucher gerado.</td></tr>
            <?php else: ?>
                <?php foreach(array_reverse($vouchersArr) as $v): ?>
                <tr>
                    <td data-label="Código"><?= htmlspecialchars($v['codigo']) ?></td>
                    <td data-label="Valor">R$ <?= htmlspecialchars(number_format((float)$v['valor'], 2, ',', '.')) ?></td>
                    <td data-label="Validade"><?= !empty($v['data_validade']) ? htmlspecialchars(date('d/m/Y', strtotime($v['data_validade']))) : 'Não definida' ?></td>
                    <td data-label="Status"><span class="status-<?= $v['status'] === 'disponivel' ? 'aprovado' : 'cancelado' ?>"><?= ucfirst($v['status']) ?></span></td>
                    <td data-label="Ações">
                        <div class="btn-group">
                            <button class="btn btn-editar" data-modal-target="#modal-voucher-editar" data-id="<?= $v['id'] ?>" data-validade="<?= $v['data_validade'] ?? '' ?>"><i class="fa fa-edit"></i></button>
                            <a href="imprimir_voucher.php?id=<?= $v['id'] ?>" target="_blank" class="btn btn-info"><i class="fa fa-print"></i></a>
                            <a href="?action=excluir_voucher&id=<?= $v['id'] ?>" class="btn btn-excluir" onclick="return confirm('Tem certeza que deseja excluir este voucher?')"><i class="fa fa-trash"></i></a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>