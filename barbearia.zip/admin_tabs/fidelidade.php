<?php
// admin_tabs/fidelidade.php
// Contém o HTML da aba "Fidelidade".
// Variáveis como $configFidelidade e $clientesFidelidadePaginados vêm do admin_data.php
?>

<h3>Programa de Fidelidade</h3>
<?php if(isset($_GET['success'])): ?><p class="mensagem">Configurações salvas com sucesso!</p><?php endif; ?>

<div class="config-section">
    <h4>Configurações Gerais</h4>
    <form method="POST" class="admin-form">
        <input type="hidden" name="action" value="salvar_config_fidelidade">
        <div class="form-group">
            <label>Status do Programa</label>
            <select name="fidelidade_ativado">
                <option value="1" <?= ($configFidelidade['ativado'] ?? 0) == 1 ? 'selected' : '' ?>>Ativado</option>
                <option value="0" <?= ($configFidelidade['ativado'] ?? 0) == 0 ? 'selected' : '' ?>>Desativado</option>
            </select>
        </div>
        <div class="form-group">
            <label>Pontos para resgate</label>
            <input type="number" name="pontos_necessarios" value="<?= $configFidelidade['pontos_necessarios'] ?? 10 ?>" required>
        </div>
        <div class="form-group">
            <label>Desconto (%)</label>
            <input type="number" name="desconto_percentual" value="<?= $configFidelidade['desconto_percentual'] ?? 50 ?>" required>
        </div>
        <button type="submit" class="btn-primary">Salvar</button>
    </form>
</div>

<div class="view-controls" style="margin-top: 30px;">
    <h4>Pontos dos Clientes</h4>
    <form method="GET" class="filters">
        <input type="hidden" name="tab" value="fidelidade">
        <input type="text" name="busca_fidelidade" placeholder="Buscar por nome..." value="<?= htmlspecialchars($busca_fidelidade) ?>">
        <button type="submit" class="btn btn-primary" style="padding: 10px 15px;">Buscar</button>
    </form>
</div>

<table>
    <thead>
        <tr>
            <th>Cliente</th>
            <th>Pontos Atuais</th>
            <th style="width: 250px;">Ajustar Pontos</th>
        </tr>
    </thead>
    <tbody>
        <?php if(empty($clientesFidelidadePaginados)): ?>
            <tr><td colspan="3" style="text-align:center;">Nenhum cliente encontrado.</td></tr>
        <?php else: ?>
            <?php foreach($clientesFidelidadePaginados as $id => $cliente): ?>
            <tr>
                <td data-label="Cliente"><?= htmlspecialchars($cliente['nome']) ?></td>
                <td data-label="Pontos"><?= $pontosFidelidade[$id] ?? 0 ?></td>
                <td data-label="Ajustar">
                    <form method="POST" style="display: flex; gap: 5px; margin: 0;">
                        <input type="hidden" name="action" value="ajustar_pontos">
                        <input type="hidden" name="cliente_id" value="<?= $id ?>">
                        <input type="number" name="novos_pontos" value="<?= $pontosFidelidade[$id] ?? 0 ?>" style="width: 80px; padding: 8px;">
                        <button type="submit" class="btn btn-editar" style="padding: 8px 12px;">Salvar</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>
<div class="pagination"><?php for ($i = 1; $i <= $fidelidade_totalPages; $i++): ?><a href="?tab=fidelidade&fid_page=<?= $i ?>&busca_fidelidade=<?= urlencode($busca_fidelidade) ?>" class="<?= ($i == $fidelidade_currentPage ? 'current' : '') ?>"><?= $i ?></a><?php endfor; ?></div>