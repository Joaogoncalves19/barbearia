<?php
// admin_tabs/configuracoes.php
// Contém o HTML da aba "Configurações".
// Variáveis como $config, $configGeral, $configAgendamento, etc. vêm do admin_data.php
?>

<h3>Configurações do Sistema</h3>
<?php if(isset($_GET['success'])): ?><p class="mensagem">Configurações salvas com sucesso!</p><?php endif; ?>

<div class="config-section">
    <h4><i class="fa fa-check-circle"></i> Aprovação de Agendamentos</h4>
    <form class="admin-form" method="post" style="justify-content: flex-start;">
        <input type="hidden" name="action" value="salvar_config_aprovacao">
        <select name="modo_aprovacao">
            <option value="manual" <?= ($config['aprovar'] ?? 'manual') === 'manual' ? 'selected' : '' ?>>Manual (Requer aprovação do admin)</option>
            <option value="automatico" <?= ($config['aprovar'] ?? 'manual') === 'automatico' ? 'selected' : '' ?>>Automática (Aprovado ao agendar)</option>
        </select>
        <button type="submit" class="btn-primary" style="width: auto; padding: 10px 20px;">Salvar Modo</button>
    </form>
</div>

<div class="config-section">
    <h4><i class="fa fa-building"></i> Dados da Barbearia e Redes Sociais</h4>
    <form method="POST" class="admin-form" enctype="multipart/form-data">
        <input type="hidden" name="action" value="salvar_config_geral">
        <div class="form-grid">
            <div class="form-group"><label>Nome da Barbearia</label><input type="text" name="nome_barbearia" value="<?= htmlspecialchars($configGeral['nome_barbearia']) ?>" required></div>
            <div class="form-group"><label>Telefone de Contato</label><input type="text" name="telefone_contato" value="<?= htmlspecialchars($configGeral['telefone_contato']) ?>"></div>
            <div class="form-group"><label>Endereço</label><input type="text" name="endereco" value="<?= htmlspecialchars($configGeral['endereco']) ?>"></div>
            <div class="form-group"><label>Link do Instagram</label><input type="url" name="link_instagram" value="<?= htmlspecialchars($configGeral['link_instagram']) ?>" placeholder="https://instagram.com/seu_usuario"></div>
            <div class="form-group"><label>Link do Facebook</label><input type="url" name="link_facebook" value="<?= htmlspecialchars($configGeral['link_facebook']) ?>" placeholder="https://facebook.com/sua_pagina"></div>
            <div class="form-group"><label>Nº de WhatsApp (apenas números com código do país)</label><input type="text" name="link_whatsapp" value="<?= htmlspecialchars($configGeral['link_whatsapp']) ?>" placeholder="5521999999999"></div>
            <div class="form-group"><label>Latitude (para mapa)</label><input type="text" name="geofence_lat" value="<?= htmlspecialchars($configGeral['geofence_lat'] ?? '') ?>" placeholder="Ex: -22.906847"></div>
            <div class="form-group"><label>Longitude (para mapa)</label><input type="text" name="geofence_lon" value="<?= htmlspecialchars($configGeral['geofence_lon'] ?? '') ?>" placeholder="Ex: -43.172897"></div>
            <div class="form-group" style="grid-column: 1 / -1;"><label>Logo da Barbearia</label><?php if (!empty($configGeral['logo_path']) && file_exists($configGeral['logo_path'])): ?><img src="<?= htmlspecialchars($configGeral['logo_path']) ?>" alt="Logo Atual" style="max-height: 80px; display: block; margin-bottom: 10px; border-radius: 8px; background: #ddd; padding: 5px;"><?php endif; ?><input type="file" name="logo" accept="image/png, image/jpeg, image/gif"><p style="font-size:0.8em;">Envie um novo arquivo para substituir o logo atual. Recomendado: fundo transparente.</p></div>
        </div>
        <button type="submit" class="btn-primary">Salvar Dados da Barbearia</button>
    </form>
</div>

<div class="config-section">
    <h4><i class="fa fa-calendar-alt"></i> Políticas de Agendamento</h4>
    <form method="POST" class="admin-form">
        <input type="hidden" name="action" value="salvar_config_agendamento">
        <div class="form-grid">
            <div class="form-group"><label>Antecedência Mínima para Agendar (minutos)</label><input type="number" name="antecedencia_minima_minutos" value="<?= $configAgendamento['antecedencia_minima_minutos'] ?>" min="0" required></div>
            <div class="form-group"><label>Limite para Agendar no Futuro (dias)</label><input type="number" name="antecedencia_maxima" value="<?= $configAgendamento['antecedencia_maxima'] ?>" min="1" required></div>
            <div class="form-group"><label>Máximo de Serviços por Agendamento</label><input type="number" name="max_servicos" value="<?= $configAgendamento['max_servicos'] ?>" min="1" required></div>
        </div>
        <h4 style="margin-top: 30px;"><i class="fa fa-bell"></i> Notificações para Clientes (Painel e E-mail)</h4>
        <div class="form-grid">
            <div class="form-switch"><label for="notif_confirmacao">E-mail de confirmação de novo agendamento</label><input type="checkbox" id="notif_confirmacao" name="notif_confirmacao" value="1" <?= $configAgendamento['notif_confirmacao'] ? 'checked' : '' ?>></div>
            <div class="form-switch"><label for="notif_aprovacao">Notificação de aprovação/cancelamento</label><input type="checkbox" id="notif_aprovacao" name="notif_aprovacao" value="1" <?= $configAgendamento['notif_aprovacao'] ? 'checked' : '' ?>></div>
            <div class="form-switch"><label for="notif_lembrete">Lembrete 24h antes (requer config. de servidor)</label><input type="checkbox" id="notif_lembrete" name="notif_lembrete" value="1" <?= $configAgendamento['notif_lembrete'] ? 'checked' : '' ?>></div>
        </div>
        <button type="submit" class="btn-primary" style="margin-top:20px;">Salvar Políticas e Notificações</button>
    </form>
</div>

<div class="config-section">
    <h4><i class="fa fa-envelope"></i> Configurações de E-mail (PHPMailer)</h4>
    <form method="POST" class="admin-form">
        <input type="hidden" name="action" value="salvar_config_email">
        <div class="form-grid">
            <div class="form-group"><label>Host do Servidor SMTP</label><input type="text" name="host" value="<?= htmlspecialchars($configEmail['host'] ?? 'smtp.gmail.com') ?>" required></div>
            <div class="form-group"><label>Usuário SMTP</label><input type="email" name="username" value="<?= htmlspecialchars($configEmail['username'] ?? '') ?>" required></div>
            <div class="form-group"><label>Senha de App</label><input type="password" name="password" placeholder="Preencha apenas para alterar"><p style="font-size:0.8em;">Para Gmail, gere uma "Senha de App" na sua conta Google.</p></div>
            <div class="form-group"><label>Porta SMTP</label><input type="number" name="port" value="<?= htmlspecialchars($configEmail['port'] ?? '465') ?>" required></div>
            <div class="form-group"><label>Criptografia</label><select name="smtp_secure"><option value="tls" <?= ($configEmail['smtp_secure'] ?? 'tls') == 'tls' ? 'selected' : '' ?>>TLS</option><option value="ssl" <?= ($configEmail['smtp_secure'] ?? 'ssl') == 'ssl' ? 'selected' : '' ?>>SSL</option></select></div>
            <div class="form-group"><label>Nome do Remetente</label><input type="text" name="nome_remetente" value="<?= htmlspecialchars($configEmail['nome_remetente'] ?? '') ?>" required></div>
        </div>
        <button type="submit" class="btn-primary">Salvar Configurações de E-mail</button>
    </form>
</div>

<div class="config-section">
    <h4><i class="fa fa-cogs"></i> Manutenção do Sistema</h4>
    <div class="form-grid">
        <div>
            <h5>Backup de Dados</h5>
            <?php if (class_exists('ZipArchive')): ?>
                <p style="font-size:0.9em;">Crie e descarregue uma cópia de segurança de todos os seus dados.</p>
                <a href="?action=backup_dados" class="btn btn-editar"><i class="fa fa-download"></i> Fazer Backup Agora</a>
            <?php else: ?>
                <p style="font-size:0.9em; color: var(--error-color);"><b>Funcionalidade indisponível.</b> A extensão <code>zip</code> do PHP não está ativada no seu servidor.</p>
            <?php endif; ?>
        </div>
        <div>
            <h5>Limpeza de Histórico</h5>
            <p style="font-size:0.9em;">Remova agendamentos concluídos ou cancelados há mais de 1 ano.</p>
            <a href="?action=limpar_agendamentos_antigos" class="btn btn-excluir" onclick="return confirm('Tem a certeza? Esta ação não pode ser desfeita.')"><i class="fa fa-trash"></i> Limpar Agendamentos Antigos</a>
        </div>
    </div>
</div>

<div class="config-section">
    <h4><i class="fa fa-user-shield"></i> Gerenciar Usuários do Painel</h4>
    <button class="btn btn-add" data-modal-target="#modal-usuario"><i class="fa fa-plus"></i> Adicionar Usuário</button>
    <table>
        <thead><tr><th>Usuário</th><th>Ações</th></tr></thead>
        <tbody>
            <?php foreach ($usersArr as $u): ?>
            <tr>
                <td data-label="Usuário"><?= htmlspecialchars($u['username']) ?></td>
                <td data-label="Ações">
                    <div class="btn-group">
                        <button class="btn btn-editar" data-modal-target="#modal-usuario" data-id="<?= htmlspecialchars($u['username']) ?>" data-type="usuario"><i class="fa fa-edit"></i> Editar</button>
                        <a href="?action=excluir_usuario&username=<?= htmlspecialchars($u['username']) ?>" class="btn btn-excluir" onclick="return confirm('Excluir este usuário?')"><i class="fa fa-trash"></i> Excluir</a>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div class="theme-customizer">
    <h4><i class="fa fa-paint-brush"></i> Personalizar Cores do Tema</h4>
    <form method="POST">
        <input type="hidden" name="action" value="salvar_tema">
        <?php 
        $default_colors = [ 'primary-color' => '#333333', 'secondary-color' => '#007bff', 'background-color' => '#f8f9fa', 'card-background' => '#ffffff', 'border-color' => '#e0e0e0', 'success-color' => '#28a745', 'error-color' => '#dc3545', 'text-color' => '#495057', 'warning-color' => '#ffc107' ]; 
        $current_colors = $default_colors; 
        if (file_exists($themeConfigFile)) { 
            $current_colors = array_merge($default_colors, json_decode(file_get_contents($themeConfigFile), true) ?: []); 
        } 
        $color_labels = [ 'primary-color' => 'Primária (Títulos)', 'secondary-color' => 'Secundária (Links, Botões)', 'background-color' => 'Fundo da Página', 'card-background' => 'Fundo dos Cards', 'border-color' => 'Bordas', 'success-color' => 'Sucesso', 'error-color' => 'Erro', 'text-color' => 'Texto Principal', 'warning-color' => 'Aviso' ]; 
        ?>
        <div class="color-grid">
            <?php foreach ($default_colors as $key => $color): ?>
            <div class="color-picker-group">
                <label for="<?= $key ?>"><?= $color_labels[$key] ?>:</label>
                <input type="color" id="<?= $key ?>" name="colors[<?= $key ?>]" value="<?= htmlspecialchars($current_colors[$key]) ?>">
            </div>
            <?php endforeach; ?>
        </div>
        <button type="submit" class="btn-primary" style="margin-top: 20px; width: auto; padding: 10px 20px;">Salvar Cores</button>
    </form>
</div>