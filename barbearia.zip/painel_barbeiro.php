<?php
session_start();
date_default_timezone_set('America/Sao_Paulo');

// FUNÇÃO DE DETECÇÃO ATUALIZADA
function isMobileDevice() {
    if (!isset($_SERVER['HTTP_USER_AGENT'])) { return false; }
    $user_agent = strtolower($_SERVER['HTTP_USER_AGENT']);
    if (strpos($user_agent, 'android') !== false) { return false; }
    if (strpos($user_agent, 'iphone') !== false || strpos($user_agent, 'ipad') !== false || strpos($user_agent, 'ipod') !== false) { return true; }
    return false;
}

if (!isset($_SESSION['barbeiro_loggedin'])) {
    header('Location: login.php');
    exit;
}

require_once 'functions.php';

$mensagem_sucesso = '';
if (isset($_SESSION['agendamento_sucesso'])) {
    $mensagem_sucesso = $_SESSION['agendamento_sucesso'];
    unset($_SESSION['agendamento_sucesso']);
}

$barbeiro_id = $_SESSION['barbeiro_id'];

// --- ATUALIZAÇÃO: CHAVES COMPLETAS PARA NÃO PERDER DADOS DE PLANOS ---
$keys_agendamentos = [
    'id', 'nome', 'email', 'telefone', 'barbeiro_id', 'servicos_ids', 
    'data', 'hora', 'status', 'desconto_aplicado', 'tipo_desconto', 
    'observacoes', 'produtos_vendidos', 'plano_provisorio' 
];

$configGeral = carregarConfigGeral();
$servicosArr = lerDados('servicos.txt', ['id', 'nome', 'valor']);
$combosArr = lerDados('combos.txt', ['id', 'nome', 'servicos_ids', 'valor']); 
$agendamentosArr = lerDados('agendamentos.txt', $keys_agendamentos);
$clientesArr = lerDados('clientes.txt', ['id', 'nome', 'email', 'telefone']);
$avaliacoesArr = lerDados('avaliacoes.txt', ['id', 'agendamento_id', 'cliente_id', 'barbeiro_id', 'rating', 'comment', 'timestamp']);
$barbeirosArr = lerDados('barbeiros.txt', ['id', 'nome', 'foto']);
$planosArr = lerDados('planos.txt', ['id', 'nome', 'valor']); 
$barbeiro_atual = $barbeirosArr[$barbeiro_id] ?? null;
$configFidelidade = getFidelityConfig();

$action = $_POST['action'] ?? $_GET['action'] ?? null;
$id = $_POST['id'] ?? $_GET['id'] ?? null;

// --- LÓGICA DE AÇÕES (APROVAR, CONCLUIR, CANCELAR) ---
if (($action === 'aprovar' || $action === 'concluir' || $action === 'cancelar') && !empty($id)) {
    $novoStatus = ($action === 'aprovar') ? 'aprovado' : (($action === 'concluir') ? 'concluido' : 'cancelado');
    
    if (isset($agendamentosArr[$id]) && $agendamentosArr[$id]['barbeiro_id'] === $barbeiro_id) {
        $agendamento_atual = $agendamentosArr[$id];
        $status_anterior = $agendamento_atual['status'];
        
        // Atualiza o status em memória
        $agendamentosArr[$id]['status'] = $novoStatus;

        // Busca dados do cliente (Necessário para fidelidade e indicação)
        $cliente = getClientePorEmailTelefoneOuCPF($agendamento_atual['telefone']);
        if (!$cliente) {
            $cliente = getClientePorEmailTelefoneOuCPF($agendamento_atual['email']);
        }

        // --- LÓGICA AO CONCLUIR ---
        if ($novoStatus === 'concluido' && $status_anterior !== 'concluido') {
            
            // 1. PONTOS DE FIDELIDADE (Para o Cliente Visitante)
            if (($configFidelidade['ativado'] ?? 0) && $cliente) {
                $assinatura = getAssinaturaCliente($cliente['id']);
                $tem_assinatura = ($assinatura && $assinatura['status'] === 'ativo');

                if (!$tem_assinatura) {
                    $pontos_atuais = getClientFidelityPoints($cliente['id']);
                    updateClientFidelityPoints($cliente['id'], $pontos_atuais + 1, "Agendamento concluído");
                }
            }

            // 2. ATIVAÇÃO DE ASSINATURA (ADESÃO NO LOCAL)
            $plano_id_adesao = $agendamento_atual['plano_provisorio'] ?? '';
            $tipo_desconto = $agendamento_atual['tipo_desconto'] ?? '';

            if ($cliente && $tipo_desconto === 'adesao_plano' && !empty($plano_id_adesao)) {
                // Ativa por 30 dias a partir de hoje
                salvarAssinaturaCliente($cliente['id'], $plano_id_adesao, '+30 days');
                criarNotificacao($cliente['id'], "Sua assinatura VIP foi ativada com sucesso pelo barbeiro!");
            }

            // 3. PONTOS DE INDICAÇÃO (Para o Padrinho) - NOVO
            // Lógica: Se o cliente foi indicado E esta é a primeira conclusão de serviço dele
            if ($cliente && !empty($cliente['indicado_por_id'])) {
                
                // Verifica se é a PRIMEIRA visita concluída
                // (Como acabamos de atualizar o status para 'concluido' em memória, contamos quantos 'concluido' existem)
                $concluidosCount = 0;
                foreach ($agendamentosArr as $ag) {
                    // Verifica se o agendamento pertence a este cliente
                    $emailAg = $ag['email'] ?? '';
                    $telAg = limparTelefone($ag['telefone'] ?? '');
                    $emailCli = $cliente['email'] ?? '';
                    $telCli = limparTelefone($cliente['telefone'] ?? '');

                    if (($emailAg === $emailCli || $telAg === $telCli) && ($ag['status'] === 'concluido')) {
                        $concluidosCount++;
                    }
                }

                // Se o contador for exatamente 1, significa que este é o primeiro agendamento concluído
                if ($concluidosCount === 1) {
                    processarRecompensaIndicacao($cliente['indicado_por_id'], $cliente['nome']);
                }
            }
        }
        
        salvarDados('agendamentos.txt', $agendamentosArr, $keys_agendamentos);
        
        // --- ENVIO DE E-MAIL CORRIGIDO ---
        $configAgendamentoEmail = carregarConfigAgendamento(); 
        if (($configAgendamentoEmail['notif_aprovacao'] ?? 0) == 1 && ($novoStatus === 'aprovado' || $novoStatus === 'cancelado')) {
             $dados_email = [
                'nome_cliente' => $agendamento_atual['nome'],
                'data_agendamento' => date('d/m/Y', strtotime($agendamento_atual['data'])),
                'hora_agendamento' => $agendamento_atual['hora'],
                
                // CORREÇÃO AQUI: Verifica Combos E Serviços com Fallback melhor
                'servicos' => array_map(function($sid) use ($servicosArr, $combosArr) {
                    $sid = trim($sid);
                    if (isset($servicosArr[$sid])) {
                        return $servicosArr[$sid]['nome'];
                    } elseif (isset($combosArr[$sid])) {
                        return $combosArr[$sid]['nome'] . " (Combo)";
                    }
                    return 'Item (removido)'; // Fallback melhor que "?"
                }, explode(',', $agendamento_atual['servicos_ids'])),
                
                'barbeiro' => $barbeirosArr[$agendamento_atual['barbeiro_id']]['nome'] ?? 'Não especificado',
                'tipo_desconto' => $agendamento_atual['tipo_desconto'] ?? '' 
            ];
            $template = ($novoStatus === 'aprovado') ? 'aprovado' : 'cancelado';
            $assunto = ($novoStatus === 'aprovado') ? 'Seu Agendamento foi Aprovado!' : 'Informações sobre seu Agendamento';
            enviarEmail($agendamento_atual['email'], $assunto, $template, $dados_email);
        }

        if ($cliente) {
            $cliente_id_notif = $cliente['id'];
            $data_hora_formatada = date('d/m/Y', strtotime($agendamento_atual['data']))." às ".$agendamento_atual['hora'];
            if ($novoStatus === 'aprovado') {
                criarNotificacao($cliente_id_notif, "Seu agendamento para ".$data_hora_formatada." foi APROVADO.");
            } elseif ($novoStatus === 'cancelado') {
                criarNotificacao($cliente_id_notif, "Seu agendamento para ".$data_hora_formatada." foi CANCELADO pelo estabelecimento.");
            }
        }
    }
    header('Location: painel_barbeiro.php');
    exit;
}

if ($action === 'adicionar_produto') {
    $agendamento_id = $_POST['agendamento_id'];
    $nome_produto = trim(htmlspecialchars($_POST['nome_produto']));
    $valor_produto = (float) str_replace(',', '.', $_POST['valor_produto']);

    if (!empty($agendamento_id) && !empty($nome_produto) && $valor_produto > 0 && isset($agendamentosArr[$agendamento_id]) && $agendamentosArr[$agendamento_id]['barbeiro_id'] === $barbeiro_id) {
        adicionarProdutoAoAgendamento($agendamento_id, $nome_produto, $valor_produto);
    }
    header('Location: painel_barbeiro.php');
    exit;
}
if ($action === 'salvar_config_almoco') {
    $status_almoco = $_POST['status_almoco'];
    $horario_almoco = $_POST['horario_almoco'];
    $almocoFile = DATA_DIR . 'config_almoco_barbeiro.txt';
    $fp = fopen($almocoFile, 'c+');
    if ($fp && flock($fp, LOCK_EX)) {
        $linhas = [];
        while (($linha = fgets($fp)) !== false) { $linhas[] = trim($linha); }
        $novasLinhas = array_filter($linhas, function($l) use ($barbeiro_id) {
            if (empty(trim($l))) return false;
            return strpos($l, "$barbeiro_id|") !== 0;
        });
        $novasLinhas[] = "$barbeiro_id|$status_almoco|$horario_almoco";
        ftruncate($fp, 0); rewind($fp); fwrite($fp, implode("\n", $novasLinhas) . "\n");
        flock($fp, LOCK_UN);
    }
    if($fp) fclose($fp);
    header('Location: painel_barbeiro.php');
    exit;
}

$config_almoco_barbeiro = ['status' => 'inativo', 'horario' => '12:00'];
$almocoFile = DATA_DIR . 'config_almoco_barbeiro.txt';
if(file_exists($almocoFile)) {
    $fp = fopen($almocoFile, 'r');
    if ($fp && flock($fp, LOCK_SH)) {
        while (($linha = fgets($fp)) !== false) {
            $parts = explode('|', trim($linha));
            if($parts[0] === $barbeiro_id) { $config_almoco_barbeiro['status'] = $parts[1]; $config_almoco_barbeiro['horario'] = $parts[2]; break; }
        }
        flock($fp, LOCK_UN); fclose($fp);
    }
}

$horarios_para_almoco = [];
$horarioTrabalhoReferencia = null;
for ($i = 1; $i <= 5; $i++) { $horarioTrabalhoReferencia = getHorarioDeTrabalho($barbeiro_id, $i); if ($horarioTrabalhoReferencia) break; }
if ($horarioTrabalhoReferencia) {
    $start = strtotime($horarioTrabalhoReferencia['inicio']); $end = strtotime($horarioTrabalhoReferencia['fim']);
    while ($start < $end) { $horarios_para_almoco[] = date('H:i', $start); $start = strtotime('+30 minutes', $start); }
    if (count($horarios_para_almoco) > 1) array_pop($horarios_para_almoco);
}

$meusAgendamentos = array_filter($agendamentosArr, function($ag) use ($barbeiro_id) { return $ag['barbeiro_id'] === $barbeiro_id; });
$hoje = date('Y-m-d');
$agendamentosPendentes = array_filter($meusAgendamentos, function($a) { return $a['status'] === 'pendente'; });
$agendamentosHoje = array_filter($meusAgendamentos, function($a) use ($hoje) { return $a['data'] === $hoje && $a['status'] === 'aprovado'; });
$agendamentosFuturos = array_filter($meusAgendamentos, function($a) use ($hoje) { return $a['data'] > $hoje && $a['status'] === 'aprovado'; });
$agendamentosPassados = array_filter($meusAgendamentos, function($a) use ($hoje) { return $a['data'] < $hoje || !in_array($a['status'], ['aprovado', 'pendente']); });

uasort($agendamentosHoje, function($a, $b) { return strcmp($a['hora'], $b['hora']); });
uasort($agendamentosFuturos, function($a, $b) { return strtotime($a['data'] . ' ' . $a['hora']) - strtotime($b['data'] . ' ' . $b['hora']); });
uasort($agendamentosPassados, function($a, $b) { return strtotime($b['data'] . ' ' . $b['hora']) - strtotime($a['data'] . ' ' . $a['hora']); });

$itemsPerPage = 5;
$totalItems = count($agendamentosPassados);
$totalPages = $totalItems > 0 ? ceil($totalItems / $itemsPerPage) : 1;
$currentPage = max(1, min((int)($_GET['page'] ?? 1), $totalPages));
$agendamentosPaginados = array_slice($agendamentosPassados, ($currentPage - 1) * $itemsPerPage, $itemsPerPage, true);

$agendamentos_concluidos_hoje = array_filter($meusAgendamentos, function($ag) use ($hoje) { return $ag['data'] === $hoje && $ag['status'] === 'concluido'; });
$receita_total_hoje = 0;
foreach($agendamentos_concluidos_hoje as $ag) {
    $sids = explode(',', $ag['servicos_ids']);
    foreach($sids as $sid) {
        $sid = trim($sid);
        if(isset($servicosArr[$sid])) { $receita_total_hoje += (float)$servicosArr[$sid]['valor']; }
        elseif(isset($combosArr[$sid])) { $receita_total_hoje += (float)$combosArr[$sid]['valor']; }
    }
    $prods = !empty($ag['produtos_vendidos']) ? json_decode($ag['produtos_vendidos'], true) : [];
    foreach($prods as $p) $receita_total_hoje += (float)$p['valor'];
    
    $receita_total_hoje -= (float)($ag['desconto_aplicado'] ?? 0);
}
$avaliacoes_barbeiro = array_filter($avaliacoesArr, function($av) use ($barbeiro_id) { return $av['barbeiro_id'] === $barbeiro_id; });
$media_avaliacoes = count($avaliacoes_barbeiro) > 0 ? round(array_sum(array_column($avaliacoes_barbeiro, 'rating')) / count($avaliacoes_barbeiro), 1) : 'N/A';

function renderAgendamentosTable($agendamentos, $servicosArr, $combosArr, $isHistorico = false) {
    if (empty($agendamentos)) {
        echo "<p style='text-align:center; padding: 20px; background: #f9f9f9; border-radius: 8px;'>Nenhum agendamento encontrado.</p>";
        return;
    }
?>
<table>
    <thead>
        <tr>
            <th>Cliente</th><th>Data & Hora</th><th>Detalhes</th><th>Total</th><th>Status</th>
            <?php if (!$isHistorico): ?><th>Ações</th><?php endif; ?>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($agendamentos as $ag):
            $servicosIds = explode(',', $ag['servicos_ids']);
            $servicoNomes = [];
            $valor_total_bruto = 0;
            
            foreach ($servicosIds as $sid) {
                $sid = trim($sid);
                if (isset($servicosArr[$sid])) {
                    $servicoNomes[] = $servicosArr[$sid]['nome'];
                    $valor_total_bruto += (float)$servicosArr[$sid]['valor'];
                } elseif (isset($combosArr[$sid])) {
                    $servicoNomes[] = $combosArr[$sid]['nome'] . " (Combo)";
                    $valor_total_bruto += (float)$combosArr[$sid]['valor'];
                } else {
                    $servicoNomes[] = 'Item removido'; // Melhor que '?'
                }
            }

            $produtos_vendidos = !empty($ag['produtos_vendidos']) ? json_decode($ag['produtos_vendidos'], true) : [];
            $valor_total_produtos = array_sum(array_column($produtos_vendidos, 'valor'));
            
            $desconto_valor = (float) ($ag['desconto_aplicado'] ?? 0);
            $tipo_desconto = $ag['tipo_desconto'] ?? '';
            $observacoes = $ag['observacoes'] ?? '';
            $valor_final = $valor_total_bruto + $valor_total_produtos - $desconto_valor;
            
            $reagendar_url = isMobileDevice() ? 'reagendar_barbeiro.php' : 'reagendar_barbeiro_pc.php';
            $isAdesao = ($tipo_desconto === 'adesao_plano');
            $isVip = ($tipo_desconto === 'assinatura_vip' || $tipo_desconto === 'assinatura');
        ?>
        <tr class="<?= $ag['status'] === 'pendente' ? 'pendente' : '' ?>">
            <td data-label="Cliente">
                <?= htmlspecialchars($ag['nome']) ?>
                <?php if($isVip): ?><span style="background: #28a745; color: white; padding: 2px 5px; border-radius: 4px; font-size: 0.7em; font-weight: bold; margin-left: 5px;">VIP</span><?php endif; ?>
                <?php if($isAdesao): ?><span style="background: #6f42c1; color: white; padding: 2px 5px; border-radius: 4px; font-size: 0.7em; font-weight: bold; margin-left: 5px;">ADESÃO</span><?php endif; ?>
            </td>
            <td data-label="Data & Hora"><?= htmlspecialchars(date('d/m/Y', strtotime($ag['data']))) ?> às <?= htmlspecialchars($ag['hora']) ?></td>
            <td data-label="Detalhes">
                <?= htmlspecialchars(implode(', ', $servicoNomes)) ?>
                <?php if (!empty($produtos_vendidos)): ?><div class="detalhes-extra produtos-vendidos"><strong>Produtos:</strong><ul><?php foreach($produtos_vendidos as $p): ?><li><?= htmlspecialchars($p['nome']) ?> - R$<?= number_format($p['valor'], 2, ',', '.') ?></li><?php endforeach; ?></ul></div><?php endif; ?>
                <?php if ($desconto_valor > 0): 
                    $icon = 'fa-tag'; 
                    if ($tipo_desconto === 'fidelidade') $icon = 'fa-star'; 
                    if ($tipo_desconto === 'aniversario') $icon = 'fa-birthday-cake'; 
                    if ($tipo_desconto === 'adesao_plano') $icon = 'fa-crown'; 
                    if ($tipo_desconto === 'assinatura_vip') $icon = 'fa-check-circle';
                ?>
                <div class="detalhes-extra desconto-info" style="<?= $isAdesao ? 'border-left-color: #6f42c1;' : '' ?>">
                    <i class="fa <?= $icon ?>"></i> Desconto (<?= ucfirst($tipo_desconto) ?>): R$<?= number_format($desconto_valor, 2, ',', '.') ?>
                </div>
                <?php endif; ?>
                <?php if (!empty($observacoes)): ?><div class="detalhes-extra observacao-cliente"><i class="fa fa-comment-dots"></i> <?= htmlspecialchars($observacoes) ?></div><?php endif; ?>
            </td>
            <td data-label="Total">R$<?= number_format($valor_final, 2, ',', '.') ?></td>
            <td data-label="Status"><span class="status-<?= htmlspecialchars($ag['status']) ?>"><?= ucfirst(str_replace('_', ' ',$ag['status'])) ?></span></td>
            <?php if (!$isHistorico): ?>
            <td data-label="Ações">
                <div class="btn-group">
                    <?php if (in_array($ag['status'], ['aprovado', 'pendente'])): ?>
                        <?php if ($ag['status'] === 'pendente'): ?>
                            <a href="?action=aprovar&id=<?= $ag['id'] ?>" class="btn btn-aprovar" title="Aprovar"><i class="fa fa-check"></i></a>
                        <?php else: ?>
                            <a href="?action=concluir&id=<?= $ag['id'] ?>" 
                               class="btn" 
                               style="background-color: <?= $isAdesao ? '#6f42c1' : 'var(--primary-color)' ?>;" 
                               title="<?= $isAdesao ? 'Concluir e Ativar Assinatura' : 'Marcar como Concluído' ?>"
                               onclick="return confirm('<?= $isAdesao ? 'Este agendamento contém uma ADESÃO DE PLANO. Ao concluir, a assinatura do cliente será ativada automaticamente. O pagamento foi recebido?' : 'Marcar este atendimento como concluído?' ?>')">
                                <i class="fa <?= $isAdesao ? 'fa-crown' : 'fa-check-double' ?>"></i>
                            </a>
                        <?php endif; ?>
                        
                        <a href="<?= $reagendar_url ?>?id=<?= htmlspecialchars($ag['id']) ?>" class="btn btn-editar" title="Reagendar"><i class="fa fa-calendar-alt"></i></a>
                    <?php endif; ?>
                    
                    <button class="btn" style="background-color: #6f42c1;" data-modal-target="#modal-add-produto" data-id="<?= htmlspecialchars($ag['id']) ?>" title="Adicionar Produto"><i class="fa fa-plus"></i></button>
                    
                    <?php if (in_array($ag['status'], ['aprovado', 'pendente'])): ?>
                        <a href="?action=cancelar&id=<?= $ag['id'] ?>" class="btn btn-excluir" onclick="return confirm('Tem certeza que deseja cancelar este agendamento? O cliente será notificado.')" title="Cancelar"><i class="fa fa-times-circle"></i></a>
                    <?php endif; ?>
                </div>
            </td>
            <?php endif; ?>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?php } ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel do Barbeiro - <?= htmlspecialchars($barbeiro_atual['nome']) ?></title>
    <link rel="stylesheet" href="css/style.css"><link rel="stylesheet" href="css/custom_theme.css.php">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .header { align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 15px; }
        .header-info { display: flex; align-items: center; gap: 15px; }
        .header-info h2 { margin: 0; font-size: 1.5rem; }
        .header-info .barbearia-name { font-size: 0.8rem; color: #6c757d; text-transform: uppercase; display: block; margin-top: 4px; }
        .header img.barbeiro-foto { width: 80px; height: 80px; border-radius: 50%; object-fit: cover; border: 3px solid var(--secondary-color); }
        .header-actions { display: flex; flex-wrap: wrap; gap: 10px; }
        .stats-bar { display: flex; background-color: #f8f9fa; border-radius: 10px; padding: 15px; justify-content: space-around; margin-bottom: 30px; border: 1px solid var(--border-color); flex-wrap: wrap; gap: 15px; }
        .stat-item { text-align: center; }
        .stat-item .value { font-size: 1.8rem; font-weight: bold; color: var(--primary-color); }
        .stat-item .label { font-size: 0.9rem; color: #6c757d; }
        h3 { margin-top: 40px; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 2px solid var(--border-color); }
        .detalhes-extra { font-size: 0.9em; color: #666; background-color: #f8f9fa; border-left: 3px solid var(--secondary-color); padding: 8px; margin-top: 8px; border-radius: 4px; }
        .detalhes-extra strong { color: var(--primary-color); }
        .detalhes-extra ul { list-style: none; padding: 0; margin: 0; }
        .desconto-info { border-left-color: var(--success-color); }
        .observacao-cliente { border-left-color: var(--warning-color); }
        .pending-notification-bar { padding: 15px; background-color: var(--warning-color); color: var(--primary-color); text-align: center; font-weight: bold; margin-bottom: 20px; border-radius: 8px; }
        .notification-bar { display: none; padding: 15px; background-color: var(--secondary-color); color: white; text-align: center; font-weight: bold; position: sticky; top: 0; z-index: 1000; }
        .notification-bar a { color: white; text-decoration: underline; font-weight: bold; }
        tr.pendente { background-color: #fffbe6 !important; }
    </style>
</head>
<body class="admin-page">
<div class="notification-bar" id="notification-bar">
    Você tem um novo agendamento! <a href="painel_barbeiro.php">Atualizar página</a>.
</div>
<div class="container admin-container">
    <div class="header">
        <div class="header-info">
            <?php if($barbeiro_atual && !empty($barbeiro_atual['foto'])): ?><img src="<?= htmlspecialchars($barbeiro_atual['foto']) ?>" alt="Foto de <?= htmlspecialchars($barbeiro_atual['nome']) ?>" class="barbeiro-foto"><?php endif; ?>
            <div>
                <h2>Painel de <?= htmlspecialchars($barbeiro_atual['nome']) ?></h2>
                <span class="barbearia-name"><?= htmlspecialchars(strtoupper($configGeral['nome_barbearia'])) ?></span>
            </div>
        </div>
        <div class="header-actions">
            <a href="agendamento_manual_barbeiro.php" class="btn btn-add"><i class="fa fa-plus"></i> Agendamento Manual</a>
            <button class="btn" style="background-color: #ffc107; color: #212529;" data-modal-target="#modal-almoco"><i class="fa fa-utensils"></i> Almoço</button>
            <a href="painel_barbeiro.php" class="btn" style="background-color:#6c757d;"><i class="fa fa-sync-alt"></i></a>
            <a href="login.php?logout=1" class="btn-logout"><i class="fa fa-sign-out-alt"></i></a>
        </div>
    </div>
    <?php if ($mensagem_sucesso): ?><div class="mensagem"><?= $mensagem_sucesso ?></div><?php endif; ?>
    <?php if (count($agendamentosPendentes) > 0): ?><div class="pending-notification-bar"><i class="fa fa-clock"></i> Você tem <strong><?= count($agendamentosPendentes) ?></strong> agendamento(s) aguardando sua aprovação.</div><?php endif; ?>
    <div class="stats-bar">
        <div class="stat-item"><div class="value"><?= count($agendamentos_concluidos_hoje) ?></div><div class="label">Concluídos Hoje</div></div>
        <div class="stat-item"><div class="value">R$<?= number_format($receita_total_hoje, 2, ',', '.') ?></div><div class="label">Receita de Hoje</div></div>
        <div class="stat-item"><div class="value"><i class="fa fa-star" style="color:var(--warning-color);"></i> <?= $media_avaliacoes ?></div><div class="label">Sua Média Geral</div></div>
    </div>
    
    <?php if (count($agendamentosPendentes) > 0): ?><h3>Agendamentos para Aprovar</h3><?php renderAgendamentosTable($agendamentosPendentes, $servicosArr, $combosArr); ?><?php endif; ?>
    <h3>Agenda de Hoje (<?= date('d/m/Y') ?>)</h3><?php renderAgendamentosTable($agendamentosHoje, $servicosArr, $combosArr); ?>
    <h3>Próximos Agendamentos</h3><?php renderAgendamentosTable($agendamentosFuturos, $servicosArr, $combosArr); ?>
    <h3>Histórico de Agendamentos</h3><?php renderAgendamentosTable($agendamentosPaginados, $servicosArr, $combosArr, true); ?>
    
    <div class="pagination"><?php for ($i = 1; $i <= $totalPages; $i++) echo "<a href='?page=$i' class='".($i==$currentPage?'current':'')."'>$i</a>"; ?></div>
</div>
<div id="modal-add-produto" class="modal-overlay"><div class="modal-content"><button class="modal-close">&times;</button><h3>Adicionar Produto Vendido</h3><form method="post"><input type="hidden" name="action" value="adicionar_produto"><input type="hidden" name="agendamento_id" id="produto_agendamento_id_barbeiro"><div class="form-group"><label for="nome_produto">Nome</label><input type="text" name="nome_produto" required></div><div class="form-group"><label for="valor_produto">Valor (R$)</label><input type="number" name="valor_produto" step="0.01" required></div><button type="submit" class="btn-primary">Adicionar</button></form></div></div>
<div id="modal-almoco" class="modal-overlay"><div class="modal-content"><button class="modal-close">&times;</button><h3>Definir Horário de Almoço</h3><form method="post"><input type="hidden" name="action" value="salvar_config_almoco"><div class="form-group"><label>Status</label><select name="status_almoco" id="status_almoco" required><option value="ativo" <?= $config_almoco_barbeiro['status'] == 'ativo' ? 'selected' : '' ?>>Ativo</option><option value="inativo" <?= $config_almoco_barbeiro['status'] == 'inativo' ? 'selected' : '' ?>>Inativo</option></select></div><div class="form-group"><label>Início do Almoço</label><select name="horario_almoco" id="horario_almoco_select" required><?php if (empty($horarios_para_almoco)): ?><option value="">Não há horários</option><?php else: ?><?php foreach ($horarios_para_almoco as $horario): ?><option value="<?= $horario ?>" <?= ($config_almoco_barbeiro['horario'] ?? '') == $horario ? 'selected' : '' ?>><?= $horario ?></option><?php endforeach; ?><?php endif; ?></select><p style="font-size: 0.8em; color: #6c757d; margin-top: 10px; background-color: #f0f0f0; padding: 10px; border-radius: 5px;"><strong>Atenção:</strong> Ativar esta função bloqueará <strong>1 hora (2 slots)</strong> a partir do horário selecionado.</p></div><button type="submit" class="btn-primary">Salvar</button></form></div></div>
<script>
    let initialAppointmentCount = <?= count($meusAgendamentos) ?>;
    document.addEventListener('DOMContentLoaded', function () {
        const modals = document.querySelectorAll('.modal-overlay');
        const openModalButtons = document.querySelectorAll('[data-modal-target]');
        const closeModalButtons = document.querySelectorAll('.modal-close');
        function openModal(modal) { if (modal) modal.style.display = 'flex'; }
        function closeModal(modal) { if (modal) { modal.style.display = 'none'; const form = modal.querySelector('form'); if(form) form.reset(); } }
        openModalButtons.forEach(button => {
            button.addEventListener('click', () => {
                const modal = document.querySelector(button.dataset.modalTarget);
                if (!modal) return;
                openModal(modal);
                if(modal.id === 'modal-add-produto') {
                    modal.querySelector('#produto_agendamento_id_barbeiro').value = button.dataset.id;
                }
            });
        });
        closeModalButtons.forEach(button => button.addEventListener('click', () => closeModal(button.closest('.modal-overlay'))));
        modals.forEach(modal => modal.addEventListener('click', e => { if (e.target === modal) closeModal(modal); }));
        setInterval(function() {
            fetch('check_new_appointments.php?barbeiro_id=<?= $barbeiro_id ?>')
                .then(response => response.json())
                .then(data => {
                    if (data.appointment_count > initialAppointmentCount) {
                        document.getElementById('notification-bar').style.display = 'block';
                    }
                })
                .catch(error => console.error('Error checking for new appointments:', error));
        }, 15000);
    });
</script>
</body>
</html>