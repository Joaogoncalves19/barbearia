<?php
session_start();
date_default_timezone_set('America/Sao_Paulo');
require_once 'functions.php';

$pageTitle = 'Cadastre-se'; // Variável para o título no header_app.php

$configGeral = carregarConfigGeral();
$configIndicacao = getIndicacaoConfig(); 

$mensagem = '';
$sucesso = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim(htmlspecialchars($_POST['nome']));
    $email = trim(htmlspecialchars($_POST['email']));
    $telefone = limparTelefone($_POST['telefone']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $data_nascimento = $_POST['data_nascimento'];
    $cpf = limparTelefone($_POST['cpf']);
    $codigo_indicacao_usado = trim(strtoupper($_POST['codigo_indicacao'] ?? ''));

    if ($password !== $confirm_password) {
        $mensagem = "As senhas não coincidem.";
    } elseif (getClientePorEmailTelefoneOuCPF($email)) { // (Função segura)
        $mensagem = "Este e-mail já está cadastrado.";
    } elseif (getClientePorEmailTelefoneOuCPF($telefone)) { // (Função segura)
        $mensagem = "Este telefone já está cadastrado.";
    
    // --- INÍCIO DA CORREÇÃO (Campos Obrigatórios) ---
    } elseif (empty($cpf)) {
        $mensagem = "O CPF é obrigatório.";
    } elseif (empty($data_nascimento)) {
        $mensagem = "A data de nascimento é obrigatória.";
    // --- FIM DA CORREÇÃO ---

    } elseif (getClientePorEmailTelefoneOuCPF($cpf)) { // (Função segura)
        $mensagem = "Este CPF já está cadastrado.";
    } elseif (!validarCPF($cpf)) {
        $mensagem = "CPF inválido.";
    } else {
        $cliente_que_indicou = null;
        if (($configIndicacao['ativado'] ?? 0) && !empty($codigo_indicacao_usado)) {
            $cliente_que_indicou = getClientByReferralCode($codigo_indicacao_usado); // (Função segura)
            if (!$cliente_que_indicou) {
                $mensagem = "Código de indicação inválido.";
            }
        }
        
        if (empty($mensagem)) {
            $id = uniqid('cl-');
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $meu_codigo_indicacao = strtoupper(substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 6));
            $foto_perfil = 'uploads/default-profile.jpg';
            $status = 'inativo'; // Requer confirmação por e-mail
            $confirmation_token = bin2hex(random_bytes(32));

            // --- INÍCIO DA CORREÇÃO (BUG DESCONTO INDICAÇÃO) ---
            // Pega o ID do cliente que indicou (se existir)
            $id_do_indicador = $cliente_que_indicou ? $cliente_que_indicou['id'] : '';
            // --- FIM DA CORREÇÃO ---

            // --- CORREÇÃO: Adicionada a variável $id_do_indicador na 10ª posição ---
            $novaLinha = "$id|$nome|$email|$telefone|$password_hash|$data_nascimento|$foto_perfil|$meu_codigo_indicacao|$cpf|$id_do_indicador|$status|$confirmation_token\n";
            
            // --- ATUALIZAÇÃO DE SEGURANÇA (LOCK_EX) ---
            // Garante que a adição do novo cliente seja atômica
            file_put_contents(DATA_DIR . 'clientes.txt', $novaLinha, FILE_APPEND | LOCK_EX);
            // --- FIM DA ATUALIZAÇÃO ---

            // Envia e-mail de confirmação
            $dados_email = [
                'nome_cliente' => $nome,
                'link_confirmacao' => BASE_URL . "confirmar_email.php?token=$confirmation_token"
            ];
            enviarEmail($email, 'Confirme seu Cadastro', 'confirmar_cadastro', $dados_email);
            
            // NOTA: A premiação de pontos foi removida daqui. 
            // Agora ocorre apenas quando o agendamento é concluído (ver painel_barbeiro.php e admin.php).

            $sucesso = true;
            $mensagem = "Cadastro realizado com sucesso! Um e-mail de confirmação foi enviado para $email. Por favor, verifique sua caixa de entrada (e spam).";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro - <?= htmlspecialchars($configGeral['nome_barbearia']) ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/custom_theme.css.php">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'header_app.php'; ?>

    <div class="container" style="max-width: 500px; margin-top: 50px;">
        
        <h2>Crie sua Conta</h2>

        <?php if ($mensagem): ?>
            <p class="mensagem <?= $sucesso ? '' : 'erro' ?>"><?= $mensagem ?></p>
        <?php endif; ?>

        <?php if (!$sucesso): ?>
        <form method="POST">
            <div class="form-group">
                <label for="nome">Nome e Sobrenome</label>
                <div class="input-icon"><i class="fa fa-user"></i><input type="text" name="nome" id="nome" required value="<?= htmlspecialchars($_POST['nome'] ?? '') ?>"></div>
            </div>
            <div class="form-group">
                <label for="email">E-mail</label>
                <div class="input-icon"><i class="fa fa-envelope"></i><input type="email" name="email" id="email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"></div>
            </div>
            
            <div class="form-group">
                <label for="cpf">CPF</label>
                <div class="input-icon"><i class="fa fa-id-card"></i><input type="text" name="cpf" id="cpf" placeholder="000.000.000-00" value="<?= htmlspecialchars($_POST['cpf'] ?? '') ?>" required></div>
            </div>
            <div class="form-group">
                <label for="telefone">Telefone (WhatsApp)</label>
                <div class="input-icon"><i class="fa fa-phone"></i><input type="tel" name="telefone" id="telefone" placeholder="(99) 99999-9999" required value="<?= htmlspecialchars($_POST['telefone'] ?? '') ?>"></div>
            </div>
            <div class="form-group">
                <label for="data_nascimento">Data de Nascimento</label>
                <div class="input-icon"><i class="fa fa-calendar-alt"></i><input type="date" name="data_nascimento" id="data_nascimento" value="<?= htmlspecialchars($_POST['data_nascimento'] ?? '') ?>" required></div>
            </div>
            
            <div class="form-group">
                <label for="password">Senha</label>
                <div class="input-icon"><i class="fa fa-lock"></i><input type="password" name="password" id="password" required></div>
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirmar Senha</label>
                <div class="input-icon"><i class="fa fa-lock"></i><input type="password" name="confirm_password" id="confirm_password" required></div>
            </div>
            <?php if (($configIndicacao['ativado'] ?? 0)): ?>
            <div class="form-group">
                <label for="codigo_indicacao">Código de Indicação (Opcional)</label>
                <div class="input-icon"><i class="fa fa-gift"></i><input type="text" name="codigo_indicacao" id="codigo_indicacao" value="<?= htmlspecialchars($_GET['ref'] ?? '') ?>"></div>
            </div>
            <?php endif; ?>
            <button type="submit" class="btn-primary">Criar Conta</button>
        </form>
        <?php endif; ?>

        <p style="text-align: center; margin-top: 20px;">
            Já tem uma conta? <a href="login_cliente.php">Faça login aqui</a>
        </p>
    </div>
    
    <script>
    // Script para máscaras
    document.addEventListener('DOMContentLoaded', function() {
        const telInput = document.getElementById('telefone');
        if (telInput) {
            telInput.addEventListener('input', (e) => {
                let v = e.target.value.replace(/\D/g, '');
                v = v.replace(/^(\d{2})(\d)/g, '($1) $2');
                
                // --- INÍCIO DA CORREÇÃO ---
                // Remove a regra de 8 dígitos que estava causando o bug
                // v = v.replace(/(\d{4})(\d)/, '$1-$2'); // <-- LINHA REMOVIDA
                
                // Mantém apenas a regra de 9 dígitos
                v = v.replace(/(\d{5})(\d)/, '$1-$2');
                
                // Limita o tamanho total para 15 caracteres (XX) XXXXX-XXXX
                e.target.value = v.slice(0, 15);
                // --- FIM DA CORREÇÃO ---
            });
        }
        
        const cpfInput = document.getElementById('cpf');
        if (cpfInput) {
            cpfInput.addEventListener('input', (e) => {
                let v = e.target.value.replace(/\D/g, '');
                v = v.replace(/(\d{3})(\d)/, '$1.$2');
                v = v.replace(/(\d{3})(\d)/, '$1.$2');
                v = v.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
                e.target.value = v.slice(0, 14);
            });
        }
    });
    </script>
</body>
</html>