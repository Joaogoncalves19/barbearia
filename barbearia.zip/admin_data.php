<?php
// admin_data.php
// Prepara os dados para exibição no painel administrativo (Dashboard e Relatórios)

// --- DEFINIÇÃO DE PERÍODO (DASHBOARD/RELATÓRIOS) ---
$data_hoje = date('Y-m-d');
$data_inicio_filtro = $_GET['data_inicio'] ?? date('Y-m-01');
$data_fim_filtro = $_GET['data_fim'] ?? date('Y-m-t');

// Filtra os agendamentos para o período (USADO APENAS NO DASHBOARD E RELATÓRIOS)
$agendamentosFiltrados = array_filter($agendamentosArr, function($ag) use ($data_inicio_filtro, $data_fim_filtro) {
    if (!isset($ag['data'])) {
        return false;
    }
    return $ag['data'] >= $data_inicio_filtro && $ag['data'] <= $data_fim_filtro;
});
$agendamentosConcluidos = array_filter($agendamentosFiltrados, function($a) {
    return isset($a['status']) && $a['status'] === 'concluido';
});

// [NOVO] CARREGAMENTO DE DADOS DE PLANOS E ASSINATURAS
$planosArr = lerDados('planos.txt', ['id', 'nome', 'valor', 'servicos_ids']);
$assinaturasClientesArr = lerDados('clientes_assinaturas.txt', ['cliente_id', 'plano_id', 'data_inicio', 'data_fim', 'status']);

// --- CÁLCULOS DE ASSINATURAS (NOVO SISTEMA) ---
$totalAssinantesAtivos = 0;
$mrrAtual = 0; // Monthly Recurring Revenue (Receita Recorrente Mensal)
$planosPopulares = []; // Contagem de assinantes por plano
$assinaturasVencendo = []; // Assinaturas que vencem nos próximos 7 dias
$novasAssinaturasPeriodo = 0; // Assinaturas iniciadas no período do filtro

foreach($assinaturasClientesArr as $assinatura) {
    // Verifica status e validade
    $estaAtiva = (isset($assinatura['status']) && $assinatura['status'] === 'ativo' && $assinatura['data_fim'] >= $data_hoje);
    
    if ($estaAtiva) {
        $totalAssinantesAtivos++;
        
        // Calcula MRR
        if (isset($planosArr[$assinatura['plano_id']])) {
            $valorPlano = (float) $planosArr[$assinatura['plano_id']]['valor'];
            $mrrAtual += $valorPlano;
            
            // Contagem por plano para gráfico
            $nomePlano = $planosArr[$assinatura['plano_id']]['nome'];
            if (!isset($planosPopulares[$nomePlano])) {
                $planosPopulares[$nomePlano] = 0;
            }
            $planosPopulares[$nomePlano]++;
        }
        
        // Verifica vencimento próximo (7 dias)
        $dataVencimento = $assinatura['data_fim'];
        $dataLimiteAlerta = date('Y-m-d', strtotime('+7 days'));
        
        // Se vence nos próximos 7 dias e ainda não venceu (ou vence hoje)
        if ($dataVencimento <= $dataLimiteAlerta && $dataVencimento >= $data_hoje) {
            $tempAssinatura = $assinatura; // Cria cópia para não alterar o original
            $tempAssinatura['nome_cliente'] = $clientesArr[$assinatura['cliente_id']]['nome'] ?? 'Cliente Removido';
            $tempAssinatura['nome_plano'] = $planosArr[$assinatura['plano_id']]['nome'] ?? 'Plano Removido';
            $assinaturasVencendo[] = $tempAssinatura;
        }
    }

    // Contagem de novas adesões no período selecionado
    if ($assinatura['data_inicio'] >= $data_inicio_filtro && $assinatura['data_inicio'] <= $data_fim_filtro) {
        $novasAssinaturasPeriodo++;
    }
}
arsort($planosPopulares); // Ordena planos mais populares

// --- CÁLCULOS FINANCEIROS GERAIS ---
$receitaTotal = 0;
$receitaServicos = 0; // NOVO: Separação de receita
$receitaProdutos = 0;
$totalProdutos = 0;   
$receitaPlanos = 0;   // NOVO: Separação de receita
$totalDescontos = 0;
$economiaVIP = 0;     // NOVO: Desconto dado por assinatura
$totalDescontosMkt = 0; // Descontos de Marketing

$receitaDiaria = []; 

foreach ($agendamentosConcluidos as $ag) {
    // 1. Calcula valor BRUTO dos serviços (sem desconto)
    $sids = isset($ag['servicos_ids']) ? explode(',', $ag['servicos_ids']) : [];
    $valor_servicos_bruto = 0;
    foreach($sids as $sid) {
        $sid_limpo = trim($sid);
        if(isset($servicosArr[$sid_limpo])) {
            $valor_servicos_bruto += (float)$servicosArr[$sid_limpo]['valor'];
        } elseif (isset($combosArr[$sid_limpo])) {
             $valor_servicos_bruto += (float)$combosArr[$sid_limpo]['valor'];
        }
    }

    // 2. Calcula valor dos Produtos
    $valor_produtos_ag = 0;
    $produtos_vendidos = !empty($ag['produtos_vendidos']) ? json_decode($ag['produtos_vendidos'], true) : [];
    if (is_array($produtos_vendidos)) {
        foreach($produtos_vendidos as $produto) {
            $valor_produtos_ag += (float)($produto['valor'] ?? 0);
        }
    }
    $receitaProdutos += $valor_produtos_ag;
    $totalProdutos += $valor_produtos_ag;

    // 3. Processa Descontos
    $desconto = (float)($ag['desconto_aplicado'] ?? 0);
    $tipo_desconto = $ag['tipo_desconto'] ?? '';
    
    // Só soma ao "Total de Descontos" se for um valor positivo
    if ($desconto > 0) {
        $totalDescontos += $desconto;
    }

    // 4. Distribui a Receita Líquida
    // Receita Final = (Serviços + Produtos) - Desconto
    $valor_final_pago = ($valor_servicos_bruto + $valor_produtos_ag) - $desconto;
    
    if ($tipo_desconto === 'adesao_plano') {
        // Se é adesão, o valor pago é atribuído a Planos
        $receitaPlanos += $valor_final_pago;
    } else {
        // Se não é adesão, o valor pago é atribuído a Serviços (após descontar produtos)
        $receitaServicos += max(0, $valor_final_pago - $valor_produtos_ag);
    }
    
    // 5. Categoriza Economia VIP vs Marketing
    if ($tipo_desconto === 'assinatura_vip') {
        $economiaVIP += $desconto;
    } elseif ($desconto > 0 && $tipo_desconto !== 'adesao_plano') {
        $totalDescontosMkt += $desconto;
    }

    $receitaTotal += $valor_final_pago;

    // Para o gráfico de receita diária
    $data_ag = $ag['data'];
    if (!isset($receitaDiaria[$data_ag])) {
        $receitaDiaria[$data_ag] = 0;
    }
    $receitaDiaria[$data_ag] += $valor_final_pago;
}
ksort($receitaDiaria);

$vendasProdutos = getVendasProdutosNoPeriodo($agendamentosConcluidos);
$analiseDescontos = getAnaliseDescontos($agendamentosConcluidos); 

// --- CÁLCULOS OPERACIONAIS ---
$contagemStatus = getContagemStatusAgendamentos($agendamentosFiltrados);
$ticketMedio = ($contagemStatus['concluido'] > 0) ? $receitaTotal / $contagemStatus['concluido'] : 0;

$horariosTrabalhoRaw = [];
if (file_exists($horariosFilePath)) {
    $fp = fopen($horariosFilePath, 'r');
    if ($fp) {
        if (flock($fp, LOCK_SH)) {
            while (($linha = fgets($fp)) !== false) {
                $linhaLimpa = trim($linha);
                if (!empty($linhaLimpa)) {
                    $horariosTrabalhoRaw[] = $linhaLimpa;
                }
            }
            flock($fp, LOCK_UN);
        }
        fclose($fp);
    }
}

$taxasOcupacao = [];
foreach ($barbeirosArr as $id => $barbeiro) {
    $taxa = getTaxaOcupacaoBarbeiro($id, $data_inicio_filtro, $data_fim_filtro, $agendamentosFiltrados, $horariosTrabalhoRaw); 
    $taxasOcupacao[$barbeiro['nome']] = $taxa;
}
$taxaOcupacaoMedia = !empty($taxasOcupacao) ? round(array_sum($taxasOcupacao) / count($taxasOcupacao), 1) : 0;

$melhorBarbeiro = getMelhorBarbeiro($agendamentosConcluidos, $barbeirosArr, $servicosArr); 
$rankingServicosIds = getRankingServicos($agendamentosConcluidos, $servicosArr); 
$servicosMaisCombinados = getServicosMaisCombinados($agendamentosConcluidos, $servicosArr); 

$agendamentosDiaSemana = array_fill_keys(['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'], 0);
foreach ($agendamentosFiltrados as $ag) {
    $dia_semana_num = date('w', strtotime($ag['data']));
    $dia_semana_label = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'][$dia_semana_num];
    if (isset($agendamentosDiaSemana[$dia_semana_label])) {
        $agendamentosDiaSemana[$dia_semana_label]++;
    }
}

$horariosPico = getHorariosDePico($agendamentosFiltrados); 

// --- CÁLCULOS DE CRM ---
$dadosNovosVsRecorrentes = getNovosVsRecorrentes($agendamentosFiltrados); 
$frequenciaMedia = getFrequenciaMediaVisitas($agendamentosFiltrados); 
$topClientes = getTopClientesPorGasto($agendamentosConcluidos, $servicosArr); 
$clientesEmRisco = getClientesEmRisco($agendamentosArr, $clientesArr, 90); 
$aniversariantesDoMes = getAniversariantesDoMes($clientesArr); 

// --- CÁLCULOS DE AVALIAÇÕES ---
$avaliacoesFiltradas = array_filter($avaliacoesArr, function($av) use ($data_inicio_filtro, $data_fim_filtro) {
    if (!isset($av['timestamp'])) {
        return false;
    }
    $data_av = date('Y-m-d', strtotime($av['timestamp']));
    return $data_av >= $data_inicio_filtro && $data_av <= $data_fim_filtro;
});
$totalAvaliacoes = count($avaliacoesFiltradas);
$mediaAvaliacoes = $totalAvaliacoes > 0 ? round(array_sum(array_column($avaliacoesFiltradas, 'rating')) / $totalAvaliacoes, 1) : 'N/A';

$agendamentos_avaliados_ids = array_column($avaliacoesArr, 'agendamento_id');
$agendamentosPendentesDeAvaliacao = array_filter($agendamentosArr, function($ag) use ($agendamentos_avaliados_ids) {
    return isset($ag['status']) && $ag['status'] === 'concluido' && !in_array($ag['id'], $agendamentos_avaliados_ids);
});

$media_geral_avaliacoes = count($avaliacoesArr) > 0 ? round(array_sum(array_column($avaliacoesArr, 'rating')) / count($avaliacoesArr), 1) : 0;
$distribuicao_notas = ['5' => 0, '4' => 0, '3' => 0, '2' => 0, '1' => 0];
$sentimentoGeral = ['positivo_count' => 0, 'neutro_count' => 0, 'negativo_count' => 0];
$media_por_barbeiro = [];
foreach($avaliacoesArr as $av) {
    $nota = (int)($av['rating'] ?? 0);
    if ($nota >= 1 && $nota <= 5) {
        $distribuicao_notas[(string)$nota]++;
    }
    if ($nota >= 4) {
        $sentimentoGeral['positivo_count']++;
    } elseif ($nota == 3) {
        $sentimentoGeral['neutro_count']++;
    } else {
        $sentimentoGeral['negativo_count']++;
    }
}
foreach($barbeirosArr as $b_id => $b) {
    $avaliacoes_do_barbeiro = array_filter($avaliacoesArr, function($av) use ($b_id) {
        return $av['barbeiro_id'] === $b_id;
    });
    $media = count($avaliacoes_do_barbeiro) > 0 ? round(array_sum(array_column($avaliacoes_do_barbeiro, 'rating')) / count($avaliacoes_do_barbeiro), 1) : 0;
    if (!empty($b['nome'])) { 
        $media_por_barbeiro[$b['nome']] = $media;
    }
}

$landingConfig = carregarLandingPageConfig(); 

$agendamentosPendentes = array_filter($agendamentosArr, function($a) {
    return isset($a['status']) && $a['status'] === 'pendente';
});

$estatisticas_clientes = [];
$pontosFidelidade = getAllFidelityPoints(); 
foreach ($clientesArr as $id => $cliente) {
    $agendamentos_cliente = array_filter($agendamentosArr, function($ag) use ($cliente) {
        return ($ag['email'] === $cliente['email'] || limparTelefone($ag['telefone']) === limparTelefone($cliente['telefone']));
    });
    $agendamentos_concluidos_cliente = array_filter($agendamentos_cliente, function($ag) {
        return $ag['status'] === 'concluido';
    });
    
    $gasto_total = 0;
    $ultima_visita = 'N/A';
    if (!empty($agendamentos_concluidos_cliente)) {
        uasort($agendamentos_concluidos_cliente, function($a, $b) {
            return strtotime($b['data']) - strtotime($a['data']);
        });
        $ultima_visita = date('d/m/Y', strtotime(reset($agendamentos_concluidos_cliente)['data']));
        
        foreach ($agendamentos_concluidos_cliente as $ag) {
             $sids = isset($ag['servicos_ids']) ? explode(',', $ag['servicos_ids']) : []; 
             $total_servicos_ag = 0; 
             foreach($sids as $sid) {
                $sid_limpo = trim($sid);
                if(isset($servicosArr[$sid_limpo])) {
                    $total_servicos_ag += (float)$servicosArr[$sid_limpo]['valor'];
                } elseif (isset($combosArr[$sid_limpo])) {
                    $total_servicos_ag += (float)$combosArr[$sid_limpo]['valor'];
                }
             }
             $produtos_vendidos = !empty($ag['produtos_vendidos']) ? json_decode($ag['produtos_vendidos'], true) : [];
             if (is_array($produtos_vendidos)) {
                foreach($produtos_vendidos as $produto) {
                    $total_servicos_ag += (float)($produto['valor'] ?? 0);
                }
             }
             $gasto_total += $total_servicos_ag - (float)($ag['desconto_aplicado'] ?? 0);
        }
    }
    
    $estatisticas_clientes[$id] = [
        'gasto_total' => $gasto_total,
        'total_agendamentos' => count($agendamentos_concluidos_cliente),
        'pontos_fidelidade' => $pontosFidelidade[$id] ?? 0,
        'ultima_visita' => $ultima_visita
    ];
}

$estatisticas_barbeiros = [];
foreach ($barbeirosArr as $id => $barbeiro) {
    $agendamentos_barbeiro = array_filter($agendamentosArr, function($ag) use ($id) {
        return $ag['barbeiro_id'] === $id;
    });
    $agendamentos_concluidos_barbeiro = array_filter($agendamentos_barbeiro, function($ag) {
        return $ag['status'] === 'concluido';
    });
    $avaliacoes_barbeiro = array_filter($avaliacoesArr, function($av) use ($id) {
        return $av['barbeiro_id'] === $id;
    });
    
    $receita = 0;
    foreach ($agendamentos_concluidos_barbeiro as $ag) {
         $sids = isset($ag['servicos_ids']) ? explode(',', $ag['servicos_ids']) : []; 
         $total_servicos_ag = 0; 
         foreach($sids as $sid) {
            $sid_limpo = trim($sid);
            if(isset($servicosArr[$sid_limpo])) {
                $total_servicos_ag += (float)$servicosArr[$sid_limpo]['valor'];
            } elseif (isset($combosArr[$sid_limpo])) {
                $total_servicos_ag += (float)$combosArr[$sid_limpo]['valor'];
            }
         }
         $produtos_vendidos = !empty($ag['produtos_vendidos']) ? json_decode($ag['produtos_vendidos'], true) : [];
         if (is_array($produtos_vendidos)) {
            foreach($produtos_vendidos as $produto) {
                $total_servicos_ag += (float)($produto['valor'] ?? 0);
            }
         }
         $receita += $total_servicos_ag - (float)($ag['desconto_aplicado'] ?? 0);
    }
    
    $media = count($avaliacoes_barbeiro) > 0 ? round(array_sum(array_column($avaliacoes_barbeiro, 'rating')) / count($avaliacoes_barbeiro), 1) : 0;
    
    $estatisticas_barbeiros[$id] = [
        'concluidos' => count($agendamentos_concluidos_barbeiro),
        'receita' => $receita,
        'media_avaliacoes' => $media
    ];
}

// ==========================================================================
// LÓGICA DE PAGINAÇÃO RECONSTRUÍDA E CORRIGIDA
// ==========================================================================

// --- 1. PAGINAÇÃO DE CLIENTES ---
$busca_cliente = trim($_GET['busca_cliente'] ?? '');
$clientesFiltrados = $clientesArr;

if (!empty($busca_cliente)) {
    $term = strtolower($busca_cliente);
    $termPhone = limparTelefone($busca_cliente); // Calcula apenas números do termo

    $clientesFiltrados = array_filter($clientesArr, function($c) use ($term, $termPhone) {
        $nome = strtolower($c['nome'] ?? '');
        $email = strtolower($c['email'] ?? '');
        
        $phoneMatch = false;
        // CORREÇÃO: Só busca no telefone se o termo tiver números
        if (!empty($termPhone)) {
             $phone = limparTelefone($c['telefone'] ?? '');
             if (!empty($phone)) {
                 $phoneMatch = (strpos($phone, $termPhone) !== false);
             }
        }
        
        return strpos($nome, $term) !== false ||
               strpos($email, $term) !== false ||
               $phoneMatch;
    });
}

uasort($clientesFiltrados, fn($a, $b) => strnatcasecmp($a['nome'], $b['nome']));

$clientes_itemsPerPage = 10;
$clientes_totalItems = count($clientesFiltrados);
$clientes_totalPages = $clientes_totalItems > 0 ? ceil($clientes_totalItems / $clientes_itemsPerPage) : 1;
$clientes_currentPage = max(1, min((int)($_GET['cli_page'] ?? 1), $clientes_totalPages));
$clientes_offset = ($clientes_currentPage - 1) * $clientes_itemsPerPage;

$clientesPaginados = array_slice($clientesFiltrados, $clientes_offset, $clientes_itemsPerPage, true);


// --- 2. PAGINAÇÃO DE BARBEIROS ---
$barbeirosPaginados = $barbeirosArr;
uasort($barbeirosPaginados, fn($a, $b) => strnatcasecmp($a['nome'], $b['nome']));

$barbeiros_itemsPerPage = 10;
$barbeiros_totalItems = count($barbeirosPaginados);
$barbeiros_totalPages = $barbeiros_totalItems > 0 ? ceil($barbeiros_totalItems / $barbeiros_itemsPerPage) : 1;
$barbeiros_currentPage = max(1, min((int)($_GET['bar_page'] ?? 1), $barbeiros_totalPages));
$barbeiros_offset = ($barbeiros_currentPage - 1) * $barbeiros_itemsPerPage;

$barbeirosPaginados = array_slice($barbeirosPaginados, $barbeiros_offset, $barbeiros_itemsPerPage, true);


// --- 3. PAGINAÇÃO DE FIDELIDADE ---
$busca_fidelidade = trim($_GET['busca_fidelidade'] ?? '');
$clientesFidelidadeFiltrados = $clientesArr;

if (!empty($busca_fidelidade)) {
    $termFid = strtolower($busca_fidelidade);
    $clientesFidelidadeFiltrados = array_filter($clientesArr, function($c) use ($termFid) {
        return strpos(strtolower($c['nome']), $termFid) !== false;
    });
}

uasort($clientesFidelidadeFiltrados, function($a, $b) use ($pontosFidelidade) {
    $ptsA = $pontosFidelidade[$a['id']] ?? 0;
    $ptsB = $pontosFidelidade[$b['id']] ?? 0;
    return $ptsB <=> $ptsA; 
});

$fidelidade_itemsPerPage = 15;
$fidelidade_totalItems = count($clientesFidelidadeFiltrados);
$fidelidade_totalPages = $fidelidade_totalItems > 0 ? ceil($fidelidade_totalItems / $fidelidade_itemsPerPage) : 1;
$fidelidade_currentPage = max(1, min((int)($_GET['fid_page'] ?? 1), $fidelidade_totalPages));
$fidelidadePaginados = array_slice($clientesFidelidadeFiltrados, ($fidelidade_currentPage - 1) * $fidelidade_itemsPerPage, $fidelidade_itemsPerPage, true);
$clientesFidelidadePaginados = $fidelidadePaginados;


// --- 4. PAGINAÇÃO DE AVALIAÇÕES ---
$filtro_barbeiro_av = $_GET['filtro_barbeiro_av'] ?? '';
$filtro_nota_av = $_GET['filtro_nota_av'] ?? '';

$avaliacoesFiltradasLista = $avaliacoesArr;

if (!empty($filtro_barbeiro_av)) {
    $avaliacoesFiltradasLista = array_filter($avaliacoesFiltradasLista, fn($av) => $av['barbeiro_id'] === $filtro_barbeiro_av);
}
if (!empty($filtro_nota_av)) {
    $avaliacoesFiltradasLista = array_filter($avaliacoesFiltradasLista, fn($av) => (int)$av['rating'] == (int)$filtro_nota_av);
}

uasort($avaliacoesFiltradasLista, fn($a, $b) => strtotime($b['timestamp']) - strtotime($a['timestamp']));

$avaliacoes_itemsPerPage = 10;
$avaliacoes_totalItems = count($avaliacoesFiltradasLista);
$avaliacoes_totalPages = $avaliacoes_totalItems > 0 ? ceil($avaliacoes_totalItems / $avaliacoes_itemsPerPage) : 1;
$avaliacoes_currentPage = max(1, min((int)($_GET['av_page'] ?? 1), $avaliacoes_totalPages));
$avaliacoes_offset = ($avaliacoes_currentPage - 1) * $avaliacoes_itemsPerPage;

$avaliacoesPaginados = array_slice($avaliacoesFiltradasLista, $avaliacoes_offset, $avaliacoes_itemsPerPage, true);


// --- 5. PAGINAÇÃO DE AGENDAMENTOS ---
$agendamentosListagem = $agendamentosArr;

$view = $_GET['view'] ?? 'today';
$filtro_data = $_GET['filtro_data'] ?? '';
$filtro_barbeiro = $_GET['filtro_barbeiro'] ?? '';
$filtro_status = $_GET['filtro_status'] ?? '';

$hoje = date('Y-m-d');

if (!empty($filtro_data)) {
    $agendamentosListagem = array_filter($agendamentosListagem, fn($ag) => $ag['data'] === $filtro_data);
} else {
    if ($view === 'today') {
        $agendamentosListagem = array_filter($agendamentosListagem, fn($ag) => $ag['data'] === $hoje);
    } elseif ($view === 'future') {
        $agendamentosListagem = array_filter($agendamentosListagem, fn($ag) => $ag['data'] > $hoje);
    }
}

if (!empty($filtro_barbeiro)) {
    $agendamentosListagem = array_filter($agendamentosListagem, fn($ag) => $ag['barbeiro_id'] === $filtro_barbeiro);
}
if (!empty($filtro_status)) {
    $agendamentosListagem = array_filter($agendamentosListagem, fn($ag) => $ag['status'] === $filtro_status);
}

uasort($agendamentosListagem, fn($a, $b) => strtotime($a['data'] . ' ' . $a['hora']) - strtotime($b['data'] . ' ' . $b['hora']));

$itemsPerPage = 15;
$totalItems = count($agendamentosListagem);
$totalPages = $totalItems > 0 ? ceil($totalItems / $itemsPerPage) : 1;
$currentPage = max(1, min((int)($_GET['page'] ?? 1), $totalPages));
$offset = ($currentPage - 1) * $itemsPerPage;

$agendamentosPaginados = array_slice($agendamentosListagem, $offset, $itemsPerPage, true);

$agendamentosAgrupadosPorBarbeiro = [];
foreach ($agendamentosListagem as $ag) {
    $agendamentosAgrupadosPorBarbeiro[$ag['barbeiro_id']][] = $ag;
}

// --- DADOS PARA O JAVASCRIPT ---
$adminJSData = []; 

$adminJSData['dashboardChartData'] = [
    'novosRecorrentes' => [
        'labels' => ['Novos Clientes', 'Recorrentes'],
        'data' => [$dadosNovosVsRecorrentes['novos'], $dadosNovosVsRecorrentes['recorrentes']]
    ]
];

$labelsDescontos = array_column($analiseDescontos, 'label');
$valoresDescontos = array_column($analiseDescontos, 'total');

$adminJSData['relatoriosChartData'] = [
    'receitaDiaria' => ['labels' => array_keys($receitaDiaria), 'data' => array_values($receitaDiaria)],
    
    // [NOVO] Fontes de Receita (Serviços vs Planos vs Produtos)
    'fontesReceita' => [
        'labels' => ['Serviços Avulsos', 'Assinaturas/Planos', 'Produtos'],
        'data' => [$receitaServicos, $receitaPlanos, $receitaProdutos]
    ],
    // [NOVO] Gráfico de Planos Populares
    'popularidadePlanos' => [
        'labels' => array_keys($planosPopulares),
        'data' => array_values($planosPopulares)
    ],

    'analiseDescontos' => ['labels' => $labelsDescontos, 'data' => $valoresDescontos],
    'ocupacaoBarbeiro' => ['labels' => array_keys($taxasOcupacao), 'data' => array_values($taxasOcupacao)],
    'agendamentosDiaSemana' => ['labels' => array_keys($agendamentosDiaSemana), 'data' => array_values($agendamentosDiaSemana)],
    'novosClientes' => ['data' => [$dadosNovosVsRecorrentes['recorrentes'], $dadosNovosVsRecorrentes['novos']]],
    'horariosPico' => ['labels' => array_keys($horariosPico), 'data' => array_values($horariosPico)]
];

$adminJSData['avaliacoesChartData'] = [
    'distribuicaoNotas' => ['data' => array_values(array_reverse($distribuicao_notas, true))],
    'mediaPorBarbeiro' => ['labels' => array_keys($media_por_barbeiro), 'data' => array_values($media_por_barbeiro)],
    'sentimentoGeral' => ['data' => array_values($sentimentoGeral)]
];

$adminJSData['clientesData'] = array_values($clientesArr);
$adminJSData['agendamentosData'] = array_values($agendamentosArr);
$adminJSData['anotacoesClientesData'] = $anotacoesClientes;
$adminJSData['barbeirosData'] = $barbeirosArr;
$combosJS = []; foreach($combosArr as $combo) { $combosJS[$combo['id']] = $combo; }
$adminJSData['combosData'] = $combosJS;
$adminJSData['categoriasData'] = $categoriasArr;
$adminJSData['horariosTrabalhoData'] = $horariosTrabalhoRaw;
$adminJSData['avaliacoesData'] = array_values($avaliacoesArr);
$adminJSData['clientesInfoData'] = array_column($clientesArr, 'nome', 'id');
$adminJSData['respostasAvaliacoesData'] = $respostasAvaliacoesArr;
$adminJSData['servicosData'] = $servicosArr;
$adminJSData['planosData'] = $planosArr;
$adminJSData['assinaturasData'] = $assinaturasClientesArr;
?>