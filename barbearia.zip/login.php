<?php
session_start();
require_once 'functions.php';
$configGeral = carregarConfigGeral();
$mensagemErro = '';

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login_type = $_POST['login_type'] ?? 'admin';
    $username_input = trim($_POST['username']);
    $password_input = $_POST['password'];

    $loginSuccess = false;

    if ($login_type === 'admin') {
        $usersFile = __DIR__ . '/_dados/users.txt';
        $loginSuccess = false;

        if (file_exists($usersFile)) {
            // --- INÍCIO DA ATUALIZAÇÃO DE SEGURANÇA (Leitura Segura) ---
            $fp = fopen($usersFile, 'r');
            if (!$fp) {
                log_activity("FALHA: Não foi possível abrir o arquivo $usersFile (login.php).");
                $mensagemErro = 'Erro interno do servidor. Tente novamente.';
            } else {
                // Solicita bloqueio de leitura
                if (flock($fp, LOCK_SH)) {
                    while (($userLine = fgets($fp)) !== false) {
                        $userLine = trim($userLine);
                        if (empty($userLine)) continue;
                        
                        $parts = explode(':', $userLine, 2);
                        if (count($parts) === 2) {
                            list($storedUsername, $storedPasswordHash) = $parts;
                            
                            // --- INÍCIO DA ATUALIZAÇÃO DE SEGURANÇA (Verificação de Senha) ---
                            // Compara o username e verifica o HASH da senha
                            if ($username_input === $storedUsername && password_verify($password_input, $storedPasswordHash)) {
                            // --- FIM DA ATUALIZAÇÃO DE SEGURANÇA ---
                                
                                $_SESSION['loggedin'] = true;
                                $_SESSION['username'] = $username_input;
                                $loginSuccess = true; // Marca como sucesso
                                break; // Para o loop
                            }
                        }
                    }
                    flock($fp, LOCK_UN); // Libera o bloqueio
                } else {
                     log_activity("FALHA: Não foi possível obter LOCK_SH no arquivo $usersFile (login.php).");
                     $mensagemErro = 'Erro interno do servidor. Tente novamente.';
                }
                fclose($fp);
            }
            // --- FIM DA ATUALIZAÇÃO DE SEGURANÇA (Leitura Segura) ---
        }
        
        if ($loginSuccess) {
            header('Location: admin.php');
            exit;
        } else if (empty($mensagemErro)) {
             $mensagemErro = 'Usuário ou senha incorretos.';
        }

    } elseif ($login_type === 'barbeiro') {
        // Esta função (getBarbeiroByUsername) já usa lerDados(), que é segura.
        $barbeiro = getBarbeiroByUsername($username_input); 
        
        // Esta verificação já estava correta usando password_verify
        if ($barbeiro && password_verify($password_input, $barbeiro['password'])) {
            $_SESSION['barbeiro_loggedin'] = true;
            $_SESSION['barbeiro_id'] = $barbeiro['id'];
            $_SESSION['barbeiro_nome'] = $barbeiro['nome'];
            header('Location: painel_barbeiro.php');
            exit;
        }
        $mensagemErro = 'Usuário ou senha incorretos.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?= htmlspecialchars($configGeral['nome_barbearia']) ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/custom_theme.css.php">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Ajustei o margin-top para 40px pois o header já empurra o conteúdo */
        .container { max-width: 400px; margin: 40px auto; text-align: center; }
        .login-type-selector { display: flex; justify-content: center; margin-bottom: 20px; background-color: #eee; border-radius: 50px; padding: 5px; }
        .login-type-selector label { flex: 1; padding: 10px; border-radius: 50px; cursor: pointer; font-weight: bold; transition: background-color 0.3s, color 0.3s; }
        .login-type-selector input[type="radio"] { display: none; }
        .login-type-selector input[type="radio"]:checked + label { background-color: var(--secondary-color); color: white; }
    </style>
</head>
<body>

    <?php 
        // Inserção do cabeçalho moderno
        $pageTitle = 'Login';
        require_once 'header_app.php'; 
    ?>

    <div class="container">
        <h2>Área Restrita</h2>
        
        <?php if ($mensagemErro): ?>
            <p class="mensagem erro" style="background-color: #f8d7da; border: 1px solid #f5c6cb;"><?= htmlspecialchars($mensagemErro) ?></p>
        <?php endif; ?>
        
        <form method="POST">
            <div class="login-type-selector">
                <input type="radio" id="type_admin" name="login_type" value="admin" checked>
                <label for="type_admin">Administrador</label>
                <input type="radio" id="type_barbeiro" name="login_type" value="barbeiro">
                <label for="type_barbeiro">Barbeiro</label>
            </div>
            <div class="form-group">
                <label for="username">Usuário</label>
                <div class="input-icon"><i class="fa fa-user"></i><input type="text" name="username" id="username" required></div>
            </div>
            <div class="form-group">
                <label for="password">Senha</label>
                <div class="input-icon"><i class="fa fa-lock"></i><input type="password" name="password" id="password" required></div>
            </div>
            <button type="submit" class="btn-primary">Entrar</button>
        </form>
    </div>
</body>
</html>