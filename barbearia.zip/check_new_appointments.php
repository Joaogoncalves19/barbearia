<?php
// Define o diretório de dados para encontrar o arquivo correto
define('DATA_DIR', __DIR__ . '/_dados/');
$agendamentosFile = DATA_DIR . 'agendamentos.txt';

// Headers para garantir que a resposta seja sempre a mais recente, evitando cache
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header('Content-Type: application/json');

if (!file_exists($agendamentosFile)) {
    echo json_encode(['appointment_count' => 0]);
    exit;
}

// --- INÍCIO DA ATUALIZAÇÃO DE SEGURANÇA (Leitura Segura) ---
$count = 0;
$fp = fopen($agendamentosFile, 'r');
if ($fp) {
    // Solicita um bloqueio de LEITURA (LOCK_SH)
    // Se outro processo estiver escrevendo (LOCK_EX), ele espera.
    if (flock($fp, LOCK_SH)) {
        while (($linha = fgets($fp)) !== false) {
            // Conta apenas linhas não vazias
            if (trim($linha) !== '') {
                $count++;
            }
        }
        flock($fp, LOCK_UN); // Libera o bloqueio
    }
    // (Não há log de falha aqui para não corromper a saída JSON)
    fclose($fp);
}
// --- FIM DA ATUALIZAÇÃO DE SEGURANÇA ---

echo json_encode(['appointment_count' => $count]);
?>