<?php
session_start();
require_once 'functions.php';

// Apenas utilizadores logados podem avaliar
if (!isset($_SESSION['cliente_logado'])) {
    header('Location: login_cliente.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $agendamento_id = $_POST['agendamento_id'] ?? null;
    $barbeiro_id = $_POST['barbeiro_id'] ?? null;
    $rating = $_POST['rating'] ?? null;
    $comment = trim(htmlspecialchars($_POST['comment']));
    $cliente_id = $_SESSION['cliente_id'];

    if (empty($agendamento_id) || empty($barbeiro_id) || empty($rating)) {
        header('Location: minha_conta.php?error=avaliacao_invalida');
        exit;
    }

    // Medida de segurança: Verifica se o agendamento pertence ao cliente logado
    // (A função lerDados() já é segura, pois usa LOCK_SH)
    $agendamentos = lerDados('agendamentos.txt', ['id', 'nome', 'email', 'telefone', 'barbeiro_id', 'servicos_ids', 'data', 'hora', 'status']);
    $agendamento = $agendamentos[$agendamento_id] ?? null;

    if (!$agendamento || limparTelefone($agendamento['telefone']) !== limparTelefone($_SESSION['cliente_telefone'])) {
         header('Location: minha_conta.php?error=agendamento_nao_encontrado');
         exit;
    }

    // Salvar a avaliação
    $avaliacoesFile = DATA_DIR . 'avaliacoes.txt';
    $id_avaliacao = uniqid('av-');
    $timestamp = date('Y-m-d H:i:s');
    $comment_safe = str_replace(["\r", "\n"], ' ', $comment); // Remove quebras de linha para evitar corromper o ficheiro .txt

    $linha = "$id_avaliacao|$agendamento_id|$cliente_id|$barbeiro_id|$rating|$comment_safe|$timestamp\n";
    
    // Garante que o ficheiro existe antes de adicionar conteúdo
    if (!file_exists($avaliacoesFile)) {
        // --- ATUALIZAÇÃO DE SEGURANÇA: Adiciona LOCK_EX ---
        file_put_contents($avaliacoesFile, '', LOCK_EX);
    }
    
    // --- ATUALIZAÇÃO DE SEGURANÇA: Adiciona LOCK_EX ---
    // Garante que a adição da nova linha seja atômica
    file_put_contents($avaliacoesFile, $linha, FILE_APPEND | LOCK_EX);
    // --- FIM DA ATUALIZAÇÃO ---

    header('Location: minha_conta.php?success=avaliacao_enviada');
    exit;
}

// Redireciona se o acesso for direto
header('Location: minha_conta.php');
exit;
?>