<?php
session_start();
require_once 'functions.php';
$configGeral = carregarConfigGeral(); // Carrega as configurações gerais
$mensagem = '';
$msg_tipo_sucesso = false;

// --- MODIFICAÇÃO 1: Adiciona nova mensagem de sucesso ---
if (isset($_GET['success'])) {
    if ($_GET['success'] === '1') {
        $mensagem = "Cadastro realizado com sucesso! Faça o login.";
        $msg_tipo_sucesso = true;
    }
    if ($_GET['success'] === 'confirm_email') {
        $mensagem = "Cadastro realizado! Por favor, verifique seu e-mail para ativar sua conta.";
        $msg_tipo_sucesso = true;
    }
}
if (isset($_GET['reset']) && $_GET['reset'] === 'success') {
    $mensagem = "Sua senha foi redefinida com sucesso! Você já pode fazer o login.";
    $msg_tipo_sucesso = true;
}
// Mensagem se o usuário tentar logar com conta inativa (redirecionado)
if (isset($_GET['error']) && $_GET['error'] === 'inactive') {
    $mensagem = "Sua conta ainda não foi ativada. Por favor, verifique seu e-mail de confirmação.";
    $msg_tipo_sucesso = false;
}
// Mensagem se a confirmação for bem-sucedida (do confirmar_email.php)
if (isset($_GET['activated']) && $_GET['activated'] === '1') {
    $mensagem = "Sua conta foi ativada com sucesso! Faça o login.";
    $msg_tipo_sucesso = true;
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim(htmlspecialchars($_POST['email']));
    $senha = $_POST['senha'];

    if (empty($email) || empty($senha)) {
        $mensagem = "E-mail e senha são obrigatórios.";
    } else {
        $cliente = getClientePorEmailTelefoneOuCPF($email);

        // --- MODIFICAÇÃO 2: Verifica a senha E o status do cliente ---
        if ($cliente && password_verify($senha, $cliente['password_hash'])) {
            
            // Verifica se o cliente está ativo
            if (isset($cliente['status']) && $cliente['status'] === 'ativo') {
                // Cliente logado com sucesso
                $_SESSION['cliente_logado'] = true;
                $_SESSION['cliente_id'] = $cliente['id'];
                $_SESSION['cliente_nome'] = $cliente['nome'];
                $_SESSION['cliente_email'] = $cliente['email'];
                $_SESSION['cliente_telefone'] = $cliente['telefone'];
                header('Location: minha_conta.php');
                exit;
            } else {
                // Cliente existe, mas está inativo
                $mensagem = "Sua conta ainda não foi ativada. Por favor, verifique seu e-mail de confirmação.";
                $msg_tipo_sucesso = false;
            }
        } else {
            // E-mail ou senha incorretos
            $mensagem = "E-mail ou senha incorretos.";
            $msg_tipo_sucesso = false;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Login do Cliente</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/custom_theme.css.php">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            /* Remove a imagem de fundo e volta ao estilo padrão do tema */
            background-image: none;
            background-color: var(--body-bg-color); /* Assumindo que você tem essa variável em custom_theme.css.php */
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            max-width: 420px;
            width: 100%;
            margin: 20px auto; /* Centraliza horizontalmente e mantém margem vertical */
            padding: 40px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1); /* Mantém uma sombra suave para o card */
            border-radius: 10px;
        }
        .btn-primary {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
    </style>
</head>
<body>

<?php 
    // Insere o cabeçalho novo
    $pageTitle = 'Login';
    require_once 'header_app.php'; 
?>

<div class="container">
    
    <h2 style="text-align: center;">Área do Cliente</h2>
    
    <?php if ($mensagem): ?>
        <p class="mensagem <?= $msg_tipo_sucesso ? '' : 'erro' ?>" 
           style="<?= $msg_tipo_sucesso ? 'background-color: #d4edda; border-color: #c3e6cb;' : 'background-color: #f8d7da; border-color: #f5c6cb;' ?>">
           <?= htmlspecialchars($mensagem) ?>
        </p>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label for="email">E-mail</label>
            <div class="input-icon">
                <i class="fa fa-envelope"></i>
                <input type="email" name="email" required>
            </div>
        </div>
        <div class="form-group">
            <label for="senha">Senha</label>
            <div class="input-icon">
                <i class="fa fa-lock"></i>
                <input type="password" name="senha" required>
            </div>
        </div>
        <button type="submit" class="btn-primary">
            <i class="fa fa-sign-in-alt"></i> Entrar
        </button>
        <div style="display: flex; justify-content: space-between; margin-top: 15px;">
             <a href="esqueci_senha.php">Esqueci minha senha</a>
             <a href="registro.php">Cadastre-se</a>
        </div>
    </form>
    
</div>
</body>
</html>