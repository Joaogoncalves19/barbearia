<?php
// Definição global das chaves completas para garantir integridade dos dados
$keys_agendamentos_completo = [
    'id', 'nome', 'email', 'telefone', 'barbeiro_id', 'servicos_ids', 
    'data', 'hora', 'status', 'desconto_aplicado', 'tipo_desconto', 
    'observacoes', 'produtos_vendidos', 'plano_provisorio'
];

$action = $_POST['action'] ?? $_GET['action'] ?? null;
$id = $_POST['id'] ?? $_GET['id'] ?? null;

// --- AÇÃO: ENVIAR LEMBRETES DE AMANHÃ ---
if ($action === 'enviar_lembretes_amanha') {
    if (($configAgendamento['notif_lembrete'] ?? 0) != 1) {
        header('Location: admin.php?tab=agendamentos&error_msg=' . urlencode('Os lembretes por e-mail estão desativados nas Configurações.'));
        exit;
    }
    $amanha = date('Y-m-d', strtotime('+1 day'));
    $total_enviados = 0;
    
    // Leitura completa para não perder dados se precisar salvar algo (embora aqui seja só leitura)
    $agendamentosArr = lerDados('agendamentos.txt', $keys_agendamentos_completo);

    $agendamentos_para_lembrar = array_filter($agendamentosArr, function($ag) use ($amanha) {
        return isset($ag['data'], $ag['status']) && $ag['data'] === $amanha && $ag['status'] === 'aprovado';
    });

    if (empty($agendamentos_para_lembrar)) {
        header('Location: admin.php?tab=agendamentos&success_msg=' . urlencode('Nenhum agendamento aprovado para amanhã. Nenhum lembrete foi enviado.'));
        exit;
    }

    foreach ($agendamentos_para_lembrar as $ag) {
        if (empty($ag['email']) || !filter_var($ag['email'], FILTER_VALIDATE_EMAIL)) { continue; }
        
        $servicosNomes = array_map(function($sid) use ($servicosArr, $combosArr) { 
            $sid = trim($sid);
            if (isset($servicosArr[$sid])) {
                return $servicosArr[$sid]['nome'];
            } elseif (isset($combosArr[$sid])) {
                return $combosArr[$sid]['nome'] . " (Combo)";
            }
            return 'Item (removido)'; 
        }, explode(',', $ag['servicos_ids']));

        $dados_email = [
            'nome_cliente' => $ag['nome'],
            'data_agendamento' => date('d/m/Y', strtotime($ag['data'])),
            'hora_agendamento' => $ag['hora'],
            'servicos' => $servicosNomes,
            'barbeiro' => $barbeirosArr[$ag['barbeiro_id']]['nome'] ?? 'Não especificado',
            'tipo_desconto' => $ag['tipo_desconto'] ?? ''
        ];
        if (enviarEmail($ag['email'], 'Lembrete do seu Agendamento', 'lembrete', $dados_email)) {
            $total_enviados++;
        }
    }
    header('Location: admin.php?tab=agendamentos&success_msg=' . urlencode("Lembretes enviados com sucesso para $total_enviados cliente(s)."));
    exit;
}

// --- AÇÃO: ENVIAR NEWSLETTER ---
if ($action === 'enviar_newsletter') {
    $destinatarios_tipo = $_POST['destinatarios'] ?? 'ativos';
    $assunto = trim(htmlspecialchars($_POST['assunto']));
    $corpo_email_template = nl2br(htmlspecialchars($_POST['corpo_email'])); 

    if (empty($assunto) || empty($corpo_email_template)) {
        header('Location: admin.php?tab=marketing&error=' . urlencode('Assunto e corpo do e-mail são obrigatórios.'));
        exit;
    }
    $todos_clientes = $clientesArr; 
    $clientes_para_enviar = [];
    if ($destinatarios_tipo === 'todos') {
        $clientes_para_enviar = $todos_clientes;
    } else {
        $clientes_para_enviar = array_filter($todos_clientes, function($cliente) {
            $status = $cliente['status'] ?? 'ativo';
            if(empty($status)) $status = 'ativo';
            return $status === 'ativo';
        });
    }
    $total_enviados = 0;
    foreach ($clientes_para_enviar as $cliente) {
        if (!filter_var($cliente['email'], FILTER_VALIDATE_EMAIL)) { continue; }
        $corpo_email_personalizado = str_replace('{nome_cliente}', htmlspecialchars($cliente['nome']), $corpo_email_template);
        $dados_email = ['nome_cliente' => $cliente['nome'], 'assunto_email' => $assunto, 'corpo_email' => $corpo_email_personalizado];
        if (enviarEmail($cliente['email'], $assunto, 'newsletter_generica', $dados_email)) { $total_enviados++; }
    }
    header('Location: admin.php?tab=marketing&success=1&total=' . urlencode("Campanha enviada para $total_enviados cliente(s)."));
    exit;
}

// --- AÇÃO: ENVIAR REATIVAÇÃO ---
if ($action === 'enviar_reativacao') {
    $cupom_id = $_POST['cupom_id'] ?? null;
    if (empty($cupom_id) || !isset($cupoesArr[$cupom_id])) {
        header('Location: admin.php?tab=marketing&error=' . urlencode('Cupom inválido ou não selecionado.'));
        exit;
    }
    $cupom_selecionado = $cupoesArr[$cupom_id];
    $clientes_em_risco = getClientesEmRisco($agendamentosArr, $clientesArr, 90);
    if (empty($clientes_em_risco)) {
        header('Location: admin.php?tab=marketing&error=' . urlencode('Nenhum cliente em risco para enviar.'));
        exit;
    }
    $total_enviados = 0;
    foreach ($clientes_em_risco as $cliente) {
        if (!filter_var($cliente['email'], FILTER_VALIDATE_EMAIL)) { continue; }
        $dados_email = ['nome_cliente' => $cliente['nome'], 'cupom_codigo' => $cupom_selecionado['codigo'], 'cupom_desconto' => $cupom_selecionado['desconto_percentual']];
        if (enviarEmail($cliente['email'], 'Sentimos sua falta! Um presente para você.', 'reativacao_cliente', $dados_email)) { $total_enviados++; }
    }
    header('Location: admin.php?tab=marketing&success=1&total=' . urlencode("E-mail de reativação enviado para $total_enviados cliente(s)."));
    exit;
}

// --- AÇÃO: ENVIAR LEMBRETE DE AVALIAÇÃO ---
if ($action === 'enviar_lembretes_avaliacao') {
    $agendamentos_avaliados_ids = array_column($avaliacoesArr, 'agendamento_id');
    // Leitura segura e completa
    $agendamentosArr = lerDados('agendamentos.txt', $keys_agendamentos_completo);
    
    $agendamentosParaLembrar = array_filter($agendamentosArr, function($ag) use ($agendamentos_avaliados_ids) {
        return isset($ag['status']) && $ag['status'] === 'concluido' && !in_array($ag['id'], $agendamentos_avaliados_ids);
    });
    if (empty($agendamentosParaLembrar)) {
        header('Location: admin.php?tab=avaliacoes&error=' . urlencode('Nenhum agendamento pendente de avaliação.'));
        exit;
    }
    $total_enviados = 0;
    foreach ($agendamentosParaLembrar as $ag) {
        if (!filter_var($ag['email'], FILTER_VALIDATE_EMAIL)) { continue; }
        $dados_email = ['nome_cliente' => $ag['nome'], 'data_agendamento' => date('d/m/Y', strtotime($ag['data'])), 'barbeiro' => $barbeirosArr[$ag['barbeiro_id']]['nome'] ?? 'Nosso Time'];
        if (enviarEmail($ag['email'], 'Como foi sua experiência? Deixe sua avaliação!', 'lembrete_avaliacao', $dados_email)) { $total_enviados++; }
    }
    header('Location: admin.php?tab=avaliacoes&success_av=1&total=' . urlencode("Lembretes enviados para $total_enviados cliente(s)."));
    exit;
}

// --- AÇÃO: SALVAR BLOQUEIOS ---
if ($action === 'salvar_bloqueios') {
    $barbeiro_id = $_POST['bloqueio_barbeiro_id'];
    $data = $_POST['bloqueio_data_selecionada'];
    $horarios_selecionados = $_POST['horarios_bloqueados'] ?? [];
    $bloqueiosFile = DATA_DIR . 'horarios_bloqueados.txt';
    $fp = fopen($bloqueiosFile, 'c+'); 
    if ($fp && flock($fp, LOCK_EX)) { 
        $linhas = [];
        while (($linha = fgets($fp)) !== false) { $linhas[] = trim($linha); }
        $novasLinhas = array_filter($linhas, function($linha) use ($barbeiro_id, $data) {
            if(empty(trim($linha))) return false;
            $partes = explode('|', $linha);
            if (count($partes) === 3) { return ($partes[0] !== $barbeiro_id || $partes[1] !== $data); }
            return true;
        });
        foreach ($horarios_selecionados as $hora) { $novasLinhas[] = "$barbeiro_id|$data|$hora"; }
        ftruncate($fp, 0); rewind($fp);
        fwrite($fp, implode("\n", $novasLinhas) . (empty($novasLinhas) ? "" : "\n"));
        flock($fp, LOCK_UN);
    } 
    if($fp) fclose($fp);
    header('Location: admin.php?tab=barbeiros&success=bloqueio_salvo');
    exit;
}

// --- AÇÃO: SALVAR LANDING PAGE ---
if ($action === 'salvar_landing_page') {
    $currentConfig = carregarLandingPageConfig();
    $sanitizedData = [];
    foreach ($currentConfig as $key => $defaultValue) {
        $sanitizedData[$key] = $_POST[$key] ?? $defaultValue;
    }
    $video_path_atual = $_POST['hero_video_path_atual'] ?? '';
    if (isset($_FILES['hero_video_file']) && $_FILES['hero_video_file']['error'] == 0) {
        $file_type = $_FILES['hero_video_file']['type'];
        $file_ext = ($file_type === 'video/mp4') ? '.mp4' : (($file_type === 'video/webm') ? '.webm' : '');
        if (!empty($file_ext)) {
            $video_path = 'uploads/hero_video_' . uniqid() . $file_ext;
            if (move_uploaded_file($_FILES['hero_video_file']['tmp_name'], $video_path)) {
                $sanitizedData['hero_video_path'] = $video_path;
                if (!empty($video_path_atual) && file_exists($video_path_atual) && $video_path_atual != $video_path) { @unlink($video_path_atual); }
            } else { $sanitizedData['hero_video_path'] = $video_path_atual; }
        } else { $sanitizedData['hero_video_path'] = $video_path_atual; }
    } else { $sanitizedData['hero_video_path'] = $video_path_atual; }
    salvarLandingPageConfig($sanitizedData);
    header('Location: admin.php?tab=landingpage&success=1');
    exit;
}

// --- AÇÃO: ADICIONAR PRODUTO ---
if ($action === 'adicionar_produto') {
    $agendamento_id = $_POST['agendamento_id'];
    $nome_produto = trim(htmlspecialchars($_POST['nome_produto']));
    $valor_produto = (float) str_replace(',', '.', $_POST['valor_produto']);
    if (!empty($agendamento_id) && !empty($nome_produto) && $valor_produto > 0) {
        adicionarProdutoAoAgendamento($agendamento_id, $nome_produto, $valor_produto); 
    }
    header('Location: admin.php?tab=agendamentos');
    exit;
}

// --- AÇÃO: SALVAR CONFIG GERAL ---
if ($action === 'salvar_config_geral') {
    $currentConfig = carregarConfigGeral();
    $logo_path = $currentConfig['logo_path']; 
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] == 0) {
        $logo_path = 'uploads/logo_' . time() . '.' . pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION);
        move_uploaded_file($_FILES['logo']['tmp_name'], $logo_path);
    }
    $conteudo = "nome_barbearia=\"".htmlspecialchars($_POST['nome_barbearia'])."\"\n";
    $conteudo .= "telefone_contato=\"".htmlspecialchars($_POST['telefone_contato'])."\"\n";
    $conteudo .= "endereco=\"".htmlspecialchars($_POST['endereco'])."\"\n";
    $conteudo .= "link_instagram=\"".htmlspecialchars($_POST['link_instagram'])."\"\n";
    $conteudo .= "link_facebook=\"".htmlspecialchars($_POST['link_facebook'])."\"\n";
    $conteudo .= "link_whatsapp=\"".htmlspecialchars($_POST['link_whatsapp'])."\"\n";
    $conteudo .= "logo_path=\"".htmlspecialchars($logo_path)."\"\n";
    $conteudo .= "geofence_lat=\"".htmlspecialchars($_POST['geofence_lat'])."\"\n";
    $conteudo .= "geofence_lon=\"".htmlspecialchars($_POST['geofence_lon'])."\"\n";
    file_put_contents(DATA_DIR . 'config_geral.txt', $conteudo, LOCK_EX);
    header('Location: admin.php?tab=configuracoes&subtab=geral&success=geral_salvo');
    exit;
}

// --- AÇÃO: SALVAR BARBEIRO ---
if ($action === 'salvar_barbeiro') {
    $id = $_POST['id'] ?: uniqid('br-');
    $nome = trim(htmlspecialchars($_POST['nome']));
    $username = trim(htmlspecialchars($_POST['username']));
    $password = $_POST['password'];
    $status = $_POST['status'] ?? 'ativo'; 
    $especialidades_ids_array = $_POST['especialidades_ids'] ?? []; 
    $servicos_ids_string = implode(',', $especialidades_ids_array); 
    $foto = $_POST['foto_atual'] ?? 'uploads/default.png';
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
        $foto = 'uploads/' . uniqid() . '-' . basename($_FILES['foto']['name']);
        move_uploaded_file($_FILES['foto']['tmp_name'], $foto);
    }
    $password_hash = $barbeirosArr[$id]['password'] ?? '';
    if(!empty($password)) { $password_hash = password_hash($password, PASSWORD_DEFAULT); }
    $barbeirosArr[$id] = ['id' => $id, 'nome' => $nome, 'foto' => $foto, 'username' => $username, 'password' => $password_hash, 'status' => $status, 'servicos_ids' => $servicos_ids_string];
    salvarDados($barbeirosFile, $barbeirosArr, $keys_barbeiros); 
    header('Location: admin.php?tab=barbeiros');
    exit;
}

// --- AÇÃO: SALVAR CONFIG INDICACAO ---
if ($action === 'salvar_config_indicacao') { 
    $ativado = $_POST['indicacao_ativado'] ?? 0; 
    $pontos = (int) $_POST['pontos_indicacao']; 
    $desconto = (int) $_POST['desconto_novo_cliente']; 
    $conteudo = "ativado=$ativado\npontos_indicacao=$pontos\ndesconto_novo_cliente=$desconto"; 
    file_put_contents($configIndicacaoPath, $conteudo, LOCK_EX); 
    header('Location: admin.php?tab=marketing&success=indicacao_salvo'); 
    exit; 
}

// --- AÇÃO: SALVAR CONFIG EMAIL ---
if ($action === 'salvar_config_email') {
    $conteudo = "host=\"".htmlspecialchars($_POST['host'])."\"\n";
    $conteudo .= "username=\"".htmlspecialchars($_POST['username'])."\"\n";
    $pass = !empty($_POST['password']) ? $_POST['password'] : $configEmail['password'];
    $conteudo .= "password=\"".htmlspecialchars($pass)."\"\n";
    $conteudo .= "port=". (int)$_POST['port'] ."\n";
    $conteudo .= "smtp_secure=\"".htmlspecialchars($_POST['smtp_secure'])."\"\n";
    $conteudo .= "nome_remetente=\"".htmlspecialchars($_POST['nome_remetente'])."\"\n";
    file_put_contents(DATA_DIR . 'config_email.txt', $conteudo, LOCK_EX);
    header('Location: admin.php?tab=configuracoes&subtab=email&success=email_salvo');
    exit;
}

// --- AÇÃO: SALVAR CONFIG AGENDAMENTO ---
if ($action === 'salvar_config_agendamento') { 
    $conteudo = "antecedencia_minima_minutos=". (int)$_POST['antecedencia_minima_minutos'] ."\n"; 
    $conteudo .= "antecedencia_maxima=". (int)$_POST['antecedencia_maxima'] ."\n"; 
    $conteudo .= "max_servicos=". (int)$_POST['max_servicos'] ."\n"; 
    $conteudo .= "notif_confirmacao=". (isset($_POST['notif_confirmacao']) ? 1 : 0) ."\n"; 
    $conteudo .= "notif_aprovacao=". (isset($_POST['notif_aprovacao']) ? 1 : 0) ."\n"; 
    $conteudo .= "notif_lembrete=". (isset($_POST['notif_lembrete']) ? 1 : 0) ."\n"; 
    file_put_contents($configAgendamentoPath, $conteudo, LOCK_EX); 
    header('Location: admin.php?tab=configuracoes&subtab=agendamento&success=agendamento_salvo'); 
    exit; 
}

// --- AÇÃO: BACKUP DADOS ---
if ($action === 'backup_dados') { 
    if (class_exists('ZipArchive')) { 
        $zipname = 'backup_barbearia_'.date('Y-m-d').'.zip'; 
        $zip = new ZipArchive; 
        $zip->open($zipname, ZipArchive::CREATE); 
        if ($handle = opendir(DATA_DIR)) { 
            while (false !== ($entry = readdir($handle))) { 
                if ($entry != "." && $entry != "..") { 
                    $zip->addFile(DATA_DIR . $entry, $entry); 
                } 
            } 
            closedir($handle); 
        } 
        $zip->close(); 
        header('Content-Type: application/zip'); 
        header('Content-disposition: attachment; filename='.$zipname); 
        header('Content-Length: ' . filesize($zipname)); 
        readfile($zipname); 
        unlink($zipname); 
        exit; 
    } else { 
        die('A extensão ZipArchive do PHP não está ativada no seu servidor.'); 
    } 
}

// --- AÇÃO: LIMPAR AGENDAMENTOS ANTIGOS ---
if ($action === 'limpar_agendamentos_antigos') { 
    $novasLinhas = []; 
    $umAnoAtras = strtotime('-1 year'); 
    $fp = fopen($agendamentosFilePath, 'c+');
    if ($fp && flock($fp, LOCK_EX)) { 
        while (($linha = fgets($fp)) !== false) {
            $l = trim($linha); if(empty($l)) continue;
            $partes = explode('|', $l); 
            if (count($partes) >= 9) { 
                $data_ag = strtotime($partes[6]); 
                $status = $partes[8]; 
                if (!(($status === 'concluido' || $status === 'cancelado' || $status === 'cancelado_pelo_cliente') && $data_ag < $umAnoAtras)) { 
                    $novasLinhas[] = $l; 
                } 
            } else { $novasLinhas[] = $l; }
        }
        ftruncate($fp, 0); rewind($fp);
        fwrite($fp, implode("\n", $novasLinhas) . (empty($novasLinhas) ? "" : "\n"));
        flock($fp, LOCK_UN);
    } 
    if($fp) fclose($fp);
    header('Location: admin.php?tab=configuracoes&subtab=sistema&success=limpeza_concluida'); 
    exit; 
}

// --- AÇÃO: SALVAR/EXCLUIR CATEGORIA ---
if ($action === 'salvar_categoria') {
    $id = $_POST['id'] ?: uniqid('cat-');
    $nome = trim(htmlspecialchars($_POST['nome']));
    $ordem = (int)($_POST['ordem'] ?? 99);
    if (!empty($nome)) {
        $categoriasArr[$id] = ['id' => $id, 'nome' => $nome, 'ordem' => $ordem];
        salvarDados($categoriasFile, $categoriasArr, $keys_categorias);
    }
    header('Location: admin.php?tab=servicos&subtab=categorias&success=1');
    exit;
}
if ($action === 'excluir_categoria' && !empty($id)) {
    if (isset($categoriasArr[$id])) {
        unset($categoriasArr[$id]);
        salvarDados($categoriasFile, $categoriasArr, $keys_categorias);
        foreach ($servicosArr as $servicoId => $servico) {
            if (isset($servico['categoria_id']) && $servico['categoria_id'] === $id) { $servicosArr[$servicoId]['categoria_id'] = ''; }
        }
        salvarDados($servicosFile, $servicosArr, $keys_servicos);
        foreach ($combosArr as $comboId => $combo) {
            if (isset($combo['categoria_id']) && $combo['categoria_id'] === $id) { $combosArr[$comboId]['categoria_id'] = ''; }
        }
        salvarDados($combosFile, $combosArr, $keys_combos);
    }
    header('Location: admin.php?tab=servicos&subtab=categorias&success=2');
    exit;
}

// --- AÇÃO: SALVAR/EXCLUIR COMBO ---
if ($action === 'salvar_combo') { 
    $id = $_POST['id'] ?: uniqid('cb-'); 
    $nome = trim(htmlspecialchars($_POST['nome'])); 
    $servicos_ids = $_POST['combo_servicos_ids'] ?? ''; 
    $valor = trim(htmlspecialchars($_POST['valor'])); 
    $categoria_id = $_POST['categoria_id'] ?? '';
    if (!empty($nome) && !empty($servicos_ids) && !empty($valor)) { 
        $combosArr[$id] = ['id' => $id, 'nome' => $nome, 'servicos_ids' => $servicos_ids, 'valor' => $valor, 'categoria_id' => $categoria_id]; 
        salvarDados($combosFile, $combosArr, $keys_combos); 
    } 
    header('Location: admin.php?tab=servicos&subtab=combos'); 
    exit; 
}
if ($action === 'excluir_combo' && isset($combosArr[$id])) { 
    unset($combosArr[$id]); 
    salvarDados($combosFile, $combosArr, $keys_combos); 
    header('Location: admin.php?tab=servicos&subtab=combos'); 
    exit; 
}

// --- AÇÃO: GERAR/EXCLUIR VOUCHER ---
if ($action === 'gerar_voucher') { 
    $valor = (float) str_replace(',', '.', $_POST['valor_voucher']); 
    if ($valor > 0) { 
        $novo_voucher = [ 'id' => uniqid('vch-'), 'codigo' => strtoupper('PRESENTE-' . substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 6)), 'valor' => number_format($valor, 2, '.', ''), 'status' => 'disponivel', 'data_criacao' => date('Y-m-d H:i:s'), 'agendamento_id_uso' => '', 'data_validade' => '' ]; 
        $vouchersArr[$novo_voucher['id']] = $novo_voucher; 
        salvarDados($vouchersFile, $vouchersArr, $keys_vouchers); 
    } 
    header('Location: admin.php?tab=marketing&success=voucher_gerado'); 
    exit; 
}
if ($action === 'excluir_voucher' && !empty($id)) { 
    if (isset($vouchersArr[$id])) { unset($vouchersArr[$id]); salvarDados($vouchersFile, $vouchersArr, $keys_vouchers); } 
    header('Location: admin.php?tab=marketing'); 
    exit; 
}
if ($action === 'salvar_voucher_editado') { 
    $voucher_id = $_POST['voucher_id']; $data_validade = $_POST['data_validade']; 
    if (isset($vouchersArr[$voucher_id])) { $vouchersArr[$voucher_id]['data_validade'] = $data_validade; salvarDados($vouchersFile, $vouchersArr, $keys_vouchers); } 
    header('Location: admin.php?tab=marketing'); 
    exit; 
}

// --- AÇÃO: SALVAR TEMA ---
if ($action === 'salvar_tema') { 
    $colors = $_POST['colors'] ?? []; 
    if (!empty($colors)) { 
        $sanitized_colors = array_filter($colors, function($color) { return preg_match('/^#[a-f0-9]{6}$/i', $color); }); 
        file_put_contents($themeConfigFile, json_encode($sanitized_colors, JSON_PRETTY_PRINT), LOCK_EX); 
    } 
    header('Location: admin.php?tab=configuracoes&subtab=tema&success=tema_salvo'); 
    exit; 
}

// --- AÇÃO: SALVAR CONFIG FIDELIDADE ---
if ($action === 'salvar_config_fidelidade') { 
    $ativado = $_POST['fidelidade_ativado'] ?? 0; $pontos = (int) $_POST['pontos_necessarios']; $desconto = (int) $_POST['desconto_percentual']; 
    $conteudo = "ativado=$ativado\npontos_necessarios=$pontos\ndesconto_percentual=$desconto"; 
    file_put_contents($fidelidadeConfigPath, $conteudo, LOCK_EX); 
    header('Location: admin.php?tab=fidelidade&success=1'); 
    exit; 
}
if ($action === 'ajustar_pontos') { 
    $cliente_id = $_POST['cliente_id']; $novos_pontos = (int) $_POST['novos_pontos']; 
    if (isset($clientesArr[$cliente_id])) { updateClientFidelityPoints($cliente_id, $novos_pontos); } 
    header('Location: admin.php?tab=fidelidade'); 
    exit; 
}

// --- AÇÃO: SALVAR ANOTAÇÃO ---
if ($action === 'salvar_anotacao') { 
    $cliente_id = $_POST['cliente_id']; $anotacao = trim(htmlspecialchars($_POST['anotacao'])); 
    if (isset($clientesArr[$cliente_id])) { salvarAnotacaoCliente($cliente_id, $anotacao); } 
    header('Location: admin.php?tab=clientes'); 
    exit; 
}

// --- AÇÃO: STATUS AGENDAMENTO (APROVAR/REJEITAR/CONCLUIR) ---
if (($action === 'aprovar' || $action === 'rejeitar' || $action === 'concluir') && !empty($id)) {
    
    // CORREÇÃO CRÍTICA: Leitura usando as chaves completas para não perder dados do plano VIP
    $agendamentosArr = lerDados('agendamentos.txt', $keys_agendamentos_completo);
    
    $novoStatus = '';
    if ($action === 'aprovar') $novoStatus = 'aprovado';
    if ($action === 'rejeitar') $novoStatus = 'cancelado';
    if ($action === 'concluir') $novoStatus = 'concluido';

    if (!empty($novoStatus) && isset($agendamentosArr[$id])) {
        $agendamento = $agendamentosArr[$id];
        $status_anterior = $agendamento['status'];
        $agendamentosArr[$id]['status'] = $novoStatus;

        $cliente = getClientePorEmailTelefoneOuCPF($agendamento['telefone']);
        if (!$cliente) { $cliente = getClientePorEmailTelefoneOuCPF($agendamento['email']); }

        if (($configAgendamento['notif_aprovacao'] ?? 0) == 1 && ($novoStatus === 'aprovado' || $novoStatus === 'cancelado')) {
            $nomes_servicos = array_map(function($sid) use ($servicosArr, $combosArr) { 
                $sid = trim($sid);
                if (isset($servicosArr[$sid])) return $servicosArr[$sid]['nome'];
                if (isset($combosArr[$sid])) return $combosArr[$sid]['nome'] . " (Combo)";
                return 'Item (removido)';
            }, explode(',', $agendamento['servicos_ids']));

            $dados_email = [
                'nome_cliente' => $agendamento['nome'],
                'data_agendamento' => date('d/m/Y', strtotime($agendamento['data'])),
                'hora_agendamento' => $agendamento['hora'],
                'servicos' => $nomes_servicos,
                'barbeiro' => $barbeirosArr[$agendamento['barbeiro_id']]['nome'] ?? 'Não especificado',
                'tipo_desconto' => $agendamento['tipo_desconto'] ?? ''
            ];
            $template = ($novoStatus === 'aprovado') ? 'aprovado' : 'cancelado';
            $assunto = ($novoStatus === 'aprovado') ? 'Seu Agendamento foi Aprovado!' : 'Informações sobre seu Agendamento';
            enviarEmail($agendamento['email'], $assunto, $template, $dados_email);
        }
        
        if ($cliente) { 
            $cliente_id_notif = $cliente['id'];
            $data_formatada = date('d/m/Y', strtotime($agendamento['data']));
            if ($novoStatus === 'aprovado') { criarNotificacao($cliente_id_notif, "Seu agendamento para {$data_formatada} às {$agendamento['hora']} foi APROVADO."); } 
            else if ($novoStatus === 'cancelado') { criarNotificacao($cliente_id_notif, "Seu agendamento para {$data_formatada} às {$agendamento['hora']} foi CANCELADO pelo estabelecimento."); } 
            else if ($novoStatus === 'concluido') { criarNotificacao($cliente_id_notif, "Obrigado pela sua visita! Seu atendimento em {$data_formatada} foi concluído. Não se esqueça de avaliar!"); } 
        }

        if ($novoStatus === 'concluido' && $status_anterior !== 'concluido' && ($configFidelidade['ativado'] ?? 0) && $cliente) { 
            $assinatura = getAssinaturaCliente($cliente['id']);
            $tem_assinatura = ($assinatura && $assinatura['status'] === 'ativo');
            if (!$tem_assinatura) {
                $pontos_atuais = getClientFidelityPoints($cliente['id']); 
                updateClientFidelityPoints($cliente['id'], $pontos_atuais + 1, "Agendamento concluído"); 
            }
        }
        
        // --- ATIVAR ASSINATURA AUTOMATICAMENTE AO CONCLUIR ---
        if ($novoStatus === 'concluido' && $status_anterior !== 'concluido') {
            // Agora pegamos diretamente do array carregado corretamente
            $plano_provisorio_id = $agendamento['plano_provisorio'] ?? '';
            
            if (!empty($plano_provisorio_id) && $cliente) {
                // Ativa a assinatura por 30 dias
                salvarAssinaturaCliente($cliente['id'], $plano_provisorio_id, '+30 days');
                criarNotificacao($cliente['id'], "Sua assinatura VIP foi ativada com sucesso! Aproveite os benefícios.");
            }
        }

        // --- CORREÇÃO AQUI: RECOMPENSA DE INDICAÇÃO (FALTAVA NO ADMIN) ---
        if ($novoStatus === 'concluido' && $status_anterior !== 'concluido' && $cliente && !empty($cliente['indicado_por_id'])) {
            // Conta quantos agendamentos concluídos este cliente tem (incluindo o atual, que acabamos de marcar)
            // Precisamos iterar sobre o array ATUALIZADO em memória
            $concluidosCount = 0;
            foreach ($agendamentosArr as $ag_check) {
                // Normaliza dados para comparação
                $emailCheck = $ag_check['email'] ?? '';
                $telCheck = limparTelefone($ag_check['telefone'] ?? '');
                $emailCli = $cliente['email'] ?? '';
                $telCli = limparTelefone($cliente['telefone'] ?? '');

                // Verifica se o agendamento pertence ao cliente
                if (($emailCheck === $emailCli || (!empty($telCli) && $telCheck === $telCli))) {
                    if (($ag_check['status'] ?? '') === 'concluido') {
                        $concluidosCount++;
                    }
                }
            }

            // Se for exatamente 1, é a primeira vez que conclui um serviço
            if ($concluidosCount === 1) {
                processarRecompensaIndicacao($cliente['indicado_por_id'], $cliente['nome']);
            }
        }
        // --- FIM DA CORREÇÃO ---
        
        salvarDados('agendamentos.txt', $agendamentosArr, $keys_agendamentos_completo);
    }
    header('Location: admin.php?tab=agendamentos');
    exit;
}

// --- AÇÃO: REAGENDAR ---
if ($action === 'salvar_reagendamento') {
    $agendamento_id = $_POST['reagendar_agendamento_id'];
    $nova_data = $_POST['reagendar_data'];
    $nova_hora = $_POST['reagendar_horario'];
    
    // CORREÇÃO CRÍTICA: Carregar todas as colunas para não perder 'plano_provisorio'
    $agendamentosArr = lerDados('agendamentos.txt', $keys_agendamentos_completo);

    if (!empty($agendamento_id) && isset($agendamentosArr[$agendamento_id])) {
        $agendamento_original = $agendamentosArr[$agendamento_id];
        $agendamentosArr[$agendamento_id]['data'] = $nova_data;
        $agendamentosArr[$agendamento_id]['hora'] = $nova_hora;
        $agendamentosArr[$agendamento_id]['status'] = 'aprovado'; 
        
        // Salvar usando todas as colunas
        salvarDados('agendamentos.txt', $agendamentosArr, $keys_agendamentos_completo);
        
        $cliente = getClientePorEmailTelefoneOuCPF($agendamento_original['email']);
        if ($cliente) { criarNotificacao($cliente['id'], "Seu agendamento foi REAGENDADO para ".date('d/m/Y', strtotime($nova_data))." às ".$nova_hora."."); }
    }
    header('Location: admin.php?tab=agendamentos');
    exit;
}

// --- AÇÃO: EXCLUIR AGENDAMENTO/BARBEIRO ---
if ($action === 'excluir_agendamento') {
    $agendamentosArr = lerDados('agendamentos.txt', $keys_agendamentos_completo);
    if(isset($agendamentosArr[$id])) { 
        unset($agendamentosArr[$id]); 
        salvarDados('agendamentos.txt', $agendamentosArr, $keys_agendamentos_completo); 
    }
    header('Location: admin.php?tab=agendamentos'); 
    exit; 
}
if ($action === 'excluir_barbeiro' && isset($barbeirosArr[$id])) { unset($barbeirosArr[$id]); salvarDados('barbeiros.txt', $barbeirosArr, $keys_barbeiros); header('Location: admin.php?tab=barbeiros'); exit; }

// --- AÇÃO: SALVAR/EXCLUIR SERVIÇO ---
if ($action === 'salvar_servico') {
    $id = $_POST['id'] ?: uniqid('sv-');
    $nome = trim(htmlspecialchars($_POST['nome']));
    $valor = trim(htmlspecialchars($_POST['valor']));
    $slots = (int)($_POST['slots'] ?? 1); if ($slots <= 0) $slots = 1;
    $categoria_id = $_POST['categoria_id'] ?? '';
    $servicosArr[$id] = ['id' => $id, 'nome' => $nome, 'valor' => $valor, 'slots' => $slots, 'categoria_id' => $categoria_id];
    salvarDados('servicos.txt', $servicosArr, $keys_servicos); 
    header('Location: admin.php?tab=servicos&subtab=servicos-individuais');
    exit;
}
if ($action === 'excluir_servico' && isset($servicosArr[$id])) { unset($servicosArr[$id]); salvarDados('servicos.txt', $servicosArr, $keys_servicos); header('Location: admin.php?tab=servicos&subtab=servicos-individuais'); exit; }

// --- AÇÃO: CONFIG APROVAÇÃO ---
if ($action === 'salvar_config_aprovacao') { 
    $modo = $_POST['modo_aprovacao']; 
    file_put_contents(DATA_DIR . 'config.txt', "aprovar=$modo", LOCK_EX); 
    header('Location: admin.php?tab=configuracoes&subtab=agendamento'); 
    exit; 
}

// --- AÇÃO: SALVAR SEMANA COMPLETA DE HORÁRIOS ---
if ($action === 'salvar_semana_horarios') {
    $barbeiro_id = $_POST['barbeiro_id'];
    $horarios_post = $_POST['horarios'] ?? []; 

    if (empty($barbeiro_id)) {
        header('Location: admin.php?tab=barbeiros&error=barbeiro_nao_selecionado');
        exit;
    }

    $fp = fopen(DATA_DIR . 'horarios_trabalho.txt', 'c+'); 
    if ($fp && flock($fp, LOCK_EX)) {
        $todas_linhas = [];
        while (($linha = fgets($fp)) !== false) {
            $todas_linhas[] = trim($linha);
        }

        $linhas_finais = array_filter($todas_linhas, function($linha) use ($barbeiro_id) {
            if (empty(trim($linha))) return false;
            $partes = explode('|', $linha);
            return ($partes[0] !== $barbeiro_id);
        });

        foreach ($horarios_post as $dia => $dados) {
            if (isset($dados['ativo']) && $dados['ativo'] == '1') {
                $inicio = $dados['inicio'];
                $fim = $dados['fim'];
                
                if (!empty($inicio) && !empty($fim)) {
                    $linhas_finais[] = "$barbeiro_id|$dia|$inicio|$fim";
                }
            }
        }

        ftruncate($fp, 0); 
        rewind($fp); 
        fwrite($fp, implode("\n", $linhas_finais) . "\n");
        
        flock($fp, LOCK_UN);
    }
    if($fp) fclose($fp);

    header('Location: admin.php?tab=barbeiros&success=horarios_atualizados');
    exit;
}

// --- AÇÃO: SALVAR/EXCLUIR HORÁRIO BARBEIRO (ANTIGO - MANTIDO PARA COMPATIBILIDADE) ---
if ($action === 'salvar_horario') { 
    $barbeiro_id = $_POST['barbeiro_id']; $dias_semana = $_POST['dias_semana'] ?? []; $hora_inicio = $_POST['hora_inicio']; $hora_fim = $_POST['hora_fim']; 
    $fp = fopen(DATA_DIR . 'horarios_trabalho.txt', 'c+'); $horariosTrabalho = [];
    if ($fp && flock($fp, LOCK_EX)) { 
        while (($linha = fgets($fp)) !== false) { $horariosTrabalho[] = trim($linha); }
        $novosHorarios = array_filter($horariosTrabalho, function($h) use ($barbeiro_id, $dias_semana) { 
            if(empty(trim($h))) return false; 
            $partes = explode('|', $h); 
            if ($partes[0] == $barbeiro_id && in_array($partes[1], $dias_semana)) return false;
            return true;
        }); 
        foreach ($dias_semana as $dia) { $novosHorarios[] = "$barbeiro_id|$dia|$hora_inicio|$hora_fim"; } 
        ftruncate($fp, 0); rewind($fp); fwrite($fp, implode("\n", $novosHorarios) . "\n"); flock($fp, LOCK_UN);
    } if($fp) fclose($fp);
    header('Location: admin.php?tab=barbeiros'); exit; 
}
if ($action === 'excluir_horario') { 
    $key_del = $_GET['key']; $fp = fopen(DATA_DIR . 'horarios_trabalho.txt', 'c+'); $horariosTrabalho = [];
    if ($fp && flock($fp, LOCK_EX)) { 
        while (($linha = fgets($fp)) !== false) { $horariosTrabalho[] = trim($linha); }
        if (isset($horariosTrabalho[$key_del])) { unset($horariosTrabalho[$key_del]); ftruncate($fp, 0); rewind($fp); fwrite($fp, implode("\n", $horariosTrabalho) . "\n"); }
        flock($fp, LOCK_UN);
    } if($fp) fclose($fp);
    header('Location: admin.php?tab=barbeiros'); exit; 
}

// --- AÇÃO: USUÁRIOS E CLIENTES ---
if ($action === 'salvar_usuario') {
    $current_username = $_POST['current_username']; $new_username = trim($_POST['new_username']); $new_password = $_POST['new_password'];
    if (empty($current_username) && empty($new_password)) { header('Location: admin.php?tab=configuracoes&subtab=sistema&error=senha_obrigatoria'); exit; }
    if (!empty($new_username)) {
        $password_hash_to_save = '';
        if (!empty($new_password)) { $password_hash_to_save = password_hash($new_password, PASSWORD_DEFAULT); } 
        elseif (!empty($current_username) && isset($usersArr[$current_username])) { $password_hash_to_save = $usersArr[$current_username]['password']; }
        if (!empty($current_username) && $current_username !== $new_username && isset($usersArr[$current_username])) { unset($usersArr[$current_username]); }
        $usersArr[$new_username] = ['username' => $new_username, 'password' => $password_hash_to_save];
        $userLines = array_map(function($u) { return "{$u['username']}:{$u['password']}"; }, $usersArr);
        
        // --- CORREÇÃO AQUI: Usar DATA_DIR . 'users.txt' ---
        file_put_contents(DATA_DIR . 'users.txt', implode("\n", $userLines) . "\n", LOCK_EX);
        
        if (isset($_SESSION['username']) && $_SESSION['username'] == $current_username) { $_SESSION['username'] = $new_username; }
    }
    header('Location: admin.php?tab=configuracoes&subtab=sistema&success=usuario_salvo'); exit;
}
if ($action === 'excluir_usuario') { 
    $username = $_GET['username']; if (count($usersArr) > 1 && isset($usersArr[$username])) { unset($usersArr[$username]); $userLines = array_map(function($u) { return "{$u['username']}:{$u['password']}"; }, $usersArr); 
    
    // --- CORREÇÃO AQUI: Usar DATA_DIR . 'users.txt' ---
    file_put_contents(DATA_DIR . 'users.txt', implode("\n", $userLines) . "\n", LOCK_EX); } 
    
    header('Location: admin.php?tab=configuracoes&subtab=sistema'); exit; 
}
if ($action === 'salvar_cliente') {
    $id = $_POST['id'] ?: uniqid('cl-'); $nome = trim(htmlspecialchars($_POST['nome'])); $email = trim(htmlspecialchars($_POST['email'])); $telefone = limparTelefone($_POST['telefone']); $cpf = limparTelefone($_POST['cpf']); $data_nascimento = $_POST['data_nascimento']; $nova_senha = $_POST['nova_senha']; $foto_atual = $_POST['foto_perfil_atual'] ?? '';
    $foto_perfil = $foto_atual; if (empty($foto_perfil) || $foto_perfil == 'uploads/default-profile.jpg') { $foto_perfil = 'uploads/default-profile.jpg'; }
    if (isset($_FILES['foto_perfil']) && $_FILES['foto_perfil']['error'] == 0) { $foto_perfil = 'uploads/perfil-' . $id . '-' . time() . '.jpg'; move_uploaded_file($_FILES['foto_perfil']['tmp_name'], $foto_perfil); }
    $password_hash = $clientesArr[$id]['password_hash'] ?? '';
    if (!empty($nova_senha)) { $password_hash = password_hash($nova_senha, PASSWORD_DEFAULT); } elseif (empty($id) && empty($password_hash)) { $password_hash = password_hash(bin2hex(random_bytes(16)), PASSWORD_DEFAULT); }
    $cliente_existente = $clientesArr[$id] ?? [];
    $clientesArr[$id] = ['id' => $id, 'nome' => $nome, 'email' => $email, 'telefone' => $telefone, 'password_hash' => $password_hash, 'data_nascimento' => $data_nascimento, 'foto_perfil' => $foto_perfil, 'codigo_indicacao' => $cliente_existente['codigo_indicacao'] ?? '', 'cpf' => $cpf, 'indicado_por_id' => $cliente_existente['indicado_por_id'] ?? '', 'status' => $cliente_existente['status'] ?? 'ativo', 'confirmation_token' => $cliente_existente['confirmation_token'] ?? ''];
    if(empty($clientesArr[$id]['codigo_indicacao'])) { $clientesArr[$id]['codigo_indicacao'] = strtoupper(substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 6)); }
    salvarDadosCliente($clientesArr); 
    header('Location: admin.php?tab=clientes&success=cliente_salvo'); exit;
}
if ($action === 'excluir_cliente' && isset($clientesArr[$id])) { unset($clientesArr[$id]); salvarDadosCliente($clientesArr); header('Location: admin.php?tab=clientes'); exit; }
if ($action === 'toggle_cliente_status' && isset($clientesArr[$id])) {
    $cliente_data = $clientesArr[$id]; $status_atual = $cliente_data['status'] ?? 'ativo'; if(empty($status_atual)) $status_atual = 'ativo';
    $novo_status = ($status_atual === 'ativo') ? 'inativo' : 'ativo'; $clientesArr[$id]['status'] = $novo_status;
    salvarDadosCliente($clientesArr); header('Location: admin.php?tab=clientes'); exit;
}

// --- AÇÃO: SALVAR AGENDAMENTO MANUAL ---
if ($action === 'salvar_agendamento_manual') {
    $cliente_id = $_POST['manual_cliente_id']; 
    $servicos_ids = $_POST['manual_servicos'] ?? ''; 
    $data = $_POST['manual_data']; 
    $hora = $_POST['manual_horario']; 
    $barbeiro_id = $_POST['manual_barbeiro']; 
    $plano_adesao_id = $_POST['manual_plano_id'] ?? '';
    
    $nome_cliente = ''; $telefone_cliente = ''; $email_cliente = 'manual@admin.com'; 
    if (!empty($cliente_id) && isset($clientesArr[$cliente_id])) { 
        $nome_cliente = $clientesArr[$cliente_id]['nome']; 
        $telefone_cliente = limparTelefone($clientesArr[$cliente_id]['telefone']); 
        $email_cliente = $clientesArr[$cliente_id]['email']; 
    } else { 
        $nome_cliente = trim(htmlspecialchars($_POST['manual_nome'])); 
        $telefone_cliente = limparTelefone($_POST['manual_telefone']); 
    }
    
    if (empty($nome_cliente) || empty($telefone_cliente) || empty($barbeiro_id) || empty($servicos_ids) || empty($data) || empty($hora)) { 
        header('Location: admin.php?tab=agendamentos&error_msg=' . urlencode('Falha: Todos os campos são obrigatórios.')); 
        exit; 
    }
    
    $desconto_aplicado = 0; $tipo_desconto = ''; $plano_provisorio_para_salvar = '';
    
    // Garante carregamento de dados caso não venham do escopo global
    if (!isset($planosArr)) $planosArr = lerDados('planos.txt', ['id', 'nome', 'valor', 'servicos_ids']);
    if (!isset($servicosArr)) $servicosArr = lerDados('servicos.txt', ['id', 'nome', 'valor']);
    if (!isset($combosArr)) $combosArr = lerDados('combos.txt', ['id', 'nome', 'servicos_ids', 'valor']);

    // 1. Identificar o que foi selecionado e calcular Valor Bruto
    $itens_selecionados = explode(',', $servicos_ids);
    $valor_total_bruto = 0;
    $combos_selecionados_ids = [];
    $servicos_individuais_ids = [];

    foreach ($itens_selecionados as $item) {
        $item = trim($item);
        if (strpos($item, 'cb-') === 0 && isset($combosArr[$item])) {
            $valor_total_bruto += (float)$combosArr[$item]['valor'];
            $combos_selecionados_ids[] = $item;
        } elseif (strpos($item, 'sv-') === 0 && isset($servicosArr[$item])) {
            $valor_total_bruto += (float)$servicosArr[$item]['valor'];
            $servicos_individuais_ids[] = $item;
        }
    }

    // 2. Lógica de Cálculo da Adesão (Quebra de Combo)
    if (!empty($plano_adesao_id) && isset($planosArr[$plano_adesao_id])) {
        $plano = $planosArr[$plano_adesao_id];
        $valor_plano = (float)$plano['valor'];
        $servicosInclusos = array_map('trim', explode(',', $plano['servicos_ids']));
        
        $total_extras_a_pagar = 0;

        // Processa Combos: Verifica cobertura parcial
        foreach($combos_selecionados_ids as $combo_id) {
            $combo = $combosArr[$combo_id];
            $servicos_do_combo = explode(',', $combo['servicos_ids']);
            
            $algum_coberto = false;
            $valor_nao_cobertos_deste_combo = 0;

            foreach($servicos_do_combo as $sid) {
                $sid_limpo = trim($sid);
                if (isset($servicosArr[$sid_limpo])) {
                    if (in_array($sid_limpo, $servicosInclusos)) {
                        $algum_coberto = true;
                    } else {
                        // Se não está coberto, soma o valor individual do serviço
                        $valor_nao_cobertos_deste_combo += (float)$servicosArr[$sid_limpo]['valor'];
                    }
                }
            }

            if ($algum_coberto) {
                // Se o plano cobre algo no combo, cobramos apenas os itens "fora"
                $total_extras_a_pagar += $valor_nao_cobertos_deste_combo;
            } else {
                // Se o plano não cobre nada neste combo, cobra o valor original do combo
                $total_extras_a_pagar += (float)$combo['valor'];
            }
        }

        // Processa Serviços Individuais
        foreach($servicos_individuais_ids as $sid) {
            if (isset($servicosArr[$sid])) {
                if (!in_array($sid, $servicosInclusos)) {
                    $total_extras_a_pagar += (float)$servicosArr[$sid]['valor'];
                }
            }
        }

        // Valor Final = Preço do Plano + Serviços/Combos não cobertos
        $valor_final_esperado = $valor_plano + $total_extras_a_pagar;
        
        // O "Desconto" é a diferença entre o Bruto e o Final Esperado
        // Ex: Combo (45) + Adesão (50). Combo tem Corte(25, incluso) + Barba(25, não inclusa).
        // Bruto: 45. Final Esperado: 50 + 25 = 75. 
        // Desconto Aplicado no registro: 45 - 75 = -30.
        // O sistema entende desconto negativo como acréscimo, ou ajusta na hora de exibir "Total a Pagar".
        $desconto_aplicado = $valor_total_bruto - $valor_final_esperado;
        
        $tipo_desconto = 'adesao_plano';
        $plano_provisorio_para_salvar = $plano_adesao_id;
        
    } elseif (!empty($cliente_id)) {
        // ... (Lógica de assinatura VIP existente se não for adesão) ...
        $assinatura = getAssinaturaCliente($cliente_id);
        if ($assinatura && $assinatura['status'] === 'ativo') {
            $tipo_desconto = 'assinatura_vip';
            // A lógica de VIP já é calculada ao exibir/salvar em outros lugares,
            // ou você pode replicar a lógica de quebra de combo aqui também se necessário para o Manual.
            // Para "Adesão" (que era o erro reportado), o bloco acima resolve.
        }
    }

    $timestamp_agendamento = strtotime("$data $hora");
    $status_inicial = ($timestamp_agendamento < time()) ? 'concluido' : 'aprovado';
    $id_agendamento = uniqid('ag-');
    $linha = "$id_agendamento|$nome_cliente|$email_cliente|$telefone_cliente|$barbeiro_id|$servicos_ids|$data|$hora|$status_inicial|$desconto_aplicado|$tipo_desconto|||$plano_provisorio_para_salvar\n";
    file_put_contents(DATA_DIR . 'agendamentos.txt', $linha, FILE_APPEND | LOCK_EX);

    header('Location: admin.php?tab=agendamentos&success_msg=' . urlencode('Agendamento manual criado com sucesso!')); 
    exit;
}

// --- AÇÕES DE AVALIAÇÃO ---
if ($action === 'toggle_destaque_avaliacao' && !empty($id)) {
    if (isset($avaliacoesDestacadasArr[$id])) { unset($avaliacoesDestacadasArr[$id]); } else { $avaliacoesDestacadasArr[$id] = ['id_avaliacao' => $id]; }
    salvarDados($avaliacoesDestacadasFile, $avaliacoesDestacadasArr, $keys_avaliacoes_destacadas); header('Location: admin.php?tab=avaliacoes'); exit;
}
if ($action === 'salvar_resposta_avaliacao') {
    $id_avaliacao = $_POST['id_avaliacao'] ?? null; $texto_resposta = trim(htmlspecialchars($_POST['texto_resposta']));
    if (!empty($id_avaliacao) && !empty($texto_resposta)) {
        $respostasRaw = lerDados($respostasAvaliacoesFile, $keys_respostas_avaliacoes);
        $id_resposta_existente = null;
        foreach ($respostasRaw as $resp_id => $resp) { if ($resp['id_avaliacao'] === $id_avaliacao) { $id_resposta_existente = $resp_id; break; } }
        if ($id_resposta_existente) { $respostasRaw[$id_resposta_existente]['texto_resposta'] = $texto_resposta; $respostasRaw[$id_resposta_existente]['timestamp'] = date('Y-m-d H:i:s'); } 
        else { $id_nova_resposta = uniqid('resp-'); $respostasRaw[$id_nova_resposta] = ['id_resposta' => $id_nova_resposta, 'id_avaliacao' => $id_avaliacao, 'texto_resposta' => $texto_resposta, 'timestamp' => date('Y-m-d H:i:s')]; }
        salvarDados($respostasAvaliacoesFile, $respostasRaw, $keys_respostas_avaliacoes);
    }
    header('Location: admin.php?tab=avaliacoes&success_av=1'); exit;
}
if ($action === 'excluir_avaliacao' && !empty($id)) {
    if (isset($avaliacoesArr[$id])) { unset($avaliacoesArr[$id]); salvarDados($avaliacoesFile, $avaliacoesArr, $keys_avaliacoes); }
    if (isset($avaliacoesDestacadasArr[$id])) { unset($avaliacoesDestacadasArr[$id]); salvarDados($avaliacoesDestacadasFile, $avaliacoesDestacadasArr, $keys_avaliacoes_destacadas); }
    if (isset($respostasAvaliacoesArr[$id])) {
        $respostasRaw = lerDados($respostasAvaliacoesFile, $keys_respostas_avaliacoes);
        foreach($respostasRaw as $resp_id => $resp) { if ($resp['id_avaliacao'] === $id) { unset($respostasRaw[$resp_id]); break; } }
        salvarDados($respostasAvaliacoesFile, $respostasRaw, $keys_respostas_avaliacoes);
    }
    header('Location: admin.php?tab=avaliacoes'); exit; 
}

// --- AÇÃO: SALVAR CUPOM ---
if ($action === 'salvar_cupom') { 
    $id = $_POST['id'] ?: uniqid('cup-'); 
    $codigo = strtoupper(trim(htmlspecialchars($_POST['codigo']))); 
    $desconto = (int) $_POST['desconto_percentual']; 
    $usos_max = (int) $_POST['usos_maximos']; 
    $validade = $_POST['data_validade']; 
    $usos_atuais = $_POST['usos_atuais'] ?? 0; 
    $cupoesArr[$id] = [ 'id' => $id, 'codigo' => $codigo, 'desconto_percentual' => $desconto, 'usos_maximos' => $usos_max, 'data_validade' => $validade, 'usos_atuais' => $usos_atuais ]; 
    salvarDados($cupoesFile, $cupoesArr, $keys_cupoes); 
    header('Location: admin.php?tab=marketing'); 
    exit; 
}
if ($action === 'excluir_cupom' && isset($cupoesArr[$id])) { unset($cupoesArr[$id]); salvarDados($cupoesFile, $cupoesArr, $keys_cupoes); header('Location: admin.php?tab=marketing'); exit; }
if ($action === 'salvar_config_aniversario') { $ativado = $_POST['aniversario_ativado'] ?? 0; $desconto = (int) $_POST['desconto_percentual']; $conteudo = "ativado=$ativado\ndesconto_percentual=$desconto"; file_put_contents($aniversarioConfigPath, $conteudo, LOCK_EX); header('Location: admin.php?tab=marketing&success=aniversario_salvo'); exit; }

// --- AÇÕES DE PLANOS DE ASSINATURA ---

if ($action === 'salvar_plano') {
    $planosArr = lerDados('planos.txt', ['id', 'nome', 'valor', 'servicos_ids']);
    $id = $_POST['id'] ?: uniqid('plano-');
    $nome = trim(htmlspecialchars($_POST['nome']));
    $valor = str_replace(',', '.', $_POST['valor']);
    $servicos = implode(',', $_POST['plano_servicos_ids'] ?? []);
    if (!empty($nome) && !empty($valor)) {
        $planosArr[$id] = ['id' => $id, 'nome' => $nome, 'valor' => $valor, 'servicos_ids' => $servicos];
        salvarDados('planos.txt', $planosArr, ['id', 'nome', 'valor', 'servicos_ids']);
    }
    header('Location: admin.php?tab=servicos&subtab=planos');
    exit;
}

if ($action === 'excluir_plano') {
    $planosArr = lerDados('planos.txt', ['id', 'nome', 'valor', 'servicos_ids']);
    if (isset($planosArr[$id])) { unset($planosArr[$id]); salvarDados('planos.txt', $planosArr, ['id', 'nome', 'valor', 'servicos_ids']); }
    header('Location: admin.php?tab=servicos&subtab=planos');
    exit;
}

// --- ATIVAR ASSINATURA MANUALMENTE (GERENCIAR) ---
if ($action === 'ativar_assinatura') {
    $cliente_id = $_POST['cliente_id'];
    $plano_id = $_POST['plano_id'];
    $dias = (int) $_POST['dias_validade'];
    $status = $_POST['status_assinatura'] ?? 'ativo';
    
    $duracao_str = "+" . $dias . " days";
    
    $assinaturaAtual = getAssinaturaCliente($cliente_id);
    $data_base = date('Y-m-d');
    
    if ($assinaturaAtual && $assinaturaAtual['data_fim'] > $data_base && $status === 'ativo') {
        $data_inicio_base = $assinaturaAtual['data_fim'];
    } else {
        $data_inicio_base = $data_base;
    }
    
    salvarAssinaturaCliente($cliente_id, $plano_id, $duracao_str, $data_inicio_base, $status);
    
    header('Location: admin.php?tab=clientes&success=assinatura_atualizada');
    exit;
}
?>