<?php
// lembretes_cron.php

// Define o fuso horário e carrega as funções
date_default_timezone_set('America/Sao_Paulo');

require_once __DIR__ . '/functions.php'; 

$configAgendamento = carregarConfigAgendamento(); 

if (($configAgendamento['notif_lembrete'] ?? 0) != 1) {
    echo "Lembretes desativados.\n";
    exit;
}

$amanha = date('Y-m-d', strtotime('+1 day'));
$agendamentosFile = DATA_DIR . 'agendamentos.txt';

$servicosArr = lerDados('servicos.txt', ['id', 'nome', 'valor']); 
$barbeirosArr = lerDados('barbeiros.txt', ['id', 'nome', 'foto']); 
$combosArr = lerDados('combos.txt', ['id', 'nome', 'servicos_ids', 'valor']);

if (!file_exists($agendamentosFile)) {
    echo "Arquivo de agendamentos não encontrado.\n";
    exit;
}

// --- INÍCIO DA ATUALIZAÇÃO DE SEGURANÇA (Leitura Segura) ---
$total_enviados = 0;

$fp = fopen($agendamentosFile, 'r');
if (!$fp) {
    if (function_exists('log_activity')) {
         log_activity("FALHA CRON: Não foi possível abrir $agendamentosFile para leitura.");
    }
    echo "Erro: Não foi possível abrir o arquivo de agendamentos.\n";
    exit;
}

if (flock($fp, LOCK_SH)) {
    while (($linha = fgets($fp)) !== false) {
        if (empty(trim($linha))) continue;
        
        $partes = explode('|', $linha);
        
        $keys_agendamentos = ['id', 'nome', 'email', 'telefone', 'barbeiro_id', 'servicos_ids', 'data', 'hora', 'status'];
        $ag = [];
        foreach ($partes as $i => $parte) {
            if (isset($keys_agendamentos[$i])) {
                $ag[$keys_agendamentos[$i]] = $parte;
            }
        }

        if (isset($ag['data'], $ag['status']) && $ag['data'] === $amanha && $ag['status'] === 'aprovado') {
            
            // CORREÇÃO: Lógica unificada de busca de nomes
            $servicosNomes = array_map(
                function($sid) use ($servicosArr, $combosArr) { 
                    $sid = trim($sid);
                    if (isset($servicosArr[$sid])) {
                        return $servicosArr[$sid]['nome'];
                    } elseif (isset($combosArr[$sid])) {
                        return $combosArr[$sid]['nome'] . " (Combo)";
                    }
                    return 'Item (removido)'; 
                }, 
                explode(',', $ag['servicos_ids'])
            );
            
            $dados_email = [
                'nome_cliente' => $ag['nome'],
                'data_agendamento' => date('d/m/Y', strtotime($ag['data'])),
                'hora_agendamento' => $ag['hora'],
                'servicos' => $servicosNomes,
                'barbeiro' => $barbeirosArr[$ag['barbeiro_id']]['nome'] ?? 'Não especificado'
            ];

            if (enviarEmail($ag['email'], 'Lembrete do seu Agendamento', 'lembrete', $dados_email)) {
                $total_enviados++;
            }
        }
    } 
    flock($fp, LOCK_UN);
}
fclose($fp);

echo "Total de $total_enviados lembretes enviados.\n";
?>