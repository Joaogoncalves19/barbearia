<?php
session_start();
date_default_timezone_set('America/Sao_Paulo');
require_once 'functions.php';

$configGeral = carregarConfigGeral();
$mensagem = '';
$sucesso = false;
$token_valido = false;
$email_do_token = null;

$token = $_GET['token'] ?? null;
$resetFile = DATA_DIR . 'password_resets.txt';

if ($token && file_exists($resetFile)) {
    // --- INÍCIO DA ATUALIZAÇÃO DE SEGURANÇA (Leitura Segura) ---
    $fp = fopen($resetFile, 'r');
    if (!$fp) {
        log_activity("FALHA: Não foi possível abrir $resetFile (redefinir_senha.php).");
    } else {
        // Solicita bloqueio de leitura
        if (flock($fp, LOCK_SH)) {
            while (($linha = fgets($fp)) !== false) {
                $linha = trim($linha);
                if (empty($linha)) continue;

                $partes = explode('|', $linha);
                if (count($partes) === 3) {
                    list($email, $file_token, $timestamp) = $partes;
                    // Verifica se o token é o mesmo e se não expirou (ex: 1 hora = 3600 segundos)
                    if ($file_token === $token && (time() - $timestamp) < 3600) {
                        $token_valido = true;
                        $email_do_token = $email;
                        break;
                    }
                }
            }
            flock($fp, LOCK_UN); // Libera o bloqueio
        } else {
             log_activity("FALHA: Não foi possível obter LOCK_SH no $resetFile (redefinir_senha.php).");
        }
        fclose($fp);
    }
    // --- FIM DA ATUALIZAÇÃO DE SEGURANÇA ---
}

if (!$token_valido && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    $mensagem = "Token inválido ou expirado. Por favor, solicite um novo link de redefinição.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token_post = $_POST['token'] ?? '';
    $email_post = $_POST['email'] ?? '';
    $nova_senha = $_POST['nova_senha'];
    $confirma_nova_senha = $_POST['confirma_nova_senha'];

    // Valida o token e o email novamente no POST
    if ($token_post !== $token || $email_post !== $email_do_token || !$token_valido) {
        $mensagem = "Erro de validação. Tente novamente.";
        $token_valido = false;
    } elseif ($nova_senha !== $confirma_nova_senha) {
        $mensagem = "As senhas não coincidem.";
    } elseif (strlen($nova_senha) < 6) {
        $mensagem = "A nova senha deve ter pelo menos 6 caracteres.";
    } else {
        // --- INÍCIO DA ATUALIZAÇÃO DE SEGURANÇA (Escrita Segura) ---
        
        // --- CORREÇÃO DO BUG (Chave 'indicado_por_id' adicionada) ---
        $keys_clientes_completo = [
            'id', 'nome', 'email', 'telefone', 'password_hash', 
            'data_nascimento', 'foto_perfil', 'codigo_indicacao', 'cpf', 
            'indicado_por_id', 
            'status', 'confirmation_token'
        ];
        // --- FIM DA CORREÇÃO DO BUG ---

        $clientesArr = lerDados('clientes.txt', $keys_clientes_completo);
        
        $cliente_id_para_atualizar = null;
        foreach ($clientesArr as $id => $cliente) {
            if ($cliente['email'] === $email_do_token) {
                $cliente_id_para_atualizar = $id;
                break;
            }
        }

        if ($cliente_id_para_atualizar) {
            $clientesArr[$cliente_id_para_atualizar]['password_hash'] = password_hash($nova_senha, PASSWORD_DEFAULT);
            salvarDadosCliente($clientesArr); // Salva o arquivo de clientes com LOCK_EX

            // Invalida o token no arquivo password_resets.txt
            // Operação de Leitura-Modificação-Escrita ATÔMICA
            $fp = fopen($resetFile, 'c+');
            if (!$fp || !flock($fp, LOCK_EX)) {
                 log_activity("FALHA: Não foi possível obter LOCK_EX no $resetFile para limpar o token.");
            } else {
                $linhas = [];
                while (($linha = fgets($fp)) !== false) {
                    $linhaLimpa = trim($linha);
                    if (empty($linhaLimpa)) continue;
                    // Adiciona apenas as linhas que NÃO contêm o token usado
                    if (strpos($linhaLimpa, "|$token|") === false) {
                        $linhas[] = $linhaLimpa;
                    }
                }
                
                ftruncate($fp, 0); // Limpa o arquivo
                rewind($fp); // Volta ao início
                fwrite($fp, implode("\n", $linhas) . (empty($linhas) ? "" : "\n"));
                flock($fp, LOCK_UN); // Libera o bloqueio
            }
            if ($fp) fclose($fp);
            // --- FIM DA ATUALIZAÇÃO DE SEGURANÇA ---

            $sucesso = true;
            $mensagem = "Senha redefinida com sucesso! Você já pode fazer login.";
            $token_valido = false; // Impede que o formulário seja exibido novamente
        } else {
            $mensagem = "Erro: Cliente não encontrado.";
        }
    }
}

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redefinir Senha - <?= htmlspecialchars($configGeral['nome_barbearia']) ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/custom_theme.css.php">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .page-header {
            text-align: center;
            margin-bottom: 25px;
        }
        .page-header img {
            max-height: 120px;
            border-radius: 50%; /* Deixa a logo redonda */
            background: #fff;   /* Fundo branco */
            padding: 10px;      /* Espaçamento interno */
            box-shadow: 0 4px 10px rgba(0,0,0,0.1); /* Sombra suave */
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container" style="max-width: 500px; margin-top: 50px;">
        
        <div class="page-header">
            <?php if (!empty($configGeral['logo_path']) && file_exists($configGeral['logo_path'])): ?>
                <a href="index.php"><img src="<?= htmlspecialchars($configGeral['logo_path']) ?>" alt="Logo"></a>
            <?php endif; ?>
        </div>
        <h2>Redefinir Senha</h2>

        <?php if ($mensagem): ?>
            <p class="mensagem <?= $sucesso ? '' : 'erro' ?>"><?= $mensagem ?></p>
        <?php endif; ?>

        <?php if ($token_valido): ?>
        <form method="POST">
            <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
            <input type="hidden" name="email" value="<?= htmlspecialchars($email_do_token) ?>">
            
            <p style="text-align: center; color: #555;">Digite sua nova senha. Ela deve ter no mínimo 6 caracteres.</p>
            
            <div class="form-group">
                <label for="nova_senha">Nova Senha</label>
                <div class="input-icon"><i class="fa fa-lock"></i><input type="password" name="nova_senha" id="nova_senha" required></div>
            </div>
            <div class="form-group">
                <label for="confirma_nova_senha">Confirme a Nova Senha</label>
                <div class="input-icon"><i class="fa fa-lock"></i><input type="password" name="confirma_nova_senha" id="confirma_nova_senha" required></div>
            </div>
            <button type="submit" class="btn-primary">Salvar Nova Senha</button>
        </form>
        <?php endif; ?>

        <p style="text-align: center; margin-top: 20px;">
            <a href="login_cliente.php">Ir para o Login</a>
        </p>
    </div>
</body>
</html>