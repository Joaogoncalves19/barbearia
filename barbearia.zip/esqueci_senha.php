<?php
session_start();
require_once 'functions.php';
$configGeral = carregarConfigGeral();
$mensagem = '';
$msg_tipo = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim(htmlspecialchars($_POST['email']));
    
    if (empty($email)) {
        $mensagem = "Por favor, informe seu e-mail.";
        $msg_tipo = 'erro';
    } else {
        $cliente = getClientePorEmailTelefoneOuCPF($email);
        
        if ($cliente) {
            // Gera token único
            $token = bin2hex(random_bytes(32));
            $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
            
            // Salva token no arquivo de tokens (ou banco)
            // Formato: email|token|expiry
            $linha = "$email|$token|$expiry\n";
            file_put_contents(DATA_DIR . 'password_resets.txt', $linha, FILE_APPEND);
            
            // Envia e-mail (Simulação ou Real via PHPMailer se configurado)
            $link = "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/redefinir_senha.php?token=$token&email=" . urlencode($email);
            
            $assunto = "Redefinir Senha - " . $configGeral['nome_barbearia'];
            
            // Tenta enviar usando a função de email do sistema
            $dados_email = ['link' => $link, 'nome_cliente' => $cliente['nome']];
            if (enviarEmail($email, $assunto, 'redefinir_senha_link', $dados_email)) {
                $mensagem = "Um link de redefinição foi enviado para seu e-mail.";
                $msg_tipo = 'sucesso';
            } else {
                 // Fallback simples se o template não existir ou falhar
                 $mensagem = "Verifique seu e-mail (Link simulado: $link)"; // Em produção, não mostre o link aqui!
                 $msg_tipo = 'sucesso';
            }
        } else {
            // Por segurança, mostramos a mesma mensagem mesmo se não encontrar
            $mensagem = "Se o e-mail estiver cadastrado, você receberá um link.";
            $msg_tipo = 'sucesso';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Recuperar Senha - <?= htmlspecialchars($configGeral['nome_barbearia']) ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/custom_theme.css.php">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-image: none;
            background-color: var(--body-bg-color);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            max-width: 420px;
            width: 100%;
            margin: 40px auto;
            padding: 40px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            border-radius: 10px;
            text-align: center;
        }
    </style>
</head>
<body>

<?php 
    $pageTitle = 'Recuperar Senha';
    require_once 'header_app.php'; 
?>

<div class="container">
    
    <h2 style="margin-bottom: 15px;">Esqueceu a Senha?</h2>
    <p style="color: #666; margin-bottom: 25px; font-size: 0.95rem;">
        Digite seu e-mail abaixo e enviaremos um link para você redefinir sua senha.
    </p>

    <?php if ($mensagem): ?>
        <p class="mensagem <?= $msg_tipo == 'erro' ? 'erro' : '' ?>" 
           style="<?= $msg_tipo == 'sucesso' ? 'background-color: #d4edda; border-color: #c3e6cb; color: #155724;' : 'background-color: #f8d7da; border-color: #f5c6cb;' ?>">
           <?= htmlspecialchars($mensagem) ?>
        </p>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group" style="text-align: left;">
            <label for="email">Seu E-mail Cadastrado</label>
            <div class="input-icon">
                <i class="fa fa-envelope"></i>
                <input type="email" name="email" required placeholder="exemplo@email.com">
            </div>
        </div>
        
        <button type="submit" class="btn-primary" style="width: 100%; justify-content: center;">
            <i class="fa fa-paper-plane"></i> Enviar Link
        </button>
    </form>
    
    <div style="margin-top: 20px;">
        <a href="login_cliente.php" style="font-size: 0.9rem; font-weight: bold;"><i class="fa fa-arrow-left"></i> Voltar para o Login</a>
    </div>
</div>

</body>
</html>