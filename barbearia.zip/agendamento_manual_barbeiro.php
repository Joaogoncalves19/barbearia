<?php
session_start();

if (!isset($_SESSION['barbeiro_loggedin'])) {
    header('Location: login.php');
    exit;
}

date_default_timezone_set('America/Sao_Paulo');
require_once 'functions.php'; 

$barbeiro_id_logado = $_SESSION['barbeiro_id'];
$configGeral = carregarConfigGeral();

$clientesArr = lerDados('clientes.txt', ['id', 'nome', 'email', 'telefone']);
$barbeirosArr = lerDados('barbeiros.txt', ['id', 'nome', 'foto', 'username', 'password', 'status', 'servicos_ids']);
$servicosArr = lerDados('servicos.txt', ['id', 'nome', 'valor', 'slots', 'categoria_id']);
$combosArr = lerDados('combos.txt', ['id', 'nome', 'servicos_ids', 'valor', 'categoria_id']);
$categoriasArr = lerDados('categorias.txt', ['id', 'nome', 'ordem']); 
$planosArr = lerDados('planos.txt', ['id', 'nome', 'valor', 'servicos_ids']);
$assinaturasClientesArr = lerDados('clientes_assinaturas.txt', ['cliente_id', 'plano_id', 'data_inicio', 'data_fim', 'status']);

function getAssinaturaClienteLocal($cliente_id, $assinaturasArr) {
    return $assinaturasArr[$cliente_id] ?? null;
}

$barbeiro_atual = $barbeirosArr[$barbeiro_id_logado] ?? null;
$especialidades = [];
if ($barbeiro_atual && !empty($barbeiro_atual['servicos_ids'])) {
    $especialidades = explode(',', $barbeiro_atual['servicos_ids']);
}

foreach ($combosArr as $comboId => &$combo) {
    $slots_combo = 0;
    $servicos_do_combo = explode(',', $combo['servicos_ids']);
    foreach ($servicos_do_combo as $sid_combo) {
        $sid_limpo = trim($sid_combo);
        if (isset($servicosArr[$sid_limpo])) {
            $slots = (int)($servicosArr[$sid_limpo]['slots'] ?? 1);
            $slots_combo += ($slots > 0) ? $slots : 1;
        } else {
            $slots_combo += 1;
        }
    }
    $combo['slots'] = $slots_combo;
}
unset($combo); 

$itensAgrupados = [];
foreach ($categoriasArr as $catId => $cat) {
    $itensAgrupados[$catId] = [ 'nome' => $cat['nome'], 'ordem' => (int)($cat['ordem'] ?? 99), 'servicos' => [], 'combos' => [] ];
}
$itensAgrupados['sem_categoria'] = [ 'nome' => 'Outros', 'ordem' => 999, 'servicos' => [], 'combos' => [] ];
foreach ($servicosArr as $servico) {
    $catId = $servico['categoria_id'] ?? 'sem_categoria';
    if (empty($catId) || !isset($itensAgrupados[$catId])) $catId = 'sem_categoria';
    $itensAgrupados[$catId]['servicos'][] = $servico;
}
foreach ($combosArr as $combo) {
    $catId = $combo['categoria_id'] ?? 'sem_categoria';
    if (empty($catId) || !isset($itensAgrupados[$catId])) $catId = 'sem_categoria';
    $itensAgrupados[$catId]['combos'][] = $combo;
}
$itensAgrupados = array_filter($itensAgrupados, function($cat) { return !empty($cat['servicos']) || !empty($cat['combos']); });
uasort($itensAgrupados, fn($a, $b) => $a['ordem'] <=> $b['ordem']);

$mensagem = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cliente_id = $_POST['manual_cliente_id'];
    $servicos_ids_str = $_POST['manual_servicos'] ?? ''; 
    $data = $_POST['manual_data'];
    $hora = $_POST['manual_horario'];
    
    $aderir_plano = isset($_POST['aderir_plano']);
    $plano_id_adesao = $_POST['plano_adesao_id'] ?? '';

    if (!empty($cliente_id) && isset($clientesArr[$cliente_id])) {
        $nome_cliente = $clientesArr[$cliente_id]['nome'];
        $telefone_cliente = limparTelefone($clientesArr[$cliente_id]['telefone']);
        $email_cliente = $clientesArr[$cliente_id]['email'];
    } else {
        $nome_cliente = trim(htmlspecialchars($_POST['manual_nome']));
        $telefone_cliente = limparTelefone($_POST['manual_telefone']);
        $email_cliente = 'manual@agendamento.com'; 
    }

    if (empty($nome_cliente) || empty($telefone_cliente) || empty($servicos_ids_str) || empty($data) || empty($hora)) {
        $mensagem = "Por favor, preencha todos os campos obrigatórios.";
    } else {
        
        $desconto_aplicado = 0;
        $tipo_desconto = '';
        $plano_para_salvar = ''; 
        
        $itens_selecionados = explode(',', $servicos_ids_str);
        $valor_total_bruto = 0;
        $combos_selecionados_ids = [];
        $servicos_individuais_ids = [];
        $servicos_dentro_de_combos = [];

        foreach ($itens_selecionados as $item) {
            $item = trim($item);
            if (strpos($item, 'cb-') === 0 && isset($combosArr[$item])) {
                $valor_total_bruto += (float)$combosArr[$item]['valor'];
                $combos_selecionados_ids[] = $item;
                $subs = explode(',', $combosArr[$item]['servicos_ids']);
                foreach($subs as $sub) $servicos_dentro_de_combos[] = trim($sub);
            } elseif (strpos($item, 'sv-') === 0 && isset($servicosArr[$item])) {
                $valor_total_bruto += (float)$servicosArr[$item]['valor'];
                $servicos_individuais_ids[] = $item;
            }
        }

        // Lógica de Cálculo com Planos
        if ($aderir_plano && !empty($plano_id_adesao) && isset($planosArr[$plano_id_adesao])) {
            $tipo_desconto = 'adesao_plano';
            $plano_para_salvar = $plano_id_adesao;
            
            $plano = $planosArr[$plano_id_adesao];
            $valor_plano = (float)$plano['valor'];
            $servicosInclusos = array_map('trim', explode(',', $plano['servicos_ids']));
            $total_a_pagar_itens = 0;

            foreach($combos_selecionados_ids as $combo_id) {
                $combo = $combosArr[$combo_id];
                $servicos_do_combo = explode(',', $combo['servicos_ids']);
                $algum_coberto = false;
                $valor_nao_cobertos = 0;

                foreach($servicos_do_combo as $sid) {
                    $sid_limpo = trim($sid);
                    if (isset($servicosArr[$sid_limpo])) {
                        if (in_array($sid_limpo, $servicosInclusos)) {
                            $algum_coberto = true;
                        } else {
                            $valor_nao_cobertos += (float)$servicosArr[$sid_limpo]['valor'];
                        }
                    }
                }

                if ($algum_coberto) {
                    $total_a_pagar_itens += $valor_nao_cobertos;
                } else {
                    $total_a_pagar_itens += (float)$combo['valor'];
                }
            }

            foreach($servicos_individuais_ids as $sid) {
                if (isset($servicosArr[$sid])) {
                    if (!in_array($sid, $servicosInclusos)) {
                        $total_a_pagar_itens += (float)$servicosArr[$sid]['valor'];
                    }
                }
            }

            $valor_final_esperado = $valor_plano + $total_a_pagar_itens;
            $desconto_aplicado = $valor_total_bruto - $valor_final_esperado;

        } elseif (!empty($cliente_id)) {
            $assinatura = getAssinaturaClienteLocal($cliente_id, $assinaturasClientesArr);
            if ($assinatura && $assinatura['status'] === 'ativo') {
                $plano = $planosArr[$assinatura['plano_id']] ?? null;
                
                if ($plano) {
                    $servicosInclusos = array_map('trim', explode(',', $plano['servicos_ids']));
                    $desconto_total_vip = 0;

                    foreach($combos_selecionados_ids as $combo_id) {
                        $combo = $combosArr[$combo_id];
                        $servicos_do_combo = explode(',', $combo['servicos_ids']);
                        $itens_cobertos_count = 0;
                        $custo_real_itens_nao_cobertos = 0;

                        foreach($servicos_do_combo as $sid) {
                            $sid_limpo = trim($sid);
                            if (isset($servicosArr[$sid_limpo])) {
                                if (in_array($sid_limpo, $servicosInclusos)) {
                                    $itens_cobertos_count++;
                                } else {
                                    $custo_real_itens_nao_cobertos += (float)$servicosArr[$sid_limpo]['valor'];
                                }
                            }
                        }

                        if ($itens_cobertos_count > 0) {
                            $desconto_para_este_combo = (float)$combo['valor'] - $custo_real_itens_nao_cobertos;
                            $desconto_total_vip += $desconto_para_este_combo;
                        }
                    }

                    foreach($servicos_individuais_ids as $sid) {
                        if (in_array($sid, $servicosInclusos) && isset($servicosArr[$sid])) {
                            $desconto_total_vip += (float)$servicosArr[$sid]['valor'];
                        }
                    }

                    if ($desconto_total_vip != 0) {
                        $desconto_aplicado = $desconto_total_vip;
                        $tipo_desconto = 'assinatura_vip';
                    }
                }
            }
        }
        
        $timestamp_agendamento = strtotime("$data $hora");
        $status_inicial = ($timestamp_agendamento < time()) ? 'concluido' : 'aprovado';

        $id_agendamento = uniqid('ag-');
        $observacoes = '';
        $produtos_vendidos = ''; 
        
        $linha = "$id_agendamento|$nome_cliente|$email_cliente|$telefone_cliente|$barbeiro_id_logado|$servicos_ids_str|$data|$hora|$status_inicial|$desconto_aplicado|$tipo_desconto|$observacoes|$produtos_vendidos|$plano_para_salvar\n";
        
        file_put_contents(DATA_DIR . 'agendamentos.txt', $linha, FILE_APPEND | LOCK_EX);

        $configAgendamentoEmail = carregarConfigAgendamento();
        if ($status_inicial === 'aprovado' && filter_var($email_cliente, FILTER_VALIDATE_EMAIL) && ($configAgendamentoEmail['notif_aprovacao'] ?? 0) == 1) {
            $nomes_itens = [];
            foreach (explode(',', $servicos_ids_str) as $item_id) {
                $item_id = trim($item_id);
                if (isset($combosArr[$item_id])) $nomes_itens[] = $combosArr[$item_id]['nome'] . " (Combo)";
                elseif (isset($servicosArr[$item_id])) $nomes_itens[] = $servicosArr[$item_id]['nome'];
            }

             $dados_email = [
                'nome_cliente' => $nome_cliente,
                'data_agendamento' => date('d/m/Y', strtotime($data)),
                'hora_agendamento' => $hora,
                'servicos' => $nomes_itens,
                'barbeiro' => $barbeirosArr[$barbeiro_id_logado]['nome'] ?? 'Não especificado',
                'tipo_desconto' => $tipo_desconto // <--- CORREÇÃO APLICADA
            ];
            enviarEmail($email_cliente, 'Seu Agendamento foi Confirmado!', 'aprovado', $dados_email);
        }

        $_SESSION['agendamento_sucesso'] = "Agendamento para ".htmlspecialchars($nome_cliente)." realizado com sucesso!";
        header('Location: painel_barbeiro.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendamento Manual - Painel do Barbeiro</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/custom_theme.css.php">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .container { max-width: 700px; }
        .header { align-items: center; justify-content: space-between; }
        .header-info { display: flex; align-items: center; gap: 15px; }
        .header-info h2 { margin: 0; }
        
        #servicos-container { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 10px; margin-top: 10px; max-height: 250px; overflow-y: auto; border: 1px solid var(--border-color); padding: 10px; border-radius: 8px; background: #f8f9fa; }
        .categoria-titulo { font-size: 1.2rem; font-weight: bold; color: var(--primary-color); margin-top: 25px; margin-bottom: 10px; padding-bottom: 8px; border-bottom: 2px solid var(--border-color); text-align: left; grid-column: 1 / -1; }
        #servicos-container .categoria-titulo:first-of-type { margin-top: 0; }
        .servico-btn { font-size: 0.85rem; padding: 10px; text-align: left; display: flex; flex-direction: column; justify-content: space-between; line-height: 1.3; flex-grow: 0; min-width: auto; }
        .servico-btn .duracao { font-size: 0.8em; color: #6c757d; font-weight: normal; margin-top: 5px; }
        .combo-btn .duracao { color: var(--primary-color); opacity: 0.7; }
        .servico-btn span:first-child { font-weight: bold; font-size: 1.1em; pointer-events: none; }
        .servico-btn .duracao { pointer-events: none; }
        .servico-btn.combo-btn { border-color: var(--warning-color) !important; color: var(--warning-color) !important; }
        .servico-btn.combo-btn:hover, .servico-btn.combo-btn.selected { background: var(--warning-color) !important; color: var(--primary-color) !important; }
        #vip-badge { display: none; background-color: #28a745; color: white; font-size: 0.8em; padding: 3px 8px; border-radius: 12px; margin-left: 10px; font-weight: bold; vertical-align: middle; }
        .vip-section { background: #f3e5f5; padding: 15px; border-radius: 8px; border: 1px solid #e1bee7; margin-bottom: 15px; margin-top: 20px; }
        .vip-header { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; color: #6a1b9a; font-weight: bold; font-size: 1.1em; border-bottom: 1px solid rgba(106,27,154,0.2); padding-bottom: 5px; }
    </style>
</head>
<body class="admin-page">
    <div class="container">
        <div class="header">
            <div class="header-info">
                <h2><i class="fa fa-plus-circle"></i> Agendamento Manual</h2>
            </div>
            <a href="painel_barbeiro.php" class="btn" style="background-color:#6c757d;"><i class="fa fa-arrow-left"></i> Voltar ao Painel</a>
        </div>
        
        <?php if ($mensagem): ?>
            <p class="mensagem erro"><?= htmlspecialchars($mensagem) ?></p>
        <?php endif; ?>

        <form method="POST" id="form-agendamento-manual">
            <div class="form-group">
                <label>Cliente <span id="vip-badge"><i class="fa fa-crown"></i> CLIENTE VIP</span></label>
                <select name="manual_cliente_id" id="manual_cliente_id">
                    <option value="">-- Novo Cliente / Sem Cadastro --</option>
                    <?php foreach($clientesArr as $id => $c) echo "<option value='".htmlspecialchars($id)."' data-nome='".htmlspecialchars($c['nome'])."' data-telefone='".htmlspecialchars($c['telefone'])."'>".htmlspecialchars($c['nome'])."</option>"; ?>
                </select>
            </div>
            <div id="novo-cliente-fields">
                <div class="form-group">
                    <label for="manual_nome">Nome do Cliente</label>
                    <input type="text" name="manual_nome" id="manual_nome" required>
                </div>
                <div class="form-group">
                    <label for="manual_telefone">Telefone</label>
                    <input type="tel" name="manual_telefone" id="manual_telefone" placeholder="(99) 99999-9999" required>
                </div>
            </div>

            <div class="form-group">
                <label>Serviços e Combos (Especialidades de <?= htmlspecialchars($barbeiro_atual['nome']) ?>)</label>
                <div id="servicos-container">
                    <?php 
                    $totalItensExibidos = 0;
                    foreach ($itensAgrupados as $categoria):
                        $itensNestaCategoria = 0;
                        foreach ($categoria['combos'] as $c) { if (in_array($c['id'], $especialidades)) $itensNestaCategoria++; }
                        foreach ($categoria['servicos'] as $s) { if (in_array($s['id'], $especialidades)) $itensNestaCategoria++; }
                        
                        if ($itensNestaCategoria == 0) continue;
                        $totalItensExibidos += $itensNestaCategoria;
                    ?>
                        <h4 class="categoria-titulo"><?= htmlspecialchars($categoria['nome']) ?></h4>
                        <?php foreach ($categoria['combos'] as $c): if (!in_array($c['id'], $especialidades)) continue; $slots_combo = (int)($c['slots'] ?? 1); ?>
                            <button type="button" class="servico-btn combo-btn" data-id="<?= htmlspecialchars($c['id']) ?>" data-slots="<?= $slots_combo ?>" data-servicos-ids="<?= htmlspecialchars($c['servicos_ids']) ?>">
                                <span><?= htmlspecialchars($c['nome']) ?> - R$<?= htmlspecialchars($c['valor']) ?></span>
                                <span class="duracao"><i class="fa fa-clock"></i> <?= $slots_combo * 30 ?> min</span>
                            </button>
                        <?php endforeach; ?>
                        <?php foreach ($categoria['servicos'] as $s): if (!in_array($s['id'], $especialidades)) continue; $slots = (int)($s['slots'] ?? 1); $slots = max(1, $slots); ?>
                            <button type="button" class="servico-btn" data-id="<?= htmlspecialchars($s['id']) ?>" data-slots="<?= $slots ?>">
                                <span><?= htmlspecialchars($s['nome']) ?> - R$<?= htmlspecialchars($s['valor']) ?></span>
                                <span class="duracao"><i class="fa fa-clock"></i> <?= $slots * 30 ?> min</span>
                            </button>
                        <?php endforeach; ?>
                    <?php endforeach; ?>
                    <?php if ($totalItensExibidos == 0): echo "<p style='font-size: 0.9em; color: #6c757d; grid-column: 1 / -1;'>Nenhum serviço ou combo cadastrado para este barbeiro.</p>"; endif; ?>
                </div>
                <input type="hidden" name="manual_servicos" id="manual_servicos" required>
            </div>
            
            <?php if (!empty($planosArr)): ?>
            <div class="vip-section">
                <div class="vip-header"><i class="fa fa-crown"></i> Adesão Clube VIP</div>
                <div style="margin-bottom: 10px;">
                    <input type="checkbox" name="aderir_plano" id="aderir_plano" value="1" style="width: auto; margin-right: 5px;">
                    <label for="aderir_plano" style="display: inline; font-weight: normal;">Cliente deseja assinar/renovar um plano agora?</label>
                </div>
                <div id="container_plano_select" style="display: none; margin-top: 10px;">
                    <label style="font-size: 0.9em; font-weight: bold; margin-bottom: 5px; display: block;">Selecione o Plano:</label>
                    <select name="plano_adesao_id" id="plano_adesao_id" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                        <option value="">-- Escolha --</option>
                        <?php foreach($planosArr as $plano): ?>
                            <option value="<?= $plano['id'] ?>">
                                <?= htmlspecialchars($plano['nome']) ?> - R$ <?= number_format($plano['valor'], 2, ',', '.') ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p style="font-size: 0.8em; color: #666; margin-top: 5px;">
                        * O valor do agendamento será ajustado: Valor do Plano + Serviços não cobertos.
                    </p>
                </div>
            </div>
            <?php endif; ?>
            
            <div class="form-group">
                <label>Data</label>
                <input type="date" name="manual_data" id="manual_data" required>
            </div>
            <div class="form-group"><label>Horário</label><div class="horario-grid" id="manual_horarios-container">Selecione data e serviços.</div><input type="hidden" name="manual_horario" id="manual_horario" required></div>
            <button type="submit" class="btn-primary">Salvar Agendamento</button>
        </form>
    </div>

<script>
const servicosData = <?= json_encode($servicosArr) ?>;
const combosData = <?= json_encode($combosArr) ?>;
const assinaturasData = <?= json_encode($assinaturasClientesArr) ?>; 

document.addEventListener('DOMContentLoaded', function () {
    const clienteSelect = document.getElementById('manual_cliente_id');
    const nomeInputManual = document.getElementById('manual_nome');
    const telefoneInputManual = document.getElementById('manual_telefone');
    const novoClienteFields = document.getElementById('novo-cliente-fields');
    const barbeiroId = '<?= $barbeiro_id_logado ?>';
    const dataInput = document.getElementById('manual_data');
    const horariosContainer = document.getElementById('manual_horarios-container');
    const horarioHidden = document.getElementById('manual_horario');
    const servicosContainer = document.getElementById('servicos-container');
    const servicosHidden = document.getElementById('manual_servicos');
    const vipBadge = document.getElementById('vip-badge');
    const chkAderir = document.getElementById('aderir_plano');
    const containerSelect = document.getElementById('container_plano_select');
    const selectPlano = document.getElementById('plano_adesao_id');

    if (chkAderir) {
        chkAderir.addEventListener('change', function() {
            if (this.checked) {
                containerSelect.style.display = 'block';
                if(selectPlano) selectPlano.required = true;
            } else {
                containerSelect.style.display = 'none';
                if(selectPlano) {
                    selectPlano.required = false;
                    selectPlano.value = '';
                }
            }
        });
    }

    clienteSelect.addEventListener('change', function() {
        const selectedOption = this.options[this.selectedIndex];
        const isNewClient = !selectedOption.value;
        const clienteId = selectedOption.value;

        novoClienteFields.style.display = isNewClient ? 'block' : 'none';
        nomeInputManual.required = isNewClient;
        telefoneInputManual.required = isNewClient;

        let isVip = false;
        if (clienteId && assinaturasData[clienteId] && assinaturasData[clienteId].status === 'ativo') {
            const hoje = new Date().toISOString().split('T')[0];
            if (assinaturasData[clienteId].data_fim >= hoje) {
                isVip = true;
            }
        }
        if (isVip) vipBadge.style.display = 'inline-block';
        else vipBadge.style.display = 'none';

        if (!isNewClient) {
            nomeInputManual.value = selectedOption.dataset.nome;
            telefoneInputManual.value = selectedOption.dataset.telefone;
        } else {
            nomeInputManual.value = '';
            telefoneInputManual.value = '';
        }
    });

    servicosContainer.addEventListener('click', function(e) {
        const target = e.target.closest('.servico-btn');
        if (!target) return; 
        target.classList.toggle('selected');
        
        const isCombo = target.classList.contains('combo-btn');
        const idDoTarget = target.dataset.id;

        if (target.classList.contains('selected')) {
            if (isCombo) {
                const servicosNoCombo = target.dataset.servicosIds.split(',');
                servicosContainer.querySelectorAll('.servico-btn:not(.combo-btn).selected').forEach(btn => {
                    if (servicosNoCombo.includes(btn.dataset.id)) btn.classList.remove('selected');
                });
            } else {
                servicosContainer.querySelectorAll('.servico-btn.combo-btn.selected').forEach(btn => {
                    const servicosNoCombo = btn.dataset.servicosIds.split(',');
                    if (servicosNoCombo.includes(idDoTarget)) btn.classList.remove('selected');
                });
            }
        }
        const selecionados = Array.from(servicosContainer.querySelectorAll('.servico-btn.selected')).map(btn => btn.dataset.id);
        servicosHidden.value = selecionados.join(',');
        buscarHorarios();
    });

    async function buscarHorarios() {
        const data = dataInput.value;
        const selecionadosBotoes = Array.from(servicosContainer.querySelectorAll('.servico-btn.selected'));
        const itemIds = selecionadosBotoes.map(btn => btn.dataset.id);
        let totalSlots = 0;
        selecionadosBotoes.forEach(btn => { totalSlots += parseInt(btn.dataset.slots || 1); });
        const numServicosParaCalculo = totalSlots > 0 ? totalSlots : 1;
        
        horariosContainer.innerHTML = 'Aguardando...';
        horarioHidden.value = '';

        if (!data || itemIds.length === 0) {
            horariosContainer.innerHTML = 'Selecione data e serviços.';
            return;
        }

        try {
            const url = `get_horarios.php?barbeiro_id=${barbeiroId}&data=${data}&num_servicos_total=${numServicosParaCalculo}&itens_selecionados=${itemIds.join(',')}&admin_mode=1`;
            const response = await fetch(url);
            if (!response.ok) throw new Error('Erro na requisição.');
            const horariosDisponiveis = await response.json();
            
            horariosContainer.innerHTML = '';
            if (horariosDisponiveis.error || horariosDisponiveis.length === 0) {
                horariosContainer.innerHTML = `<p class="erro">${horariosDisponiveis.error || 'Nenhum horário disponível.'}</p>`;
                return;
            }
            horariosDisponiveis.forEach(h => {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'disponivel';
                btn.textContent = h;
                btn.addEventListener('click', () => {
                    horarioHidden.value = h;
                    horariosContainer.querySelectorAll('button').forEach(b => b.classList.remove('selecionado'));
                    btn.classList.add('selecionado');
                });
                horariosContainer.appendChild(btn);
            });
        } catch (error) {
            horariosContainer.innerHTML = '<p class="erro">Erro ao carregar horários.</p>';
        }
    }
    dataInput.addEventListener('change', buscarHorarios);
});
</script>
</body>
</html>