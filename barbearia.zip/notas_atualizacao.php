<?php
session_start();

// 1. Proteção de Administrador
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

// 2. Carregar funções e configurações básicas para o cabeçalho
require_once 'functions.php';
$configGeral = carregarConfigGeral();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Notas de Atualização - <?= htmlspecialchars($configGeral['nome_barbearia']) ?></title>
    
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/custom_theme.css.php">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        /* Estilos do Acordeão (baseados no admin.php) */
        .accordion-button {
            background-color: #e9ecef;
            color: #495057;
            cursor: pointer;
            padding: 18px;
            width: 100%;
            border: none;
            text-align: left;
            outline: none;
            font-size: 1.1rem;
            font-weight: bold;
            transition: 0.4s;
            border-radius: 8px;
            margin-top: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .accordion-button:hover { background-color: #dde2e6; }
        .accordion-button.active { border-radius: 8px 8px 0 0; }
        
        /* Ícone de seta (usa Font Awesome 6) */
        .accordion-button:after {
            content: '\f078'; /* Ícone 'chevron-down' */
            font-family: 'Font Awesome 6 Free';
            font-weight: 900;
            color: var(--secondary-color);
        }
        .accordion-button.active:after {
            content: "\f077"; /* Ícone 'chevron-up' */
        }
        
        /* Painel de conteúdo */
        .accordion-panel {
            padding: 0 18px; /* Inicia com padding 0 */
            background-color: var(--card-background, white);
            max-height: 0;
            overflow: hidden; /* Mantém hidden para a animação */
            transition: max-height 0.3s ease-out; /* Animação suave */
            border: 1px solid #e9ecef;
            border-top: none;
            border-radius: 0 0 8px 8px;
        }
        
        /* Classe 'active' é adicionada via JS para padding */
        .accordion-panel.active {
            padding: 18px; 
        }

        /* Estilos para o conteúdo dentro do painel */
        .release-notes-content {
            line-height: 1.6;
        }
        .release-notes-content h2 {
            color: var(--primary-color);
            border-bottom: 2px solid var(--border-color);
            padding-bottom: 10px;
            margin-top: 25px;
            font-size: 1.5rem;
        }
         .release-notes-content h2:first-of-type {
            margin-top: 0;
        }
        .release-notes-content h3 {
            color: var(--secondary-color);
            margin-top: 20px;
            margin-bottom: 10px;
            font-size: 1.2rem;
        }
        .release-notes-content ul {
            list-style-type: disc;
            padding-left: 20px;
        }
        .release-notes-content li {
            margin-bottom: 10px;
        }
        .release-notes-content code {
            background-color: #e9ecef;
            padding: 2px 5px;
            border-radius: 4px;
            font-family: monospace;
            color: #c7254e;
        }
        
        /* Estilo para a data */
        .accordion-date {
            font-size: 0.9rem;
            font-weight: normal;
            color: #6c757d;
            margin-left: 10px;
        }
    </style>
</head>
<body class="admin-page">

    <div class="container admin-container">

        <div class="header" style="align-items: center; justify-content: space-between;">
            <h2 style="margin: 0;"><i class="fa fa-clipboard-list"></i> Notas de Atualização</h2>
            <a href="admin.php" class="btn" style="background-color:#6c757d;"><i class="fa fa-arrow-left"></i> Voltar ao Painel</a>
        </div>

        <div style="margin-top: 20px;">
        
            <button class="accordion-button active" data-accordion="v2_6">
                <span>
                    Versão 2.6
                    <span class="accordion-date">(17 de Dezembro de 2025)</span>
                </span>
            </button>
            <div class="accordion-panel active" id="v2_6">
                <div class="release-notes-content">
                    <p>A Versão 2.6 foca na consistência visual e na experiência de onboarding do cliente, padronizando a interface de entrada e cadastro.</p>

                    <h2>1. Padronização de Acesso e UX</h2>
                    <p>As páginas de acesso dos clientes foram reformuladas para seguir a identidade visual e funcional do restante do sistema.</p>
                    <ul>
                        <li><strong>Cabeçalho Unificado:</strong> Implementação do cabeçalho global nas páginas de acesso. Isso garante que o usuário tenha acesso imediato ao menu de navegação e sinta consistência visual com a área logada e a landing page.</li>
                        <li><strong>Limpeza Visual:</strong> Remoção de logotipos duplicados e elementos redundantes que poluíam as telas, aproveitando o logo já presente no novo cabeçalho.</li>
                        <li><strong>Correção de Navegação:</strong> Ajuste na definição de variáveis de página no backend para garantir que o cabeçalho identifique corretamente a página atual e exiba os títulos apropriados.</li>
                    </ul>
                </div>
            </div>

            <button class="accordion-button" data-accordion="v2_5">
                <span>
                    Versão 2.5
                    <span class="accordion-date">(16 de Dezembro de 2025)</span>
                </span>
            </button>
            <div class="accordion-panel" id="v2_5">
                <div class="release-notes-content">
                    <p>A Versão 2.5 é um marco na evolução do sistema, introduzindo o poderoso <strong>Clube VIP</strong> e redefinindo completamente a experiência do usuário com uma nova <strong>Área do Cliente</strong> e melhorias estruturais de navegação.</p>

                    <h2>1. Reformulação Completa da Área do Cliente</h2>
                    <p>A antiga página "Minha Conta" foi transformada em um <strong>Dashboard Pessoal</strong> completo para o cliente, focado em retenção e facilidade de uso.</p>
                    <ul>
                        <li><strong>Dashboard de Estatísticas:</strong> O cliente agora visualiza cards com métricas pessoais: "Total de Visitas", "Total Investido", "Valor Economizado" e "Pontos de Fidelidade".</li>
                        <li><strong>Card "Próximo Agendamento":</strong> Um destaque visual no topo da página exibe o próximo compromisso com contagem regressiva, foto do barbeiro e botões de ação rápida para reagendar ou ver detalhes.</li>
                        <li><strong>Histórico Interativo:</strong> A lista de agendamentos passados agora possui design moderno em formato de cartões, mostrando claramente os serviços, valores e status de pagamento.</li>
                        <li><strong>Gestão de Assinatura:</strong> Uma nova seção dedicada exibe o status da assinatura VIP, dias restantes para o vencimento e o plano contratado, com alertas visuais coloridos (Verde para ativo, Amarelo para vencendo).</li>
                        <li><strong>Barbeiros Favoritos:</strong> O cliente pode favoritar barbeiros para acesso rápido no futuro.</li>
                    </ul>

                    <h2>2. Sistema de Assinaturas e Recorrência (Clube VIP)</h2>
                    <p>Uma nova forma de fidelizar clientes e garantir receita previsível.</p>
                    <ul>
                        <li><strong>Gestão de Planos:</strong> Nova aba em <code>Serviços > Planos</code> para criar pacotes personalizados (ex: "Vip Mensal", "Barba Ilimitada").</li>
                        <li><strong>Adesão Simplificada:</strong> O cliente pode marcar a opção <em>"Quero ser VIP"</em> diretamente no formulário de agendamento.</li>
                        <li><strong>Cobrança Inteligente:</strong> Ao aderir, o sistema cobra o valor do plano e automaticamente zera o custo dos serviços individuais inclusos.</li>
                        <li><strong>Renovação:</strong> Botão dedicado no perfil do cliente (Admin) para renovar a assinatura manualmente a cada mês, estendendo a validade.</li>
                    </ul>

                    <h2>3. URLs Amigáveis e Modernização (SEO)</h2>
                    <p>O sistema passou por uma atualização estrutural para suporte nativo a <strong>URLs Amigáveis</strong>.</p>
                    <ul>
                        <li><strong>Navegação Limpa:</strong> O sistema agora utiliza reescrita de URL (via <code>.htaccess</code>) para remover a extensão <code>.php</code> dos endereços.</li>
                        <li><strong>Exemplos:</strong>
                            <ul>
                                <li>Antes: <code>seusite.com/agendamento.php</code></li>
                                <li>Agora: <code>seusite.com/agendamento</code></li>
                            </ul>
                        </li>
                        <li><strong>Benefícios:</strong> Além de uma estética mais profissional, isso melhora a segurança (ocultando a tecnologia do backend) e a usabilidade.</li>
                    </ul>

                    <h2>4. Ajustes Gerais de Usabilidade e UX</h2>
                    <p>Diversos refinamentos foram aplicados em todo o sistema para tornar a navegação mais fluida tanto para o cliente quanto para o administrador.</p>
                    <ul>
                        <li><strong>Seleção Visual de Barbeiros:</strong> O dropdown de seleção de barbeiros no agendamento agora exibe a foto de perfil ao lado do nome, facilitando a identificação.</li>
                        <li><strong>Calendário Mobile (Flatpickr):</strong> Substituição dos seletores de data nativos pelo componente <em>Flatpickr</em>, garantindo compatibilidade total com dispositivos iOS e Android, além de bloquear visualmente dias passados e domingos (se configurado).</li>
                        <li><strong>Feedback Visual de Status:</strong> Novos badges coloridos em todo o sistema (Admin e Cliente) para identificar rapidamente status como "Pendente", "Concluído", "Cancelado" e "VIP".</li>
                        <li><strong>Modais Responsivos:</strong> Todos os formulários de edição (clientes, serviços, barbeiros) abrem em janelas modais sobrepostas, evitando o recarregamento desnecessário da página e agilizando a gestão.</li>
                    </ul>

                    <h2>5. Alterações Técnicas</h2>
                    <ul>
                        <li><strong>Novos Bancos de Dados:</strong> Criação dos arquivos <code>planos.txt</code> e <code>clientes_assinaturas.txt</code>.</li>
                        <li><strong>Lógica de Validade:</strong> Implementação de cálculo de datas (<code>+1 month</code>) para garantir renovações precisas.</li>
                        <li><strong>Refatoração do Backend:</strong> O sistema de cálculo de preços foi reescrito para suportar descontos de 100% baseados em planos ativos.</li>
                    </ul>
                </div>
            </div>

            <button class="accordion-button" data-accordion="v2_0">
                <span>
                    Versão 2.0
                    <span class="accordion-date">(13 de Novembro de 2025)</span>
                </span>
            </button>
            <div class="accordion-panel" id="v2_0">
                <div class="release-notes-content">
                    
                    <p>A versão 2.0 é uma atualização massiva focada em **estabilidade**, **segurança** e **performance**, além de introduzir dezenas de novas funcionalidades e um redesign completo da interface do cliente e da landing page.</p>

                    <h2>1. Performance, Estabilidade e Correções de Bugs</h2>
                    <p>O núcleo do sistema foi reescrito para garantir a integridade dos dados e otimizar a velocidade, corrigindo bugs críticos relacionados a agendamentos e performance.</p>

                    <h3>Melhorias de Estabilidade e Performance</h3>
                    <ul>
                        <li><strong>Estabilidade de Dados (File Locking):</strong> Implementamos um sistema de bloqueio de arquivos (<code>flock</code>) em todas as operações de leitura (<code>LOCK_SH</code>) e escrita (<code>LOCK_EX</code>). Isso elimina a "condição de corrida", garantindo que agendamentos não sejam perdidos ou arquivos corrompidos quando múltiplos usuários acessam o sistema ao mesmo tempo.</li>
                        <li><strong>Otimização de Consultas:</strong> A função <code>get_horarios.php</code> agora centraliza todo o cálculo de duração (slots) no backend, reduzindo a carga no JavaScript do cliente e aumentando a precisão da verificação de disponibilidade.</li>
                        <li><strong>Performance de Carregamento:</strong> A modularização do código (veja abaixo) reduziu o tempo de carregamento do painel de admin, pois o sistema agora carrega apenas os dados necessários para a aba selecionada.</li>
                    </ul>
                    
                    <h3>Principais Correções de Bugs</h3>
                    <ul>
                        <li><strong>Cálculo de Duração (Slots) no Reagendamento:</strong> Corrigido um bug crítico em todas as páginas de reagendamento (Admin e Barbeiro) onde a duração total do serviço (slots) não era respeitada. O sistema agora envia a lista de serviços ao backend, que calcula a duração correta e evita agendamentos sobrepostos.</li>
                        <li><strong>Agendamento Manual do Barbeiro:</strong> A página <code>agendamento_manual_barbeiro.php</code> foi corrigida para filtrar corretamente as especialidades do barbeiro, exibir combos, e usar o cálculo de slots de duração.</li>
                        <li><strong>Cadastro de Cliente (Admin):</strong> Restaurada a funcionalidade de "Salvar Cliente" no painel de admin, que não estava sendo processada.</li>
                        <li><strong>Lógica de Combos (JS):</strong> Corrigida a lógica de seleção de combos e serviços no frontend para evitar seleções conflitantes (ex: selecionar um combo e um serviço que já estava nele).</li>
                        <li><strong>Compatibilidade Mobile (iOS):</strong> Corrigido o bug no seletor de data nas páginas de reagendamento do barbeiro, garantindo funcionamento no Safari (iOS).</li>
                    </ul>

                    <h2>2. Melhorias de Arquitetura e Código</h2>
                    <p>O código-fonte foi completamente refatorado para modularização, tornando o sistema mais seguro, estável e fácil de manter.</p>
                    <ul>
                        <li><strong>Modularização (Backend):</strong> O arquivo <code>functions.php</code> foi simplificado para ser um "hub" central. Toda a lógica de banco de dados (<code>db_functions.php</code>), autenticação (<code>auth_functions.php</code>), e-mails (<code>email_functions.php</code>), agendamento (<code>agendamento_functions.php</code>), etc., foi movida para a nova pasta <code>/lib</code>.</li>
                        <li><strong>Modularização (Admin):</strong> O arquivo <code>admin.php</code> foi dividido. O HTML de cada aba foi movido para a pasta <code>/admin_tabs</code>, as ações de formulário para <code>admin_actions.php</code>, e o carregamento de dados para <code>admin_data.php</code>.</li>
                        <li><strong>Segurança de Senhas:</strong> O sistema de login e cadastro de administradores foi refeito para usar <code>password_hash()</code> e <code>password_verify()</code>, garantindo que nenhuma senha de admin seja armazenada em texto puro.</li>
                        <li><strong>Ferramenta de Diagnóstico:</strong> Adicionado o arquivo <code>install.php</code> para verificar permissões de pasta, extensões do PHP e permitir a criação segura do primeiro administrador.</li>
                    </ul>
                    
                    <h2>3. Novas Funcionalidades (Painel Admin)</h2>
                    <p>O painel de administração foi reestruturado para ser mais intuitivo e poderoso, com diversas novas funcionalidades de gestão.</p>
                    <ul>
                        <li><strong>Dashboard e Relatórios:</strong> A tela inicial do admin foi redesenhada com novos cartões de KPIs. A aba "Relatórios" foi expandida com gráficos financeiros, operacionais e de CRM, além de uma nova função de "Imprimir Relatório".</li>
                        <li><strong>Visualização de Agendamentos:</strong> A aba "Agendamentos" agora possui três modos de visualização: Lista, Cards e Agrupado por Barbeiro, além de uma função para "Imprimir Agenda do Dia".</li>
                        <li><strong>Gestão de Clientes (CRM):</strong> A aba "Clientes" foi redesenhada em formato de cards. Administradores agora podem <strong>Ativar/Desativar</strong> clientes.</li>
                        <li><strong>Gestão de Barbeiros:</strong> Adicionada a ferramenta <strong>"Gerenciar Agenda"</strong>, permitindo ao admin bloquear horários específicos para um barbeiro.</li>
                        <li><strong>Gestão de Serviços:</strong>
                            <ul>
                                <li><strong>Slots de Tempo (Duração):</strong> Cada serviço agora tem uma duração personalizada em "slots" de 30 minutos, que o sistema usa para calcular a disponibilidade.</li>
                                <li><strong>Categorias de Serviços:</strong> Implementado um sistema de "Categorias" para organizar serviços e combos.</li>
                                <li><strong>Especialidades do Barbeiro:</strong> Barbeiros agora são associados a serviços e combos específicos que eles podem realizar.</li>
                            </ul>
                        </li>
                        <li><strong>Marketing e Avaliações:</strong>
                            <ul>
                                <li>Adicionada ferramenta de <strong>E-mail Marketing (Newsletter)</strong>.</li>
                                <li>Adicionada ferramenta de <strong>Reativação de Clientes Ausentes</strong>.</li>
                                <li>Administradores agora podem <strong>responder avaliações</strong> (visível na "Minha Conta" do cliente).</li>
                                <li>Adicionado botão para <strong>enviar lembretes de avaliação</strong> manualmente.</li>
                            </ul>
                        </li>
                    </ul>
                    
                    <h2>4. Redesign da Landing Page (index.php)</h2>
                    <p>A página inicial foi completamente modernizada para uma aparência mais premium e dinâmica.</p>
                    <ul>
                        <li><strong>Vídeo de Fundo:</strong> A seção principal agora suporta upload de vídeo de fundo.</li>
                        <li><strong>Menu Fixo e Inteligente:</strong> O menu superior agora é fixo e muda de transparente para sólido durante a rolagem.</li>
                        <li><strong>Unificação de Cores:</strong> A página agora usa a "Cor Secundária" definida no painel de admin como sua cor de destaque principal.</li>
                        <li><strong>Animações de Scroll:</strong> Adicionadas animações "fade-in" suaves conforme o usuário rola a página.</li>
                    </ul>

                    <h2>5. Redesign da "Minha Conta" (Área do Cliente)</h2>
                    <p>A área do cliente foi redesenhada com foco na personalização e em fornecer mais informações úteis.</p>
                    <ul>
                        <li><strong>Cabeçalho Personalizado:</strong> O cabeçalho agora exibe a foto de perfil do cliente.</li>
                        <li><strong>Novo Card "Próximo Agendamento":</strong> Um card de destaque exibe a foto do barbeiro, sua média de avaliações, os serviços agendados e a contagem regressiva.</li>
                        <li><strong>Painel de Estatísticas:</strong> O cliente agora pode ver seu "Total de Visitas", "Gasto Total" e "Pontos Atuais" na aba "Meu Perfil".</li>
                        <li><strong>Respostas do Admin:</strong> O cliente agora pode ver as respostas do administrador às suas avaliações na aba "Minhas Avaliações".</li>
                        <li><strong>Feedback Visual:</strong> O botão "Copiar Código" de indicação agora mostra "Copiado!" em vez de um alerta.</li>
                    </ul>
                </div>
            </div>

            <button class="accordion-button" data-accordion="v1_0">
                <span>
                    Versão 1.0
                    <span class="accordion-date">(Final de Setembro de 2025)</span>
                </span>
            </button>
            <div class="accordion-panel" id="v1_0">
                <div class="release-notes-content">
                    <p>Notas sobre o lançamento original do sistema.</p>
                    
                    <h3>Funcionalidades Principais</h3>
                    <ul>
                        <li>Sistema de agendamento online para clientes.</li>
                        <li>Painel de administração para gestão de horários.</li>
                        <li>Cadastro de clientes e barbeiros.</li>
                    </ul>
                </div>
            </div>

        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var acc = document.getElementsByClassName("accordion-button");
        
        for (var i = 0; i < acc.length; i++) {
            
            // Seta o painel 'ativo' (Versão 2.6) para abrir no carregamento
            if (acc[i].classList.contains('active')) {
                var panel = document.getElementById(acc[i].dataset.accordion);
                
                // Adiciona um "buffer" de 50px à altura para garantir que o texto não corte
                panel.style.maxHeight = (panel.scrollHeight + 50) + "px"; 
                
                panel.classList.add('active'); // Adiciona classe para o padding
            }

            // Adiciona o evento de clique
            acc[i].addEventListener("click", function() {
                // Fecha todos os outros painéis (opcional, mas bom para listas longas)
                for (var j = 0; j < acc.length; j++) {
                    if (this !== acc[j] && acc[j].classList.contains('active')) {
                        acc[j].classList.remove('active');
                        var otherPanel = document.getElementById(acc[j].dataset.accordion);
                        otherPanel.style.maxHeight = null;
                        otherPanel.classList.remove('active');
                    }
                }
                
                // Abre ou fecha o painel clicado
                this.classList.toggle("active");
                var panel = document.getElementById(this.dataset.accordion);
                
                if (panel.style.maxHeight) {
                    // Fechar
                    panel.style.maxHeight = null;
                    panel.classList.remove('active');
                } else {
                    // Abrir
                    // Adiciona um "buffer" de 50px à altura para garantir que o texto não corte
                    panel.style.maxHeight = (panel.scrollHeight + 50) + "px"; 
                    panel.classList.add('active');
                } 
            });
        }
    });
    </script>
</body>
</html>