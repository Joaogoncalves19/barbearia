<?php
session_start();
require_once 'functions.php';
$configGeral = carregarConfigGeral(); // Carrega as configurações gerais

$token = $_GET['token'] ?? null;
$mensagem = '';
$mensagem_tipo = 'erro'; // 'erro' ou 'sucesso'

if (empty($token)) {
    $mensagem = "Token de confirmação inválido ou ausente.";
} else {
    // --- INÍCIO DA ATUALIZAÇÃO DE SEGURANÇA ---
    
    // Estrutura esperada (baseada no novo registro.php):
    // --- CORREÇÃO AQUI ---
    // A chave 'indicado_por_id' foi adicionada na 10ª posição para corresponder
    // à estrutura de 12 colunas salva no arquivo 'registro.php'.
    $keys_clientes_completo = [
        'id', 'nome', 'email', 'telefone', 'password_hash', 
        'data_nascimento', 'foto_perfil', 'codigo_indicacao', 'cpf', 
        'indicado_por_id', // <-- CHAVE CORRIGIDA
        'status', 'confirmation_token'
    ];
    // --- FIM DA CORREÇÃO ---
    
    // 1. Leitura Segura (usa flock LOCK_SH via lerDados)
    $clientesArr = lerDados('clientes.txt', $keys_clientes_completo);
    
    $token_encontrado = false;
    $cliente_id_para_ativar = null;

    // 2. Encontra o cliente com o token correspondente
    foreach ($clientesArr as $id => $cliente) {
        // Verifica se a linha tem o token e se o status é 'inativo'
        if (isset($cliente['confirmation_token']) && $cliente['confirmation_token'] === $token && isset($cliente['status']) && $cliente['status'] === 'inativo') {
            $cliente_id_para_ativar = $id;
            $token_encontrado = true;
            break;
        }
    }

    if ($token_encontrado && $cliente_id_para_ativar) {
        // 3. Modifica os dados do cliente no array
        $clientesArr[$cliente_id_para_ativar]['status'] = 'ativo';   // Muda o status para 'ativo'
        $clientesArr[$cliente_id_para_ativar]['confirmation_token'] = ''; // Limpa o token

        // 4. Salva as alterações de forma segura (usa flock LOCK_EX via salvarDadosCliente)
        salvarDadosCliente($clientesArr);
        
        $mensagem = "Seu cadastro foi ativado com sucesso! Você já pode fazer o login.";
        $mensagem_tipo = 'sucesso';
    } else {
        // Token não encontrado ou a conta já estava ativa
        $mensagem = "Este link de confirmação é inválido ou já foi utilizado.";
    }
    // --- FIM DA ATUALIZAÇÃO DE SEGURANÇA ---
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmação de Cadastro</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/custom_theme.css.php">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .page-header { text-align: center; margin-bottom: 25px; }
        .page-header img { max-height: 120px; }
        
        .container {
            max-width: 550px;
            margin-top: 60px;
            text-align: center;
        }
        
        /* Estilos para telas menores (celulares) */
        @media (max-width: 600px) {
            body {
                display: block;
                min-height: 100%;
            }
            .container {
                width: 100%;
                max-width: none;
                margin: 0;
                padding: 25px;
                box-shadow: none;
                border-radius: 0;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <div class="page-header">
        <?php if (!empty($configGeral['logo_path']) && file_exists($configGeral['logo_path'])): ?>
            <a href="index.php"><img src="<?= htmlspecialchars($configGeral['logo_path']) ?>" alt="Logo da Barbearia"></a>
        <?php endif; ?>
    </div>
    
    <?php if ($mensagem_tipo === 'sucesso'): ?>
        <h2>Cadastro Confirmado!</h2>
        <p class="mensagem" style="background-color: #d4edda; border-color: #c3e6cb;"><?= htmlspecialchars($mensagem) ?></p>
        <a href="login_cliente.php" class="btn-primary" style="text-decoration: none; padding: 15px; display: block;">Ir para o Login</a>
    <?php else: ?>
        <h2>Erro na Confirmação</h2>
        <p class="mensagem erro" style="background-color: #f8d7da; border-color: #f5c6cb;"><?= htmlspecialchars($mensagem) ?></p>
        <a href="registro.php" class="btn-primary" style="text-decoration: none; padding: 15px; display: block;">Tentar Cadastro Novamente</a>
    <?php endif; ?>
</div>
</body>
</html>