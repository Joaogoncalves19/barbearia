<?php
// functions.php (Arquivo Centralizador)

// --- CONFIGURAÇÕES GLOBAIS ---
// Define o fuso horário padrão para todo o sistema
date_default_timezone_set('America/Sao_Paulo');

// Define constantes globais para os caminhos de dados
define('DATA_DIR', __DIR__ . '/_dados/');
define('LOG_FILE', __DIR__ . '/_logs/app_log.txt');

// --- INÍCIO DA CORREÇÃO (Definição da BASE_URL) ---
// Define a URL base do site dinamicamente
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443)) ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
define('BASE_URL', $protocol . $host . $uri . '/');
// --- FIM DA CORREÇÃO ---


// --- CARREGAMENTO DOS MÓDULOS DE LÓGICA ---
// A ordem de alguns arquivos é importante (ex: utils e db devem vir primeiro)

// Funções pequenas e utilitárias (log, limparTelefone, validarCPF)
require_once 'lib/utils_functions.php';

// Funções de acesso ao "banco de dados" (lerDados, salvarDados)
require_once 'lib/db_functions.php';

// Funções para carregar arquivos de configuração (geral, email, agendamento, etc.)
require_once 'lib/config_functions.php';

// Funções de autenticação e gerenciamento de usuários (clientes, barbeiros)
require_once 'lib/auth_functions.php';

// Funções relacionadas ao envio de e-mail (PHPMailer)
require_once 'lib/email_functions.php';

// Funções de lógica de agendamento (horários, vagas, etc.)
require_once 'lib/agendamento_functions.php';

// Funções de marketing (fidelidade, cupons, vouchers, indicação)
require_once 'lib/marketing_functions.php';

// Funções de notificações internas do sistema
require_once 'lib/notificacao_functions.php';

// Funções de cálculo para relatórios e dashboard
require_once 'lib/relatorio_functions.php';

?>