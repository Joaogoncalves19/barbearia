<?php
session_start();
// Define o fuso horário no início do script para garantir consistência nas datas
date_default_timezone_set('America/Sao_Paulo');

// --- CORREÇÃO DO BUG DE LOGIN ---
// A verificação deve ser por 'loggedin', conforme definido no login.php corrigido
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: login.php');
    exit;
}

// 1. Inclui as funções principais
require_once 'functions.php';

// 2. Define as chaves e caminhos (necessário para ações e dados)
$barbeirosFile = 'barbeiros.txt'; $servicosFile = 'servicos.txt'; $combosFile = 'combos.txt'; $agendamentosFile = 'agendamentos.txt'; $horariosFile = 'horarios_trabalho.txt'; $configFile = 'config.txt'; $usersFile = 'users.txt'; $clientesFile = 'clientes.txt'; $avaliacoesFile = 'avaliacoes.txt'; $fidelidadeConfigFile = 'fidelidade_config.txt'; $cupoesFile = 'cupoes.txt'; $aniversarioConfigFile = 'config_aniversario.txt'; $anotacoesFile = 'anotacoes_clientes.txt'; $vouchersFile = 'vouchers.txt'; $configGeralFile = 'config_geral.txt'; $configAgendamentoFile = 'config_agendamento.txt'; $configIndicacaoFile = 'config_indicacao.txt';

// --- INÍCIO DA ATUALIZAÇÃO (Funcionalidade 2: Categorias) ---
$categoriasFile = 'categorias.txt';
$keys_categorias = ['id', 'nome', 'ordem'];
// --- FIM DA ATUALIZAÇÃO ---

// --- INÍCIO DAS NOVAS FUNCIONALIDADES DE AVALIAÇÃO ---
$avaliacoesDestacadasFile = 'avaliacoes_destacadas.txt';
$respostasAvaliacoesFile = 'respostas_avaliacoes.txt';

$keys_avaliacoes_destacadas = ['id_avaliacao']; // Simples, apenas o ID da avaliação em destaque
$keys_respostas_avaliacoes = ['id_resposta', 'id_avaliacao', 'texto_resposta', 'timestamp'];
// --- FIM DAS NOVAS FUNCIONALIDADES DE AVALIAÇÃO ---


$agendamentosFilePath = DATA_DIR . $agendamentosFile; $horariosFilePath = DATA_DIR . $horariosFile; $configFilePath = DATA_DIR . $configFile; $usersFilePath = DATA_DIR . $usersFile; $themeConfigFile = DATA_DIR . 'theme_config.json'; $fidelidadeConfigPath = DATA_DIR . $fidelidadeConfigFile; $aniversarioConfigPath = DATA_DIR . $aniversarioConfigFile; $configGeralPath = DATA_DIR . $configGeralFile; $configAgendamentoPath = DATA_DIR . $configAgendamentoFile; $configIndicacaoPath = DATA_DIR . $configIndicacaoFile;

$keys_barbeiros = ['id', 'nome', 'foto', 'username', 'password', 'status', 'servicos_ids']; 

// --- INÍCIO DA ATUALIZAÇÃO (Funcionalidade 1 e 2) ---
// Adiciona 'slots' (coluna 4) e 'categoria_id' (coluna 5)
$keys_servicos = ['id', 'nome', 'valor', 'slots', 'categoria_id']; 
// Adiciona 'categoria_id' (coluna 5)
$keys_combos = ['id', 'nome', 'servicos_ids', 'valor', 'categoria_id']; 
// --- FIM DA ATUALIZAÇÃO ---

$keys_agendamentos = ['id', 'nome', 'email', 'telefone', 'barbeiro_id', 'servicos_ids', 'data', 'hora', 'status', 'desconto_aplicado', 'tipo_desconto', 'observacoes', 'produtos_vendidos']; 

// --- INÍCIO DA CORREÇÃO (O BUG ESTAVA AQUI) ---
// A chave 'indicado_por_id' estava faltando, causando desalinhamento
// dos dados de status e token ao ler o arquivo clientes.txt.
$keys_clientes = [
    'id', 'nome', 'email', 'telefone', 'password_hash', 
    'data_nascimento', 'foto_perfil', 'codigo_indicacao', 'cpf', 
    'indicado_por_id', // <-- CHAVE ADICIONADA NA 10ª POSIÇÃO
    'status', 'confirmation_token'
];
// --- FIM DA CORREÇÃO ---

$keys_avaliacoes = ['id', 'agendamento_id', 'cliente_id', 'barbeiro_id', 'rating', 'comment', 'timestamp']; $keys_cupoes = ['id', 'codigo', 'desconto_percentual', 'usos_maximos', 'data_validade', 'usos_atuais']; $keys_vouchers = ['id', 'codigo', 'valor', 'status', 'data_criacao', 'agendamento_id_uso', 'data_validade'];
$dias_semana_texto = ['0' => 'Domingo', '1' => 'Segunda', '2' => 'Terça', '3' => 'Quarta', '4' => 'Quinta', '5' => 'Sexta', '6' => 'Sábado'];
$meses_texto = ['01' => 'Janeiro', '02' => 'Fevereiro', '03' => 'Março', '04' => 'Abril', '05' => 'Maio', '06' => 'Junho', '07' => 'Julho', '08' => 'Agosto', '09' => 'Setembro', '10' => 'Outubro', '11' => 'Novembro', '12' => 'Dezembro'];

// 3. Carrega os dados iniciais (necessários para as ações)
// (Todas estas funções já são seguras pois usam lerDados())
$configGeral = carregarConfigGeral();
$configAgendamento = carregarConfigAgendamento();
$configEmail = carregarConfigEmail();
$configIndicacao = getIndicacaoConfig();
$barbeirosArr = lerDados($barbeirosFile, $keys_barbeiros); $servicosArr = lerDados($servicosFile, $keys_servicos); $combosArr = lerDados($combosFile, $keys_combos); $agendamentosArr = lerDados($agendamentosFile, $keys_agendamentos); 

// --- INÍCIO DA ATUALIZAÇÃO (Funcionalidade 2: Categorias) ---
$categoriasArr = lerDados($categoriasFile, $keys_categorias); 
// --- FIM DA ATUALIZAÇÃO ---

// --- INÍCIO DAS NOVAS FUNCIONALIDADES DE AVALIAÇÃO ---
$avaliacoesDestacadasArr = lerDados($avaliacoesDestacadasFile, $keys_avaliacoes_destacadas);
$respostasAvaliacoesRaw = lerDados($respostasAvaliacoesFile, $keys_respostas_avaliacoes);
$respostasAvaliacoesArr = [];
foreach ($respostasAvaliacoesRaw as $resposta) {
    if (isset($resposta['id_avaliacao'])) {
        $respostasAvaliacoesArr[$resposta['id_avaliacao']] = $resposta;
    }
}
// --- FIM DAS NOVAS FUNCIONALIDADES DE AVALIAÇÃO ---


$clientesArr = lerDados($clientesFile, $keys_clientes); 

$avaliacoesArr = lerDados($avaliacoesFile, $keys_avaliacoes); $cupoesArr = lerDados($cupoesFile, $keys_cupoes); $vouchersArr = lerDados($vouchersFile, $keys_vouchers); 

// --- INÍCIO DA ATUALIZAÇÃO DE SEGURANÇA: Leitura segura do config.txt ---
$config = ['aprovar' => 'manual'];
if (file_exists($configFilePath)) {
    $fp = fopen($configFilePath, 'r');
    if (!$fp) {
        log_activity("FALHA: Não foi possível abrir $configFilePath (admin.php).");
    } else {
        if (flock($fp, LOCK_SH)) {
            $contents = '';
            while (!feof($fp)) {
                $contents .= fread($fp, 8192);
            }
            flock($fp, LOCK_UN);
            
            if (!empty($contents)) {
                $parsedConfig = parse_ini_string($contents);
                if ($parsedConfig) {
                    $config = $parsedConfig;
                }
            }
        } else {
             log_activity("FALHA: Não foi possível obter LOCK_SH no $configFilePath (admin.php).");
        }
        fclose($fp);
    }
}
// --- FIM DA ATUALIZAÇÃO DE SEGURANÇA ---

$pontosFidelidade = getAllFidelityPoints(); // (Função segura)
$configFidelidade = getFidelityConfig(); // (Função segura)
$configAniversario = getAniversarioConfig(); // (Função segura)
$anotacoesClientes = lerAnotacoesTodosClientes(); // (Função segura)

// --- INÍCIO DA ATUALIZAÇÃO DE SEGURANÇA: Leitura segura do users.txt ---
$usersArr = [];
if (!file_exists($usersFilePath)) {
    log_activity("FALHA: Arquivo users.txt não encontrado (admin.php).");
} else {
    $fp = fopen($usersFilePath, 'r');
    if (!$fp) {
        log_activity("FALHA: Não foi possível abrir o arquivo $usersFilePath (admin.php).");
    } else {
        if (flock($fp, LOCK_SH)) {
            while (($line = fgets($fp)) !== false) {
                $line = trim($line);
                if (empty($line)) continue;
                $parts = explode(':', $line, 2);
                if (count($parts) === 2) {
                    $usersArr[$parts[0]] = ['username' => $parts[0], 'password' => $parts[1]]; // $parts[1] é um HASH
                }
            }
            flock($fp, LOCK_UN);
        } else {
            log_activity("FALHA: Não foi possível obter LOCK_SH no arquivo $usersFilePath (admin.php).");
        }
        fclose($fp);
    }
}
// --- FIM DA ATUALIZAÇÃO DE SEGURANÇA ---


// 4. Processa qualquer ação (POST/GET)
// (O 'admin_actions.php' corrigido já foi aplicado)
require_once 'admin_actions.php';

// 5. Carrega e prepara os dados para exibição (relatórios, dashboards, etc.)
// (O 'admin_data.php' corrigido já foi aplicado)
require_once 'admin_data.php';

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin - <?= htmlspecialchars($configGeral['nome_barbearia']) ?></title>
<link rel="stylesheet" href="css/style.css"><link rel="stylesheet" href="css/custom_theme.css.php"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"><script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
    /* ... (todo o seu CSS original de 600 linhas vai aqui) ... */
    /* (Copiado do arquivo original que você enviou) */
    .btn.btn-info { background-color: #17a2b8; } .btn.btn-info:hover { background-color: #138496; }
    .tab { flex-wrap: wrap; }
    .dashboard { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }
    .dash-card { background-color: var(--card-background); border: 1px solid var(--border-color); border-radius: 10px; padding: 25px; text-align: center; box-shadow: 0 4px 10px rgba(0,0,0,0.05); }
    .dash-card .icon { font-size: 2.5rem; color: var(--secondary-color); margin-bottom: 15px; }
    .dash-card h4 { font-size: 1.2rem; margin: 0 0 10px 0; color: var(--text-color); }
    .dash-card .value { font-size: 2rem; font-weight: bold; color: var(--primary-color); }
    .dashboard-filter-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 15px;}
    .dashboard-filter-header h3, .dashboard-filter-header h4 { margin: 0; }
    .dashboard-filter { display: flex; gap: 10px; align-items: center; }
    .dashboard-filter select, .dashboard-filter input { font-size: 14px; padding: 8px 12px; border-radius: 6px; border: 1px solid var(--border-color); background-color: #fff; }
    .dashboard-filter .btn-filtrar { background-color: var(--secondary-color); color: white; padding: 8px 15px; border-radius: 6px; border: none; cursor: pointer; font-weight: bold; }
    .dashboard-periodo { font-size: 1.1rem; text-align: center; margin-bottom: 25px; background-color: #e9f0f6; padding: 10px; border-radius: 8px; }
    .aniversariantes-card { grid-column: 1 / -1; text-align: left; }
    .aniversariantes-lista { list-style: none; padding: 0; max-height: 250px; overflow-y: auto; }
    .aniversariantes-lista li { padding: 12px; border-bottom: 1px solid var(--border-color); display: flex; align-items: center; gap: 15px; }
    .aniversariantes-lista li:last-child { border-bottom: none; }
    .aniversariante-info { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; flex-grow: 1; }
    .aniversariante-nome { font-weight: bold; font-size: 1.1rem; }
    .aniversariante-contato { display: flex; flex-direction: column; gap: 5px; font-size: 0.9rem; color: #555; }
    .aniversariante-contato span { display: flex; align-items: center; gap: 5px; }
    .header-buttons { display: flex; gap: 10px; align-items: center; }
    .btn-refresh { padding: 8px 15px; background-color: var(--secondary-color); color: #fff; border-radius: 8px; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; font-weight: normal; }
    .theme-customizer { background-color: #f8f9fa; border: 1px solid #e0e0e0; border-radius: 8px; padding: 20px; margin-top: 20px; }
    .theme-customizer h4 { margin-top: 0; margin-bottom: 25px; text-align: left; }
    .color-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }
    .color-picker-group { display: flex; align-items: center; gap: 10px; }
    .color-picker-group label { font-weight: bold; flex-shrink: 0; }
    .color-picker-group input[type="color"] { width: 50px; height: 30px; padding: 0; border: 1px solid #ccc; border-radius: 4px; cursor: pointer; }
    .desconto-info { font-weight: bold; color: #28a745; display: block; font-size: 0.9em; margin-top: 5px; }
    .desconto-info .fa { margin-right: 5px; }
    .chart-container { position: relative; height: 40vh; width: 100%; max-width: 900px; margin: 20px auto; }
    .relatorios-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
    .combo-servicos-lista, .ranking-lista { list-style: none; padding-left: 0; margin: 0; font-size: 0.9em; color: #666; }
    .combo-servicos-lista li, .ranking-lista li { padding: 5px 0; display: flex; justify-content: space-between; }
    #servicos-para-combo-container { display: flex; flex-wrap: wrap; gap: 10px; max-height: 200px; overflow-y: auto; padding: 10px; border: 1px solid var(--border-color); border-radius: 8px; }
    .config-section { background: #f8f9fa; padding: 25px; border-radius: 12px; margin-bottom: 30px; border: 1px solid var(--border-color); }
    .config-section h4 { text-align: left; margin-top: 0; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1px solid var(--border-color); display: flex; align-items: center; gap: 10px; }
    .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }
    .form-switch { display: flex; justify-content: space-between; align-items: center; background: #fff; padding: 12px; border-radius: 8px; border: 1px solid var(--border-color); }
    .observacao-cliente, .produtos-vendidos { font-size: 0.9em; color: #666; background-color: #f0f8ff; border-left: 3px solid var(--secondary-color); padding: 8px; margin-top: 5px; display: block; white-space: pre-wrap; }
    .produtos-vendidos ul { list-style: none; padding: 0; margin: 0; }
    @media (max-width: 992px) { .relatorios-grid { grid-template-columns: 1fr; } }
    .sub-tab { display: flex; gap: 5px; margin-bottom: 20px; background-color: #e9ecef; padding: 5px; border-radius: 8px; }
    .sub-tab-btn { flex: 1; padding: 10px; background: transparent; border: none; border-radius: 6px; cursor: pointer; font-weight: bold; color: #495057; }
    .sub-tab-btn.active { background: var(--card-background); color: var(--secondary-color); box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
    .sub-tabcontent { display: none; }
    .sub-tabcontent.active { display: block; }
    .avaliacao-card-admin { background-color: #fff; border: 1px solid var(--border-color); border-radius: 8px; padding: 15px; margin-bottom: 15px; }
    .avaliacao-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
    .avaliacao-cliente-info { display: flex; align-items: center; gap: 10px; }
    .avaliacao-cliente-info img { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; }
    .avaliacao-cliente-info .nome-cliente { font-weight: bold; text-decoration: none; color: var(--primary-color); }
    .avaliacao-cliente-info .nome-cliente:hover { color: var(--secondary-color); }
    .avaliacao-rating { font-size: 1.1rem; color: var(--warning-color); }
    .avaliacao-comment { margin: 10px 0; font-style: italic; color: #555; }
    .avaliacao-footer { display: flex; justify-content: space-between; align-items: center; font-size: 0.9em; color: #777; }
    .barbeiros-grid, .clientes-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 20px; }
    .barbeiro-card { background-color: var(--card-background); border: 1px solid var(--border-color); border-radius: 12px; display: flex; flex-direction: column; overflow: hidden; }
    .barbeiro-card-header { display: flex; align-items: center; gap: 15px; padding: 15px; border-bottom: 1px solid var(--border-color); }
    .barbeiro-card-header img { width: 60px; height: 60px; border-radius: 50%; object-fit: cover; }
    .barbeiro-card-header h4 { margin: 0; font-size: 1.3rem; word-break: break-word; }
    .barbeiro-card-stats { display: grid; grid-template-columns: 1fr 1fr 1fr; text-align: center; padding: 15px; gap: 10px; }
    .barbeiro-card-stats div { padding: 10px; background-color: #f8f9fa; border-radius: 8px; }
    .barbeiro-card-stats .stat-value { font-size: 1.2rem; font-weight: bold; }
    .barbeiro-card-stats .stat-label { font-size: 0.8rem; color: #6c757d; }
    .barbeiro-card-actions { display: flex; gap: 10px; padding: 15px; border-top: 1px solid var(--border-color); background-color: #fdfdfd; border-radius: 0 0 12px 12px;}
    .barbeiro-card-actions .btn { flex-grow: 1; }
    .notification-bar { display: none; padding: 15px; background-color: var(--secondary-color); color: white; text-align: center; font-weight: bold; position: sticky; top: 0; z-index: 1000; }
    .notification-bar a { color: white; text-decoration: underline; font-weight: bold; }
    .admin-container .header { align-items: center; }
    .header .barbearia-name { font-size: 0.8rem; color: #6c757d; text-transform: uppercase; display: block; margin-top: 4px; }
    .accordion-button { background-color: #e9ecef; color: #495057; cursor: pointer; padding: 18px; width: 100%; border: none; text-align: left; outline: none; font-size: 1.1rem; font-weight: bold; transition: 0.4s; border-radius: 8px; margin-top: 15px; display: flex; justify-content: space-between; align-items: center; }
    .accordion-button:hover { background-color: #dde2e6; }
    .accordion-button.active { border-radius: 8px 8px 0 0; }
    .accordion-button:after { content: '\f078'; font-family: 'Font Awesome 5 Free'; font-weight: 900; }
    .accordion-button.active:after { content: "\f077"; }
    .accordion-panel { padding: 0 18px; background-color: white; max-height: 0; overflow: hidden; transition: max-height 0.2s ease-out; border: 1px solid #e9ecef; border-top: none; border-radius: 0 0 8px 8px; }

    /* --- INÍCIO DOS NOVOS ESTILOS PARA ABA AGENDAMENTOS --- */
    
    /* Botão para nome de cliente clicável */
    .btn-link {
        background: none;
        border: none;
        color: var(--secondary-color);
        text-decoration: underline;
        cursor: pointer;
        font-size: 1em;
        font-weight: bold;
        padding: 0;
        text-align: left;
    }
    .btn-link:hover {
        color: var(--primary-color);
    }
    
    /* Alternador de Modo de Visualização */
    .view-controls-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 20px;
        margin-bottom: 20px;
    }
    
    .view-mode-toggle {
        display: flex;
        border: 1px solid var(--border-color);
        border-radius: 8px;
        overflow: hidden;
    }
    .view-mode-toggle .btn {
        border-radius: 0;
        background-color: #fff;
        color: var(--primary-color);
        border-right: 1px solid var(--border-color);
        margin: 0;
    }
    .view-mode-toggle .btn:last-child {
        border-right: none;
    }
    .view-mode-toggle .btn.active,
    .view-mode-toggle .btn:hover {
        background-color: var(--secondary-color);
        color: #fff;
    }
    
    /* Grid de Cards de Agendamento */
    .agendamentos-card-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
        gap: 20px;
    }
    
    .agendamento-card-admin {
        background-color: var(--card-background);
        border: 1px solid var(--border-color);
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.05);
        display: flex;
        flex-direction: column;
    }
    
    .agendamento-card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 15px;
        border-bottom: 1px solid var(--border-color);
    }
    
    .agendamento-card-header .cliente-info {
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .agendamento-card-header .cliente-info img {
        width: 45px;
        height: 45px;
        border-radius: 50%;
        object-fit: cover;
    }
    
    .agendamento-card-header .cliente-info .btn-link {
        font-size: 1.1rem;
    }
    
    .agendamento-card-admin .status-span {
        padding: 5px 10px;
        border-radius: 20px;
        font-size: 0.8em;
        font-weight: bold;
        text-transform: uppercase;
        color: #fff;
    }
    
    /* Cores de fundo para status */
    .status-span.status-pendente { background-color: var(--warning-color); color: var(--primary-color); }
    .status-span.status-aprovado { background-color: var(--success-color); }
    .status-span.status-concluido { background-color: var(--primary-color); }
    .status-span.status-cancelado,
    .status-span.status-cancelado_pelo_cliente { background-color: var(--error-color); }

    .agendamento-card-body {
        padding: 15px;
        flex-grow: 1;
    }
    
    .agendamento-card-body p {
        margin: 0 0 10px 0;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .agendamento-card-body p .fa {
        color: var(--secondary-color);
        width: 15px;
    }
    
    .agendamento-card-servicos {
        font-size: 0.9em;
        color: #555;
        background: #f8f9fa;
        padding: 10px;
        border-radius: 8px;
    }
    
    .agendamento-card-footer {
        padding: 15px;
        border-top: 1px solid var(--border-color);
        background-color: #fdfdfd;
    }
    
    .agendamento-card-footer .btn-group {
        justify-content: center;
        flex-wrap: wrap;
    }
    
    /* Visualização Agrupada */
    .agendamento-group-wrapper {
        margin-bottom: 30px;
    }
    
    .agendamento-group-wrapper h4 {
        font-size: 1.5rem;
        padding-bottom: 10px;
        border-bottom: 2px solid var(--secondary-color);
        margin-bottom: 15px;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .agendamento-group-wrapper h4 img {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        object-fit: cover;
    }

    /* --- FIM DOS NOVOS ESTILOS --- */
</style>
</head>
<body class="admin-page">
<div class="notification-bar" id="notification-bar">
    Você tem um novo agendamento! <a href="admin.php?tab=agendamentos">Atualizar página</a>.
</div>
<div class="container admin-container">
    <div class="header">
        <div style="display: flex; align-items: center;">
            <?php if (!empty($configGeral['logo_path']) && file_exists($configGeral['logo_path'])): ?>
                <img src="<?= htmlspecialchars($configGeral['logo_path']) ?>" alt="Logo" style="max-height: 70px; margin-right: 20px;">
            <?php endif; ?>
            <div>
                <h2>Painel Administrativo</h2>
                <span class="barbearia-name"><?= htmlspecialchars(strtoupper($configGeral['nome_barbearia'])) ?></span>
            </div>
        </div>
        <div class="header-buttons">
            <a href="admin.php" class="btn-refresh"><i class="fa fa-sync-alt"></i> Atualizar</a>
            <a href="?logout=1" class="btn-logout">Sair <i class="fa fa-sign-out-alt"></i></a>
        </div>
    </div>

    <div class="tab">
        <button class="tab-btn active" data-tab="dashboard"><i class="fa fa-tachometer-alt"></i> Dashboard</button>
        <button class="tab-btn" data-tab="agendamentos"><i class="fa fa-calendar-alt"></i> Agendamentos</button>
        <button class="tab-btn" data-tab="relatorios"><i class="fa fa-chart-line"></i> Relatórios</button>
        <button class="tab-btn" data-tab="clientes"><i class="fa fa-users"></i> Clientes</button>
        <button class="tab-btn" data-tab="barbeiros"><i class="fa fa-user"></i> Barbeiros</button>
        <button class="tab-btn" data-tab="servicos"><i class="fa fa-tags"></i> Serviços</button>
        <button class="tab-btn" data-tab="marketing"><i class="fa fa-bullhorn"></i> Marketing</button>
        <button class="tab-btn" data-tab="fidelidade"><i class="fa fa-star"></i> Fidelidade</button>
        <button class="tab-btn" data-tab="avaliacoes"><i class="fa fa-star-half-alt"></i> Avaliações</button>
        <button class="tab-btn" data-tab="landingpage"><i class="fa fa-paint-brush"></i> Landing Page</button>
        <button class="tab-btn" data-tab="configuracoes"><i class="fa fa-cog"></i> Configurações</button>
    </div>

    <div id="dashboard" class="tabcontent active">
        <?php include 'admin_tabs/dashboard.php'; ?>
    </div>
    
    <div id="agendamentos" class="tabcontent">
        <?php include 'admin_tabs/agendamentos.php'; ?>
    </div>
    
    <div id="relatorios" class="tabcontent">
        <?php include 'admin_tabs/relatorios.php'; ?>
    </div>

    <div id="clientes" class="tabcontent">
        <?php include 'admin_tabs/clientes.php'; ?>
    </div>

    <div id="barbeiros" class="tabcontent">
        <?php include 'admin_tabs/barbeiros.php'; ?>
    </div>

    <div id="servicos" class="tabcontent">
        <?php include 'admin_tabs/servicos.php'; ?>
    </div>

    <div id="marketing" class="tabcontent">
        <?php include 'admin_tabs/marketing.php'; ?>
    </div>

    <div id="fidelidade" class="tabcontent">
        <?php include 'admin_tabs/fidelidade.php'; ?>
    </div>

    <div id="avaliacoes" class="tabcontent">
        <?php include 'admin_tabs/avaliacoes.php'; ?>
    </div>
    
    <div id="landingpage" class="tabcontent">
        <?php include 'admin_tabs/landingpage.php'; ?>
    </div>

    <div id="configuracoes" class="tabcontent">
        <?php include 'admin_tabs/configuracoes.php'; ?>
    </div>
    
    <footer style="text-align: center; padding: 20px 0; margin-top: 30px; border-top: 1px solid var(--border-color, #e0e0e0); font-size: 0.9rem; color: #6c757d;">
        Desenvolvido com <i class="fa fa-heart" style="color: #e74c3c;"></i> por 
        <a href="https://instagram.com/ggxuao" target="_blank" rel="noopener noreferrer" style="color: var(--secondary-color, #007bff); text-decoration: none;">João Gonçalves</a>
        <br>
        <a href="notas_atualizacao.php" style="color: var(--secondary-color, #007bff); text-decoration: none; margin-top: 5px; display: inline-block;">
            Notas de atualização
        </a>
    </footer>
    </div> <div id="modal-add-produto" class="modal-overlay"><div class="modal-content"><button class="modal-close">&times;</button><h3>Adicionar Produto Vendido</h3><form method="post"><input type="hidden" name="action" value="adicionar_produto"><input type="hidden" name="agendamento_id" id="produto_agendamento_id"><div class="form-group"><label for="nome_produto">Nome do Produto</label><input type="text" name="nome_produto" required></div><div class="form-group"><label for="valor_produto">Valor (R$)</label><input type="number" name="valor_produto" step="0.01" required></div><button type="submit" class="btn-primary">Adicionar</button></form></div></div>
<div id="modal-combo" class="modal-overlay">
    <div class="modal-content">
        <button class="modal-close">&times;</button>
        <h3>Adicionar/Editar Combo</h3>
        <form method="post">
            <input type="hidden" name="action" value="salvar_combo">
            <input type="hidden" name="id" value="">
            <div class="form-group">
                <label>Nome do Combo</label>
                <input type="text" name="nome" required>
            </div>
            
            <div class="form-group">
                <label>Categoria</label>
                <select name="categoria_id">
                    <option value="">Sem Categoria</option>
                    <?php 
                    // Ordena categorias pelo nome para o dropdown
                    $categoriasOrdenadas = $categoriasArr;
                    uasort($categoriasOrdenadas, fn($a, $b) => strnatcasecmp($a['nome'], $b['nome']));
                    foreach ($categoriasOrdenadas as $cat): ?>
                        <option value="<?= htmlspecialchars($cat['id']) ?>"><?= htmlspecialchars($cat['nome']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Serviços (selecione 2 ou mais)</label>
                <div id="servicos-para-combo-container">
                    <?php foreach ($servicosArr as $id => $s): ?>
                        <button type="button" class="servico-btn-modal" data-id="<?= htmlspecialchars($id) ?>">
                            <?= htmlspecialchars($s['nome']) ?> - R$<?= htmlspecialchars($s['valor']) ?>
                        </button>
                    <?php endforeach; ?>
                </div>
                <input type="hidden" name="combo_servicos_ids" id="combo_servicos_ids" required>
            </div>
            <div class="form-group">
                <label>Valor Promocional do Combo (R$)</label>
                <input type="number" name="valor" step="0.01" required>
            </div>
            <button type="submit" class="btn-primary">Salvar Combo</button>
        </form>
    </div>
</div>
<div id="modal-agendamento-manual" class="modal-overlay"><div class="modal-content"><button class="modal-close">&times;</button><h3>Adicionar Agendamento Manual</h3><form method="post"><input type="hidden" name="action" value="salvar_agendamento_manual"><div class="form-group"><label>Cliente Cadastrado (Opcional)</label><select name="manual_cliente_id" id="manual_cliente_id"><option value="">-- Novo Cliente / Sem Cadastro --</option><?php foreach($clientesArr as $id => $c) echo "<option value='".htmlspecialchars($id)."' data-nome='".htmlspecialchars($c['nome'])."' data-telefone='".htmlspecialchars($c['telefone'])."'>".htmlspecialchars($c['nome'])."</option>"; ?></select></div><div class="form-group"><label>Nome e Sobrenome</label><input type="text" name="manual_nome" id="manual_nome" required></div><div class="form-group"><label>Telefone</label><input type="tel" name="manual_telefone" id="manual_telefone" placeholder="(99) 99999-9999" required></div><div class="form-group"><label>Barbeiro</label><select name="manual_barbeiro" id="manual_barbeiro" required><option value="">Selecione...</option><?php foreach($barbeirosArr as $id => $b) echo "<option value='".htmlspecialchars($id)."'>".htmlspecialchars($b['nome'])."</option>"; ?></select></div>
            
            <div class="form-group">
                <label>Serviços e Combos</label>
                <div id="servicos-container-modal" style="max-height: 200px; overflow-y: auto; border: 1px solid var(--border-color); padding: 10px; border-radius: 8px; background: #f8f9fa;">
                    
                    <?php if (empty($servicosArr) && empty($combosArr)): ?>
                        <p style="margin:0; text-align: center; color: #6c757d;">Nenhum serviço ou combo cadastrado na aba "Serviços".</p>
                    <?php else: ?>
                        
                        <h5 style="text-align: left; margin-top: 0; margin-bottom: 10px; color: var(--primary-color);">Serviços</h5>
                        <?php foreach ($servicosArr as $id => $s): 
                            $slots_servico = (int)($s['slots'] ?? 1); if ($slots_servico <= 0) $slots_servico = 1;
                        ?>
                            <button type="button" class="servico-btn-modal" 
                                    data-id="<?= htmlspecialchars($id) ?>" 
                                    data-slots="<?= $slots_servico ?>">
                                <?= htmlspecialchars($s['nome']) ?> - R$<?= htmlspecialchars($s['valor']) ?> (<?= $slots_servico * 30 ?> min)
                            </button>
                        <?php endforeach; ?>
                        
                        <?php if (!empty($combosArr)): ?>
                            <h5 style="text-align: left; margin-top: 15px; margin-bottom: 10px; color: var(--primary-color);">Combos</h5>
                            <?php foreach ($combosArr as $id => $c): 
                                // Calcula slots do combo (esta lógica já está em admin_data.php, mas podemos replicar por segurança)
                                $slots_combo = 0;
                                $sids_do_combo = explode(',', $c['servicos_ids']);
                                foreach ($sids_do_combo as $sid_combo) {
                                    $sid_limpo = trim($sid_combo);
                                    if (isset($servicosArr[$sid_limpo])) {
                                        $slots_combo += (int)($servicosArr[$sid_limpo]['slots'] ?? 1);
                                    } else {
                                        $slots_combo += 1; // Fallback
                                    }
                                }
                                if ($slots_combo == 0) $slots_combo = 1;
                            ?>
                                <button type="button" class="servico-btn-modal combo-btn" 
                                        style="border-color: var(--warning-color); color: var(--warning-color);"
                                        data-id="<?= htmlspecialchars($id) ?>" 
                                        data-slots="<?= $slots_combo ?>">
                                    <?= htmlspecialchars($c['nome']) ?> - R$<?= htmlspecialchars($c['valor']) ?> (<?= $slots_combo * 30 ?> min)
                                </button>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        
                    <?php endif; ?>

                </div>
                <input type="hidden" name="manual_servicos" id="manual_servicos" required>
            </div>

            <div class="form-group" style="background: #e8f5e9; padding: 10px; border-radius: 8px; border: 1px solid #28a745; margin-bottom: 15px;">
                <label style="cursor:pointer; display:flex; align-items:center; color: #155724; margin-bottom: 0;">
                    <input type="checkbox" id="manual_aderir_plano" name="manual_aderir_plano" style="width:auto; margin-right:8px; transform: scale(1.2);">
                    <i class="fa fa-crown" style="margin-right: 5px;"></i> Ativar Assinatura VIP (Adesão)
                </label>
                <div id="container_plano_manual" style="display:none; margin-top:10px; border-top: 1px solid #28a745; padding-top: 10px;">
                    <label style="font-size: 0.9em; color: #155724;">Selecione o Plano:</label>
                    <select name="manual_plano_id" id="manual_plano_id" style="width:100%; border-color: #28a745;">
                        <option value="">Selecione...</option>
                        <?php foreach ($planosArr as $p): ?>
                            <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['nome']) ?> - R$ <?= number_format((float)$p['valor'], 2, ',', '.') ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p style="font-size:0.8em; color:#155724; margin-top:5px; font-style: italic;">
                        * O valor deste agendamento será ajustado: Cobrança do Plano + Diferença de serviços não inclusos.
                    </p>
                </div>
            </div>
            <div class="form-group"><label>Data</label><input type="date" name="manual_data" id="manual_data" required></div><div class="form-group"><label>Horário</label><div class="horario-grid" id="manual_horarios-container">Selecione barbeiro, data e serviços.</div><input type="hidden" name="manual_horario" id="manual_horario" required></div><button type="submit" class="btn-primary">Salvar Agendamento</button></form></div></div>
<div id="modal-cliente" class="modal-overlay"><div class="modal-content"><button class="modal-close">&times;</button><h3>Adicionar/Editar Cliente</h3>
    <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="action" value="salvar_cliente">
        <input type="hidden" name="id" value="">
        <input type="hidden" name="foto_perfil_atual" value="">
        
        <div class="form-group">
            <label>Foto de Perfil (max 2MB)</label>
            <input type="file" name="foto_perfil" accept="image/jpeg, image/png">
        </div>
        <div class="form-group"><label>Nome e Sobrenome</label><input type="text" name="nome" required></div>
        <div class="form-group"><label>E-mail</label><input type="email" name="email" required></div>
        <div class="form-group"><label>CPF</label><input type="text" name="cpf" id="cpf-modal" placeholder="000.000.000-00"></div>
        <div class="form-group"><label>Telefone</label><input type="tel" name="telefone" placeholder="(99) 99999-9999" required></div>
        <div class="form-group"><label>Data de Nascimento</label><input type="date" name="data_nascimento"></div>
        <div class="form-group"><label>Nova Senha</label><input type="password" name="nova_senha" placeholder="Obrigatório para novo cliente"></div>
        <button type="submit" class="btn-primary">Salvar</button>
    </form>
</div></div>
<div id="modal-cliente-detalhes" class="modal-overlay"><div class="modal-content"><button class="modal-close">&times;</button><h3 id="cliente-detalhes-nome"></h3><div id="cliente-detalhes-content" style="max-height: 70vh; overflow-y: auto;"></div></div></div>
<div id="modal-barbeiro" class="modal-overlay"><div class="modal-content"><button class="modal-close">&times;</button><h3>Adicionar/Editar Barbeiro</h3><form method="post" enctype="multipart/form-data"><input type="hidden" name="action" value="salvar_barbeiro"><input type="hidden" name="id" value=""><input type="hidden" name="foto_atual" value=""><div class="form-group"><label>Nome</label><input type="text" name="nome" required></div><div class="form-group"><label>Foto (max 2MB)</label><input type="file" name="foto" accept="image/jpeg, image/png"></div>
    
    <div class="form-group">
        <label>Status</label>
        <select name="status">
            <option value="ativo">Ativo (Aparece para agendamento)</option>
            <option value="inativo">Inativo (Não aparece para agendamento)</option>
        </select>
    </div>

    <div class="form-group">
        <label>Especialidades (O que este barbeiro pode fazer?)</label>
        <div id="servicos-container-modal-checkbox"> 
            <?php if (empty($servicosArr) && empty($combosArr)): ?>
                <p style="font-size: 0.9em; color: #6c757d;">Nenhum serviço ou combo cadastrado. Adicione-os na aba "Serviços".</p>
            <?php else: ?>
                
                <h5 style="text-align: left; margin-top: 0; margin-bottom: 10px;">Serviços</h5>
                <?php foreach ($servicosArr as $servico): ?>
                    <div class="checkbox-wrapper">
                        <input type="checkbox" name="especialidades_ids[]" value="<?= htmlspecialchars($servico['id']) ?>" id="item-barbeiro-<?= htmlspecialchars($servico['id']) ?>">
                        <label for="item-barbeiro-<?= htmlspecialchars($servico['id']) ?>"><?= htmlspecialchars($servico['nome']) ?></label>
                    </div>
                <?php endforeach; ?>
                
                <?php if (!empty($combosArr)): ?>
                    <h5 style="text-align: left; margin-top: 15px; margin-bottom: 10px;">Combos</h5>
                    <?php foreach ($combosArr as $combo): ?>
                        <div class="checkbox-wrapper">
                            <input type="checkbox" name="especialidades_ids[]" value="<?= htmlspecialchars($combo['id']) ?>" id="item-barbeiro-<?= htmlspecialchars($combo['id']) ?>">
                            <label for="item-barbeiro-<?= htmlspecialchars($combo['id']) ?>"><?= htmlspecialchars($combo['nome']) ?> (Combo)</label>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
                
            <?php endif; ?>
        </div>
    </div>
    <hr style="margin: 20px 0;"><h4>Acesso ao Painel do Barbeiro</h4><div class="form-group"><label>Usuário</label><input type="text" name="username" required></div><div class="form-group"><label>Senha</label><input type="password" name="password" placeholder="Deixe em branco para não alterar"></div><button type="submit" class="btn-primary">Salvar</button></form></div></div>
<div id="modal-barbeiro-detalhes" class="modal-overlay"><div class="modal-content"><button class="modal-close">&times;</button><h3 id="barbeiro-detalhes-nome"></h3><div id="barbeiro-detalhes-content" style="max-height: 70vh; overflow-y: auto;"></div></div></div>
<div id="modal-servico" class="modal-overlay">
    <div class="modal-content">
        <button class="modal-close">&times;</button>
        <h3>Adicionar/Editar Serviço</h3>
        <form method="post">
            <input type="hidden" name="action" value="salvar_servico">
            <input type="hidden" name="id" value="">
            <div class="form-group">
                <label>Nome</label>
                <input type="text" name="nome" required>
            </div>
            <div class="form-group">
                <label>Valor (R$)</label>
                <input type="number" name="valor" step="0.01" required>
            </div>
            <div class="form-group">
                <label>Duração (em slots de 30 min)</label>
                <input type="number" name="slots" min="1" value="1" required>
                <p style="font-size: 0.8em; color: #6c757d; margin-top: 5px;">
                    Ex: 1 = 30 min, 2 = 60 min, 3 = 90 min.
                </p>
            </div>
            
            <div class="form-group">
                <label>Categoria</label>
                <select name="categoria_id">
                    <option value="">Sem Categoria</option>
                    <?php 
                    // Ordena categorias pelo nome para o dropdown
                    $categoriasOrdenadas = $categoriasArr;
                    uasort($categoriasOrdenadas, fn($a, $b) => strnatcasecmp($a['nome'], $b['nome']));
                    foreach ($categoriasOrdenadas as $cat): ?>
                        <option value="<?= htmlspecialchars($cat['id']) ?>"><?= htmlspecialchars($cat['nome']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn-primary">Salvar</button>
        </form>
    </div>
</div>
<div id="modal-categoria" class="modal-overlay">
    <div class="modal-content">
        <button class="modal-close">&times;</button>
        <h3>Adicionar/Editar Categoria</h3>
        <form method="post">
            <input type="hidden" name="action" value="salvar_categoria">
            <input type="hidden" name="id" value="">
            <div class="form-group">
                <label>Nome da Categoria</label>
                <input type="text" name="nome" required>
            </div>
            <div class="form-group">
                <label>Ordem de Exibição</label>
                <input type="number" name="ordem" value="10">
                <p style="font-size: 0.8em; color: #6c757d; margin-top: 5px;">
                    Números menores aparecem primeiro.
                </p>
            </div>
            <button type="submit" class="btn-primary">Salvar Categoria</button>
        </form>
    </div>
</div>
<div id="modal-usuario" class="modal-overlay"><div class="modal-content"><button class="modal-close">&times;</button><h3>Adicionar/Editar Usuário</h3><form method="post"><input type="hidden" name="action" value="salvar_usuario"><input type="hidden" name="current_username" value=""><div class="form-group"><label>Usuário</label><input type="text" name="new_username" required></div><div class="form-group"><label>Nova Senha</label><input type="password" name="new_password" required placeholder="Digite a nova senha"></div><button type="submit" class="btn-primary">Salvar</button></form></div></div>
<div id="modal-cupom" class="modal-overlay"><div class="modal-content"><button class="modal-close">&times;</button><h3>Adicionar/Editar Cupom</h3><form method="post"><input type="hidden" name="action" value="salvar_cupom"><input type="hidden" name="id" value=""><input type="hidden" name="usos_atuais" value="0"><div class="form-group"><label>Código</label><input type="text" name="codigo" required></div><div class="form-group"><label>Desconto (%)</label><input type="number" name="desconto_percentual" max="100" required></div><div class="form-group"><label>Usos Máximos</label><input type="number" name="usos_maximos" required></div><div class="form-group"><label>Data de Validade</label><input type="date" name="data_validade" required></div><button type="submit" class="btn-primary">Salvar</button></form></div></div>
<div id="modal-reagendamento" class="modal-overlay"><div class="modal-content"><button class="modal-close">&times;</button><h3>Reagendar Horário</h3><form method="post"><input type="hidden" name="action" value="salvar_reagendamento"><input type="hidden" name="reagendar_agendamento_id" id="reagendar_agendamento_id"><input type="hidden" id="reagendar_barbeiro_id"><input type="hidden" id="reagendar_servicos_ids"><div class="form-group"><label>Nova Data</label><input type="date" name="reagendar_data" id="reagendar_data" required></div><div class="form-group"><label>Novo Horário</label><div class="horario-grid" id="reagendar_horarios-container">Selecione uma nova data.</div><input type="hidden" name="reagendar_horario" id="reagendar_horario" required></div><button type="submit" class="btn-primary">Salvar Novo Horário</button></form></div></div>
<div id="modal-voucher-editar" class="modal-overlay"><div class="modal-content"><button class="modal-close">&times;</button><h3>Editar Voucher</h3><form method="post"><input type="hidden" name="action" value="salvar_voucher_editado"><input type="hidden" name="voucher_id" id="edit_voucher_id"><div class="form-group"><label for="data_validade">Data de Validade</label><input type="date" name="data_validade" id="edit_data_validade"></div><button type="submit" class="btn-primary">Salvar Alterações</button></form></div></div>
<div id="modal-bloqueio-horarios" class="modal-overlay">
    <div class="modal-content" style="max-width: 800px;">
        <button class="modal-close">&times;</button>
        <h3 id="bloqueio-barbeiro-nome">Gerenciar Agenda</h3>
        
        <form method="POST">
            <input type="hidden" name="action" value="salvar_bloqueios">
            <input type="hidden" name="bloqueio_barbeiro_id" id="bloqueio_barbeiro_id">
            <input type="hidden" name="bloqueio_data_selecionada" id="bloqueio_data_selecionada">
            
            <div class="reagendamento-container">
                <div class="form-group">
                    <label>1. Selecione o Dia</label>
                    <div id="bloqueio-calendario"></div>
                </div>
                <div class="form-group">
                    <label>2. Marque os horários para bloquear</label>
                    <p style="font-size: 0.85em; color: #6c757d; margin-bottom: 10px;">
                        (Horários já agendados não são exibidos aqui)
                    </p>
                    <div class="horario-grid" id="bloqueio-horarios-container" style="max-height: 300px;">
                        Selecione um dia no calendário.
                    </div>
                </div>
            </div>
            
            <button type="submit" class="btn-primary" style="margin-top: 20px; width: 100%;">Salvar Bloqueios do Dia</button>
        </form>
    </div>
</div>
<div id="modal-responder-avaliacao" class="modal-overlay">
    <div class="modal-content">
        <button class="modal-close">&times;</button>
        <h3>Responder Avaliação</h3>
        <form method="post">
            <input type="hidden" name="action" value="salvar_resposta_avaliacao">
            <input type="hidden" name="id_avaliacao" id="modal_resposta_id_avaliacao">
            <div class="form-group">
                <label for="texto_resposta">Sua Resposta Pública</label>
                <textarea name="texto_resposta" id="modal_texto_resposta" rows="5" required></textarea>
            </div>
            <button type="submit" class="btn-primary">Salvar Resposta</button>
        </form>
    </div>
</div>
<div id="modal-ver-agendamento" class="modal-overlay">
    <div class="modal-content" style="max-width: 450px;">
        <button class="modal-close">&times;</button>
        <h3>Detalhes do Agendamento</h3>
        <div id="modal-agendamento-detalhes-content">
            <p>Carregando...</p>
        </div>
    </div>
</div>
<script> let initialAppointmentCount = <?= count($agendamentosArr) ?>; </script>

<script>
// Passa as variáveis PHP para o JavaScript
// A variável $adminJSData é definida no 'admin_data.php' e usada por 'admin_script.js'
const adminJSData = <?= json_encode($adminJSData ?? []) ?>;

// --- INÍCIO DA CORREÇÃO ---
// Define as variáveis globais que o 'admin_script.js' espera
const dashboardChartData = adminJSData.dashboardChartData || {};
const relatoriosChartData = adminJSData.relatoriosChartData || {};
const avaliacoesChartData = adminJSData.avaliacoesChartData || {};
// --- FIM DA CORREÇÃO ---

// O script antigo (abaixo) também espera essas variáveis globalmente.
// Nós as definimos usando os dados do $adminJSData para consistência.
const clientesData = adminJSData.clientesData ? Object.values(adminJSData.clientesData) : [];
const agendamentosData = adminJSData.agendamentosData || [];
const anotacoesData = adminJSData.anotacoesClientesData || {};
const barbeirosData = adminJSData.barbeirosData || {};
const combosData = adminJSData.combosData ? Object.values(adminJSData.combosData) : [];
const servicosData = adminJSData.servicosData || {};
const categoriasData = adminJSData.categoriasData ? Object.values(adminJSData.categoriasData) : [];
const horariosTrabalhoData = adminJSData.horariosTrabalhoData || [];
const avaliacoesData = adminJSData.avaliacoesData || [];
const clientesInfoData = adminJSData.clientesInfoData || {};
const diasSemanaTexto = <?= json_encode($dias_semana_texto) ?>;
const respostasAvaliacoesData = adminJSData.respostasAvaliacoesData || {};
</script>
<script src="js/admin_script.js"></script> 

</body>
</html>