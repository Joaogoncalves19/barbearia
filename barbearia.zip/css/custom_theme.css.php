<?php
// Define o tipo de conteúdo como CSS
header('Content-Type: text/css');

// Define o caminho para o ficheiro de configuração do tema
$themeConfigFile = __DIR__ . '/../_dados/theme_config.json';

// Define as cores padrão caso o ficheiro de configuração não exista
$default_colors = [
    'primary-color' => '#333',
    'secondary-color' => '#007bff',
    'background-color' => '#f8f9fa',
    'card-background' => '#fff',
    'border-color' => '#e0e0e0',
    'success-color' => '#28a745',
    'error-color' => '#dc3545',
    'text-color' => '#495057',
    'warning-color' => '#ffc107'
];

$colors = $default_colors;

// Se o ficheiro de configuração existir, carrega as cores dele
if (file_exists($themeConfigFile)) {
    $json_content = file_get_contents($themeConfigFile);
    $saved_colors = json_decode($json_content, true);
    if (is_array($saved_colors)) {
        // Combina as cores salvas com as padrão para garantir que todas as variáveis existam
        $colors = array_merge($default_colors, $saved_colors);
    }
}
?>

/* Estilos Personalizados do Tema */
:root {
    --primary-color: <?= htmlspecialchars($colors['primary-color']) ?>;
    --secondary-color: <?= htmlspecialchars($colors['secondary-color']) ?>;
    --background-color: <?= htmlspecialchars($colors['background-color']) ?>;
    --card-background: <?= htmlspecialchars($colors['card-background']) ?>;
    --border-color: <?= htmlspecialchars($colors['border-color']) ?>;
    --success-color: <?= htmlspecialchars($colors['success-color']) ?>;
    --error-color: <?= htmlspecialchars($colors['error-color']) ?>;
    --text-color: <?= htmlspecialchars($colors['text-color']) ?>;
    --warning-color: <?= htmlspecialchars($colors['warning-color']) ?>;
}