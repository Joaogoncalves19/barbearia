document.addEventListener('DOMContentLoaded', function () {
    // --- Variáveis Globais do Script ---
    const modals = document.querySelectorAll('.modal-overlay');
    const openModalButtons = document.querySelectorAll('[data-modal-target]');
    const closeModalButtons = document.querySelectorAll('.modal-close');
    
    // --- Lógica de Modais (Abrir/Fechar) ---
    function openModal(modal) { if (modal) modal.style.display = 'flex'; }
    function closeModal(modal) { if (modal) { modal.style.display = 'none'; } }
    
    openModalButtons.forEach(button => {
        button.addEventListener('click', () => {
            const modal = document.querySelector(button.dataset.modalTarget);
            if (!modal) return; 

            const form = modal.querySelector('form');
            if (form) {
                form.reset();
                if (modal.id === 'modal-combo') {
                    form.querySelectorAll('.servico-btn-modal').forEach(btn => btn.classList.remove('selected'));
                    // Verifica se a função existe antes de chamar
                    const containerCombo = form.querySelector('#servicos-para-combo-container');
                    if(containerCombo) updateComboServicesInput(containerCombo);
                }
                 if(modal.id === 'modal-add-produto') {
                    modal.querySelector('#produto_agendamento_id').value = button.dataset.id;
                }
                if(form.querySelector('input[name="id"]')) form.querySelector('input[name="id"]').value = '';
                if(form.querySelector('input[name="current_username"]')) form.querySelector('input[name="current_username"]').value = '';
                
                if(modal.id === 'modal-agendamento-manual') {
                    modal.querySelector('#manual_nome').readOnly = false;
                    modal.querySelector('#manual_telefone').readOnly = false;
                    modal.querySelector('#manual_servicos').value = '';
                    modal.querySelector('#manual_horario').value = '';
                    modal.querySelector('#manual_horarios-container').innerHTML = 'Selecione barbeiro, data e serviços.';
                    modal.querySelectorAll('#servicos-container-modal .servico-btn-modal.selected').forEach(btn => btn.classList.remove('selected'));
                    
                    const badge = modal.querySelector('#vip-badge-modal');
                    if(badge) badge.style.display = 'none';

                    if (typeof filtrarServicosManuaisPorBarbeiro === 'function') {
                        filtrarServicosManuaisPorBarbeiro();
                    }
                }
                
                if(modal.id === 'modal-cliente') {
                    form.querySelector('input[name="foto_perfil_atual"]').value = ''; 
                    const senhaInput = modal.querySelector('input[name="nova_senha"]');
                    if (senhaInput) {
                       senhaInput.placeholder = button.dataset.id ? "Deixe em branco para não alterar" : "Obrigatório para novo cadastro";
                       senhaInput.required = !button.dataset.id; 
                    }
                }
                if(modal.id === 'modal-barbeiro') {
                    form.querySelectorAll('input[name="especialidades_ids[]"]').forEach(cb => cb.checked = false);
                    const senhaInput = modal.querySelector('input[name="password"]');
                    if (senhaInput) {
                       senhaInput.placeholder = button.dataset.id ? "Deixe em branco para não alterar" : "Obrigatório para novo cadastro";
                       senhaInput.required = !button.dataset.id; 
                    }
                }

                // Limpa modal de Plano ao clicar em Criar Novo
                if (modal.id === 'modal-plano') {
                    modal.querySelector('h3').textContent = 'Novo Plano de Assinatura';
                    form.querySelectorAll('input[name="plano_servicos_ids[]"]').forEach(cb => cb.checked = false);
                }
            }

            // --- Lógica de Preenchimento de Modais ---
            if (button.dataset.id) {
                const type = button.dataset.type;
                const id = button.dataset.id;
                
                if (type === 'cliente') {
                    const cliente = clientesData.find(c => c.id === id);
                    if (cliente && form) {
                        form.querySelector('[name="id"]').value = cliente.id;
                        form.querySelector('[name="nome"]').value = cliente.nome;
                        form.querySelector('[name="email"]').value = cliente.email;
                        form.querySelector('[name="telefone"]').value = cliente.telefone;
                        form.querySelector('[name="cpf"]').value = cliente.cpf || '';
                        form.querySelector('[name="data_nascimento"]').value = cliente.data_nascimento;
                        form.querySelector('[name="foto_perfil_atual"]').value = cliente.foto_perfil || '';
                    }
                } else if (type === 'barbeiro') {
                    const barbeiro = barbeirosData[id];
                    if (barbeiro && form) {
                        form.querySelector('[name="id"]').value = barbeiro.id;
                        form.querySelector('[name="nome"]').value = barbeiro.nome;
                        form.querySelector('[name="username"]').value = barbeiro.username;
                        form.querySelector('[name="foto_atual"]').value = barbeiro.foto;
                        form.querySelector('[name="status"]').value = barbeiro.status || 'ativo';
                        
                        const especialidadesSalvas = barbeiro.servicos_ids || '';
                        const especialidadesIdsArray = especialidadesSalvas.split(',').filter(Boolean);

                        if (especialidadesIdsArray.length > 0) {
                            especialidadesIdsArray.forEach(itemId => {
                                const checkbox = form.querySelector(`input[name="especialidades_ids[]"][value="${itemId.trim()}"]`);
                                if (checkbox) {
                                    checkbox.checked = true;
                                }
                            });
                        }
                    }
                } else if (type === 'plano') {
                    // Preenche Modal de Plano
                    const nome = button.dataset.nome;
                    const valor = button.dataset.valor;
                    const servicosIds = button.dataset.servicos ? button.dataset.servicos.split(',') : [];

                    if (form) {
                        form.querySelector('input[name="id"]').value = id;
                        form.querySelector('input[name="nome"]').value = nome;
                        form.querySelector('input[name="valor"]').value = valor;

                        servicosIds.forEach(sid => {
                            const checkbox = form.querySelector(`input[name="plano_servicos_ids[]"][value="${sid.trim()}"]`);
                            if (checkbox) checkbox.checked = true;
                        });

                        modal.querySelector('h3').textContent = 'Editar Plano de Assinatura';
                    }
                } else {
                    const containerElement = button.closest('tr') || button.closest('.barbeiro-card');
                     if (containerElement) {
                        
                        if (type === 'servico' && containerElement.tagName === 'TR') { 
                            const servico = servicosData[id]; 
                            if (servico && form) {
                                form.querySelector('[name="id"]').value = servico.id; 
                                form.querySelector('[name="nome"]').value = servico.nome; 
                                form.querySelector('[name="valor"]').value = servico.valor; 
                                form.querySelector('[name="slots"]').value = servico.slots || 1;
                                form.querySelector('[name="categoria_id"]').value = servico.categoria_id || '';
                            }
                        }
                        else if (type === 'usuario' && containerElement.tagName === 'TR') { 
                            form.querySelector('[name="current_username"]').value = id; 
                            form.querySelector('[name="new_username"]').value = containerElement.cells[0].textContent; 
                        }
                        else if (type === 'combo' && containerElement.tagName === 'TR') {
                            const combo = combosData.find(c => c.id === id); // CombosData pode ser array ou obj dependendo da versao
                            if (combo) {
                                form.querySelector('[name="id"]').value = combo.id;
                                form.querySelector('[name="nome"]').value = combo.nome;
                                form.querySelector('[name="valor"]').value = combo.valor;
                                form.querySelector('[name="categoria_id"]').value = combo.categoria_id || '';
                                
                                const servicosIds = combo.servicos_ids.split(',');
                                const servicosContainer = form.querySelector('#servicos-para-combo-container');
                                servicosContainer.querySelectorAll('.servico-btn-modal').forEach(btn => {
                                    if (servicosIds.includes(btn.dataset.id)) {
                                        btn.classList.add('selected');
                                    } else {
                                        btn.classList.remove('selected');
                                    }
                                });
                                updateComboServicesInput(servicosContainer);
                            }
                        }
                        else if (type === 'categoria' && containerElement.tagName === 'TR') { 
                            const categoria = categoriasData.find(c => c.id === id);
                            if (categoria && form) {
                                form.querySelector('[name="id"]').value = categoria.id;
                                form.querySelector('[name="nome"]').value = categoria.nome;
                                form.querySelector('[name="ordem"]').value = categoria.ordem || 10;
                            }
                        }
                    }
                }
            }

            // ================================================================
            // Modal "Detalhes do Barbeiro" (Turbinado)
            // ================================================================
            if (modal.id === 'modal-barbeiro-detalhes') {
                const barbeiroId = button.dataset.id;
                const barbeiro = barbeirosData[barbeiroId];
                if (!barbeiro) return;

                // --- 1. PREPARAÇÃO DE DADOS ---
                
                // Filtra agendamentos deste barbeiro
                // Ordena por data (mais recente primeiro)
                const barbeiroAgendamentos = agendamentosData.filter(a => 
                    a.barbeiro_id === barbeiroId
                ).sort((a, b) => new Date(b.data + ' ' + b.hora) - new Date(a.data + ' ' + a.hora));

                // Cálculos Estatísticos
                let receitaTotal = 0;
                let totalConcluidos = 0;
                let totalAgendadosFuturos = 0;
                const hoje = new Date().toISOString().split('T')[0];

                barbeiroAgendamentos.forEach(ag => {
                    if (ag.status === 'concluido') {
                        totalConcluidos++;
                        
                        // Cálculo de Receita (Serviços + Produtos - Descontos)
                        let valorAg = 0;
                        
                        // Soma Serviços/Combos
                        if (ag.servicos_ids) {
                            ag.servicos_ids.split(',').forEach(sid => {
                                const cleanSid = sid.trim();
                                if (servicosData[cleanSid]) {
                                    valorAg += parseFloat(servicosData[cleanSid].valor);
                                } else if (typeof combosData !== 'undefined' && combosData.find(c => c.id === cleanSid)) {
                                    const combo = combosData.find(c => c.id === cleanSid);
                                    valorAg += parseFloat(combo.valor);
                                }
                            });
                        }
                        
                        // Soma Produtos
                        if (ag.produtos_vendidos) {
                            try {
                                const prods = JSON.parse(ag.produtos_vendidos);
                                if(Array.isArray(prods)){
                                    prods.forEach(p => valorAg += parseFloat(p.valor));
                                }
                            } catch(e){}
                        }

                        // Subtrai Desconto
                        valorAg -= parseFloat(ag.desconto_aplicado || 0);
                        receitaTotal += Math.max(0, valorAg);
                    } else if (ag.status === 'aprovado' && ag.data >= hoje) {
                        totalAgendadosFuturos++;
                    }
                });

                // Avaliações
                const avaliacoesDoBarbeiro = avaliacoesData.filter(a => a.barbeiro_id === barbeiroId);
                const mediaRating = avaliacoesDoBarbeiro.length > 0 
                    ? (avaliacoesDoBarbeiro.reduce((acc, curr) => acc + parseInt(curr.rating), 0) / avaliacoesDoBarbeiro.length).toFixed(1) 
                    : 'N/A';

                // Horários
                const horariosDoBarbeiro = horariosTrabalhoData.filter(h => h.startsWith(barbeiroId + '|')).map(h => h.split('|'));

                // --- 2. CONSTRUÇÃO DO HTML ---

                // Cabeçalho
                const statusHtml = (barbeiro.status === 'inativo') 
                    ? '<span style="background:#dc3545; color:white; padding:2px 8px; border-radius:10px; font-size:0.8em; margin-left:10px;">Inativo</span>'
                    : '<span style="background:#28a745; color:white; padding:2px 8px; border-radius:10px; font-size:0.8em; margin-left:10px;">Ativo</span>';

                let html = `
                    <div style="display: flex; align-items: center; gap: 20px; margin-bottom: 25px; padding-bottom: 20px; border-bottom: 1px solid #eee;">
                        <img src="${barbeiro.foto}" style="width: 100px; height: 100px; border-radius: 50%; object-fit: cover; border: 4px solid #fff; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
                        <div>
                            <h2 style="margin: 0; color: #333;">${barbeiro.nome} ${statusHtml}</h2>
                            <p style="margin: 5px 0 0; color: #666;"><i class="fa fa-user-circle"></i> Usuário: <strong>${barbeiro.username}</strong></p>
                        </div>
                    </div>
                `;

                // Cards de KPI
                html += `
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 15px; margin-bottom: 25px;">
                        <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; border: 1px solid #e0e0e0;">
                            <div style="font-size: 0.8em; color: #6c757d; text-transform: uppercase;">Receita Gerada</div>
                            <div style="font-size: 1.3em; font-weight: bold; color: #28a745;">R$ ${receitaTotal.toLocaleString('pt-BR', {minimumFractionDigits: 2})}</div>
                        </div>
                        <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; border: 1px solid #e0e0e0;">
                            <div style="font-size: 0.8em; color: #6c757d; text-transform: uppercase;">Atendimentos</div>
                            <div style="font-size: 1.3em; font-weight: bold; color: #007bff;">${totalConcluidos}</div>
                        </div>
                        <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; border: 1px solid #e0e0e0;">
                            <div style="font-size: 0.8em; color: #6c757d; text-transform: uppercase;">Média Avaliação</div>
                            <div style="font-size: 1.3em; font-weight: bold; color: #ffc107;">${mediaRating} <i class="fa fa-star" style="font-size:0.8em"></i></div>
                        </div>
                        <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; border: 1px solid #e0e0e0;">
                            <div style="font-size: 0.8em; color: #6c757d; text-transform: uppercase;">Agendados</div>
                            <div style="font-size: 1.3em; font-weight: bold; color: #17a2b8;">${totalAgendadosFuturos}</div>
                        </div>
                    </div>
                `;

                // Layout de Duas Colunas (Horários e Histórico)
                html += `<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">`;

                // Coluna 1: Horários e Avaliações
                html += `<div>`;
                
                // Horários
                html += `<h4 style="border-bottom: 2px solid #eee; padding-bottom: 10px; margin-bottom: 10px; color: #333;"><i class="fa fa-clock"></i> Horários de Trabalho</h4>`;
                if (horariosDoBarbeiro.length > 0) {
                    html += '<ul style="list-style: none; padding: 0; margin-bottom: 20px; background: #fff; border: 1px solid #eee; border-radius: 8px; overflow: hidden;">';
                    // Mapeamento para ordenar dias da semana corretamente
                    const ordemDias = { '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '0': 7 };
                    horariosDoBarbeiro.sort((a, b) => ordemDias[a[1]] - ordemDias[b[1]]);
                    
                    horariosDoBarbeiro.forEach(h => {
                        const diaNome = diasSemanaTexto[h[1]] || 'Dia';
                        html += `<li style="padding: 10px 15px; border-bottom: 1px solid #f5f5f5; display: flex; justify-content: space-between;">
                            <strong>${diaNome}</strong> <span>${h[2]} - ${h[3]}</span>
                        </li>`;
                    });
                    html += '</ul>';
                } else {
                    html += '<p style="color:#777; font-style:italic; margin-bottom: 20px;">Sem horários definidos.</p>';
                }

                // Últimas Avaliações
                html += `<h4 style="border-bottom: 2px solid #eee; padding-bottom: 10px; margin-bottom: 10px; color: #333;"><i class="fa fa-comment-dots"></i> Recentes</h4>`;
                if (avaliacoesDoBarbeiro.length > 0) {
                    html += '<div style="max-height: 250px; overflow-y: auto;">';
                    [...avaliacoesDoBarbeiro].reverse().slice(0, 5).forEach(av => {
                        const clienteNome = clientesInfoData[av.cliente_id] || 'Anônimo';
                        const rating = '★'.repeat(av.rating) + '☆'.repeat(5 - av.rating);
                        html += `
                            <div style="background: #f9f9f9; padding: 10px; border-radius: 6px; margin-bottom: 10px; border: 1px solid #eee;">
                                <div style="display: flex; justify-content: space-between; font-size: 0.9em;">
                                    <strong>${clienteNome}</strong>
                                    <span style="color: #ffc107;">${rating}</span>
                                </div>
                                ${av.comment ? `<p style="margin: 5px 0 0; font-style: italic; color: #555; font-size: 0.9em;">"${av.comment}"</p>` : ''}
                            </div>
                        `;
                    });
                    html += '</div>';
                } else {
                    html += '<p style="color:#777; font-style:italic;">Nenhuma avaliação.</p>';
                }
                
                html += `</div>`; // Fim Coluna 1

                // Coluna 2: Histórico de Agendamentos Recentes
                html += `<div>`;
                html += `<h4 style="border-bottom: 2px solid #eee; padding-bottom: 10px; margin-bottom: 10px; color: #333;"><i class="fa fa-history"></i> Histórico (Últimos 10)</h4>`;
                
                if (barbeiroAgendamentos.length > 0) {
                    html += '<div style="max-height: 400px; overflow-y: auto;">';
                    // Pega os 10 mais recentes
                    barbeiroAgendamentos.slice(0, 10).forEach(ag => {
                        const dataF = new Date(ag.data.replace(/-/g, '/')).toLocaleDateString('pt-BR');
                        const statusColor = ag.status === 'concluido' ? '#28a745' : (ag.status === 'cancelado' ? '#dc3545' : '#ffc107');
                        
                        // Recalcula valor para exibição na lista
                        let valorDisplay = 0;
                        if(ag.servicos_ids) {
                            ag.servicos_ids.split(',').forEach(sid => {
                                const cleanSid = sid.trim();
                                if(servicosData[cleanSid]) valorDisplay += parseFloat(servicosData[cleanSid].valor);
                                else if(typeof combosData !== 'undefined' && combosData.find(c => c.id === cleanSid)) valorDisplay += parseFloat(combosData.find(c => c.id === cleanSid).valor);
                            });
                        }
                        if(ag.produtos_vendidos) {
                            try { JSON.parse(ag.produtos_vendidos).forEach(p => valorDisplay += parseFloat(p.valor)); } catch(e){}
                        }
                        valorDisplay -= parseFloat(ag.desconto_aplicado || 0);

                        html += `
                            <div style="background: #fff; padding: 10px; border-radius: 6px; margin-bottom: 10px; border: 1px solid #e0e0e0; border-left: 4px solid ${statusColor};">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
                                    <strong style="color: #333;">${ag.nome}</strong>
                                    <span style="font-weight: bold; color: #333;">R$ ${Math.max(0, valorDisplay).toFixed(2)}</span>
                                </div>
                                <div style="font-size: 0.85em; color: #666; display: flex; justify-content: space-between;">
                                    <span>${dataF} às ${ag.hora}</span>
                                    <span style="text-transform: capitalize; color: ${statusColor}; font-weight: bold;">${ag.status}</span>
                                </div>
                            </div>
                        `;
                    });
                    html += '</div>';
                } else {
                    html += '<p style="color:#777; font-style:italic;">Nenhum agendamento registrado.</p>';
                }
                
                html += `</div>`; // Fim Coluna 2
                html += `</div>`; // Fim Grid Principal

                document.getElementById('barbeiro-detalhes-nome').textContent = ''; // Limpa título padrão, já usamos no HTML
                document.getElementById('barbeiro-detalhes-content').innerHTML = html;
            }

            // ================================================================
            // Modal "Detalhes do Cliente" (ATUALIZADO COM VALORES CORRETOS)
            // ================================================================
            if (modal.id === 'modal-cliente-detalhes') {
                const clienteId = button.dataset.id;
                const cliente = clientesData.find(c => c.id === clienteId);
                if (!cliente) return;

                const assinaturasObj = adminJSData.assinaturasData || {};
                const planosObj = adminJSData.planosData || {};
                
                const clienteAgendamentos = agendamentosData.filter(a => 
                    a.email === cliente.email || 
                    a.telefone.replace(/\D/g, '') === cliente.telefone.replace(/\D/g, '')
                ).sort((a, b) => new Date(b.data + ' ' + b.hora) - new Date(a.data + ' ' + a.hora)); 

                const clienteAnotacao = anotacoesData[clienteId] || '';
                
                // --- 1. ESTATÍSTICAS E ASSINATURA ---
                const assinatura = assinaturasObj[clienteId];
                let isVip = false;
                let planoNome = '';
                let assinaturaHtml = '';

                if (assinatura && assinatura.status === 'ativo') {
                    const dataFim = new Date(assinatura.data_fim);
                    const hoje = new Date();
                    hoje.setHours(0,0,0,0);
                    
                    if (dataFim >= hoje) {
                        isVip = true;
                        const plano = planosObj[assinatura.plano_id];
                        planoNome = plano ? plano.nome : 'Plano Personalizado';
                        const diasRestantes = Math.ceil((dataFim - hoje) / (1000 * 60 * 60 * 24));
                        
                        assinaturaHtml = `
                            <div style="background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%); padding: 15px; border-radius: 10px; border: 1px solid #28a745; margin-bottom: 20px; color: #155724;">
                                <div style="display: flex; justify-content: space-between; align-items: center;">
                                    <div>
                                        <h4 style="margin: 0; color: #155724;"><i class="fa fa-crown"></i> Cliente VIP Ativo</h4>
                                        <p style="margin: 5px 0 0 0; font-weight: bold;">${planoNome}</p>
                                    </div>
                                    <div style="text-align: right;">
                                        <span style="font-size: 2em; font-weight: bold;">${diasRestantes}</span>
                                        <span style="display: block; font-size: 0.8em;">dias restantes</span>
                                    </div>
                                </div>
                                <p style="margin: 10px 0 0 0; font-size: 0.9em; border-top: 1px solid rgba(0,0,0,0.1); padding-top: 5px;">
                                    Vencimento: ${dataFim.toLocaleDateString('pt-BR')}
                                </p>
                            </div>
                        `;
                    }
                }

                let totalGasto = 0;
                let totalEconomizado = 0;
                let totalVisitas = 0;
                const historicoDescontos = [];

                clienteAgendamentos.forEach(ag => {
                    if (ag.status === 'concluido') {
                        totalVisitas++;
                        
                        // Calcula valor total bruto (serviços + produtos)
                        let valorServicos = 0;
                        if (ag.servicos_ids) {
                            ag.servicos_ids.split(',').forEach(sid => {
                                const s = servicosData[sid.trim()] || (adminJSData.combosData ? adminJSData.combosData[sid.trim()] : null);
                                if (s) valorServicos += parseFloat(s.valor);
                            });
                        }
                        if (ag.produtos_vendidos) {
                            try {
                                const prods = JSON.parse(ag.produtos_vendidos);
                                if(Array.isArray(prods)){
                                    prods.forEach(p => valorServicos += parseFloat(p.valor));
                                }
                            } catch(e){}
                        }

                        const desconto = parseFloat(ag.desconto_aplicado || 0);
                        if (desconto > 0) {
                            totalEconomizado += desconto;
                            historicoDescontos.push({
                                data: ag.data,
                                tipo: ag.tipo_desconto || 'Outro',
                                valor: desconto
                            });
                        }
                        totalGasto += (valorServicos - desconto);
                    }
                });

                const nomeElement = document.getElementById('cliente-detalhes-nome');
                if(nomeElement) nomeElement.innerHTML = `Perfil do Cliente`;

                const fotoPerfil = cliente.foto_perfil && cliente.foto_perfil !== '' ? cliente.foto_perfil : 'uploads/default-profile.jpg';
                
                let headerHtml = `
                    <div style="display: flex; align-items: center; gap: 20px; margin-bottom: 25px; padding-bottom: 20px; border-bottom: 1px solid #eee;">
                        <div style="position: relative;">
                            <img src="${fotoPerfil}" style="width: 100px; height: 100px; border-radius: 50%; object-fit: cover; border: 4px solid #fff; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
                            ${isVip ? '<div style="position: absolute; bottom: 0; right: 0; background: #28a745; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; border: 2px solid white;"><i class="fa fa-check"></i></div>' : ''}
                        </div>
                        <div style="flex-grow: 1;">
                            <h2 style="margin: 0 0 5px 0; color: #333;">${cliente.nome}</h2>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; font-size: 0.95em; color: #555;">
                                <span><i class="fa fa-envelope" style="width: 20px; text-align: center;"></i> ${cliente.email}</span>
                                <span><i class="fa fa-phone" style="width: 20px; text-align: center;"></i> ${cliente.telefone}</span>
                                <span><i class="fa fa-id-card" style="width: 20px; text-align: center;"></i> ${cliente.cpf || 'CPF N/A'}</span>
                                <span><i class="fa fa-birthday-cake" style="width: 20px; text-align: center;"></i> ${cliente.data_nascimento ? new Date(cliente.data_nascimento.replace(/-/g, '/')).toLocaleDateString('pt-BR') : 'N/A'}</span>
                            </div>
                        </div>
                    </div>
                `;

                let statsHtml = `
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 25px;">
                        <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; border: 1px solid #e0e0e0;">
                            <div style="font-size: 0.8em; color: #6c757d; text-transform: uppercase; letter-spacing: 1px;">Total Gasto</div>
                            <div style="font-size: 1.4em; font-weight: bold; color: #333;">R$ ${totalGasto.toFixed(2).replace('.', ',')}</div>
                        </div>
                        <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; border: 1px solid #e0e0e0;">
                            <div style="font-size: 0.8em; color: #6c757d; text-transform: uppercase; letter-spacing: 1px;">Economizado</div>
                            <div style="font-size: 1.4em; font-weight: bold; color: #28a745;">R$ ${totalEconomizado.toFixed(2).replace('.', ',')}</div>
                        </div>
                        <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; border: 1px solid #e0e0e0;">
                            <div style="font-size: 0.8em; color: #6c757d; text-transform: uppercase; letter-spacing: 1px;">Visitas</div>
                            <div style="font-size: 1.4em; font-weight: bold; color: #007bff;">${totalVisitas}</div>
                        </div>
                    </div>
                `;

                // Lista de Histórico de Agendamentos
                let historicoListHtml = '';
                if (clienteAgendamentos.length > 0) {
                    clienteAgendamentos.forEach(ag => {
                        const dataF = new Date(ag.data.replace(/-/g, '/')).toLocaleDateString('pt-BR');
                        const barbeiroNome = barbeirosData[ag.barbeiro_id] ? barbeirosData[ag.barbeiro_id].nome : 'N/A';
                        const statusClass = `status-${ag.status}`;
                        const statusLabel = ag.status.replace(/_/g, ' ');
                        
                        let detalhesExtras = '';
                        if (ag.tipo_desconto === 'assinatura_vip' || ag.tipo_desconto === 'adesao_plano') {
                            detalhesExtras += `<span style="background: #6f42c1; color: white; padding: 2px 6px; border-radius: 4px; font-size: 0.75em; margin-right: 5px;"><i class="fa fa-crown"></i> Assinatura</span>`;
                        }
                        if (parseFloat(ag.desconto_aplicado) > 0 && ag.tipo_desconto !== 'assinatura_vip' && ag.tipo_desconto !== 'adesao_plano') {
                             detalhesExtras += `<span style="background: #ffc107; color: #333; padding: 2px 6px; border-radius: 4px; font-size: 0.75em; margin-right: 5px;"><i class="fa fa-tag"></i> ${ag.tipo_desconto}</span>`;
                        }

                        let servicosTxt = [];
                        // CALCULO DO VALOR DESTA LINHA PARA EXIBIÇÃO
                        let valorRow = 0;
                        if(ag.servicos_ids) {
                            ag.servicos_ids.split(',').forEach(sid => {
                                const s = servicosData[sid.trim()] || (adminJSData.combosData ? adminJSData.combosData[sid.trim()] : null);
                                if(s) {
                                    servicosTxt.push(s.nome);
                                    valorRow += parseFloat(s.valor);
                                }
                            });
                        }
                        // Adiciona produtos ao valor da linha
                        if (ag.produtos_vendidos) {
                            try {
                                const prods = JSON.parse(ag.produtos_vendidos);
                                if(Array.isArray(prods)){
                                    prods.forEach(p => valorRow += parseFloat(p.valor));
                                }
                            } catch(e){}
                        }
                        
                        // Desconto e Valor Final
                        const descontoRow = parseFloat(ag.desconto_aplicado || 0);
                        const valorFinalRow = valorRow - descontoRow;

                        historicoListHtml += `
                            <div style="display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid #eee;">
                                <div>
                                    <div style="font-weight: bold; color: #333;">
                                        ${dataF} às ${ag.hora} 
                                        <span class="${statusClass}" style="font-size: 0.8em; padding: 2px 6px; border-radius: 4px; text-transform: capitalize;">${statusLabel}</span>
                                    </div>
                                    <div style="font-size: 0.9em; color: #666; margin-top: 3px;">
                                        <i class="fa fa-cut" style="font-size: 0.8em;"></i> ${servicosTxt.join(', ')}
                                        <span style="margin-left: 10px;"><i class="fa fa-user" style="font-size: 0.8em;"></i> ${barbeiroNome}</span>
                                    </div>
                                    <div style="margin-top: 5px;">${detalhesExtras}</div>
                                </div>
                                <div style="text-align: right;">
                                    ${descontoRow > 0 ? `<div style="font-size: 0.8em; color: #dc3545;">- R$ ${descontoRow.toFixed(2)}</div>` : ''}
                                    
                                    <div style="font-weight: bold; color: #333;">R$ ${valorFinalRow.toFixed(2)}</div>
                                    
                                    ${ag.status === 'concluido' ? 
                                        `<div style="font-weight: bold; color: #28a745; font-size: 0.8em;">Pago</div>` : 
                                        `<button class="btn btn-info btn-sm" style="padding: 4px 8px; font-size: 0.8em;" onclick="window.location.href='admin.php?tab=agendamentos&busca=${ag.id}'">Ver</button>`
                                    }
                                </div>
                            </div>
                        `;
                    });
                } else {
                    historicoListHtml = '<p style="color: #777; font-style: italic;">Nenhum agendamento registrado.</p>';
                }

                let cuponsHtml = '';
                if (historicoDescontos.length > 0) {
                    cuponsHtml = `
                        <div style="margin-top: 25px; background: #fff3cd; padding: 15px; border-radius: 8px; border: 1px solid #ffeeba;">
                            <h4 style="margin-top: 0; color: #856404; font-size: 1em;"><i class="fa fa-gift"></i> Histórico de Benefícios Usados</h4>
                            <ul style="list-style: none; padding: 0; margin: 10px 0 0 0; max-height: 100px; overflow-y: auto;">
                                ${historicoDescontos.map(d => `
                                    <li style="display: flex; justify-content: space-between; font-size: 0.9em; padding: 4px 0; border-bottom: 1px dashed rgba(0,0,0,0.1);">
                                        <span>${new Date(d.data.replace(/-/g, '/')).toLocaleDateString('pt-BR')} - <strong>${d.tipo.toUpperCase()}</strong></span>
                                        <span style="font-weight: bold;">R$ ${d.valor.toFixed(2)}</span>
                                    </li>
                                `).join('')}
                            </ul>
                        </div>
                    `;
                }

                let anotacoesHtml = `
                    <div style="margin-top: 25px;">
                        <h4 style="margin-bottom: 10px; font-size: 1em; color: #333;"><i class="fa fa-sticky-note"></i> Anotações Internas</h4>
                        <form method="POST" action="admin.php">
                            <input type="hidden" name="action" value="salvar_anotacao">
                            <input type="hidden" name="cliente_id" value="${clienteId}">
                            <textarea name="anotacao" rows="3" style="width: 100%; padding: 10px; border-radius: 8px; border: 1px solid #ccc; font-size: 0.9em; resize: vertical;" placeholder="Escreva observações sobre o cliente aqui...">${clienteAnotacao}</textarea>
                            <button type="submit" class="btn-primary" style="margin-top: 8px; padding: 8px 15px; font-size: 0.9em;">Salvar Anotação</button>
                        </form>
                    </div>
                `;

                const contentDiv = document.getElementById('cliente-detalhes-content');
                if(contentDiv) {
                    contentDiv.innerHTML = `
                        ${headerHtml}
                        ${assinaturaHtml}
                        ${statsHtml}
                        
                        <div style="margin-top: 20px;">
                            <h4 style="border-bottom: 2px solid #eee; padding-bottom: 10px; margin-bottom: 15px; color: #333;">Histórico de Agendamentos</h4>
                            <div style="max-height: 300px; overflow-y: auto;">
                                ${historicoListHtml}
                            </div>
                        </div>
                        
                        ${cuponsHtml}
                        ${anotacoesHtml}
                    `;
                }
            }
            
            if (modal.id === 'modal-bloqueio-horarios') {
                const barbeiroId = button.dataset.id;
                const barbeiroNome = button.dataset.nome;
                
                modal.querySelector('#bloqueio-barbeiro-nome').textContent = `Gerenciar Agenda de ${barbeiroNome}`;
                modal.querySelector('#bloqueio_barbeiro_id').value = barbeiroId;
                
                const calendarioContainer = modal.querySelector('#bloqueio-calendario');
                const dataSelecionadaInput = modal.querySelector('#bloqueio_data_selecionada');
                const horariosContainer = modal.querySelector('#bloqueio-horarios-container');
                
                calendarioContainer.innerHTML = '';
                horariosContainer.innerHTML = 'Selecione um dia no calendário.';
                dataSelecionadaInput.value = '';

                gerarCalendarioBloqueio(calendarioContainer, new Date().getFullYear(), new Date().getMonth(), barbeiroId, dataSelecionadaInput, horariosContainer);
            }
            
            if (modal.id === 'modal-responder-avaliacao') {
                const avaliacaoId = button.dataset.id_avaliacao;
                const respostaExistente = button.dataset.resposta_existente;
                
                form.querySelector('#modal_resposta_id_avaliacao').value = avaliacaoId;
                form.querySelector('#modal_texto_resposta').value = respostaExistente;
            }

            if (modal.id === 'modal-ver-agendamento') {
                const agendamentoId = button.dataset.agendamentoId;
                const agendamento = agendamentosData.find(ag => ag.id === agendamentoId);
                const contentDiv = modal.querySelector('#modal-agendamento-detalhes-content');
                
                if (agendamento) {
                    const barbeiro = barbeirosData[agendamento.barbeiro_id] || { nome: 'N/A' };
                    
                    let servicosHtml = '';
                    let valorTotal = 0;
                    const servicosIds = agendamento.servicos_ids.split(',');
                    let servicosJaEmCombo = [];

                    servicosIds.forEach(sid => {
                        const combo = combosData[sid.trim()];
                        if(combo) {
                            servicosHtml += `<li>${combo.nome} (Combo) <span>R$ ${parseFloat(combo.valor).toFixed(2)}</span></li>`; 
                            valorTotal += parseFloat(combo.valor); 
                            if(combo.servicos_ids) {
                                servicosJaEmCombo = servicosJaEmCombo.concat(combo.servicos_ids.split(',').map(s => s.trim()));
                            }
                        }
                    });
                    servicosIds.forEach(sid => {
                        const servico = servicosData[sid.trim()];
                        if(servico && !servicosJaEmCombo.includes(sid.trim())) { 
                            servicosHtml += `<li>${servico.nome} <span>R$ ${parseFloat(servico.valor).toFixed(2)}</span></li>`; 
                            valorTotal += parseFloat(servico.valor); 
                        }
                    });

                    const desconto = parseFloat(agendamento.desconto_aplicado || 0);
                    const valorFinal = valorTotal - desconto;
                    let descontoHtml = '';
                    if (desconto > 0) {
                        descontoHtml = `<div class="detalhes-total desconto"><strong>Desconto (${agendamento.tipo_desconto || ''}):</strong><span>- R$ ${desconto.toFixed(2)}</span></div>`;
                    }

                    contentDiv.innerHTML = `
                        <div class="detalhes-info">
                            <p><strong>Cliente:</strong> ${agendamento.nome}</p>
                            <p><strong>Barbeiro:</strong> ${barbeiro.nome}</p>
                            <p><strong>Data:</strong> ${new Date(agendamento.data.replace(/-/g, '/')).toLocaleDateString('pt-BR')} às ${agendamento.hora}</p>
                        </div>
                        <ul class="detalhes-servicos">${servicosHtml}</ul>
                        ${descontoHtml}
                        <div class="detalhes-total">
                            <strong>Valor Final:</strong><span>R$ ${valorFinal.toFixed(2)}</span>
                        </div>
                    `;
                } else {
                    contentDiv.innerHTML = '<p class="erro">Não foi possível carregar os detalhes do agendamento.</p>';
                }
            }
            
            openModal(modal);
        });
    });

    closeModalButtons.forEach(button => button.addEventListener('click', () => closeModal(button.closest('.modal-overlay'))));
    modals.forEach(modal => modal.addEventListener('click', e => { if (e.target === modal) closeModal(modal); }));

    // --- Helpers de Calendário e outras funções auxiliares (MANTIDOS) ---
    const mesesTexto = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];

    function gerarCalendarioBloqueio(container, ano, mes, barbeiroId, dataInput, horariosContainer) {
        const hoje = new Date();
        hoje.setHours(0, 0, 0, 0);

        const diasNoMes = new Date(ano, mes + 1, 0).getDate();
        const primeiroDia = new Date(ano, mes, 1).getDay();
        
        let calendarioHTML = `
            <div class="calendario-header">
                <button type="button" class="nav-btn" id="bloqueio-prev-month">&lt;</button>
                <span class="mes-ano">${mesesTexto[mes]} ${ano}</span>
                <button type="button" class="nav-btn" id="bloqueio-next-month">&gt;</button>
            </div>
            <div class="dias-semana-grid">
                <div>D</div><div>S</div><div>T</div><div>Q</div><div>Q</div><div>S</div><div>S</div>
            </div>
            <div class="dias-grid">
        `;

        for (let i = 0; i < primeiroDia; i++) {
            calendarioHTML += `<div class="dia-vazio"></div>`;
        }

        for (let dia = 1; dia <= diasNoMes; dia++) {
            const dataAtual = new Date(ano, mes, dia);
            const dataISO = `${ano}-${String(mes + 1).padStart(2, '0')}-${String(dia).padStart(2, '0')}`;
            if (dataAtual < hoje) {
                calendarioHTML += `<div class="dia passado">${dia}</div>`;
            } else {
                calendarioHTML += `<div class="dia" data-date="${dataISO}">${dia}</div>`;
            }
        }

        calendarioHTML += `</div>`;
        container.innerHTML = calendarioHTML;

        container.querySelectorAll('.dia[data-date]').forEach(el => {
            el.addEventListener('click', () => {
                container.querySelectorAll('.dia.selecionado').forEach(d => d.classList.remove('selecionado'));
                el.classList.add('selecionado');
                dataInput.value = el.dataset.date;
                buscarHorariosParaBloqueio(barbeiroId, el.dataset.date, horariosContainer);
            });
        });

        document.getElementById('bloqueio-prev-month').addEventListener('click', () => {
            const novaData = new Date(ano, mes - 1);
            gerarCalendarioBloqueio(container, novaData.getFullYear(), novaData.getMonth(), barbeiroId, dataInput, horariosContainer);
        });
        document.getElementById('bloqueio-next-month').addEventListener('click', () => {
            const novaData = new Date(ano, mes + 1);
            gerarCalendarioBloqueio(container, novaData.getFullYear(), novaData.getMonth(), barbeiroId, dataInput, horariosContainer);
        });
    }

    async function buscarHorariosParaBloqueio(barbeiroId, data, horariosContainer) {
        horariosContainer.innerHTML = 'Carregando horários...';

        try {
            const responseSlots = await fetch(`get_horarios.php?mode=todos_slots&barbeiro_id=${barbeiroId}&data=${data}`);
            const todosOsSlots = await responseSlots.json();

            if (todosOsSlots.length === 0) {
                horariosContainer.innerHTML = '<p class="erro">Este barbeiro não trabalha neste dia.</p>';
                return;
            }

            const responseBloqueados = await fetch(`get_horarios.php?mode=bloqueados&barbeiro_id=${barbeiroId}&data=${data}`);
            const horariosJaBloqueados = await responseBloqueados.json();

            const responseDisponiveis = await fetch(`get_horarios.php?barbeiro_id=${barbeiroId}&data=${data}&num_servicos_total=1&itens_selecionados=`);
            const horariosDisponiveis = await responseDisponiveis.json();
            
            const horariosOcupadosPorAgendamento = todosOsSlots.filter(slot => !horariosDisponiveis.includes(slot));

            horariosContainer.innerHTML = ''; 

            todosOsSlots.forEach(horario => {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'horario-btn-bloqueio';
                btn.textContent = horario;

                if (horariosOcupadosPorAgendamento.includes(horario) && !horariosJaBloqueados.includes(horario)) {
                    btn.classList.add('ocupado');
                    btn.disabled = true;
                    btn.title = 'Horário com agendamento/almoço';
                } else if (horariosJaBloqueados.includes(horario)) {
                    btn.classList.add('selected');
                }

                const input = document.createElement('input');
                input.type = 'checkbox';
                input.name = 'horarios_bloqueados[]';
                input.value = horario;
                input.checked = btn.classList.contains('selected');
                input.style.display = 'none';

                if (!btn.disabled) {
                    btn.addEventListener('click', () => {
                        btn.classList.toggle('selected');
                        input.checked = btn.classList.contains('selected');
                    });
                }

                horariosContainer.appendChild(btn);
                horariosContainer.appendChild(input);
            });

        } catch (error) {
            horariosContainer.innerHTML = '<p class="erro">Erro ao carregar horários.</p>';
            console.error(error);
        }
    }

    const reagendarBtns = document.querySelectorAll('.reagendar-btn');
    const dataReagendarInput = document.getElementById('reagendar_data');
    
    reagendarBtns.forEach(button => { 
        button.addEventListener('click', () => { 
            document.getElementById('reagendar_agendamento_id').value = button.dataset.id; 
            document.getElementById('reagendar_barbeiro_id').value = button.dataset.barbeiroId; 
            document.getElementById('reagendar_servicos_ids').value = button.dataset.servicosIds; 
            
            const modalForm = document.getElementById('modal-reagendamento').querySelector('form'); 
            if(modalForm) modalForm.reset(); 
            document.getElementById('reagendar_horarios-container').innerHTML = 'Selecione uma nova data.'; 
            document.getElementById('reagendar_horario').value = '';
        }); 
    });
    
    if (dataReagendarInput) { 
        dataReagendarInput.addEventListener('change', buscarHorariosReagendamento); 
    }
    
    async function buscarHorariosReagendamento() { 
        const barbeiroId = document.getElementById('reagendar_barbeiro_id').value; 
        const data = document.getElementById('reagendar_data').value; 
        const servicosIds = document.getElementById('reagendar_servicos_ids').value;
        const horariosContainer = document.getElementById('reagendar_horarios-container'); 
        const horarioHidden = document.getElementById('reagendar_horario'); 
        
        horariosContainer.innerHTML = 'Carregando...'; 
        horarioHidden.value = ''; 

        const itemIds = servicosIds.split(',').filter(Boolean);
        if (!barbeiroId || !data || itemIds.length === 0) { 
            horariosContainer.innerHTML = '<p class="erro">Erro: dados do agendamento não encontrados.</p>'; 
            return; 
        } 

        let totalSlots = 0;
        let servicosJaEmCombo = [];
        
        itemIds.forEach(id => {
            id = id.trim();
            if (id.startsWith('cb-') && combosData[id]) {
                totalSlots += parseInt(combosData[id].slots || 1); 
                const servicosDoCombo = combosData[id].servicos_ids.split(',');
                servicosJaEmCombo = servicosJaEmCombo.concat(servicosDoCombo.map(s => s.trim()));
            }
        });
        
        itemIds.forEach(id => {
            id = id.trim();
            if (id.startsWith('sv-') && servicosData[id] && !servicosJaEmCombo.includes(id)) {
                totalSlots += parseInt(servicosData[id].slots || 1);
            }
        });
        
        const numServicosParaCalculo = totalSlots > 0 ? totalSlots : 1;

        try { 
            const url = `get_horarios.php?barbeiro_id=${barbeiroId}&data=${data}&num_servicos_total=${numServicosParaCalculo}&itens_selecionados=${servicosIds}`;
            
            const response = await fetch(url); 
            if (!response.ok) throw new Error('Erro na requisição.'); 
            
            const horariosDisponiveis = await response.json(); 
            
            if (horariosDisponiveis.error) { 
                horariosContainer.innerHTML = `<p class="erro">${horariosDisponiveis.error}</p>`; 
                return; 
            } 
            horariosContainer.innerHTML = ''; 
            if (horariosDisponiveis.length === 0) { 
                horariosContainer.innerHTML = `<p class="erro">Nenhum horário disponível para esta data/duração.</p>`; 
                return; 
            } 
            
            horariosDisponiveis.forEach(h => { 
                const btn = document.createElement('button'); 
                btn.type = 'button'; 
                btn.textContent = h; 
                btn.className = 'disponivel';
                btn.addEventListener('click', () => { 
                    horarioHidden.value = h; 
                    document.querySelectorAll('#reagendar_horarios-container button').forEach(b => b.classList.remove('selecionado')); 
                    btn.classList.add('selecionado'); 
                }); 
                horariosContainer.appendChild(btn); 
            }); 
        } catch (error) { 
            horariosContainer.innerHTML = '<p class="erro">Erro ao carregar horários.</p>'; 
            console.error(error);
        } 
    }

    const modalAgendamento = document.getElementById('modal-agendamento-manual');
    if (modalAgendamento) { 
        const clienteSelect = modalAgendamento.querySelector('#manual_cliente_id'); 
        const nomeInputManual = modalAgendamento.querySelector('#manual_nome'); 
        const telefoneInputManual = modalAgendamento.querySelector('#manual_telefone'); 
        const barbeiroSelect = modalAgendamento.querySelector('#manual_barbeiro'); 
        const dataInput = modalAgendamento.querySelector('#manual_data'); 
        const horariosContainer = modalAgendamento.querySelector('#manual_horarios-container'); 
        const horarioHidden = modalAgendamento.querySelector('#manual_horario'); 
        const servicosContainer = modalAgendamento.querySelector('#servicos-container-modal'); 
        const servicosHidden = modalAgendamento.querySelector('#manual_servicos'); 
        
        const labelCliente = clienteSelect.previousElementSibling;
        if (!labelCliente.querySelector('#vip-badge-modal')) {
            labelCliente.insertAdjacentHTML('beforeend', ' <span id="vip-badge-modal" style="display:none; background-color: #28a745; color: white; font-size: 0.7em; padding: 2px 6px; border-radius: 10px; vertical-align: middle; font-weight: bold;"><i class="fa fa-crown"></i> VIP</span>');
        }
        const vipBadge = labelCliente.querySelector('#vip-badge-modal');
        
        clienteSelect.addEventListener('change', function() { 
            const selectedOption = this.options[this.selectedIndex]; 
            const isNewClient = !selectedOption.value; 
            const clienteId = selectedOption.value;

            nomeInputManual.value = isNewClient ? '' : selectedOption.dataset.nome; 
            telefoneInputManual.value = isNewClient ? '' : selectedOption.dataset.telefone; 
            nomeInputManual.readOnly = !isNewClient; 
            telefoneInputManual.readOnly = !isNewClient; 
            
            const assinaturasObj = adminJSData.assinaturasData || {};
            let isVip = false;
            if (clienteId && assinaturasObj[clienteId] && assinaturasObj[clienteId].status === 'ativo') {
                const hoje = new Date().toISOString().split('T')[0];
                if (assinaturasObj[clienteId].data_fim >= hoje) {
                    isVip = true;
                }
            }
            if (isVip) {
                vipBadge.style.display = 'inline-block';
            } else {
                vipBadge.style.display = 'none';
            }
        }); 
        
        servicosContainer.addEventListener('click', function(e) { 
            const target = e.target.closest('.servico-btn-modal');
            if (target && !target.classList.contains('disabled')) { 
                target.classList.toggle('selected'); 
                
                const isCombo = target.classList.contains('combo-btn');
                const idDoTarget = target.dataset.id;
                
                const combosObj = adminJSData.combosData || {}; 
                
                if (target.classList.contains('selected')) {
                    if (isCombo) {
                        const servicosNoCombo = combosObj[idDoTarget]?.servicos_ids.split(',') || [];
                        servicosContainer.querySelectorAll('.servico-btn-modal:not(.combo-btn).selected').forEach(btn => {
                            if (servicosNoCombo.includes(btn.dataset.id)) {
                                btn.classList.remove('selected');
                            }
                        });
                    } else {
                        servicosContainer.querySelectorAll('.servico-btn-modal.combo-btn.selected').forEach(btn => {
                            const servicosNoCombo = combosObj[btn.dataset.id]?.servicos_ids.split(',') || [];
                            if (servicosNoCombo.includes(idDoTarget)) {
                                btn.classList.remove('selected');
                            }
                        });
                    }
                }

                const selecionados = Array.from(servicosContainer.querySelectorAll('.servico-btn-modal.selected')).map(btn => btn.dataset.id); 
                servicosHidden.value = selecionados.join(','); 
                buscarHorarios(); 
            } 
        }); 

        function filtrarServicosManuaisPorBarbeiro() {
            const barbeiroId = barbeiroSelect.value;
            
            let especialidades = [];

            if (barbeiroId && barbeiroId !== 'qualquer' && barbeirosData[barbeiroId]) {
                const barbeiro = barbeirosData[barbeiroId];
                if (barbeiro.servicos_ids) {
                    especialidades = barbeiro.servicos_ids.split(',');
                }
            } else if (barbeiroId === 'qualquer') {
                servicosContainer.querySelectorAll('.servico-btn-modal.disabled').forEach(btn => {
                    btn.classList.remove('disabled');
                });
                return; 
            }

            if (especialidades.length === 0 && barbeiroId !== 'qualquer' && barbeiroId !== '') {
                 servicosContainer.querySelectorAll('.servico-btn-modal').forEach(btn => {
                    btn.classList.add('disabled');
                 });
            } else if (barbeiroId !== '') { 
                servicosContainer.querySelectorAll('.servico-btn-modal').forEach(btn => {
                    const itemId = btn.dataset.id; 
                    if (especialidades.includes(itemId)) {
                        btn.classList.remove('disabled');
                    } else {
                        btn.classList.add('disabled');
                    }
                });
            } else {
                 servicosContainer.querySelectorAll('.servico-btn-modal.disabled').forEach(btn => {
                    btn.classList.remove('disabled');
                });
            }

            servicosContainer.querySelectorAll('.servico-btn-modal.selected.disabled').forEach(btn => {
                btn.classList.remove('selected');
            });
            
            const selecionados = Array.from(servicosContainer.querySelectorAll('.servico-btn-modal.selected')).map(btn => btn.dataset.id); 
            servicosHidden.value = selecionados.join(',');
        }
        
        async function buscarHorarios() { 
            const barbeiroId = barbeiroSelect.value; 
            const data = dataInput.value; 
            
            let totalSlots = 0;
            const servicosSelecionados = Array.from(servicosContainer.querySelectorAll('.servico-btn-modal.selected'));
            
            servicosSelecionados.forEach(btn => {
                totalSlots += parseInt(btn.dataset.slots || 1);
            });
            
            const numServicosParaCalculo = totalSlots > 0 ? totalSlots : 1;
            
            horariosContainer.innerHTML = 'Selecione barbeiro, data e serviços.'; 
            horarioHidden.value = ''; 
            
            if (!barbeiroId || !data) {
                 horariosContainer.innerHTML = '<p class="erro">Selecione um barbeiro e uma data.</p>';
                 return;
            }
            if (servicosSelecionados.length === 0) {
                 horariosContainer.innerHTML = '<p class="erro">Selecione pelo menos um serviço ou combo.</p>';
                 return;
            }
            
            horariosContainer.innerHTML = 'Carregando...'; 
            
            try { 
                const itemIds = servicosSelecionados.map(btn => btn.dataset.id).join(',');
                // ATUALIZAÇÃO AQUI: Adicionado &admin_mode=1 para permitir horários passados
                const response = await fetch(`get_horarios.php?barbeiro_id=${barbeiroId}&data=${data}&num_servicos_total=${numServicosParaCalculo}&itens_selecionados=${itemIds}&admin_mode=1`); 
                
                if (!response.ok) throw new Error('Erro na requisição.'); 
                
                const horariosDisponiveis = await response.json(); 
                
                if (horariosDisponiveis.error) { 
                    horariosContainer.innerHTML = `<p class="erro">${horariosDisponiveis.error}</p>`; 
                    return; 
                } 
                horariosContainer.innerHTML = ''; 
                if (horariosDisponiveis.length === 0) { 
                    horariosContainer.innerHTML = `<p class="erro">Nenhum horário disponível.</p>`; 
                    return; 
                } 
                
                horariosDisponiveis.forEach(h => { 
                    const btn = document.createElement('button'); 
                    btn.type = 'button'; 
                    btn.className = 'disponivel';

                    if (typeof h === 'object') {
                        btn.textContent = h.horario;
                        btn.innerHTML += `<span class="horario-qualquer-barbeiro" style="color: #fff; opacity: 0.8;">${h.barbeiro_nome}</span>`;
                        btn.dataset.barbeiroId = h.barbeiro_id;
                        btn.dataset.horario = h.horario;
                    } else {
                        btn.textContent = h;
                        btn.dataset.horario = h;
                    }
                    
                    btn.addEventListener('click', () => { 
                        horarioHidden.value = btn.dataset.horario; 
                        if (btn.dataset.barbeiroId && barbeiroSelect.value === 'qualquer') {
                        }
                        document.querySelectorAll('#manual_horarios-container button').forEach(b => b.classList.remove('selecionado')); 
                        btn.classList.add('selecionado'); 
                    }); 
                    horariosContainer.appendChild(btn); 
                }); 
            } catch (error) { 
                horariosContainer.innerHTML = '<p class="erro">Erro ao carregar horários.</p>'; 
            } 
        } 
        
        barbeiroSelect.addEventListener('change', () => {
            filtrarServicosManuaisPorBarbeiro(); 
            buscarHorarios(); 
        }); 
        dataInput.addEventListener('change', buscarHorarios); 
    }
    
    const fotoInput = document.querySelector('input[type="file"][name="foto"]');
    if (fotoInput) { fotoInput.addEventListener('change', function() { if (this.files.length === 0) return; const file = this.files[0], allowedTypes = ['image/jpeg', 'image/png'], maxSize = 2 * 1024 * 1024; if (!allowedTypes.includes(file.type)) { alert('Erro: Apenas arquivos JPG e PNG são permitidos.'); this.value = ''; } if (file.size > maxSize) { alert('Erro: O arquivo é muito grande (máximo 2 MB).'); this.value = ''; } }); }
    
    const cpfInputModal = document.getElementById('cpf-modal');
    if(cpfInputModal) {
        cpfInputModal.addEventListener('input', function() {
            let v = this.value.replace(/\D/g, '').substring(0, 11);
            v = v.replace(/(\d{3})(\d)/, '$1.$2');
            v = v.replace(/(\d{3})(\d)/, '$1.$2');
            v = v.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
            this.value = v;
        });
    }

    const modalCombo = document.getElementById('modal-combo');
    if (modalCombo) { const servicosContainer = modalCombo.querySelector('#servicos-para-combo-container'); servicosContainer.addEventListener('click', function(e) { if (e.target.classList.contains('servico-btn-modal')) { e.target.classList.toggle('selected'); updateComboServicesInput(servicosContainer); } }); }
    function updateComboServicesInput(container) { const hiddenInput = container.nextElementSibling; const selecionados = Array.from(container.querySelectorAll('.servico-btn-modal.selected')).map(btn => btn.dataset.id); hiddenInput.value = selecionados.join(','); }

    
    const tabs = document.querySelectorAll('.tab-btn');
    const contents = document.querySelectorAll('.tabcontent');
    
    const urlParams = new URLSearchParams(window.location.search);
    const activeTabName = urlParams.get('tab') || 'dashboard';
    
    const initialTab = document.querySelector(`.tab-btn[data-tab="${activeTabName}"]`);
    if(initialTab){
        tabs.forEach(t => t.classList.remove('active'));
        contents.forEach(c => c.classList.remove('active'));
        initialTab.classList.add('active');
        const activeContent = document.getElementById(activeTabName);
        if (activeContent) activeContent.classList.add('active');
    }

    // --- PROTEÇÃO CONTRA ERROS NOS GRÁFICOS (FIX PARA O PROBLEMA) ---
    const tabDashboard = document.querySelector('[data-tab="dashboard"]');
    const tabRelatorios = document.querySelector('[data-tab="relatorios"]');
    const tabAvaliacoes = document.querySelector('[data-tab="avaliacoes"]');

    function renderDashboardCharts() {
        try {
            var ctxNovos = document.getElementById('novosRecorrentesChart');
            if (ctxNovos && typeof dashboardChartData !== 'undefined' && dashboardChartData.novosRecorrentes) {
                if (window.novosRecorrentesChart) window.novosRecorrentesChart.destroy();
                window.novosRecorrentesChart = new Chart(ctxNovos.getContext('2d'), { 
                    type: 'pie', 
                    data: { 
                        labels: dashboardChartData.novosRecorrentes.labels, 
                        datasets: [{ 
                            data: dashboardChartData.novosRecorrentes.data, 
                            backgroundColor: ['#0e7be1', '#ffc107'] 
                        }] 
                    }, 
                    options: { 
                        responsive: true, 
                        maintainAspectRatio: false, 
                        plugins: { title: { display: true, text: 'Novos Clientes vs. Recorrentes' } } 
                    } 
                });
            }
        } catch (e) {
            console.error("Erro ao renderizar gráfico do Dashboard:", e);
        }
    }

    function renderRelatoriosCharts() {
        if (typeof relatoriosChartData === 'undefined') return;
        
        try {
            // Gráfico 1: Receita Diária
            var ctx1 = document.getElementById('receitaVsDespesaChart'); 
            if (ctx1 && relatoriosChartData.receitaDiaria) { 
                if (window.receitaChart) window.receitaChart.destroy(); 
                window.receitaChart = new Chart(ctx1.getContext('2d'), { 
                    type: 'bar', 
                    data: { 
                        labels: relatoriosChartData.receitaDiaria.labels, 
                        datasets: [{ 
                            label: 'Receita Bruta (R$)', 
                            data: relatoriosChartData.receitaDiaria.data, 
                            backgroundColor: 'rgba(40, 167, 69, 0.7)' 
                        }] 
                    }, 
                    options: { scales: { y: { beginAtZero: true } }, plugins: { title: { display: true, text: 'Receita Bruta Diária no Período' } } } 
                }); 
            }
            
            // Gráfico 2: Tipos de Desconto
            var ctx2 = document.getElementById('analiseDescontosChart'); 
            if (ctx2 && relatoriosChartData.analiseDescontos) { 
                if (window.descontosChart) window.descontosChart.destroy(); 
                window.descontosChart = new Chart(ctx2.getContext('2d'), { 
                    type: 'pie', 
                    data: { 
                        labels: relatoriosChartData.analiseDescontos.labels, 
                        datasets: [{ 
                            data: relatoriosChartData.analiseDescontos.data, 
                            backgroundColor: ['#0e7be1', '#ffc107', '#dc3545', '#17a2b8', '#6c757d', '#6f42c1', '#28a745', '#fd7e14'] 
                        }] 
                    }, 
                    options: { 
                        responsive: true, 
                        maintainAspectRatio: false, 
                        plugins: { title: { display: true, text: 'Valor Total por Tipo de Desconto (R$)' } } 
                    } 
                }); 
            }

            // Gráfico Planos Populares
            var ctxPlanos = document.getElementById('planosPopularesChart');
            if (ctxPlanos && relatoriosChartData.popularidadePlanos) {
                if (window.planosChart) window.planosChart.destroy();
                window.planosChart = new Chart(ctxPlanos.getContext('2d'), {
                    type: 'bar',
                    data: {
                        labels: relatoriosChartData.popularidadePlanos.labels,
                        datasets: [{
                            label: 'Número de Assinantes Ativos',
                            data: relatoriosChartData.popularidadePlanos.data,
                            backgroundColor: 'rgba(111, 66, 193, 0.7)',
                            borderColor: 'rgba(111, 66, 193, 1)',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        indexAxis: 'y',
                        scales: { x: { beginAtZero: true, ticks: { stepSize: 1 } } },
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: false } }
                    }
                });
            }

            // Gráfico Fontes de Receita
            var ctxFontes = document.getElementById('fontesReceitaChart');
            if (ctxFontes && relatoriosChartData.fontesReceita) {
                if (window.fontesChart) window.fontesChart.destroy();
                window.fontesChart = new Chart(ctxFontes.getContext('2d'), {
                    type: 'doughnut',
                    data: {
                        labels: relatoriosChartData.fontesReceita.labels,
                        datasets: [{
                            data: relatoriosChartData.fontesReceita.data,
                            backgroundColor: ['#007bff', '#6f42c1', '#28a745']
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { title: { display: true, text: 'Composição da Receita no Período' } }
                    }
                });
            }
            
            // Gráfico 3: Ocupação Barbeiro
            var ctx3 = document.getElementById('ocupacaoBarbeiroChart'); 
            if (ctx3 && relatoriosChartData.ocupacaoBarbeiro) { 
                if (window.ocupacaoChart) window.ocupacaoChart.destroy(); 
                window.ocupacaoChart = new Chart(ctx3.getContext('2d'), { 
                    type: 'bar', 
                    data: { 
                        labels: relatoriosChartData.ocupacaoBarbeiro.labels, 
                        datasets: [{ 
                            label: 'Taxa de Ocupação (%)', 
                            data: relatoriosChartData.ocupacaoBarbeiro.data, 
                            backgroundColor: 'rgba(23, 162, 184, 0.7)' 
                        }] 
                    }, 
                    options: { 
                        indexAxis: 'y', 
                        scales: { x: { beginAtZero: true, max: 100 } }, 
                        responsive: true, 
                        maintainAspectRatio: false, 
                        plugins: { title: { display: true, text: 'Taxa de Ocupação por Barbeiro' } } 
                    } 
                }); 
            }
            
            // Gráfico 4: Agendamentos Dia Semana
            var ctx4 = document.getElementById('agendamentosPorDiaSemanaChart'); 
            if (ctx4 && relatoriosChartData.agendamentosDiaSemana) { 
                if (window.diaSemanaChart) window.diaSemanaChart.destroy(); 
                window.diaSemanaChart = new Chart(ctx4.getContext('2d'), { 
                    type: 'line', 
                    data: { 
                        labels: relatoriosChartData.agendamentosDiaSemana.labels, 
                        datasets: [{ 
                            label: 'Nº de Agendamentos', 
                            data: relatoriosChartData.agendamentosDiaSemana.data, 
                            borderColor: 'rgba(220, 53, 69, 0.8)', 
                            tension: 0.1, 
                            fill: false 
                        }] 
                    }, 
                    options: { scales: { y: { beginAtZero: true } }, plugins: { title: { display: true, text: 'Agendamentos por Dia da Semana' } } } 
                }); 
            }
            
            // Gráfico 5: Novos Clientes
            var ctx5 = document.getElementById('novosClientesChart'); 
            if (ctx5 && relatoriosChartData.novosClientes) { 
                if (window.novosClientesChart) window.novosClientesChart.destroy(); 
                window.novosClientesChart = new Chart(ctx5.getContext('2d'), { 
                    type: 'doughnut', 
                    data: { 
                        labels: ['Clientes Recorrentes', 'Novos Clientes'], 
                        datasets: [{ 
                            data: relatoriosChartData.novosClientes.data, 
                            backgroundColor: ['#ffc107', '#0e7be1'] 
                        }] 
                    }, 
                    options: { 
                        responsive: true, 
                        maintainAspectRatio: false, 
                        plugins: { title: { display: true, text: 'Novos Clientes vs. Recorrentes no Período' } } 
                    } 
                }); 
            }
        
            // Gráfico 6: Horários Pico
            var ctxPico = document.getElementById('horariosPicoChart'); 
            if (ctxPico && relatoriosChartData.horariosPico) { 
                if (window.horariosPicoChart) window.horariosPicoChart.destroy(); 
                window.horariosPicoChart = new Chart(ctxPico.getContext('2d'), { 
                    type: 'bar', 
                    data: { 
                        labels: relatoriosChartData.horariosPico.labels, 
                        datasets: [{ 
                            label: 'Nº de Agendamentos', 
                            data: relatoriosChartData.horariosPico.data, 
                            backgroundColor: 'rgba(0, 123, 255, 0.7)' 
                        }] 
                    }, 
                    options: { 
                        scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }, 
                        plugins: { title: { display: true, text: 'Horários de Pico (Agendamentos por Hora)' } } 
                    } 
                }); 
            }
        } catch (e) {
            console.error("Erro ao renderizar gráficos de relatórios:", e);
        }
    }

    function renderAvaliacoesCharts() {
        if (typeof avaliacoesChartData === 'undefined') return;

        try {
            var ctx6 = document.getElementById('distribuicaoNotasChart'); 
            if (ctx6 && avaliacoesChartData.distribuicaoNotas) { 
                if (window.distribuicaoNotasChart) window.distribuicaoNotasChart.destroy(); 
                window.distribuicaoNotasChart = new Chart(ctx6.getContext('2d'), { 
                    type: 'bar', 
                    data: { 
                        labels: ['5 ★', '4 ★', '3 ★', '2 ★', '1 ★'], 
                        datasets: [{ 
                            label: 'Quantidade de Avaliações', 
                            data: avaliacoesChartData.distribuicaoNotas.data, 
                            backgroundColor: 'rgba(255, 193, 7, 0.7)' 
                        }] 
                    }, 
                    options: { scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }, plugins: { title: { display: true, text: 'Distribuição de Notas' } } } 
                }); 
            }
            
            var ctx7 = document.getElementById('mediaPorBarbeiroChart'); 
            if (ctx7 && avaliacoesChartData.mediaPorBarbeiro) { 
                if (window.mediaBarbeiroChart) window.mediaBarbeiroChart.destroy(); 
                window.mediaBarbeiroChart = new Chart(ctx7.getContext('2d'), { 
                    type: 'bar', 
                    data: { 
                        labels: avaliacoesChartData.mediaPorBarbeiro.labels, 
                        datasets: [{ 
                            label: 'Média de Notas', 
                            data: avaliacoesChartData.mediaPorBarbeiro.data, 
                            backgroundColor: 'rgba(0, 123, 255, 0.7)' 
                        }] 
                    }, 
                    options: { 
                        indexAxis: 'y', 
                        scales: { x: { beginAtZero: true, max: 5 } }, 
                        responsive: true, 
                        maintainAspectRatio: false, 
                        plugins: { title: { display: true, text: 'Média de Avaliações por Barbeiro' } } 
                    } 
                }); 
            }
        
            var ctxSentimento = document.getElementById('sentimentoGeralChart');
            if (ctxSentimento && avaliacoesChartData.sentimentoGeral) {
                if (window.sentimentoGeralChart) window.sentimentoGeralChart.destroy();
                window.sentimentoGeralChart = new Chart(ctxSentimento.getContext('2d'), {
                    type: 'doughnut',
                    data: {
                        labels: ['Positivas (4-5 ★)', 'Neutras (3 ★)', 'Negativas (1-2 ★)'],
                        datasets: [{
                            data: avaliacoesChartData.sentimentoGeral.data,
                            backgroundColor: [
                                'rgba(40, 167, 69, 0.7)',
                                'rgba(255, 193, 7, 0.7)',
                                'rgba(220, 53, 69, 0.7)'
                            ],
                            borderColor: ['#28a745', '#ffc107', '#dc3545'],
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            title: { display: true, text: 'Sentimento Geral' },
                            legend: { position: 'bottom' }
                        }
                    }
                });
            }
        } catch (e) {
            console.error("Erro ao renderizar gráficos de avaliações:", e);
        }
    }

    const urlParamsRender = new URLSearchParams(window.location.search);
    const initialTabRender = urlParamsRender.get('tab') || 'dashboard';
    
    const chartRenderers = {
        'dashboard': renderDashboardCharts,
        'relatorios': renderRelatoriosCharts,
        'avaliacoes': renderAvaliacoesCharts
    };

    // Executa renderizador inicial com proteção
    if (chartRenderers[initialTabRender]) {
        try {
            chartRenderers[initialTabRender]();
        } catch(e) {
            console.error("Erro na renderização inicial:", e);
        }
    }

    tabs.forEach(tab => {
        tab.addEventListener('click', (e) => {
            e.preventDefault(); 
            const tabName = tab.dataset.tab;
            tabs.forEach(t => t.classList.remove('active'));
            contents.forEach(c => c.classList.remove('active'));
            tab.classList.add('active');
            const activeContent = document.getElementById(tabName);
            if (activeContent) activeContent.classList.add('active');
            
            // Tenta renderizar gráfico se houver
            if (chartRenderers[tabName]) {
                try { setTimeout(chartRenderers[tabName], 100); } catch(e){}
            }

            const url = new URL(window.location);
            url.searchParams.set('tab', tabName);
            window.history.pushState({}, '', url);
        });
    });

    const subTabContainers = document.querySelectorAll('.sub-tab');
    if(subTabContainers.length > 0) {
        
        const activeSubTabName = urlParams.get('subtab');
        if(activeSubTabName) {
            const initialSubTabBtn = document.querySelector(`.sub-tab-btn[data-subtab="${activeSubTabName}"]`);
            if (initialSubTabBtn) {
                const parentSubTabContainer = initialSubTabBtn.closest('.sub-tab');
                const parentTabContent = initialSubTabBtn.closest('.tabcontent');
                
                parentSubTabContainer.querySelectorAll('.sub-tab-btn').forEach(btn => btn.classList.remove('active'));
                parentTabContent.querySelectorAll('.sub-tabcontent').forEach(content => content.classList.remove('active'));
                
                initialSubTabBtn.classList.add('active');
                const activeSubContent = parentTabContent.querySelector(`#${activeSubTabName}`);
                if (activeSubContent) activeSubContent.classList.add('active');
            }
        }

        subTabContainers.forEach(container => {
            container.addEventListener('click', function(event) {
                if (event.target.classList.contains('sub-tab-btn')) {
                    const targetSubTab = event.target.dataset.subtab;
                    
                    const parentContainer = event.target.closest('.sub-tab');
                    if (!parentContainer) return;

                    parentContainer.querySelectorAll('.sub-tab-btn').forEach(btn => btn.classList.remove('active'));
                    event.target.classList.add('active');
                    
                    const parentTabContent = container.closest('.tabcontent');
                    if (parentTabContent) {
                        parentTabContent.querySelectorAll('.sub-tabcontent').forEach(content => content.classList.remove('active'));
                        const activeContent = parentTabContent.querySelector(`#${targetSubTab}`);
                        if (activeContent) {
                            activeContent.classList.add('active');
                        }
                    }
                    
                    const url = new URL(window.location);
                    url.searchParams.set('subtab', targetSubTab);
                    window.history.pushState({}, '', url);
                }
            });
        });
    }

    var acc = document.getElementsByClassName("accordion-button");
    for (var i = 0; i < acc.length; i++) {
        acc[i].addEventListener("click", function() {
            this.classList.toggle("active");
            var panel = this.nextElementSibling;
            if (panel.style.maxHeight) {
                panel.style.maxHeight = null;
            } else {
                panel.style.maxHeight = (panel.scrollHeight + 20) + "px";
            } 
        });
    }

    const urlParamsRenderAccordion = new URLSearchParams(window.location.search);
    const initialAccordion = urlParamsRenderAccordion.get('accordion');
    if (initialAccordion) {
        const accordionBtn = document.querySelector(initialAccordion);
        if (accordionBtn) {
            accordionBtn.click();
        }
    }

    const editVoucherButtons = document.querySelectorAll('[data-modal-target="#modal-voucher-editar"]');
    const modalVoucher = document.getElementById('modal-voucher-editar');
    if (modalVoucher) {
        const voucherIdInput = modalVoucher.querySelector('#edit_voucher_id');
        const dataValidadeInput = modalVoucher.querySelector('#edit_data_validade');
        editVoucherButtons.forEach(button => {
            button.addEventListener('click', () => {
                const id = button.dataset.id;
                const validade = button.dataset.validade;
                voucherIdInput.value = id;
                dataValidadeInput.value = validade;
            });
        });
    }

    setInterval(function() {
        fetch('check_new_appointments.php')
            .then(response => response.json())
            .then(data => {
                if (data.appointment_count > initialAppointmentCount) {
                    document.getElementById('notification-bar').style.display = 'block';
                }
            })
            .catch(error => console.error('Error checking for new appointments:', error));
    }, 15000); 

    // --- Lógica para Adesão de Plano no Manual (Admin) ---
    const chkAderir = document.getElementById('manual_aderir_plano');
    const containerPlano = document.getElementById('container_plano_manual');
    const selectPlano = document.getElementById('manual_plano_id');

    if (chkAderir && containerPlano) {
        chkAderir.addEventListener('change', function() {
            if (this.checked) {
                containerPlano.style.display = 'block';
                selectPlano.required = true;
            } else {
                containerPlano.style.display = 'none';
                selectPlano.required = false;
                selectPlano.value = '';
            }
        });
    }

    // Resetar checkbox ao abrir o modal
    const btnOpenManual = document.querySelector('[data-modal-target="#modal-agendamento-manual"]');
    if(btnOpenManual && chkAderir){
        btnOpenManual.addEventListener('click', function(){
            chkAderir.checked = false;
            // Dispara o evento manualmente para garantir que a UI atualize
            chkAderir.dispatchEvent(new Event('change'));
        });
    }

    // ==========================================================
    // **CORREÇÃO: LÓGICA DA GRADE DE HORÁRIOS USANDO DELEGAÇÃO**
    // ==========================================================
    // Ao usar 'document.addEventListener', garantimos que o evento funcione
    // mesmo que o elemento não esteja visível/pronto no momento que o script carrega.
    
    document.addEventListener('change', function(e) {
        if (e.target && e.target.id === 'select-barbeiro-grade') {
            const barbeiroId = e.target.value;
            const containerGrade = document.getElementById('container-grade-horarios');
            const avisoSelecao = document.getElementById('aviso-selecao-grade');
            const inputHiddenBarbeiroId = document.getElementById('input_barbeiro_id_grade');

            if (barbeiroId) {
                // Mostra o formulário
                if(containerGrade) containerGrade.style.display = 'block';
                if(avisoSelecao) avisoSelecao.style.display = 'none';
                if(inputHiddenBarbeiroId) inputHiddenBarbeiroId.value = barbeiroId;

                // Carrega os horários existentes
                const horariosSalvos = (typeof adminJSData !== 'undefined' && adminJSData.horariosTrabalhoData) ? adminJSData.horariosTrabalhoData : [];
                
                // Reseta checkboxes e inputs
                document.querySelectorAll('input[name^="horarios"]').forEach(input => {
                    if(input.type === 'checkbox') input.checked = false;
                    else input.value = '';
                });

                // Preenche
                horariosSalvos.forEach(linha => {
                    const partes = linha.split('|');
                    if (partes[0] === barbeiroId) {
                        const dia = partes[1];
                        const inicio = partes[2];
                        const fim = partes[3];

                        const check = document.getElementById(`dia_ativo_${dia}`);
                        if(check) check.checked = true;

                        const inputInicio = document.getElementById(`inicio_${dia}`);
                        const inputFim = document.getElementById(`fim_${dia}`);
                        if(inputInicio) inputInicio.value = inicio;
                        if(inputFim) inputFim.value = fim;
                    }
                });

            } else {
                if(containerGrade) containerGrade.style.display = 'none';
                if(avisoSelecao) avisoSelecao.style.display = 'block';
            }
        }
    });

    // Lógica do botão "Replicar" também com delegação
    document.addEventListener('click', function(e) {
        if (e.target && e.target.id === 'btn-replicar-horarios') {
            const inicioSegunda = document.getElementById('inicio_1').value;
            const fimSegunda = document.getElementById('fim_1').value;
            const ativoSegunda = document.getElementById('dia_ativo_1').checked;

            if (!inicioSegunda || !fimSegunda) {
                alert('Defina um horário válido para Segunda-feira primeiro.');
                return;
            }

            const diasParaCopiar = [2, 3, 4, 5, 6, 0]; // Terça a Domingo

            diasParaCopiar.forEach(dia => {
                const elInicio = document.getElementById(`inicio_${dia}`);
                const elFim = document.getElementById(`fim_${dia}`);
                const elCheck = document.getElementById(`dia_ativo_${dia}`);

                if (elInicio && elFim && elCheck) {
                    elInicio.value = inicioSegunda;
                    elFim.value = fimSegunda;
                    elCheck.checked = ativoSegunda;
                }
            });
            
            alert('Horários de Segunda replicados para TODOS os dias!');
        }
    });
});