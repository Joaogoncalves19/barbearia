document.addEventListener('DOMContentLoaded', function() {
    
    // --- 1. LÓGICA DAS ABAS (TABS) ---
    const tabs = document.querySelectorAll('.nav-tab');
    const tabContents = document.querySelectorAll('.tabcontent');

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Remove 'active' de todas as abas e conteúdos
            tabs.forEach(t => t.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));

            // Adiciona 'active' na aba clicada
            tab.classList.add('active');

            // Mostra o conteúdo correspondente
            const targetId = tab.dataset.tab;
            const targetContent = document.getElementById(targetId);
            if (targetContent) {
                targetContent.classList.add('active');
            }
        });
    });

    // --- 2. LÓGICA DE MODAIS ---
    const modals = document.querySelectorAll('.modal-overlay');
    const openModalButtons = document.querySelectorAll('[data-modal-target]');
    const closeModalButtons = document.querySelectorAll('.modal-close');

    function openModal(modal) {
        if (modal) modal.style.display = 'flex';
    }

    function closeModal(modal) {
        if (modal) {
            modal.style.display = 'none';
            // Se for modal de notificação, marca como lidas ao fechar
            if(modal.id === 'modal-notificacoes') {
                 fetch('minha_conta.php?action=marcar_lidas', { method: 'POST' });
                 const badge = document.querySelector('.notification-count');
                 if(badge) badge.style.display = 'none';
            }
        }
    }

    openModalButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            e.preventDefault();
            const modal = document.querySelector(button.dataset.modalTarget);
            if (!modal) return;
            
            openModal(modal);

            // Preenche dados do modal específico se necessário
            if (button.dataset.modalTarget === '#modal-detalhes-agendamento') {
                const agId = button.dataset.agendamentoId;
                preencherDetalhesAgendamento(agId);
            }
            if (button.dataset.modalTarget === '#modal-reagendamento') {
                const agId = button.dataset.agendamentoId;
                preencherModalReagendamento(agId);
            }
            if (button.dataset.modalTarget === '#modal-avaliacao') {
                document.getElementById('avaliacao_agendamento_id').value = button.dataset.agendamentoId;
                document.getElementById('avaliacao_barbeiro_id').value = button.dataset.barbeiroId;
            }
        });
    });

    closeModalButtons.forEach(button => {
        button.addEventListener('click', () => {
            const modal = button.closest('.modal-overlay');
            closeModal(modal);
        });
    });

    // Fecha modal ao clicar fora
    window.addEventListener('click', (e) => {
        modals.forEach(modal => {
            if (e.target === modal) {
                closeModal(modal);
            }
        });
    });


    // --- 3. LÓGICA DE DETALHES DO AGENDAMENTO ---
    function preencherDetalhesAgendamento(id) {
        const data = agendamentosDataById[id];
        const contentDiv = document.getElementById('detalhes-content');
        if (!data || !contentDiv) return;

        // Recupera nomes
        let nomesServicos = [];
        let total = 0;
        
        if (data.servicos_ids) {
            data.servicos_ids.split(',').forEach(sid => {
                sid = sid.trim();
                if (servicosData[sid]) {
                    nomesServicos.push(servicosData[sid].nome + " (R$ " + parseFloat(servicosData[sid].valor).toFixed(2) + ")");
                    total += parseFloat(servicosData[sid].valor);
                } else if (combosData[sid]) {
                     nomesServicos.push(combosData[sid].nome + " (Combo - R$ " + parseFloat(combosData[sid].valor).toFixed(2) + ")");
                     total += parseFloat(combosData[sid].valor);
                }
            });
        }
        
        let produtosHtml = '';
        if(data.produtos_vendidos) {
            try {
                const prods = JSON.parse(data.produtos_vendidos);
                if(prods.length > 0) {
                    produtosHtml = '<div style="margin-top:10px; padding:10px; background:#f9f9f9; border-radius:5px;"><strong>Produtos Adquiridos:</strong><ul>';
                    prods.forEach(p => {
                        produtosHtml += `<li>${p.nome} - R$ ${parseFloat(p.valor).toFixed(2)}</li>`;
                        total += parseFloat(p.valor);
                    });
                    produtosHtml += '</ul></div>';
                }
            } catch(e){}
        }

        const desconto = parseFloat(data.desconto_aplicado || 0);
        const final = total - desconto;
        
        // Formata data e hora
        const dataObj = new Date(data.data + 'T' + data.hora);
        const dataFormatada = dataObj.toLocaleDateString('pt-BR');

        contentDiv.innerHTML = `
            <button class="modal-close">&times;</button>
            <h3>Detalhes do Agendamento</h3>
            <p><strong>Data:</strong> ${dataFormatada} às ${data.hora}</p>
            <p><strong>Barbeiro:</strong> ${barbeirosData[data.barbeiro_id]?.nome || 'N/A'}</p>
            <hr>
            <p><strong>Serviços:</strong></p>
            <ul>${nomesServicos.map(s => `<li>${s}</li>`).join('')}</ul>
            ${produtosHtml}
            <hr>
            <p>Subtotal: R$ ${total.toFixed(2)}</p>
            <p style="color: green;">Desconto: - R$ ${desconto.toFixed(2)}</p>
            <p style="font-size: 1.2em;"><strong>Total Pago: R$ ${final.toFixed(2)}</strong></p>
            
            <div style="margin-top: 20px; text-align: center;">
                ${(data.status === 'aprovado' || data.status === 'pendente') ? 
                `<a href="minha_conta.php?action=cancelar&id=${data.id}" class="btn btn-rejeitar" onclick="return confirm('Tem certeza que deseja cancelar?');">Cancelar Agendamento</a>` : ''}
            </div>
        `;
        
        // Reatacha evento de fechar no botão dinâmico
        const closeBtn = contentDiv.querySelector('.modal-close');
        if(closeBtn) closeBtn.addEventListener('click', () => closeModal(document.getElementById('modal-detalhes-agendamento')));
    }


    // --- 4. LÓGICA DE REAGENDAMENTO (CORRIGIDA) ---
    function preencherModalReagendamento(id) {
        const data = agendamentosDataById[id];
        if(!data) return;

        document.getElementById('reagendar_agendamento_id').value = id;
        document.getElementById('reagendar_barbeiro_id').value = data.barbeiro_id;
        document.getElementById('reagendar_servicos_ids').value = data.servicos_ids;
        
        // Limpa horários anteriores
        document.getElementById('reagendar_horarios-container').innerHTML = '<p style="grid-column: 1/-1; text-align:center; color:#666;">Selecione uma data para ver os horários.</p>';
        document.getElementById('reagendar_data').value = '';
    }

    const reagendarDataInput = document.getElementById('reagendar_data');
    if(reagendarDataInput) {
        reagendarDataInput.addEventListener('change', function() {
            const data = this.value;
            const barbeiroId = document.getElementById('reagendar_barbeiro_id').value;
            const servicosIds = document.getElementById('reagendar_servicos_ids').value;
            
            if(data && barbeiroId) {
                buscarHorariosDisponiveis(barbeiroId, data, servicosIds);
            }
        });
    }

    // NOVA FUNÇÃO CORRIGIDA PARA BUSCAR E EXIBIR HORÁRIOS
    function buscarHorariosDisponiveis(barbeiroId, data, servicosIds) {
        const container = document.getElementById('reagendar_horarios-container');
        const inputHorario = document.getElementById('reagendar_horario');
        const erroMsg = document.getElementById('reagendar_erro_horario');
        
        container.innerHTML = '<p style="grid-column: 1/-1; text-align: center; color: #666;">Carregando...</p>';
        inputHorario.value = '';
        if(erroMsg) erroMsg.textContent = '';

        // Chama o backend que já faz o cálculo correto de disponibilidade e slots
        fetch(`get_horarios.php?barbeiro_id=${barbeiroId}&data=${data}&itens_selecionados=${servicosIds}`)
            .then(response => response.json())
            .then(horarios => {
                container.innerHTML = '';

                if (horarios.error) {
                    container.innerHTML = `<p class="erro" style="grid-column: 1/-1;">${horarios.error}</p>`;
                    return;
                }
                
                if (!horarios || horarios.length === 0) {
                    container.innerHTML = '<p class="erro" style="grid-column: 1/-1;">Sem horários livres para esta data.</p>';
                    return;
                }

                horarios.forEach(h => {
                    // CRIA UM BOTÃO (BUTTON) PARA PEGAR O ESTILO CSS CORRETO
                    const btn = document.createElement('button');
                    btn.type = 'button';
                    btn.className = 'disponivel'; // Classe usada no style.css
                    btn.textContent = h;
                    
                    btn.onclick = (e) => {
                        e.preventDefault();
                        // Remove seleção anterior
                        container.querySelectorAll('.selecionado').forEach(b => b.classList.remove('selecionado'));
                        // Adiciona seleção atual
                        btn.classList.add('selecionado');
                        inputHorario.value = h;
                        if(erroMsg) erroMsg.textContent = '';
                    };
                    
                    container.appendChild(btn);
                });
            })
            .catch(err => {
                console.error(err);
                container.innerHTML = '<p class="erro" style="grid-column: 1/-1;">Erro ao buscar horários.</p>';
            });
    }


    // --- 5. LÓGICA DE INDICAÇÃO (COPIAR) ---
    const btnCopiar = document.getElementById('btn-copiar-codigo');
    if(btnCopiar) {
        btnCopiar.addEventListener('click', () => {
            const codigo = btnCopiar.dataset.codigo;
            navigator.clipboard.writeText(codigo).then(() => {
                const originalHtml = btnCopiar.innerHTML;
                btnCopiar.innerHTML = '<span>Copiado!</span> <i class="fa fa-check"></i>';
                btnCopiar.style.backgroundColor = '#d4edda';
                btnCopiar.style.borderColor = '#c3e6cb';
                setTimeout(() => {
                    btnCopiar.innerHTML = originalHtml;
                    btnCopiar.style.backgroundColor = '';
                    btnCopiar.style.borderColor = '';
                }, 2000);
            });
        });
    }

    // --- 6. CRONÔMETRO (COUNTDOWN) ---
    const countdownEl = document.getElementById('countdown');
    if(countdownEl) {
        const targetDate = new Date(countdownEl.dataset.datetime).getTime();
        
        const updateTimer = () => {
            const now = new Date().getTime();
            const distance = targetDate - now;

            if (distance < 0) {
                countdownEl.innerHTML = "É AGORA!";
                return;
            }

            const days = Math.floor(distance / (1000 * 60 * 60 * 24));
            const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));

            if(days > 0) {
                countdownEl.innerHTML = `${days}d ${hours}h ${minutes}m`;
            } else {
                countdownEl.innerHTML = `${String(hours).padStart(2,'0')}h ${String(minutes).padStart(2,'0')}m`;
            }
        };

        setInterval(updateTimer, 60000); // Atualiza a cada minuto
        updateTimer(); // Executa imediatamente
    }

});