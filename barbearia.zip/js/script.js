document.addEventListener('DOMContentLoaded', function () {
    // --- Elementos do DOM ---
    const form = document.getElementById('form-agendamento');
    if (!form) return;

    const barbeiroSelectContainer = document.querySelector('.custom-select-container');
    const barbeiroSelected = document.querySelector('.custom-select-selected');
    const barbeiroOptionsContainer = document.querySelector('.custom-select-items');
    const barbeiroInput = document.getElementById('barbeiro');
    
    const servicosContainer = document.getElementById('servicos-container');
    const servicosInput = document.getElementById('servicos'); 
    const combosInput = document.getElementById('combos_selecionados'); 
    
    const dataInput = document.getElementById('data');
    const horariosContainer = document.getElementById('horarios-container');
    const horarioInput = document.getElementById('horario');
    const horarioBarbeiroInput = document.getElementById('horario_barbeiro_id');
    const resumo = document.getElementById('resumo');
    const diasDisponiveisInfo = document.getElementById('dias-disponiveis-info');
    const telefoneInput = document.getElementById('telefone');

    const modal = document.getElementById('modal-barbeiro-detalhes');
    const modalContent = document.getElementById('barbeiro-detalhes-content');
    const closeModalBtn = modal ? modal.querySelector('.modal-close') : null;
    
    let diasDisponiveisCache = {};

    function updateFormState() {
        const selectedBarbeiroId = barbeiroInput.value;
        const selectedItems = getSelectedItemsInfo(); 

        updateBarberAvailability(selectedItems.itemIds); 
        updateServiceAvailability(selectedBarbeiroId); 
        getHorariosDisponiveis();
        updateResumo();
    }

    function getSelectedItemsInfo() {
        const selectedItemIds = []; 
        const selectedComboIds = []; 
        let allUniqueServiceIds = []; 
        
        let totalSlots = 0;

        // 1. Get Serviços Individuais
        if (servicosContainer) {
            servicosContainer.querySelectorAll('.servico-btn:not(.combo-btn).selected').forEach(btn => {
                const id = btn.dataset.id;
                selectedItemIds.push(id);
                allUniqueServiceIds.push(id);
                totalSlots += parseInt(btn.dataset.slots || 1); 
            });

            // 2. Get Combos
            servicosContainer.querySelectorAll('.servico-btn.combo-btn.selected').forEach(btn => {
                const id = btn.dataset.id; 
                selectedItemIds.push(id); 
                selectedComboIds.push(id); // Adiciona à lista de combos
                allUniqueServiceIds.push(id); // CORREÇÃO: Adiciona o ID DO COMBO à lista principal, não os serviços internos
                
                totalSlots += parseInt(btn.dataset.slots || 1); 
            });
        }

        // 3. Update hidden inputs
        if(servicosInput) servicosInput.value = allUniqueServiceIds.join(',');
        if(combosInput) combosInput.value = selectedComboIds.join(',');

        return {
            itemIds: selectedItemIds,   
            totalSlots: totalSlots,     
        };
    }

    // ... (Resto do código: updateBarberAvailability, updateServiceAvailability, listeners, etc. mantidos iguais) ...
    // Apenas substitua a função getSelectedItemsInfo acima, o restante do arquivo é o mesmo da versão anterior.
    // Para garantir, copiarei as funções auxiliares abaixo para manter o arquivo funcional.

    function updateBarberAvailability(itemIds) {
        if (!barbeiroOptionsContainer) return;
        const barbeiroOpcoes = barbeiroOptionsContainer.querySelectorAll('.custom-option-wrapper');
        barbeiroOpcoes.forEach(wrapper => {
            const option = wrapper.querySelector('.custom-option');
            const barbeiroId = option.dataset.value;
            if (barbeiroId === 'qualquer') return; 
            const barbeiro = typeof barbeirosData !== 'undefined' ? barbeirosData.find(b => b.id === barbeiroId) : null;
            if (!barbeiro) { wrapper.classList.add('disabled'); return; }
            if (itemIds.length === 0) { wrapper.classList.remove('disabled'); return; }
            const especialidades = barbeiro.servicos_ids ? barbeiro.servicos_ids.split(',') : [];
            if (especialidades.length === 0) { wrapper.classList.add('disabled'); return; }
            let podeRealizarTodos = true;
            for (const itemId of itemIds) {
                if (!especialidades.includes(itemId)) { podeRealizarTodos = false; break; }
            }
            if (podeRealizarTodos) { wrapper.classList.remove('disabled'); } else { wrapper.classList.add('disabled'); }
        });
        const selectedBarbeiroId = barbeiroInput.value;
        if (selectedBarbeiroId && selectedBarbeiroId !== 'qualquer') {
            const selectedWrapper = barbeiroOptionsContainer.querySelector(`.custom-option[data-value="${selectedBarbeiroId}"]`)?.closest('.custom-option-wrapper');
            if (selectedWrapper && selectedWrapper.classList.contains('disabled')) {
                barbeiroSelected.innerHTML = 'Selecione um barbeiro';
                barbeiroInput.value = '';
            }
        }
    }

    function updateServiceAvailability(selectedBarbeiroId) {
        if (!servicosContainer) return;
        let especialidades = []; 
        if (selectedBarbeiroId && selectedBarbeiroId !== 'qualquer') {
            const barbeiro = typeof barbeirosData !== 'undefined' ? barbeirosData.find(b => b.id === selectedBarbeiroId) : null;
            if (barbeiro && barbeiro.servicos_ids) { especialidades = barbeiro.servicos_ids.split(','); }
        } else {
            servicosContainer.querySelectorAll('.servico-btn.disabled').forEach(btn => { btn.classList.remove('disabled'); });
            return;
        }
        if (especialidades.length === 0) {
             servicosContainer.querySelectorAll('.servico-btn').forEach(btn => { btn.classList.add('disabled'); });
             return; 
        }
        servicosContainer.querySelectorAll('.servico-btn:not(.combo-btn)').forEach(btn => {
            if (especialidades.includes(btn.dataset.id)) { btn.classList.remove('disabled'); } else { btn.classList.add('disabled'); }
        });
        servicosContainer.querySelectorAll('.servico-btn.combo-btn').forEach(btn => {
            if (especialidades.includes(btn.dataset.id)) { btn.classList.remove('disabled'); } else { btn.classList.add('disabled'); }
        });
        servicosContainer.querySelectorAll('.servico-btn.selected.disabled').forEach(btn => { btn.classList.remove('selected'); });
    }

    if (barbeiroSelectContainer) {
        barbeiroSelected.addEventListener('click', () => { barbeiroOptionsContainer.classList.toggle('show'); });
        barbeiroOptionsContainer.addEventListener('click', (e) => {
            const detalhesBtn = e.target.closest('.btn-detalhes-barbeiro');
            const option = e.target.closest('.custom-option');
            if (detalhesBtn) {
                e.stopPropagation(); 
                const barbeiroId = detalhesBtn.dataset.barbeiroId;
                const barbeiro = typeof barbeirosData !== 'undefined' ? barbeirosData.find(b => b.id === barbeiroId) : null;
                if (!barbeiro) return;
                let avaliacoesHtml = '<h4>Avaliações Recentes</h4>';
                const avaliacoesDoBarbeiro = (typeof avaliacoesData !== 'undefined') ? avaliacoesData.filter(a => a.barbeiro_id === barbeiroId).slice(0, 5) : [];
                if (avaliacoesDoBarbeiro.length > 0) {
                    avaliacoesHtml += '<ul class="lista-avaliacoes">';
                    avaliacoesDoBarbeiro.forEach(av => {
                        const rating = '★'.repeat(av.rating) + '☆'.repeat(5 - av.rating);
                        avaliacoesHtml += `<li><span class="estrelas-modal">${rating}</span><p>"${av.comment || 'Sem comentário'}"</p></li>`;
                    });
                    avaliacoesHtml += '</ul>';
                } else { avaliacoesHtml += '<p>Nenhuma avaliação ainda.</p>'; }
                if (modalContent) {
                    modalContent.innerHTML = `<div class="modal-header-barbeiro"><img src="${barbeiro.foto}" alt="${barbeiro.nome}"><div><h3>${barbeiro.nome}</h3></div></div>${avaliacoesHtml}`;
                    if(modal) modal.style.display = 'flex';
                }
                return; 
            }
            if (option) {
                const wrapper = option.closest('.custom-option-wrapper');
                if (!wrapper || (wrapper && !wrapper.classList.contains('disabled'))) {
                    barbeiroSelected.innerHTML = option.innerHTML;
                    barbeiroInput.value = option.dataset.value;
                    barbeiroOptionsContainer.classList.remove('show');
                    updateFormState(); 
                }
            }
        });
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.custom-select-container')) { barbeiroOptionsContainer.classList.remove('show'); }
        });
    }

    if (servicosContainer) {
        servicosContainer.addEventListener('click', function (e) {
            const target = e.target.closest('.servico-btn');
            if (!target || target.classList.contains('disabled')) return;
            const maxServicos = (typeof agendamentoConfig !== 'undefined') ? (agendamentoConfig.max_servicos || 4) : 4;
            const { totalSlots } = getSelectedItemsInfo();
            if (!target.classList.contains('selected')) {
                let slotsDoItemNovo = parseInt(target.dataset.slots || 1);
                if ((totalSlots + slotsDoItemNovo) > maxServicos) {
                     alert(`Você pode selecionar no máximo ${maxServicos} slots de serviço.`);
                     return;
                }
            }
            target.classList.toggle('selected');
            const isCombo = target.classList.contains('combo-btn');
            const idDoTarget = target.dataset.id;
            const servicosIdsDoTarget = target.dataset.servicosIds ? target.dataset.servicosIds.split(',').map(s => s.trim()) : [idDoTarget];
            if (target.classList.contains('selected')) {
                if (isCombo) {
                    servicosContainer.querySelectorAll('.servico-btn:not(.combo-btn).selected').forEach(btn => {
                        if (servicosIdsDoTarget.includes(btn.dataset.id)) btn.classList.remove('selected');
                    });
                } else {
                    servicosContainer.querySelectorAll('.servico-btn.combo-btn.selected').forEach(btn => {
                        const idsDoComboBtn = btn.dataset.servicosIds ? btn.dataset.servicosIds.split(',').map(s => s.trim()) : [];
                        if (idsDoComboBtn.includes(idDoTarget)) btn.classList.remove('selected');
                    });
                }
            }
            updateFormState(); 
        });
    }

    if (dataInput) {
        flatpickr(dataInput, {
            locale: "pt", dateFormat: "Y-m-d", minDate: "today",
            maxDate: new Date().fp_incr((typeof agendamentoConfig !== 'undefined') ? (agendamentoConfig.antecedencia_maxima || 30) : 30),
            disableMobile: true,
            onMonthChange: function(selectedDates, dateStr, instance) { buscarDiasDisponiveis(instance); },
            onOpen: function(selectedDates, dateStr, instance) { buscarDiasDisponiveis(instance); },
            onChange: function(selectedDates, dateStr, instance) { horarioInput.value = ''; horarioBarbeiroInput.value = ''; updateFormState(); }
        });
    }

    async function buscarDiasDisponiveis(instance) {
        const barbeiroId = barbeiroInput.value;
        const { itemIds, totalSlots } = getSelectedItemsInfo();
        let numServicosParaCalculo = totalSlots === 0 ? 1 : totalSlots; 
        if (totalSlots === 0) { if(diasDisponiveisInfo) diasDisponiveisInfo.textContent = "Selecione um serviço para filtrar melhor os dias."; } 
        else { if(diasDisponiveisInfo) diasDisponiveisInfo.textContent = "Buscando dias disponíveis..."; }
        const mes = instance.currentMonth + 1;
        const ano = instance.currentYear;
        const cacheKey = `${barbeiroId}-${numServicosParaCalculo}-${itemIds.join('-')}-${mes}-${ano}`;
        instance.calendarContainer.querySelectorAll('.available').forEach(d => d.classList.remove('available'));
        let dias = [];
        if (diasDisponiveisCache[cacheKey]) { dias = diasDisponiveisCache[cacheKey]; } else {
            try {
                const response = await fetch(`get_horarios.php?mode=dias_disponiveis&barbeiro_id=${barbeiroId}&num_servicos_total=${numServicosParaCalculo}&mes=${mes}&ano=${ano}&itens_selecionados=${itemIds.join(',')}`);
                const data = await response.json();
                dias = data.dias || [];
                diasDisponiveisCache[cacheKey] = dias;
            } catch (error) { if(diasDisponiveisInfo) diasDisponiveisInfo.textContent = "Erro ao carregar dias."; return; }
        }
        if (dias.length === 0) { if(diasDisponiveisInfo) diasDisponiveisInfo.textContent = "Nenhum dia disponível para este mês."; return; }
        if (totalSlots > 0) { if(diasDisponiveisInfo) diasDisponiveisInfo.textContent = ""; } 
        dias.forEach(dia => {
            const diaElem = instance.calendarContainer.querySelector(`.flatpickr-day[aria-label$=" ${dia}, ${ano}"]`);
            if (diaElem) diaElem.classList.add('available');
        });
    }

    async function getHorariosDisponiveis() {
        const barbeiroId = barbeiroInput.value;
        const data = dataInput.value;
        const { itemIds, totalSlots } = getSelectedItemsInfo();
        let numServicosParaCalculo = totalSlots === 0 ? 1 : totalSlots;
        horariosContainer.innerHTML = '';
        horarioInput.value = '';
        horarioBarbeiroInput.value = '';
        if (!barbeiroId || !data) { horariosContainer.innerHTML = '<p class="erro" style="text-align: left; margin: 0;">Selecione um barbeiro e uma data.</p>'; return; }
        if (totalSlots === 0 && barbeiroId !== 'qualquer') {
             const barbeiro = typeof barbeirosData !== 'undefined' ? barbeirosData.find(b => b.id === barbeiroId) : null;
             if (barbeiro && barbeiro.servicos_ids) { horariosContainer.innerHTML = '<p class="erro" style="text-align: left; margin: 0;">Por favor, selecione os serviços que este barbeiro realiza.</p>'; return; }
        }
        horariosContainer.innerHTML = 'Carregando horários...';
        try {
            const response = await fetch(`get_horarios.php?barbeiro_id=${barbeiroId}&data=${data}&num_servicos_total=${numServicosParaCalculo}&itens_selecionados=${itemIds.join(',')}`);
            if (!response.ok) throw new Error('Erro na rede');
            const horarios = await response.json();
            if (horarios.error) { horariosContainer.innerHTML = `<p class="erro" style="text-align: left; margin: 0;">${horarios.error}</p>`; return; }
            horariosContainer.innerHTML = ''; 
            if (horarios.length === 0) { horariosContainer.innerHTML = '<p class="erro" style="text-align: left; margin: 0;">Nenhum horário disponível.</p>'; return; }
            horarios.forEach(h => {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'disponivel';
                if (typeof h === 'object') {
                    btn.textContent = h.horario;
                    btn.innerHTML += `<span class="horario-qualquer-barbeiro">${h.barbeiro_nome}</span>`;
                    btn.dataset.barbeiroId = h.barbeiro_id;
                    btn.dataset.horario = h.horario;
                } else {
                    btn.textContent = h;
                    btn.dataset.horario = h;
                }
                btn.addEventListener('click', () => {
                    horariosContainer.querySelectorAll('button').forEach(b => b.classList.remove('selecionado'));
                    btn.classList.add('selecionado');
                    horarioInput.value = btn.dataset.horario;
                    horarioBarbeiroInput.value = btn.dataset.barbeiroId || '';
                    updateResumo();
                });
                horariosContainer.appendChild(btn);
            });
        } catch (error) { horariosContainer.innerHTML = '<p class="erro" style="text-align: left; margin: 0;">Erro ao carregar horários.</p>'; }
    }

    if(closeModalBtn) closeModalBtn.onclick = () => modal.style.display = 'none';
    window.onclick = (e) => { if (e.target == modal) modal.style.display = 'none'; }

    function updateResumo() {
        const barbeiroId = barbeiroInput.value;
        const data = dataInput.value;
        const hora = horarioInput.value;
        const { itemIds, totalSlots } = getSelectedItemsInfo();

        if (itemIds.length === 0) { resumo.innerHTML = ''; resumo.style.display = 'none'; return; }

        const aderirPlanoCheckbox = document.getElementById('aderir_plano');
        const planoSelecionadoId = document.getElementById('plano_escolhido_id')?.value;
        const estaAderindo = aderirPlanoCheckbox && aderirPlanoCheckbox.checked && planoSelecionadoId;
        
        let planoAtivo = null;
        if (estaAderindo) {
            if (typeof planosData !== 'undefined') planoAtivo = planosData[planoSelecionadoId];
        } else if (typeof clienteAssinaturaAtiva !== 'undefined' && clienteAssinaturaAtiva) {
            if (typeof planosData !== 'undefined') planoAtivo = planosData[clienteAssinaturaAtiva.plano_id];
        }

        let servicosInclusos = [];
        if (planoAtivo && planoAtivo.servicos_ids) servicosInclusos = planoAtivo.servicos_ids.split(',').map(s => s.trim());

        let html = '<h4>Resumo do Agendamento</h4>';
        let valorTotal = 0;

        itemIds.forEach(itemId => {
            if (itemId.startsWith('cb-')) {
                const combo = (typeof combosData !== 'undefined') ? combosData[itemId] : null;
                if(combo) {
                    let valorOriginal = parseFloat(combo.valor);
                    let textoPreco = `R$ ${valorOriginal.toFixed(2)}`;
                    if (planoAtivo) {
                        const servicosDoCombo = combo.servicos_ids.split(',');
                        let itensCobertosCount = 0;
                        let custoItensNaoCobertos = 0;
                        servicosDoCombo.forEach(sid => {
                            const cleanSid = sid.trim();
                            if (servicosInclusos.includes(cleanSid)) { itensCobertosCount++; } 
                            else { if (servicosData[cleanSid]) custoItensNaoCobertos += parseFloat(servicosData[cleanSid].valor); }
                        });
                        if (itensCobertosCount > 0) {
                            const valorFinal = custoItensNaoCobertos;
                            textoPreco = `<span style="text-decoration: line-through; color: #999; font-size: 0.9em;">R$ ${valorOriginal.toFixed(2)}</span> <span style="color: #28a745; font-weight: bold;">R$ ${valorFinal.toFixed(2)} (VIP)</span>`;
                            valorTotal += valorFinal;
                        } else { valorTotal += valorOriginal; }
                    } else { valorTotal += valorOriginal; }
                    html += `<p><strong>Combo:</strong> ${combo.nome} (${textoPreco})</p>`;
                }
            } else if (itemId.startsWith('sv-')) {
                const servico = (typeof servicosData !== 'undefined') ? servicosData[itemId] : null;
                if(servico) {
                    let valorOriginal = parseFloat(servico.valor);
                    let textoPreco = `R$ ${valorOriginal.toFixed(2)}`;
                    if (planoAtivo && servicosInclusos.includes(itemId)) {
                        textoPreco = `<span style="text-decoration: line-through; color: #999; font-size: 0.9em;">R$ ${valorOriginal.toFixed(2)}</span> <span style="color: #28a745; font-weight: bold;">Grátis (VIP)</span>`;
                    } else { valorTotal += valorOriginal; }
                    html += `<p><strong>Serviço:</strong> ${servico.nome} (${textoPreco})</p>`;
                }
            }
        });

        if (estaAderindo && planoAtivo) {
            const valorPlano = parseFloat(planoAtivo.valor);
            html += `<div style="margin-top: 10px; padding-top: 10px; border-top: 1px dashed #ccc;"><p><strong>Adesão Plano ${planoAtivo.nome}:</strong> R$ ${valorPlano.toFixed(2)}</p><small style="color: #666;">(Cobrado hoje)</small></div>`;
            valorTotal += valorPlano;
        }

        html += `<p style="font-size: 1.2em; margin-top: 10px; border-top: 2px solid #eee; padding-top: 10px;"><strong>Valor Total:</strong> R$ ${valorTotal.toFixed(2)}</p>`;
        
        if (totalSlots > 0) html += `<p><strong>Tempo Estimado:</strong> ${totalSlots * 30} minutos</p>`;
        
        if (barbeiroId) {
            let nomeBarbeiro = "Qualquer Barbeiro";
            if (barbeiroId !== 'qualquer') {
                const barbeiro = typeof barbeirosData !== 'undefined' ? barbeirosData.find(b => b.id === barbeiroId) : null;
                if(barbeiro) nomeBarbeiro = barbeiro.nome;
            }
            const barbeiroDoHorarioId = horarioBarbeiroInput.value;
            if(barbeiroDoHorarioId) {
                 const barbeiroH = typeof barbeirosData !== 'undefined' ? barbeirosData.find(b => b.id === barbeiroDoHorarioId) : null;
                 if(barbeiroH) nomeBarbeiro = barbeiroH.nome;
            }
            html += `<p><strong>Barbeiro:</strong> ${nomeBarbeiro}</p>`;
        }
        if (data) html += `<p><strong>Data:</strong> ${new Date(data + 'T00:00:00').toLocaleDateString('pt-BR')}</p>`;
        if (hora) html += `<p><strong>Hora:</strong> ${hora}</p>`;
        resumo.innerHTML = html; resumo.style.display = 'block';
    }
    
    if(telefoneInput) {
        telefoneInput.addEventListener('input', function (e) {
            let v = e.target.value.replace(/\D/g, '');
            v = v.replace(/^(\d{2})(\d)/g, '($1) $2');
            v = v.replace(/(\d{5})(\d)/, '$1-$2');
            e.target.value = v.slice(0, 15);
        });
    }
    const btnToggleObs = document.getElementById('btn-toggle-observacoes');
    const obsContainer = document.getElementById('observacoes-container');
    if (btnToggleObs) {
        btnToggleObs.addEventListener('click', function() {
            const isHidden = obsContainer.style.display === 'none' || obsContainer.style.display === '';
            obsContainer.style.display = isHidden ? 'block' : 'none';
            this.innerHTML = isHidden ? '<i class="fa fa-plus"></i> Adicionar Observação' : '<i class="fa fa-minus"></i> Remover Observação';
        });
    }
    document.addEventListener('updateResumoNeeded', function() { updateResumo(); });
    updateFormState();
});