<?php
header('Content-Type: application/json');
require_once 'functions.php';

// Garante que o fuso horário esteja correto para todas as operações de data/hora no script
date_default_timezone_set('America/Sao_Paulo');

$configAgendamento = carregarConfigAgendamento();

// --- INÍCIO DA ATUALIZAÇÃO (Funcionalidade 1: Duração do Serviço) ---
// 1. Carrega todos os barbeiros com a nova coluna 'servicos_ids'
$todosBarbeirosArr = lerDados('barbeiros.txt', ['id', 'nome', 'foto', 'username', 'password', 'status', 'servicos_ids']);

// 2. Carrega serviços (com 4 colunas) e combos para calcular os slots
$servicosArr = lerDados('servicos.txt', ['id', 'nome', 'valor', 'slots']);
$combosArr = lerDados('combos.txt', ['id', 'nome', 'servicos_ids', 'valor']);

// 3. Cria um array filtrado APENAS com barbeiros "ativos"
$barbeirosAtivosArr = array_filter($todosBarbeirosArr, function($barbeiro) {
    $status = $barbeiro['status'] ?? 'ativo';
    if(empty($status)) $status = 'ativo';
    return $status === 'ativo';
});

// 4. Pega os ITENS (serviços E combos) que o cliente selecionou
$itens_selecionados_ids = isset($_GET['itens_selecionados']) ? array_filter(explode(',', $_GET['itens_selecionados'])) : [];

// 5. CALCULA O TOTAL DE SLOTS (DURAÇÃO) NO BACKEND
$totalSlots = 0;
$servicosJaProcessados = []; // Evita contar duas vezes (ex: cliente seleciona combo + serviço individual que está no combo)

// Processa combos primeiro
foreach ($itens_selecionados_ids as $itemId) {
    if (strpos($itemId, 'cb-') === 0 && isset($combosArr[$itemId])) {
        $servicosDoCombo = explode(',', $combosArr[$itemId]['servicos_ids']);
        foreach ($servicosDoCombo as $sid) {
            $sid = trim($sid);
            if (!in_array($sid, $servicosJaProcessados) && isset($servicosArr[$sid])) {
                $slots = (int)($servicosArr[$sid]['slots'] ?? 1);
                $totalSlots += ($slots > 0) ? $slots : 1;
                $servicosJaProcessados[] = $sid;
            }
        }
    }
}
// Processa serviços individuais que não estão nos combos já selecionados
foreach ($itens_selecionados_ids as $itemId) {
    if (strpos($itemId, 'sv-') === 0 && isset($servicosArr[$itemId])) {
        if (!in_array($itemId, $servicosJaProcessados)) {
            $slots = (int)($servicosArr[$itemId]['slots'] ?? 1);
            $totalSlots += ($slots > 0) ? $slots : 1;
            $servicosJaProcessados[] = $itemId;
        }
    }
}
// Garante que o número de slots seja no mínimo 1 (para o cálculo não falhar)
$numServicosParaCalculo = ($totalSlots > 0) ? $totalSlots : 1;
// --- FIM DA ATUALIZAÇÃO ---


$barbeiro_id = $_GET['barbeiro_id'] ?? null;
$data = $_GET['data'] ?? null;
$mode = $_GET['mode'] ?? 'horarios'; // 'horarios', 'dias_disponiveis', 'bloqueados', 'todos_slots'
$admin_mode = isset($_GET['admin_mode']) && $_GET['admin_mode'] == '1'; // NOVO: Captura modo admin

// Retorna apenas os horários que o barbeiro bloqueou manualmente
if ($mode === 'bloqueados') {
    if (!$barbeiro_id || !$data) {
        echo json_encode([]);
        exit;
    }
    $horariosBloqueados = getHorariosBloqueados($barbeiro_id, $data);
    echo json_encode($horariosBloqueados);
    exit;
}

// Retorna TODOS os slots de trabalho do dia, para o modal de bloqueio
if ($mode === 'todos_slots') {
    if (!$barbeiro_id || !$data) {
        echo json_encode([]);
        exit;
    }
    $diaSemana = date('w', strtotime($data));
    $horariosDeTrabalho = getHorarioDeTrabalho($barbeiro_id, $diaSemana);
    if (!$horariosDeTrabalho) {
        echo json_encode([]);
        exit;
    }
    
    $horariosPossiveis = [];
    $start = strtotime($horariosDeTrabalho['inicio']);
    $end = strtotime($horariosDeTrabalho['fim']);
    while ($start < $end) {
        $horariosPossiveis[] = date('H:i', $start);
        $start = strtotime('+30 minutes', $start);
    }
    echo json_encode($horariosPossiveis);
    exit;
}

// (Função interna atualizada)
// Verifica se o barbeiro pode realizar TODOS os ITENS (serviços e combos) selecionados
function barbeiroPodeRealizarItens($barbeiro, $itens_selecionados_ids) {
    // Se nenhum item foi selecionado, o barbeiro é considerado apto por padrão.
    if (empty($itens_selecionados_ids)) {
        return true; 
    }
    
    // Lista de especialidades do barbeiro (ex: "sv-1,cb-1,sv-3")
    $especialidades_barbeiro = isset($barbeiro['servicos_ids']) ? array_filter(explode(',', $barbeiro['servicos_ids'])) : [];
    
    // Se a lista de especialidades do barbeiro for vazia E o cliente selecionou itens,
    // então o barbeiro não pode realizá-los.
    if (empty($especialidades_barbeiro)) {
        return false;
    }

    // Verifica se TODOS os IDs de itens selecionados (sv- E cb-)
    // estão na lista de especialidades do barbeiro
    foreach ($itens_selecionados_ids as $item_id) {
        if (!in_array($item_id, $especialidades_barbeiro)) {
            return false; // Falta pelo menos um item
        }
    }
    
    return true; // Ele pode fazer todos
}


if ($mode === 'dias_disponiveis') {
    $mes = $_GET['mes'] ?? date('m');
    $ano = $_GET['ano'] ?? date('Y');
    
    // ATUALIZAÇÃO: Usa o $numServicosParaCalculo que foi calculado no backend
    $numServicos = $numServicosParaCalculo;
    
    $diasDisponiveis = [];
    $diasNoMes = cal_days_in_month(CAL_GREGORIAN, $mes, $ano);
    
    for ($dia = 1; $dia <= $diasNoMes; $dia++) {
        $dataCompleta = sprintf('%s-%s-%s', $ano, str_pad($mes, 2, '0', STR_PAD_LEFT), str_pad($dia, 2, '0', STR_PAD_LEFT));
        
        // CORREÇÃO: Se for admin, permite verificar dias passados (opcional, mas o calendário frontend já bloqueia por padrão)
        // Aqui mantemos o bloqueio padrão pois 'dias_disponiveis' é usado principalmente pelo cliente.
        // O admin usa o datepicker nativo que já foi liberado.
        if (!$admin_mode && strtotime($dataCompleta) < strtotime(date('Y-m-d'))) continue;

        // ATUALIZAÇÃO: Usa o array $barbeirosAtivosArr
        $barbeirosParaVerificar = ($barbeiro_id === 'qualquer' || empty($barbeiro_id)) ? $barbeirosAtivosArr : [$barbeirosAtivosArr[$barbeiro_id] ?? null];
        
        foreach ($barbeirosParaVerificar as $b_id => $barbeiro) {
            if (!$barbeiro) continue; // Pula se o barbeiro específico for nulo ou inativo

            // ATUALIZAÇÃO: Verifica especialidades usando a lista de ITENS
            if (!barbeiroPodeRealizarItens($barbeiro, $itens_selecionados_ids)) {
                continue; // Pula barbeiro que não faz os itens
            }
            
            // Passa $admin_mode para a verificação
            $horariosDoDia = getHorariosDisponiveisParaDia($b_id, $dataCompleta, $configAgendamento, $numServicos, $servicosArr, $admin_mode);
            if (!empty($horariosDoDia)) {
                $diasDisponiveis[] = (int)$dia;
                break; 
            }
        }
    }
    echo json_encode(['dias' => array_unique($diasDisponiveis)]);
    exit;
}

// CORREÇÃO: Não exige mais 'servicos_ids', apenas barbeiro e data
if (!$barbeiro_id || !$data) {
    echo json_encode(['error' => 'Dados de barbeiro ou data não fornecidos.']);
    exit;
}

// ATUALIZAÇÃO: Usa o $numServicosParaCalculo que foi calculado no backend
$numServicos = $numServicosParaCalculo;


if ($barbeiro_id === 'qualquer') {
    $horariosConsolidados = [];

    // ATUALIZAÇÃO: Itera sobre $barbeirosAtivosArr e filtra por especialidade
    foreach ($barbeirosAtivosArr as $id => $barbeiro) {
        
        // Verifica se este barbeiro pode realizar os ITENS selecionados
        if (!barbeiroPodeRealizarItens($barbeiro, $itens_selecionados_ids)) {
            continue; // Pula para o próximo barbeiro
        }
        
        // Passa $admin_mode
        $horariosDoBarbeiro = getHorariosDisponiveisParaDia($id, $data, $configAgendamento, $numServicos, $servicosArr, $admin_mode);
        foreach ($horariosDoBarbeiro as $horario) {
            $horariosConsolidados[] = [
                'horario' => $horario,
                'barbeiro_id' => $id,
                'barbeiro_nome' => $barbeiro['nome']
            ];
        }
    }
    usort($horariosConsolidados, function($a, $b) {
        return strcmp($a['horario'], $b['horario']);
    });
    echo json_encode($horariosConsolidados);

} else {
    // ATUALIZAÇÃO: Verifica se o ID do barbeiro solicitado está ativo E se pode realizar os serviços
    if (!isset($barbeirosAtivosArr[$barbeiro_id])) {
        echo json_encode(['error' => 'Este barbeiro não está disponível.']);
        exit;
    }
    
    $barbeiro_selecionado = $barbeirosAtivosArr[$barbeiro_id];
    if (!barbeiroPodeRealizarItens($barbeiro_selecionado, $itens_selecionados_ids)) {
        echo json_encode(['error' => 'Este barbeiro não realiza todos os itens selecionados.']);
        exit;
    }
    // FIM DA ATUALIZAÇÃO
    
    // Passa $admin_mode
    $horariosDisponiveis = getHorariosDisponiveisParaDia($barbeiro_id, $data, $configAgendamento, $numServicos, $servicosArr, $admin_mode);
    echo json_encode($horariosDisponiveis);
}


/**
 * Função interna de `get_horarios.php` para encontrar horários disponíveis.
 * Agora, $numServicos é o número total de slots (duração).
 * * CORREÇÃO: Adicionado parâmetro $admin_mode
 *
 * @param string $barbeiro_id
 * @param string $data
 * @param array $config
 * @param int $numServicos (Total de slots de 30 min necessários)
 * @param array $servicosArr (Necessário para a função getHorariosOcupados)
 * @param bool $admin_mode (Se true, ignora restrição de horário passado no dia atual)
 * @return array
 */
function getHorariosDisponiveisParaDia($barbeiro_id, $data, $config, $numServicos, $servicosArr, $admin_mode = false) {
    $diaSemana = date('w', strtotime($data));
    $horariosDeTrabalho = getHorarioDeTrabalho($barbeiro_id, $diaSemana);
    if (!$horariosDeTrabalho) return [];

    // ATUALIZAÇÃO: getHorariosOcupados agora depende de $servicosArr para calcular slots
    $horariosOcupados = getHorariosOcupados($barbeiro_id, $data);
    
    $horariosPossiveis = [];
    $start = strtotime($horariosDeTrabalho['inicio']);
    $end = strtotime($horariosDeTrabalho['fim']);

    // Gera todos os slots de 30 minutos dentro do horário de trabalho
    while ($start < $end) {
        $horariosPossiveis[] = date('H:i', $start);
        $start = strtotime('+30 minutes', $start);
    }
    
    // Remove horários já ocupados por outros agendamentos
    $horariosLivres = array_diff($horariosPossiveis, $horariosOcupados);
    
    $horariosAgendaveis = [];
    // ATUALIZAÇÃO: A duração é baseada no número de slots (ex: 2 slots * 30 min * 60 seg)
    $duracao_servico_segundos = $numServicos * 30 * 60;

    foreach ($horariosLivres as $horarioInicio) {
        $timestampInicio = strtotime($data . ' ' . $horarioInicio);

        // Verifica se o serviço termina ATÉ o final do expediente (inclusive)
        if (($timestampInicio + $duracao_servico_segundos) > strtotime($data . ' ' . $horariosDeTrabalho['fim'])) {
            continue; 
        }

        // Verifica se todos os slots necessários para o serviço estão livres
        $temSlotCompleto = true;
        for ($i = 1; $i < $numServicos; $i++) {
            $proximoSlot = date('H:i', $timestampInicio + ($i * 30 * 60));
            if (!in_array($proximoSlot, $horariosLivres)) {
                $temSlotCompleto = false;
                break;
            }
        }

        if ($temSlotCompleto) {
            $horariosAgendaveis[] = $horarioInicio;
        }
    }

    if (empty($horariosAgendaveis)) {
        return [];
    }
    
    // Aplica a regra de antecedência apenas se a data for hoje E NÃO FOR MODO ADMIN
    if ($data == date('Y-m-d') && !$admin_mode) {
        $antecedenciaMinima = (int) ($config['antecedencia_minima_minutos'] ?? 0);
        $horarioMinimoPermitido = date('H:i', strtotime("+$antecedenciaMinima minutes"));
        
        $horariosFinais = array_filter($horariosAgendaveis, function($horario) use ($horarioMinimoPermitido) {
            return $horario >= $horarioMinimoPermitido;
        });

        return array_values($horariosFinais);
    }

    // Para dias futuros (ou modo admin), retorna todos os horários válidos
    return array_values($horariosAgendaveis);
}
?>