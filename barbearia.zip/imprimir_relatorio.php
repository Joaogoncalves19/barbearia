<?php
// imprimir_relatorio.php
// Relatório completo "turbinado" com sistema de assinaturas e métricas financeiras detalhadas.

// Proteção básica para garantir que as funções sejam carregadas
if (file_exists('functions.php')) {
    require_once 'functions.php';
} else {
    die('Erro: Arquivo de funções principal não encontrado.');
}

// Define o fuso horário
date_default_timezone_set('America/Sao_Paulo');

// Carrega todas as configurações e dados brutos
$configGeral = carregarConfigGeral();
$barbeirosArr = lerDados('barbeiros.txt', ['id', 'nome', 'foto', 'username', 'password']);
$servicosArr = lerDados('servicos.txt', ['id', 'nome', 'valor']);
$combosArr = lerDados('combos.txt', ['id', 'nome', 'servicos_ids', 'valor']); // Carrega combos
$agendamentosArr = lerDados('agendamentos.txt', ['id', 'nome', 'email', 'telefone', 'barbeiro_id', 'servicos_ids', 'data', 'hora', 'status', 'desconto_aplicado', 'tipo_desconto', 'observacoes', 'produtos_vendidos']);
$clientesArr = lerDados('clientes.txt', ['id', 'nome', 'email', 'telefone', 'password_hash', 'data_nascimento', 'foto_perfil', 'codigo_indicacao', 'cpf']);

// Novos dados para Assinaturas
$planosArr = lerDados('planos.txt', ['id', 'nome', 'valor', 'servicos_ids']);
$assinaturasClientesArr = lerDados('clientes_assinaturas.txt', ['cliente_id', 'plano_id', 'data_inicio', 'data_fim', 'status']);

// --- Leitura Segura de Horários ---
$horariosTrabalhoRaw = [];
$horariosFilePath = DATA_DIR . 'horarios_trabalho.txt';
if (file_exists($horariosFilePath)) {
    $fp = fopen($horariosFilePath, 'r');
    if ($fp) {
        if (flock($fp, LOCK_SH)) {
            while (($linha = fgets($fp)) !== false) {
                $linhaLimpa = trim($linha);
                if (!empty($linhaLimpa)) {
                    $horariosTrabalhoRaw[] = $linhaLimpa;
                }
            }
            flock($fp, LOCK_UN);
        }
        fclose($fp);
    }
}

// Pega o período do GET
$data_inicio = $_GET['data_inicio'] ?? date('Y-m-01');
$data_fim = $_GET['data_fim'] ?? date('Y-m-t');
$data_inicio_formatada = date('d/m/Y', strtotime($data_inicio));
$data_fim_formatada = date('d/m/Y', strtotime($data_fim));
$data_hoje = date('Y-m-d');

// Filtra os agendamentos para o período
$agendamentosFiltrados = array_filter($agendamentosArr, function($ag) use ($data_inicio, $data_fim) {
    if (!isset($ag['data'])) return false;
    return $ag['data'] >= $data_inicio && $ag['data'] <= $data_fim;
});
$agendamentosConcluidos = array_filter($agendamentosFiltrados, fn($a) => isset($a['status']) && $a['status'] === 'concluido');

// ==========================================================================
// CÁLCULOS FINANCEIROS DETALHADOS
// ==========================================================================

$receitaTotal = 0; 
$receitaServicos = 0;
$receitaPlanos = 0; // Adesões
$receitaProdutos = 0;
$totalDescontos = 0; 
$economiaVIP = 0; // Quanto foi "descontado" por ser VIP

foreach($agendamentosConcluidos as $ag) { 
    // 1. Valor dos Serviços/Combos
    $sids = isset($ag['servicos_ids']) ? explode(',', $ag['servicos_ids']) : []; 
    $valor_servicos_bruto = 0; 
    foreach($sids as $sid) {
        $sid = trim($sid);
        if(isset($servicosArr[$sid])) { 
            $valor_servicos_bruto += (float)$servicosArr[$sid]['valor']; 
        } elseif (isset($combosArr[$sid])) {
            $valor_servicos_bruto += (float)$combosArr[$sid]['valor'];
        }
    }

    // 2. Valor dos Produtos
    $valor_produtos = 0;
    $produtos_vendidos = !empty($ag['produtos_vendidos']) ? json_decode($ag['produtos_vendidos'], true) : [];
    if(is_array($produtos_vendidos)) {
        foreach($produtos_vendidos as $produto) { 
            $valor_produtos += (float)$produto['valor'];
        }
    }
    $receitaProdutos += $valor_produtos;

    // 3. Descontos
    $desconto = (float)($ag['desconto_aplicado'] ?? 0); 
    $tipo_desconto = $ag['tipo_desconto'] ?? '';

    // Lógica de distribuição de receita
    $valor_final_pago = ($valor_servicos_bruto + $valor_produtos) - $desconto;

    if ($tipo_desconto === 'adesao_plano') {
        $receitaPlanos += $valor_final_pago;
    } else {
        $receitaServicos += max(0, $valor_final_pago - $valor_produtos);
    }

    if ($tipo_desconto === 'assinatura_vip') {
        $economiaVIP += $desconto;
    } elseif ($desconto > 0 && $tipo_desconto !== 'adesao_plano') {
        $totalDescontos += $desconto;
    }

    $receitaTotal += $valor_final_pago; 
}

// ==========================================================================
// CÁLCULOS DE ASSINATURAS (MRR & STATUS)
// ==========================================================================

$totalAssinantesAtivos = 0;
$mrrAtual = 0;
$planosPopulares = [];
$assinaturasVencendo = [];
$novasAssinaturasPeriodo = 0;

foreach($assinaturasClientesArr as $assinatura) {
    $estaAtiva = (isset($assinatura['status']) && $assinatura['status'] === 'ativo' && $assinatura['data_fim'] >= $data_hoje);
    
    if ($estaAtiva) {
        $totalAssinantesAtivos++;
        if (isset($planosArr[$assinatura['plano_id']])) {
            $mrrAtual += (float) $planosArr[$assinatura['plano_id']]['valor'];
            
            $nomePlano = $planosArr[$assinatura['plano_id']]['nome'];
            if (!isset($planosPopulares[$nomePlano])) $planosPopulares[$nomePlano] = 0;
            $planosPopulares[$nomePlano]++;
        }
        
        // Vencendo nos próximos 15 dias (para relatório impresso é bom um prazo maior)
        $dataVencimento = $assinatura['data_fim'];
        $dataLimiteAlerta = date('Y-m-d', strtotime('+15 days'));
        if ($dataVencimento <= $dataLimiteAlerta && $dataVencimento >= $data_hoje) {
            $temp = $assinatura;
            $temp['nome_cliente'] = $clientesArr[$assinatura['cliente_id']]['nome'] ?? 'Desc.';
            $temp['nome_plano'] = $planosArr[$assinatura['plano_id']]['nome'] ?? 'Desc.';
            $assinaturasVencendo[] = $temp;
        }
    }
    
    // Novas adesões no período do relatório
    if ($assinatura['data_inicio'] >= $data_inicio && $assinatura['data_inicio'] <= $data_fim) {
        $novasAssinaturasPeriodo++;
    }
}
arsort($planosPopulares);

// ==========================================================================
// CÁLCULOS OPERACIONAIS E CRM
// ==========================================================================

$contagemStatus = getContagemStatusAgendamentos($agendamentosFiltrados);
$taxasOcupacao = [];
foreach ($barbeirosArr as $id => $barbeiro) {
    $taxasOcupacao[$barbeiro['nome']] = getTaxaOcupacaoBarbeiro($id, $data_inicio, $data_fim, $agendamentosFiltrados, $horariosTrabalhoRaw);
}
$rankingServicosIds = getRankingServicos($agendamentosConcluidos, $servicosArr);
$topClientes = getTopClientesPorGasto($agendamentosConcluidos, $servicosArr);
$clientesEmRisco = getClientesEmRisco($agendamentosArr, $clientesArr, 90);
$dadosNovosVsRecorrentes = getNovosVsRecorrentes($agendamentosFiltrados);
$analiseDescontos = getAnaliseDescontos($agendamentosConcluidos); // Pega a análise detalhada para a tabela

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório Gerencial - <?= htmlspecialchars($configGeral['nome_barbearia']) ?></title>
    <link rel="stylesheet" href="css/custom_theme.css.php"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background-color: #525659; color: #333; line-height: 1.4; margin: 0; padding: 20px; }
        .page { width: 210mm; min-height: 297mm; padding: 15mm; margin: 0 auto; background: white; box-shadow: 0 0 10px rgba(0,0,0,0.5); box-sizing: border-box; }
        
        .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 15px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }
        .header-left { text-align: left; }
        .header-right { text-align: right; }
        .header h1 { margin: 0; font-size: 22px; color: #000; text-transform: uppercase; letter-spacing: 1px; }
        .header h2 { margin: 5px 0 0; font-size: 14px; font-weight: normal; color: #666; }
        .periodo { font-size: 14px; font-weight: bold; background: #eee; padding: 5px 10px; border-radius: 4px; display: inline-block; }
        
        h3 { font-size: 16px; color: #000; border-bottom: 1px solid #ccc; padding-bottom: 5px; margin-top: 25px; margin-bottom: 15px; text-transform: uppercase; }
        
        /* Grid System para Impressão */
        .grid-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin-bottom: 20px; }
        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
        .grid-4 { display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap: 10px; margin-bottom: 20px; }

        /* Cards */
        .kpi-card { padding: 10px; border: 1px solid #ddd; border-radius: 6px; background-color: #f9f9f9; }
        .kpi-title { font-size: 11px; text-transform: uppercase; color: #666; font-weight: bold; margin-bottom: 5px; }
        .kpi-value { font-size: 20px; font-weight: bold; color: #333; }
        .kpi-sub { font-size: 10px; color: #888; margin-top: 2px; }
        
        .kpi-green .kpi-value { color: #28a745; }
        .kpi-blue .kpi-value { color: #007bff; }
        .kpi-purple .kpi-value { color: #6f42c1; }
        .kpi-red .kpi-value { color: #dc3545; }

        /* Tabelas */
        table { width: 100%; border-collapse: collapse; font-size: 11px; }
        th, td { border: 1px solid #eee; padding: 6px 8px; text-align: left; }
        th { background-color: #f0f0f0; font-weight: bold; color: #333; }
        tr:nth-child(even) { background-color: #fcfcfc; }
        
        .status-badge { padding: 2px 5px; border-radius: 3px; font-size: 9px; font-weight: bold; text-transform: uppercase; color: white; }
        .status-ativo { background-color: #28a745; }
        .status-pendente { background-color: #ffc107; color: #333; }

        .no-print { position: fixed; top: 20px; right: 20px; z-index: 999; }
        .btn-print { padding: 10px 20px; background-color: #333; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 14px; font-weight: bold; box-shadow: 0 2px 5px rgba(0,0,0,0.3); display: flex; align-items: center; gap: 8px; }
        .btn-print:hover { background-color: #000; }

        @media print {
            body { background: white; margin: 0; padding: 0; }
            .page { margin: 0; border: none; box-shadow: none; width: 100%; max-width: none; padding: 0; }
            .no-print { display: none; }
            .kpi-card { break-inside: avoid; border: 1px solid #ccc !important; }
            h3 { break-after: avoid; }
            table { break-inside: auto; }
            tr { break-inside: avoid; break-after: auto; }
            thead { display: table-header-group; }
            tfoot { display: table-footer-group; }
        }
    </style>
</head>
<body>

    <div class="no-print">
        <button onclick="window.print()" class="btn-print"><i class="fa fa-print"></i> Imprimir / Salvar PDF</button>
    </div>

    <div class="page">
        <header class="header">
            <div class="header-left">
                <h1><?= htmlspecialchars($configGeral['nome_barbearia']) ?></h1>
                <h2>Relatório Gerencial Completo</h2>
            </div>
            <div class="header-right">
                <div class="periodo">
                    <?= htmlspecialchars($data_inicio_formatada) ?> a <?= htmlspecialchars($data_fim_formatada) ?>
                </div>
                <div style="font-size: 10px; color: #999; margin-top: 5px;">Gerado em: <?= date('d/m/Y H:i') ?></div>
            </div>
        </header>

        <h3><i class="fa fa-chart-line"></i> Resumo Financeiro</h3>
        <div class="grid-4">
            <div class="kpi-card kpi-green">
                <div class="kpi-title">Receita Bruta Total</div>
                <div class="kpi-value">R$ <?= number_format($receitaTotal, 2, ',', '.') ?></div>
                <div class="kpi-sub">Faturamento geral</div>
            </div>
            <div class="kpi-card kpi-blue">
                <div class="kpi-title">Serviços Avulsos</div>
                <div class="kpi-value">R$ <?= number_format($receitaServicos, 2, ',', '.') ?></div>
                <div class="kpi-sub">Cortes e atendimentos</div>
            </div>
            <div class="kpi-card kpi-purple">
                <div class="kpi-title">Receita de Planos</div>
                <div class="kpi-value">R$ <?= number_format($receitaPlanos, 2, ',', '.') ?></div>
                <div class="kpi-sub">Adesões de assinatura</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-title">Venda de Produtos</div>
                <div class="kpi-value">R$ <?= number_format($receitaProdutos, 2, ',', '.') ?></div>
                <div class="kpi-sub">Itens adicionais</div>
            </div>
        </div>

        <div class="grid-2">
            <div class="kpi-card">
                <div class="kpi-title" style="border-bottom: 1px solid #eee; padding-bottom: 5px; margin-bottom: 10px;">Descontos Concedidos</div>
                <table style="border:none;">
                    <tr>
                        <td style="border:none; padding: 2px;"><strong>Promocionais (Mkt):</strong></td>
                        <td style="border:none; padding: 2px; text-align:right; color: #dc3545;">- R$ <?= number_format($totalDescontos, 2, ',', '.') ?></td>
                    </tr>
                    <tr>
                        <td style="border:none; padding: 2px;"><strong>Benefício VIP (Isenção):</strong></td>
                        <td style="border:none; padding: 2px; text-align:right; color: #28a745;">(R$ <?= number_format($economiaVIP, 2, ',', '.') ?>)</td>
                    </tr>
                </table>
            </div>
            
            <div class="kpi-card">
                <div class="kpi-title" style="border-bottom: 1px solid #eee; padding-bottom: 5px; margin-bottom: 10px;">Detalhamento de Descontos</div>
                <?php if(empty($analiseDescontos)): ?>
                    <p style="font-size:10px; color:#999;">Nenhum desconto registrado.</p>
                <?php else: ?>
                    <table style="border:none;">
                        <?php foreach($analiseDescontos as $tipo => $dados): ?>
                        <tr>
                            <td style="border:none; padding: 2px;"><?= htmlspecialchars($dados['label']) ?> (<?= $dados['quantidade'] ?>)</td>
                            <td style="border:none; padding: 2px; text-align:right;">R$ <?= number_format($dados['total'], 2, ',', '.') ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <h3><i class="fa fa-crown"></i> Assinaturas & Clube (Recorrência)</h3>
        <div class="grid-3">
            <div class="kpi-card kpi-purple">
                <div class="kpi-title">Assinantes Ativos</div>
                <div class="kpi-value"><?= $totalAssinantesAtivos ?></div>
                <div class="kpi-sub">Total atual</div>
            </div>
            <div class="kpi-card kpi-purple">
                <div class="kpi-title">MRR (Recorrência Mensal)</div>
                <div class="kpi-value">R$ <?= number_format($mrrAtual, 2, ',', '.') ?></div>
                <div class="kpi-sub">Faturamento mensal projetado</div>
            </div>
            <div class="kpi-card kpi-blue">
                <div class="kpi-title">Novas Assinaturas</div>
                <div class="kpi-value">+<?= $novasAssinaturasPeriodo ?></div>
                <div class="kpi-sub">Neste período</div>
            </div>
        </div>

        <div class="grid-2">
            <div>
                <div class="kpi-title" style="margin-bottom: 5px;">Popularidade dos Planos</div>
                <table>
                    <thead><tr><th>Plano</th><th style="width: 50px; text-align: center;">Qtd.</th></tr></thead>
                    <tbody>
                        <?php if(empty($planosPopulares)): ?><tr><td colspan="2">Nenhum plano ativo.</td></tr><?php endif; ?>
                        <?php foreach($planosPopulares as $nome => $qtd): ?>
                        <tr><td><?= htmlspecialchars($nome) ?></td><td style="text-align: center;"><?= $qtd ?></td></tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div>
                <div class="kpi-title" style="margin-bottom: 5px; color: #dc3545;">Vencimentos Próximos (15 Dias)</div>
                <table>
                    <thead><tr><th>Cliente</th><th>Plano</th><th>Vence em</th></tr></thead>
                    <tbody>
                        <?php if(empty($assinaturasVencendo)): ?><tr><td colspan="3" style="text-align:center;">Nenhuma assinatura vencendo em breve.</td></tr><?php endif; ?>
                        <?php foreach($assinaturasVencendo as $sub): ?>
                        <tr>
                            <td><?= htmlspecialchars($sub['nome_cliente']) ?></td>
                            <td><?= htmlspecialchars($sub['nome_plano']) ?></td>
                            <td style="color: #dc3545; font-weight: bold;"><?= date('d/m', strtotime($sub['data_fim'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <h3><i class="fa fa-cut"></i> Operacional</h3>
        <div class="grid-3">
            <div class="kpi-card">
                <div class="kpi-title">Agendamentos Totais</div>
                <div class="kpi-value"><?= $contagemStatus['total'] ?></div>
                <div class="kpi-sub">
                    <span style="color:#28a745"><?= $contagemStatus['concluido'] ?> Concluídos</span> | 
                    <span style="color:#dc3545"><?= $contagemStatus['cancelado'] ?> Canc.</span>
                </div>
            </div>
            <div class="kpi-card">
                <div class="kpi-title">Taxa de Conversão</div>
                <div class="kpi-value">
                    <?= ($contagemStatus['total'] > 0) ? round(($contagemStatus['concluido'] / $contagemStatus['total']) * 100) : 0 ?>%
                </div>
                <div class="kpi-sub">Concluídos sobre Total</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-title">Ticket Médio</div>
                <div class="kpi-value">R$ <?= ($contagemStatus['concluido'] > 0) ? number_format($receitaTotal / $contagemStatus['concluido'], 2, ',', '.') : '0,00' ?></div>
                <div class="kpi-sub">Por atendimento</div>
            </div>
        </div>

        <div class="grid-2">
            <div>
                <div class="kpi-title" style="margin-bottom: 5px;">Ranking de Serviços</div>
                <table>
                    <thead><tr><th>Serviço</th><th style="text-align: center;">Qtd.</th></tr></thead>
                    <tbody>
                        <?php foreach($rankingServicosIds as $sid => $count): ?>
                        <tr>
                            <td><?= htmlspecialchars($servicosArr[$sid]['nome'] ?? 'Serviço Removido') ?></td>
                            <td style="text-align: center;"><?= $count ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div>
                <div class="kpi-title" style="margin-bottom: 5px;">Ocupação por Barbeiro</div>
                <table>
                    <thead><tr><th>Barbeiro</th><th style="text-align: center;">% Ocupação</th></tr></thead>
                    <tbody>
                        <?php foreach($taxasOcupacao as $nome => $taxa): ?>
                        <tr>
                            <td><?= htmlspecialchars($nome) ?></td>
                            <td style="text-align: center;">
                                <div style="display: flex; align-items: center; gap: 5px;">
                                    <div style="flex-grow: 1; background: #eee; height: 6px; border-radius: 3px; overflow: hidden; width: 50px;">
                                        <div style="height: 100%; background: #007bff; width: <?= $taxa ?>%;"></div>
                                    </div>
                                    <?= number_format($taxa, 1, ',', '.') ?>%
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <h3><i class="fa fa-users"></i> Clientes (CRM)</h3>
        <div class="grid-2">
            <div class="kpi-card">
                <div class="kpi-title">Top 5 Clientes (Faturamento)</div>
                <table>
                    <thead><tr><th>Cliente</th><th style="text-align: right;">Total Gasto</th></tr></thead>
                    <tbody>
                        <?php foreach($topClientes as $nome => $valor): ?>
                        <tr>
                            <td><?= htmlspecialchars($nome) ?></td>
                            <td style="text-align: right;">R$ <?= number_format($valor, 2, ',', '.') ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="kpi-card">
                <div class="kpi-title">Clientes em Risco (>90 dias sem visita)</div>
                <?php if(empty($clientesEmRisco)): ?>
                    <p style="font-size: 11px; padding: 5px;">Nenhum cliente em risco detectado.</p>
                <?php else: ?>
                    <table style="margin-top: 0;">
                        <thead><tr><th>Cliente</th><th>Última Visita</th></tr></thead>
                        <tbody>
                            <?php 
                            $countRisco = 0;
                            foreach($clientesEmRisco as $cli): 
                                if($countRisco >= 5) break; // Limita a 5 na impressão
                                $countRisco++;
                            ?>
                            <tr>
                                <td><?= htmlspecialchars($cli['nome']) ?></td>
                                <td><?= $cli['ultimo_agendamento'] ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php if(count($clientesEmRisco) > 5): ?>
                        <div style="text-align: center; font-size: 10px; color: #666; margin-top: 5px;">
                            + <?= count($clientesEmRisco) - 5 ?> outros clientes...
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        
        <div style="text-align: center; font-size: 10px; color: #aaa; margin-top: 30px; border-top: 1px solid #eee; padding-top: 10px;">
            Relatório gerado pelo Sistema de Barbearia - <?= htmlspecialchars($configGeral['nome_barbearia']) ?>
        </div>

    </div>
</body>
</html>