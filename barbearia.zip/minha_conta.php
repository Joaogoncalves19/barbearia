<?php
session_start();
date_default_timezone_set('America/Sao_Paulo');

// 1. Verificação de Login
if (!isset($_SESSION['cliente_logado'])) {
    header('Location: login_cliente.php');
    exit;
}

// 2. Carregar Funções
require_once 'functions.php';

$configGeral = carregarConfigGeral(); 
$cliente_id = $_SESSION['cliente_id'];
$mensagem = '';
$mensagem_tipo = 'sucesso';

// --- PROCESSAMENTO DE AÇÕES (POST/GET) ---

$action = $_POST['action'] ?? $_GET['action'] ?? null;

// Ação: Marcar notificações como lidas
if ($action === 'marcar_lidas') {
    marcarNotificacoesComoLidas($cliente_id); 
    exit;
}

// Ação: Cancelar Agendamento
if ($action === 'cancelar' && isset($_GET['id'])) {
    $agendamento_id = $_GET['id'];
    $keys_agendamentos = ['id', 'nome', 'email', 'telefone', 'barbeiro_id', 'servicos_ids', 'data', 'hora', 'status', 'desconto_aplicado', 'tipo_desconto', 'observacoes', 'produtos_vendidos', 'plano_provisorio'];
    $agendamentosArr = lerDados('agendamentos.txt', $keys_agendamentos);
    
    if (isset($agendamentosArr[$agendamento_id])) {
        // Verifica se o agendamento pertence mesmo ao cliente logado
        $telAgendamento = limparTelefone($agendamentosArr[$agendamento_id]['telefone']);
        $telSessao = limparTelefone($_SESSION['cliente_telefone']);
        
        if ($telAgendamento === $telSessao) {
            $agendamentosArr[$agendamento_id]['status'] = 'cancelado_pelo_cliente';
            salvarDados('agendamentos.txt', $agendamentosArr, $keys_agendamentos);
            
            criarNotificacao($cliente_id, "Você cancelou seu agendamento de ".date('d/m/Y', strtotime($agendamentosArr[$agendamento_id]['data']))." às ".$agendamentosArr[$agendamento_id]['hora'].".");
        }
    }
    header('Location: minha_conta.php?cancelado=1');
    exit;
}

// Ação: Salvar Perfil (COM CORREÇÃO DE HISTÓRICO)
if ($action === 'salvar_perfil') {
    $keys_clientes_completo = [
        'id', 'nome', 'email', 'telefone', 'password_hash', 
        'data_nascimento', 'foto_perfil', 'codigo_indicacao', 'cpf', 
        'indicado_por_id', 'status', 'confirmation_token'
    ];
    $clientesArr = lerDados('clientes.txt', $keys_clientes_completo);

    if(isset($clientesArr[$cliente_id])) {
        // 1. Captura dados ANTIGOS para buscar nos agendamentos (Correção do Histórico)
        $email_antigo = $clientesArr[$cliente_id]['email'];
        $telefone_antigo_limpo = limparTelefone($clientesArr[$cliente_id]['telefone']);

        // 2. Novos dados do formulário
        $novo_nome = trim(htmlspecialchars($_POST['nome']));
        $novo_email = trim(htmlspecialchars($_POST['email']));
        $novo_telefone = limparTelefone($_POST['telefone']);
        
        // Atualiza array de clientes
        $clientesArr[$cliente_id]['nome'] = $novo_nome;
        $clientesArr[$cliente_id]['email'] = $novo_email;
        $clientesArr[$cliente_id]['telefone'] = $novo_telefone;
        
        // Upload da foto
        if (isset($_FILES['foto_perfil']) && $_FILES['foto_perfil']['error'] == 0) {
            $ext = pathinfo($_FILES['foto_perfil']['name'], PATHINFO_EXTENSION);
            $foto_nome = 'uploads/perfil-' . $cliente_id . '-' . time() . '.' . $ext;
            move_uploaded_file($_FILES['foto_perfil']['tmp_name'], $foto_nome);
            $clientesArr[$cliente_id]['foto_perfil'] = $foto_nome;
        }

        salvarDadosCliente($clientesArr);
        
        // --- CORREÇÃO DE HISTÓRICO: Atualiza agendamentos antigos ---
        // Se o email ou telefone mudou, atualiza todos os agendamentos passados para não perder o vínculo
        if ($email_antigo !== $novo_email || $telefone_antigo_limpo !== $novo_telefone) {
            $keys_agendamentos = ['id', 'nome', 'email', 'telefone', 'barbeiro_id', 'servicos_ids', 'data', 'hora', 'status', 'desconto_aplicado', 'tipo_desconto', 'observacoes', 'produtos_vendidos', 'plano_provisorio'];
            $todosAgendamentos = lerDados('agendamentos.txt', $keys_agendamentos);
            $houveMudancaAgendamento = false;

            foreach ($todosAgendamentos as $agId => $ag) {
                $agEmail = $ag['email'] ?? '';
                $agTelLimpo = limparTelefone($ag['telefone'] ?? '');

                // Verifica se o agendamento pertence ao cliente usando os dados ANTIGOS
                if ($agEmail === $email_antigo || $agTelLimpo === $telefone_antigo_limpo) {
                    $todosAgendamentos[$agId]['nome'] = $novo_nome; // Atualiza nome também para manter consistência
                    $todosAgendamentos[$agId]['email'] = $novo_email;
                    $todosAgendamentos[$agId]['telefone'] = $novo_telefone;
                    $houveMudancaAgendamento = true;
                }
            }

            if ($houveMudancaAgendamento) {
                salvarDados('agendamentos.txt', $todosAgendamentos, $keys_agendamentos);
            }
        }
        // --- FIM DA CORREÇÃO ---
        
        // Atualiza sessão
        $_SESSION['cliente_nome'] = $clientesArr[$cliente_id]['nome'];
        $_SESSION['cliente_email'] = $clientesArr[$cliente_id]['email'];
        $_SESSION['cliente_telefone'] = $clientesArr[$cliente_id]['telefone'];
        
        $mensagem = "Perfil atualizado com sucesso!";
    }
}

// Ação: Alterar Senha
if ($action === 'alterar_senha') {
    $cliente = getClientById($cliente_id);
    if (!password_verify($_POST['senha_atual'], $cliente['password_hash'])) {
        $mensagem = "A senha atual está incorreta.";
        $mensagem_tipo = 'erro';
    } elseif ($_POST['nova_senha'] !== $_POST['confirma_nova_senha']) {
        $mensagem = "As novas senhas não coincidem.";
        $mensagem_tipo = 'erro';
    } elseif (strlen($_POST['nova_senha']) < 6) {
        $mensagem = "A nova senha deve ter pelo menos 6 caracteres.";
        $mensagem_tipo = 'erro';
    } else {
        $keys_clientes_completo = [
            'id', 'nome', 'email', 'telefone', 'password_hash', 
            'data_nascimento', 'foto_perfil', 'codigo_indicacao', 'cpf', 
            'indicado_por_id', 'status', 'confirmation_token'
        ];
        $clientesArr = lerDados('clientes.txt', $keys_clientes_completo);
        $clientesArr[$cliente_id]['password_hash'] = password_hash($_POST['nova_senha'], PASSWORD_DEFAULT);
        salvarDadosCliente($clientesArr);
        $mensagem = "Senha alterada com sucesso!";
    }
}

// Ação: Reagendar
if ($action === 'reagendar_agendamento') {
    $agendamento_id = $_POST['reagendar_agendamento_id'];
    $nova_data = $_POST['reagendar_data'];
    $novo_horario = $_POST['reagendar_horario'];
    $keys_agendamentos = ['id', 'nome', 'email', 'telefone', 'barbeiro_id', 'servicos_ids', 'data', 'hora', 'status', 'desconto_aplicado', 'tipo_desconto', 'observacoes', 'produtos_vendidos', 'plano_provisorio'];
    $agendamentosArr = lerDados('agendamentos.txt', $keys_agendamentos);
    
    $config = ['aprovar' => 'manual'];
    if (file_exists(DATA_DIR . 'config.txt')) {
        $config = parse_ini_file(DATA_DIR . 'config.txt');
    }
    $aprovarAutomatico = ($config['aprovar'] ?? 'manual') === 'automatico';

    if (isset($agendamentosArr[$agendamento_id])) {
        $agendamentosArr[$agendamento_id]['data'] = $nova_data;
        $agendamentosArr[$agendamento_id]['hora'] = $novo_horario;
        $agendamentosArr[$agendamento_id]['status'] = $aprovarAutomatico ? 'aprovado' : 'pendente';
        
        salvarDados('agendamentos.txt', $agendamentosArr, $keys_agendamentos);

        if ($aprovarAutomatico) {
            $mensagem = "Seu horário foi reagendado e aprovado com sucesso!";
            criarNotificacao($cliente_id, "Seu agendamento foi reagendado com sucesso para ".date('d/m/Y', strtotime($nova_data))." às ".$novo_horario.".");
        } else {
            $mensagem = "Seu horário foi reagendado com sucesso e aguarda aprovação!";
            criarNotificacao($cliente_id, "Seu pedido de reagendamento para ".date('d/m/Y', strtotime($nova_data))." às ".$novo_horario." foi recebido e aguarda aprovação.");
        }
    } else {
        $mensagem = "Ocorreu um erro ao reagendar.";
        $mensagem_tipo = 'erro';
    }
}

// --- CARREGAMENTO DE DADOS PARA EXIBIÇÃO ---

$barbeirosArr = lerDados('barbeiros.txt', ['id', 'nome', 'foto']);
$servicosArr = lerDados('servicos.txt', ['id', 'nome', 'valor']);
$combosArr = lerDados('combos.txt', ['id', 'nome', 'servicos_ids', 'valor']);
$planosArr = lerDados('planos.txt', ['id', 'nome', 'valor', 'servicos_ids']);
$agendamentosArr = lerDados('agendamentos.txt', ['id', 'nome', 'email', 'telefone', 'barbeiro_id', 'servicos_ids', 'data', 'hora', 'status', 'desconto_aplicado', 'produtos_vendidos', 'tipo_desconto']);
$avaliacoesArr = lerDados('avaliacoes.txt', ['id', 'agendamento_id', 'cliente_id', 'barbeiro_id', 'rating', 'comment', 'timestamp']);
$respostasAvaliacoesRaw = lerDados('respostas_avaliacoes.txt', ['id_resposta', 'id_avaliacao', 'texto_resposta', 'timestamp']);

$clienteAtual = getClientById($cliente_id);

// Mapeia respostas de avaliação
$respostasAvaliacoesArr = [];
foreach ($respostasAvaliacoesRaw as $resposta) {
    if (isset($resposta['id_avaliacao'])) $respostasAvaliacoesArr[$resposta['id_avaliacao']] = $resposta;
}

// Notificações
$notificacoes = lerNotificacoesCliente($cliente_id);
$notificacoes_nao_lidas = count(array_filter($notificacoes, function($n){ return $n['status'] === 'nao_lida'; }));

// Minhas Avaliações
$agendamentos_avaliados_ids = [];
$minhas_avaliacoes = [];
foreach ($avaliacoesArr as $av) {
    if ($av['cliente_id'] === $cliente_id) {
        $agendamentos_avaliados_ids[] = $av['agendamento_id'];
        $minhas_avaliacoes[] = $av;
    }
}

// Configurações Marketing
$config_fidelidade = getFidelityConfig();
$config_aniversario = getAniversarioConfig();
$config_indicacao = getIndicacaoConfig();

// Pontos Fidelidade
$pontos_fidelidade = getClientFidelityPoints($cliente_id);
$pontos_necessarios = $config_fidelidade['pontos_necessarios'] ?? 10;
$historico_pontos = getFidelityHistory($cliente_id);

// Assinatura VIP
$assinaturaAtiva = getAssinaturaCliente($cliente_id);

// --- PROCESSAMENTO DOS AGENDAMENTOS DO CLIENTE ---
$agendamentosAtivos = [];
$agendamentosHistorico = [];
$hojeTimestamp = time();

// Estatísticas
$totalVisitas = 0;
$gastoTotal = 0;
$economiaTotal = 0;

// Filtra agendamentos deste cliente
foreach ($agendamentosArr as $ag) {
    // Verifica se é do cliente (por telefone ou email)
    if (limparTelefone($ag['telefone']) === limparTelefone($_SESSION['cliente_telefone'])) {
        
        $dataHoraAg = strtotime($ag['data'] . ' ' . $ag['hora']);
        
        // 1. Separação Ativos vs Histórico
        if (($ag['status'] === 'aprovado' || $ag['status'] === 'pendente') && $dataHoraAg >= $hojeTimestamp) {
            $agendamentosAtivos[] = $ag;
        } else {
            $agendamentosHistorico[] = $ag;
        }
        
        // 2. Cálculo de Estatísticas (Apenas Concluídos)
        if ($ag['status'] === 'concluido') {
            $totalVisitas++;
            
            // Valor bruto (Serviços + Produtos)
            $valorBruto = 0;
            $sids = explode(',', $ag['servicos_ids']);
            foreach($sids as $sid) {
                $sid = trim($sid);
                if(isset($servicosArr[$sid])) {
                    $valorBruto += (float)$servicosArr[$sid]['valor'];
                } elseif(isset($combosArr[$sid])) {
                    $valorBruto += (float)$combosArr[$sid]['valor'];
                }
            }
            
            if(!empty($ag['produtos_vendidos'])) {
                $prods = json_decode($ag['produtos_vendidos'], true);
                if(is_array($prods)) {
                    foreach($prods as $p) $valorBruto += (float)($p['valor'] ?? 0);
                }
            }
            
            $desconto = (float)($ag['desconto_aplicado'] ?? 0);
            
            $gastoTotal += ($valorBruto - $desconto);
            if ($desconto > 0) {
                $economiaTotal += $desconto;
            }
        }
    }
}

// Ordenação
usort($agendamentosAtivos, function($a, $b) { 
    return strtotime($a['data'].' '.$a['hora']) - strtotime($b['data'].' '.$b['hora']); 
});
usort($agendamentosHistorico, function($a, $b) { 
    return strtotime($b['data'].' '.$b['hora']) - strtotime($a['data'].' '.$a['hora']); 
});

$proximoAgendamento = !empty($agendamentosAtivos) ? $agendamentosAtivos[0] : null;

// Dados detalhados para o "Próximo Agendamento"
$proximoAgendamentoDetalhes = ['barbeiro_foto' => 'uploads/default-profile.jpg', 'servicos_nomes' => [], 'barbeiro_media' => 'N/A'];

if ($proximoAgendamento) {
    $bid = $proximoAgendamento['barbeiro_id'];
    if (isset($barbeirosArr[$bid]) && !empty($barbeirosArr[$bid]['foto'])) {
        $proximoAgendamentoDetalhes['barbeiro_foto'] = $barbeirosArr[$bid]['foto'];
    }
    
    foreach(explode(',', $proximoAgendamento['servicos_ids']) as $sid) {
       $sid = trim($sid);
       if(isset($servicosArr[$sid])) $proximoAgendamentoDetalhes['servicos_nomes'][] = $servicosArr[$sid]['nome'];
       elseif(isset($combosArr[$sid])) $proximoAgendamentoDetalhes['servicos_nomes'][] = $combosArr[$sid]['nome']." (Combo)";
    }
    
    // Calcula média do barbeiro
    $avsBarbeiro = array_filter($avaliacoesArr, function($av) use ($bid) { return $av['barbeiro_id'] === $bid; });
    if (count($avsBarbeiro) > 0) {
       $proximoAgendamentoDetalhes['barbeiro_media'] = round(array_sum(array_column($avsBarbeiro, 'rating')) / count($avsBarbeiro), 1);
    }
}

// Verifica Aniversário
$e_aniversariante = false;
if (($config_aniversario['ativado'] ?? 0) && !empty($clienteAtual['data_nascimento'])) {
    if (date('m') == date('m', strtotime($clienteAtual['data_nascimento']))) {
        $e_aniversariante = true;
    }
}

$foto_perfil = (!empty($clienteAtual['foto_perfil']) && file_exists($clienteAtual['foto_perfil'])) ? $clienteAtual['foto_perfil'] : 'uploads/default-profile.jpg';

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minha Conta - <?= htmlspecialchars($configGeral['nome_barbearia']) ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/custom_theme.css.php">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Estilos Turbinados para a Minha Conta */
        .minha-conta-container { 
            max-width: 1000px; 
            margin: 10px auto 30px; /* Reduzido de 30px para 10px no topo */
            padding: 0 20px;
            animation: fadeIn 0.8s ease-in-out;
        }
        
        /* Header do Perfil */
        .profile-header {
            display: flex; align-items: center; gap: 20px; padding: 25px;
            background: var(--card-background); border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.05); margin-bottom: 25px;
            border: 1px solid var(--border-color);
            position: relative;
            overflow: hidden;
        }
        .profile-img-wrapper { position: relative; }
        .profile-img { width: 100px; height: 100px; border-radius: 50%; object-fit: cover; border: 4px solid var(--secondary-color); }
        .vip-badge-profile {
            position: absolute; bottom: 0; right: 0;
            background: #28a745; color: white; border-radius: 50%;
            width: 30px; height: 30px; display: flex; align-items: center;
            justify-content: center; border: 2px solid white; box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
        .profile-info h2 { margin: 0; text-align: left; color: var(--primary-color); font-size: 1.8rem; }
        .profile-info p { margin: 5px 0 0; color: #666; font-size: 0.95rem; }
        .profile-actions { margin-left: auto; display: flex; gap: 15px; align-items: center; }
        .notification-bell { font-size: 1.4rem; color: #666; position: relative; transition: color 0.2s; }
        .notification-bell:hover { color: var(--secondary-color); }
        
        /* Dashboard de Estatísticas */
        .stats-grid {
            display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-bottom: 25px;
        }
        .stat-card {
            background: var(--card-background); padding: 20px; border-radius: 12px;
            text-align: center; border: 1px solid var(--border-color);
            box-shadow: 0 2px 8px rgba(0,0,0,0.03); transition: transform 0.2s;
        }
        .stat-card:hover { transform: translateY(-3px); }
        .stat-value { font-size: 1.6rem; font-weight: 800; color: var(--primary-color); margin-bottom: 5px; }
        .stat-label { font-size: 0.85rem; color: #6c757d; text-transform: uppercase; letter-spacing: 0.5px; }
        .stat-icon { font-size: 1.2rem; margin-bottom: 8px; color: var(--secondary-color); opacity: 0.8; }

        /* Card Assinatura VIP */
        .vip-subscription-card {
            background: linear-gradient(135deg, #6f42c1, #8e44ad);
            color: white; padding: 25px; border-radius: 15px;
            margin-bottom: 30px; position: relative; overflow: hidden;
            box-shadow: 0 8px 20px rgba(111, 66, 193, 0.3);
        }
        .vip-subscription-card::before {
            content: '\f521'; font-family: 'Font Awesome 6 Free'; font-weight: 900;
            position: absolute; top: -20px; right: -20px; font-size: 10rem;
            opacity: 0.1; transform: rotate(15deg);
        }
        .vip-card-content { position: relative; z-index: 1; display: flex; justify-content: space-between; align-items: center; }
        .vip-title { font-size: 1.5rem; font-weight: bold; margin-bottom: 5px; }
        .vip-detail { opacity: 0.9; font-size: 0.95rem; margin-bottom: 2px; }
        .vip-days-left { text-align: right; }
        .days-number { font-size: 2.5rem; font-weight: 800; line-height: 1; }
        .days-label { font-size: 0.8rem; text-transform: uppercase; opacity: 0.8; }

        /* Próximo Agendamento Hero */
        .next-appointment-hero {
            background: linear-gradient(135deg, var(--secondary-color), #0056b3);
            color: white; border-radius: 15px; overflow: hidden; margin-bottom: 30px;
            box-shadow: 0 8px 25px rgba(0, 123, 255, 0.2);
        }
        .hero-header {
            padding: 15px 25px; background: rgba(0,0,0,0.15);
            display: flex; justify-content: space-between; align-items: center;
        }
        .countdown-timer { font-size: 1.2rem; font-weight: bold; font-family: monospace; color: #fff; }
        
        .hero-body { padding: 25px; display: flex; align-items: center; gap: 25px; }
        .barber-hero-img { width: 90px; height: 90px; border-radius: 50%; border: 4px solid white; object-fit: cover; }
        .hero-info { flex-grow: 1; }
        .hero-info h3 { margin: 0 0 5px; font-size: 1.6rem; color: white; text-align: left;}
        .hero-services { opacity: 0.9; font-size: 1rem; display: flex; align-items: center; gap: 8px; }
        .hero-rating { background: rgba(255, 193, 7, 0.2); padding: 3px 8px; border-radius: 4px; color: #ffc107; font-weight: bold; font-size: 0.9rem; margin-top: 8px; display: inline-block; }
        .hero-actions { text-align: right; }

        /* Lista de Agendamentos */
        .appt-card {
            background: white; border: 1px solid var(--border-color); border-radius: 10px;
            padding: 20px; margin-bottom: 15px; display: flex; align-items: center; justify-content: space-between;
            transition: all 0.2s;
        }
        .appt-card:hover { border-color: var(--secondary-color); transform: translateX(5px); box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .appt-date { text-align: center; padding-right: 20px; border-right: 1px solid #eee; min-width: 80px; }
        .appt-day { font-size: 1.8rem; font-weight: 800; color: var(--primary-color); display: block; line-height: 1; }
        .appt-month { font-size: 0.9rem; text-transform: uppercase; color: #666; font-weight: 600; }
        .appt-year { font-size: 0.75rem; color: #999; }
        .appt-details { padding-left: 20px; flex-grow: 1; }
        .appt-status { font-size: 0.7rem; text-transform: uppercase; font-weight: bold; padding: 3px 8px; border-radius: 4px; letter-spacing: 0.5px; }
        
        /* Status Colors */
        .status-concluido { background: #d4edda; color: #155724; }
        .status-cancelado, .status-cancelado_pelo_cliente { background: #f8d7da; color: #721c24; }
        .status-pendente { background: #fff3cd; color: #856404; }
        .status-aprovado { background: #cce5ff; color: #004085; }
        
        /* Abas Responsivas */
        .nav-tabs { display: flex; gap: 10px; overflow-x: auto; padding-bottom: 2px; margin-bottom: 25px; border-bottom: 2px solid var(--border-color); }
        .nav-tab {
            padding: 12px 25px; background: none; border: none; font-size: 1rem; font-weight: 600;
            color: #666; cursor: pointer; white-space: nowrap; border-bottom: 3px solid transparent;
            transition: all 0.3s; margin-bottom: -2px;
        }
        .nav-tab:hover { color: var(--secondary-color); }
        .nav-tab.active { color: var(--secondary-color); border-bottom-color: var(--secondary-color); }
        
        .tabcontent { display: none; animation: fadeEffect 0.5s; }
        .tabcontent.active { display: block; }
        @keyframes fadeEffect { from {opacity: 0;} to {opacity: 1;} }
        
        /* CSS ORGANIZADO PARA NOTIFICAÇÕES */
        .notificacoes-lista { list-style: none; padding: 0; margin: 0; }
        .notificacoes-lista li {
            padding: 15px; border-bottom: 1px solid #eee; display: flex; flex-direction: column; gap: 5px;
            border-radius: 6px; margin-bottom: 5px; transition: background 0.2s;
        }
        .notificacoes-lista li:hover { background: #f9f9f9; }
        .notificacoes-lista li:last-child { border-bottom: none; }
        
        .notificacoes-lista li.nao_lida {
            background-color: #e8f4fd; border-left: 4px solid var(--secondary-color);
        }
        .notificacoes-lista li.lida {
            background-color: #fff; opacity: 0.8;
        }
        
        .notificacoes-lista .msg { font-size: 0.95rem; color: #333; line-height: 1.4; }
        .notificacoes-lista .date { font-size: 0.75rem; color: #888; text-align: right; }
        
        /* ========================================= */
        /* NOVO CSS PARA A TIMELINE DE FIDELIDADE (Melhorado) */
        /* ========================================= */
        .timeline-modern {
            position: relative;
            padding: 20px 0;
            list-style: none;
        }
        .timeline-modern:before {
            content: '';
            position: absolute;
            top: 0;
            bottom: 0;
            left: 20px;
            width: 2px;
            background: #e0e0e0;
        }
        .timeline-item {
            position: relative;
            margin-bottom: 25px;
            display: flex;
            align-items: flex-start;
        }
        .timeline-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #fff;
            border: 2px solid #e0e0e0;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 2;
            color: #666;
            flex-shrink: 0;
            margin-right: 15px;
        }
        
        /* Cores baseadas no tipo de ação */
        .timeline-icon.positive { border-color: #28a745; color: #28a745; background-color: #e8f5e9; }
        .timeline-icon.negative { border-color: #dc3545; color: #dc3545; background-color: #f8d7da; }
        .timeline-icon.neutral { border-color: var(--secondary-color); color: var(--secondary-color); background-color: #eef2ff; }

        .timeline-content {
            background: var(--card-background);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 12px 15px;
            width: 100%;
            position: relative;
            box-shadow: 0 2px 5px rgba(0,0,0,0.02);
        }
        .timeline-content:before {
            /* Seta apontando para o ícone */
            content: '';
            position: absolute;
            top: 15px;
            left: -6px;
            width: 10px;
            height: 10px;
            background: var(--card-background);
            border-left: 1px solid var(--border-color);
            border-bottom: 1px solid var(--border-color);
            transform: rotate(45deg);
        }
        
        .timeline-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 5px;
        }
        .timeline-date {
            font-size: 0.75rem;
            color: #999;
            font-weight: 600;
            text-transform: uppercase;
        }
        .timeline-desc {
            font-weight: bold;
            color: #333;
            margin: 0;
            font-size: 0.95rem;
        }
        .timeline-points {
            font-weight: 800;
            font-size: 1rem;
        }
        .timeline-points.positive { color: #28a745; }
        .timeline-points.negative { color: #dc3545; }

        /* Responsividade */
        @media (max-width: 768px) {
            .profile-header { flex-direction: column; text-align: center; gap: 15px; }
            .profile-actions { margin: 0; width: 100%; justify-content: center; }
            .hero-body { flex-direction: column; text-align: center; }
            .hero-info h3 { text-align: center; }
            .hero-services { justify-content: center; }
            .hero-actions { width: 100%; margin-top: 15px; display: flex; gap: 10px; justify-content: center; }
            .appt-card { flex-direction: column; align-items: flex-start; gap: 15px; }
            .appt-date { display: flex; gap: 10px; border: none; align-items: baseline; padding: 0; width: 100%; border-bottom: 1px solid #eee; padding-bottom: 10px; }
            .appt-details { padding: 0; width: 100%; }
            .appt-actions { width: 100%; display: flex; gap: 10px; margin-top: 10px; }
            .appt-actions .btn { flex: 1; justify-content: center; }
        }
    </style>
</head>
<body class="admin-page">
<?php
    // Inserção do novo cabeçalho fixo
    $pageTitle = 'Minha Conta';
    $backLink = 'index.php';
    require_once 'header_app.php';
?>

<div class="minha-conta-container">
    
    <div class="profile-header">
        <div class="profile-img-wrapper">
            <img src="<?= htmlspecialchars($foto_perfil) ?>" alt="Foto Perfil" class="profile-img">
            <?php if($assinaturaAtiva && $assinaturaAtiva['status'] === 'ativo'): ?>
                <div class="vip-badge-profile" title="Membro VIP"><i class="fa fa-crown"></i></div>
            <?php endif; ?>
        </div>
        <div class="profile-info">
            <h2>Olá, <?= htmlspecialchars($clienteAtual['nome']) ?>!</h2>
            <p><i class="fa fa-envelope"></i> <?= htmlspecialchars($clienteAtual['email']) ?> &bull; <i class="fa fa-phone"></i> <?= htmlspecialchars($clienteAtual['telefone']) ?></p>
        </div>
        <div class="profile-actions">
             <a href="#" class="notification-bell" data-modal-target="#modal-notificacoes">
                <i class="fa fa-bell"></i>
                <?php if($notificacoes_nao_lidas > 0): ?>
                <span class="notification-count" style="position:absolute; top:-8px; right:-8px; background:var(--error-color); color:white; font-size:0.7rem; padding:2px 6px; border-radius:50%; border:2px solid white;"><?= $notificacoes_nao_lidas ?></span>
                <?php endif; ?>
            </a>
            <a href="agendamento.php" class="btn" style="background-color: var(--secondary-color);"><i class="fa fa-plus"></i> Agendar</a>
            <a href="logout_cliente.php" class="btn" style="background-color: #dc3545; padding: 8px 12px;"><i class="fa fa-sign-out-alt"></i></a>
        </div>
    </div>

    <?php if ($mensagem): ?>
        <p class="mensagem <?= $mensagem_tipo === 'erro' ? 'erro' : '' ?>" style="<?= $mensagem_tipo === 'erro' ? 'background-color: #f8d7da; border-color: #f5c6cb; color: #721c24;' : 'background-color: #d4edda; border-color: #c3e6cb; color: #155724;' ?>"><?= htmlspecialchars($mensagem) ?></p>
    <?php endif; ?>

    <?php if ($e_aniversariante): ?>
        <div class="aniversario-banner" style="background:#fff3cd; border:1px solid #ffeeba; color:#856404; padding:15px; border-radius:10px; text-align:center; margin-bottom:25px;">
            <i class="fa fa-birthday-cake" style="font-size:1.5rem; margin-right:10px; vertical-align:middle;"></i> 
            Parabéns! No mês do seu aniversário, você ganha <strong><?= $config_aniversario['desconto_percentual'] ?>% de desconto</strong> no seu <strong>primeiro agendamento</strong> do mês!
        </div>
    <?php endif; ?>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon"><i class="fa fa-calendar-check"></i></div>
            <div class="stat-value"><?= $totalVisitas ?></div>
            <div class="stat-label">Visitas</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon"><i class="fa fa-wallet"></i></div>
            <div class="stat-value">R$ <?= number_format($gastoTotal, 2, ',', '.') ?></div>
            <div class="stat-label">Total Investido</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon"><i class="fa fa-piggy-bank"></i></div>
            <div class="stat-value" style="color: #28a745;">R$ <?= number_format($economiaTotal, 2, ',', '.') ?></div>
            <div class="stat-label">Economizado</div>
        </div>
        <?php if(($config_fidelidade['ativado'] ?? 0)): ?>
        <div class="stat-card">
            <div class="stat-icon"><i class="fa fa-star"></i></div>
            <div class="stat-value" style="color: #ffc107;"><?= $pontos_fidelidade ?></div>
            <div class="stat-label">Pontos Fidelidade</div>
        </div>
        <?php endif; ?>
    </div>

    <?php if($assinaturaAtiva && $assinaturaAtiva['status'] === 'ativo'): 
        $planoVip = $planosArr[$assinaturaAtiva['plano_id']] ?? null;
        $diasVip = ceil((strtotime($assinaturaAtiva['data_fim']) - time()) / 86400);
    ?>
        <div class="vip-subscription-card">
            <div class="vip-card-content">
                <div>
                    <div class="vip-title"><i class="fa fa-crown"></i> Assinatura VIP Ativa</div>
                    <div class="vip-detail">Plano: <strong><?= htmlspecialchars($planoVip['nome'] ?? 'VIP Personalizado') ?></strong></div>
                    <div class="vip-detail">Válido até: <?= date('d/m/Y', strtotime($assinaturaAtiva['data_fim'])) ?></div>
                </div>
                <div class="vip-days-left">
                    <div class="days-number"><?= $diasVip ?></div>
                    <div class="days-label">Dias Restantes</div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($proximoAgendamento): ?>
    <div class="next-appointment-hero">
        <div class="hero-header">
            <span style="font-weight:bold; font-size: 1.1rem;"><i class="fa fa-calendar-check"></i> Próximo Agendamento</span>
            <div style="display: flex; align-items: center; gap: 8px; background: rgba(255,255,255,0.1); padding: 5px 10px; border-radius: 20px;">
                <span style="font-size: 0.8rem; font-weight: normal; opacity: 0.9;">Começa em:</span>
                <div class="countdown-timer" id="countdown" data-datetime="<?= htmlspecialchars($proximoAgendamento['data'] . ' ' . $proximoAgendamento['hora']) ?>">--h --m</div>
            </div>
        </div>
        <div class="hero-body">
            <img src="<?= htmlspecialchars($proximoAgendamentoDetalhes['barbeiro_foto']) ?>" alt="Barbeiro" class="barber-hero-img">
            <div class="hero-info">
                <h3><?= htmlspecialchars($barbeirosArr[$proximoAgendamento['barbeiro_id']]['nome'] ?? 'Barbeiro Indisponível') ?></h3>
                <div class="hero-services">
                    <i class="fa fa-cut"></i> <?= htmlspecialchars(implode(', ', $proximoAgendamentoDetalhes['servicos_nomes'])) ?>
                </div>
                <?php if($proximoAgendamentoDetalhes['barbeiro_media'] !== 'N/A'): ?>
                    <div class="hero-rating"><i class="fa fa-star"></i> <?= $proximoAgendamentoDetalhes['barbeiro_media'] ?> de média</div>
                <?php endif; ?>
            </div>
            <div class="hero-actions">
                <button class="btn btn-detalhes" style="background: rgba(255,255,255,0.2); border: 1px solid white; color: white;" data-modal-target="#modal-detalhes-agendamento" data-agendamento-id="<?= $proximoAgendamento['id'] ?>">Ver Detalhes</button>
                <button class="btn btn-reagendar" style="background: white; color: var(--secondary-color);" data-modal-target="#modal-reagendamento" data-agendamento-id="<?= $proximoAgendamento['id'] ?>" data-barbeiro-id="<?= $proximoAgendamento['barbeiro_id'] ?>" data-servicos-ids="<?= $proximoAgendamento['servicos_ids'] ?>">Reagendar</button>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="nav-tabs">
        <button class="nav-tab active" data-tab="historico">Histórico</button>
        <?php if($config_fidelidade['ativado']): ?><button class="nav-tab" data-tab="fidelidade">Fidelidade</button><?php endif; ?>
        <button class="nav-tab" data-tab="dados">Meus Dados</button>
        <button class="nav-tab" data-tab="avaliacoes">Avaliações</button>
        <?php if($config_indicacao['ativado']): ?><button class="nav-tab" data-tab="indicacao">Indicar Amigo</button><?php endif; ?>
    </div>

    <div id="historico" class="tabcontent active">
        <?php if (empty($agendamentosHistorico)): ?>
            <p style="text-align:center; padding: 30px; background: #f9f9f9; border-radius: 10px; color: #777;">Nenhum histórico de agendamento encontrado.</p>
        <?php else: ?>
            <?php foreach($agendamentosHistorico as $ag): 
                $statusClass = 'status-'.($ag['status'] === 'cancelado_pelo_cliente' ? 'cancelado' : $ag['status']);
                
                // Nomes dos serviços
                $servicosNomes = [];
                foreach(explode(',', $ag['servicos_ids']) as $sid) {
                    $sid = trim($sid);
                    if(isset($servicosArr[$sid])) $servicosNomes[] = $servicosArr[$sid]['nome'];
                    elseif(isset($combosArr[$sid])) $servicosNomes[] = $combosArr[$sid]['nome']." (Combo)";
                }

                // Cálculo Financeiro para Exibição
                $valorTotalAg = 0;
                foreach(explode(',', $ag['servicos_ids']) as $sid) {
                    $sid = trim($sid);
                    if(isset($servicosArr[$sid])) $valorTotalAg += (float)$servicosArr[$sid]['valor'];
                    elseif(isset($combosArr[$sid])) $valorTotalAg += (float)$combosArr[$sid]['valor'];
                }
                if(!empty($ag['produtos_vendidos'])) {
                    $prods = json_decode($ag['produtos_vendidos'], true);
                    if(is_array($prods)) foreach($prods as $p) $valorTotalAg += (float)$p['valor'];
                }
                $desconto = (float)($ag['desconto_aplicado'] ?? 0);
                $valorFinal = $valorTotalAg - $desconto;
            ?>
            <div class="appt-card">
                <div class="appt-date">
                    <span class="appt-day"><?= date('d', strtotime($ag['data'])) ?></span>
                    <span class="appt-month"><?= substr(strftime('%b', strtotime($ag['data'])), 0, 3) ?></span>
                    <div class="appt-year"><?= date('Y', strtotime($ag['data'])) ?></div>
                </div>
                <div class="appt-details">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:5px; flex-wrap: wrap; gap: 5px;">
                        <strong style="font-size:1.1rem; color:var(--primary-color);"><?= implode(', ', $servicosNomes) ?></strong>
                        <span class="appt-status <?= $statusClass ?>"><?= ucfirst(str_replace(['_', 'cancelado_pelo_cliente'], [' ', 'Cancelado'], $ag['status'])) ?></span>
                    </div>
                    <div style="font-size: 0.9rem; color: #666;">
                        <i class="fa fa-clock"></i> <?= $ag['hora'] ?> com <strong><?= $barbeirosArr[$ag['barbeiro_id']]['nome'] ?? 'Barbeiro' ?></strong>
                    </div>
                    <div style="margin-top: 5px; font-size: 0.9rem;">
                        <span style="font-weight:bold; color:#333;">R$ <?= number_format($valorFinal, 2, ',', '.') ?></span>
                        <?php if($desconto > 0): ?>
                            <span style="color:#28a745; font-size: 0.8rem; margin-left: 10px; font-weight: bold;">(Economia: R$ <?= number_format($desconto, 2, ',', '.') ?>)</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="appt-actions">
                    <button class="btn btn-detalhes" data-modal-target="#modal-detalhes-agendamento" data-agendamento-id="<?= $ag['id'] ?>"><i class="fa fa-eye"></i></button>
                    <?php if($ag['status'] === 'concluido' && !in_array($ag['id'], $agendamentos_avaliados_ids)): ?>
                        <button class="btn btn-avaliar" data-modal-target="#modal-avaliacao" data-agendamento-id="<?= $ag['id'] ?>" data-barbeiro-id="<?= $ag['barbeiro_id'] ?>"><i class="fa fa-star"></i> Avaliar</button>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    
    <?php if($config_fidelidade['ativado']): ?>
    <div id="fidelidade" class="tabcontent">
        
        <?php if($assinaturaAtiva && $assinaturaAtiva['status'] === 'ativo'): ?>
        <div style="background: #fff3cd; color: #856404; padding: 15px; border-radius: 8px; border: 1px solid #ffeeba; margin-bottom: 20px;">
            <strong><i class="fa fa-exclamation-triangle"></i> Aviso Importante:</strong>
            <p style="margin: 5px 0 0;">Como você possui uma assinatura VIP ativa, seus agendamentos não geram novos pontos de fidelidade.</p>
        </div>
        <?php endif; ?>

        <div style="display: flex; gap: 20px; flex-wrap: wrap; margin-bottom: 30px;">
            <div style="flex: 1; background: var(--card-background); padding: 20px; border-radius: 10px; border: 1px solid var(--border-color); text-align: center;">
                 <h4 style="margin: 0 0 10px; color: #666;">Seus Pontos Atuais</h4>
                 <div style="font-size: 3rem; font-weight: bold; color: var(--secondary-color);"><?= $pontos_fidelidade ?></div>
            </div>
            <div style="flex: 1; background: var(--card-background); padding: 20px; border-radius: 10px; border: 1px solid var(--border-color);">
                <h4 style="margin: 0 0 10px;">Como funciona?</h4>
                <ul style="list-style: none; padding: 0; margin: 0; color: #555;">
                    <li style="margin-bottom: 8px;"><i class="fa fa-check" style="color: green;"></i> Ganhe <strong>1 ponto</strong> a cada visita concluída.</li>
                    <li style="margin-bottom: 8px;"><i class="fa fa-gift" style="color: var(--secondary-color);"></i> Junte <strong><?= $pontos_necessarios ?> pontos</strong>.</li>
                    <li><i class="fa fa-tag" style="color: var(--primary-color);"></i> Ganhe <strong><?= $config_fidelidade['desconto_percentual'] ?>% de desconto</strong> no próximo agendamento!</li>
                </ul>
            </div>
        </div>

        <h3 style="border-bottom: 1px solid #eee; padding-bottom: 10px; margin-bottom: 15px;">Extrato de Pontos</h3>
        <?php if(empty($historico_pontos)): ?>
            <p style="text-align: center; color: #777; padding: 20px;">Nenhum histórico de pontos encontrado.</p>
        <?php else: ?>
            
            <ul class="timeline-modern">
                <?php foreach(array_reverse($historico_pontos) as $h): 
                    $pontos = (int)$h['pontos'];
                    $sinal = ($pontos > 0) ? '+' : '';
                    $classeCor = ($pontos > 0) ? 'positive' : 'negative';
                    
                    // Determina ícone baseado na descrição
                    $icone = 'fa-info-circle';
                    $classeIcone = 'neutral';
                    $desc = strtolower($h['descricao']);
                    
                    if (strpos($desc, 'agendamento') !== false) { 
                        $icone = 'fa-cut'; $classeIcone = 'positive';
                    } elseif (strpos($desc, 'resgate') !== false) {
                        $icone = 'fa-ticket-alt'; $classeIcone = 'negative';
                    } elseif (strpos($desc, 'indicou') !== false || strpos($desc, 'indicação') !== false) {
                        $icone = 'fa-user-friends'; $classeIcone = 'positive';
                    } elseif (strpos($desc, 'admin') !== false || strpos($desc, 'ajuste') !== false) {
                        $icone = 'fa-user-cog'; $classeIcone = ($pontos > 0) ? 'positive' : 'negative';
                    }
                ?>
                <li class="timeline-item">
                    <div class="timeline-icon <?= $classeIcone ?>">
                        <i class="fa <?= $icone ?>"></i>
                    </div>
                    <div class="timeline-content">
                        <div class="timeline-header">
                            <span class="timeline-date"><?= date('d/m/Y H:i', strtotime($h['timestamp'])) ?></span>
                            <span class="timeline-points <?= $classeCor ?>"><?= $sinal . $pontos ?> pts</span>
                        </div>
                        <p class="timeline-desc"><?= htmlspecialchars($h['descricao']) ?></p>
                    </div>
                </li>
                <?php endforeach; ?>
            </ul>
            
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <div id="dados" class="tabcontent">
        <div class="perfil-card" style="text-align: center;">
            
            <div style="background-color: #fff3cd; border: 1px solid #ffeeba; color: #856404; padding: 15px; border-radius: 8px; margin-bottom: 20px; text-align: left; font-size: 0.9em;">
                <i class="fa fa-info-circle"></i> <strong>Informação Importante:</strong><br>
                Alguns dados como <strong>CPF</strong> e <strong>Data de Nascimento</strong> não podem ser editados por aqui para garantir a segurança da sua conta e a integridade do histórico. Caso precise alterá-los, por favor, entre em contato diretamente com a barbearia.
            </div>

            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" value="salvar_perfil">
                <div style="margin-bottom: 20px;">
                    <label for="upload-foto" style="cursor: pointer; display: inline-block;">
                        <img src="<?= htmlspecialchars($foto_perfil) ?>" alt="Foto" style="width: 120px; height: 120px; border-radius: 50%; object-fit: cover; border: 3px solid #ddd; transition: border-color 0.3s;">
                        <div style="font-size: 0.8rem; color: var(--secondary-color); margin-top: 5px;"><i class="fa fa-camera"></i> Alterar Foto</div>
                    </label>
                    <input type="file" name="foto_perfil" id="upload-foto" style="display: none;" accept="image/*">
                </div>
                
                <div class="form-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 15px; text-align: left;">
                    <div class="form-group"><label>Nome</label><input type="text" name="nome" value="<?= htmlspecialchars($clienteAtual['nome']) ?>" required></div>
                    <div class="form-group"><label>E-mail</label><input type="email" name="email" value="<?= htmlspecialchars($clienteAtual['email']) ?>" required></div>
                    <div class="form-group"><label>Telefone</label><input type="tel" name="telefone" value="<?= htmlspecialchars($clienteAtual['telefone']) ?>" required></div>
                    
                    <div class="form-group">
                        <label>Data de Nascimento</label>
                        <input type="text" value="<?= !empty($clienteAtual['data_nascimento']) ? date('d/m/Y', strtotime($clienteAtual['data_nascimento'])) : 'Não informada' ?>" disabled style="background: #e9ecef; cursor: not-allowed;">
                    </div>

                    <div class="form-group"><label>CPF (Não editável)</label><input type="text" value="<?= htmlspecialchars($clienteAtual['cpf'] ?? '') ?>" disabled style="background: #e9ecef; cursor: not-allowed;"></div>
                </div>
                
                <button type="submit" class="btn-primary" style="width: auto; padding: 10px 30px; margin-top: 15px;">Salvar Alterações</button>
            </form>
            
            <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee;">
                <h4 style="margin-bottom: 15px;">Segurança</h4>
                <button class="btn btn-rejeitar" data-modal-target="#modal-alterar-senha" style="width: auto;"><i class="fa fa-lock"></i> Alterar Senha</button>
            </div>
        </div>
    </div>

    <div id="avaliacoes" class="tabcontent">
        <?php if(empty($minhas_avaliacoes)): ?><p style="text-align:center; padding: 20px; color: #777;">Você ainda não fez nenhuma avaliação.</p><?php else: ?>
            <?php foreach(array_reverse($minhas_avaliacoes) as $av): ?>
            <div class="avaliacao-card">
                <div style="display:flex; justify-content: space-between; align-items: center;">
                    <strong style="font-size: 1.1rem;"><?= htmlspecialchars($barbeirosArr[$av['barbeiro_id']]['nome'] ?? 'N/A') ?></strong>
                    <span class="estrelas"><?= str_repeat('★', $av['rating']) . str_repeat('☆', 5 - $av['rating']) ?></span>
                </div>
                <?php if(!empty($av['comment'])): ?><p class="comentario">"<?= htmlspecialchars($av['comment']) ?>"</p><?php endif; ?>
                
                <?php if(isset($respostasAvaliacoesArr[$av['id']])): 
                    $resposta = $respostasAvaliacoesArr[$av['id']]; ?>
                <div class="avaliacao-resposta-admin">
                    <strong><i class="fa fa-reply"></i> Resposta da Barbearia:</strong>
                    <p>"<?= htmlspecialchars($resposta['texto_resposta']) ?>"</p>
                    <small style="color:#888; font-size:0.8rem;">Respondido em <?= date('d/m/Y', strtotime($resposta['timestamp'])) ?></small>
                </div>
                <?php endif; ?>
                <p class="data-avaliacao"><small><?= date('d/m/Y', strtotime($av['timestamp'])) ?></small></p>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <?php if($config_indicacao['ativado']): ?>
    <div id="indicacao" class="tabcontent">
        <div class="indicacao-card" style="text-align: center; padding: 40px; background: #fffbe6; border: 1px dashed #ffc107;">
            <i class="fa fa-gift" style="font-size: 3rem; color: #ffc107; margin-bottom: 15px;"></i>
            <h3>Indique e Ganhe!</h3>
            <p>Compartilhe seu código exclusivo. Seu amigo ganha <strong><?= $config_indicacao['desconto_novo_cliente'] ?>% de desconto</strong> na primeira visita.</p>
            
            <p style="font-size: 0.9em; margin-top: 10px; color: var(--secondary-color);">
                <strong><i class="fa fa-info-circle"></i> Como funciona:</strong> Você ganha <strong><?= $config_indicacao['pontos_indicacao'] ?> pontos</strong> de fidelidade automaticamente assim que seu amigo <strong>concluir o primeiro agendamento</strong> conosco!
            </p>
            
            <div class="codigo-indicacao" id="btn-copiar-codigo" data-codigo="<?= htmlspecialchars($clienteAtual['codigo_indicacao']) ?>" style="margin: 20px auto; display: inline-flex;">
                <span id="texto-codigo"><?= htmlspecialchars($clienteAtual['codigo_indicacao']) ?></span>
                <i class="fa fa-copy"></i>
            </div>
            <p style="font-size: 0.9rem; color: #666;">Clique no código para copiar.</p>
        </div>
    </div>
    <?php endif; ?>

</div>

<div id="modal-notificacoes" class="modal-overlay">
    <div class="modal-content" style="max-width: 500px; width: 90%;">
        <button class="modal-close">&times;</button>
        <h3><i class="fa fa-bell"></i> Notificações</h3>
        <div style="max-height: 400px; overflow-y: auto;">
            <ul class="notificacoes-lista">
            <?php if(empty($notificacoes)): ?>
                <li style="text-align: center; display: block; color: #777;">Nenhuma notificação recente.</li>
            <?php else: ?>
                <?php foreach($notificacoes as $n): ?>
                <li class="<?= $n['status'] ?>">
                    <span class="msg"><?= htmlspecialchars($n['mensagem']) ?></span>
                    <span class="date"><?= htmlspecialchars(date('d/m/Y H:i', strtotime($n['timestamp']))) ?></span>
                </li>
                <?php endforeach; ?>
            <?php endif; ?>
            </ul>
        </div>
    </div>
</div>

<div id="modal-detalhes-agendamento" class="modal-overlay"><div class="modal-content" id="detalhes-content"></div></div>
<div id="modal-reagendamento" class="modal-overlay"><div class="modal-content"><button class="modal-close">&times;</button><h3>Reagendar Horário</h3><form id="form-reagendamento" method="POST"><input type="hidden" name="action" value="reagendar_agendamento"><input type="hidden" name="reagendar_agendamento_id" id="reagendar_agendamento_id"><input type="hidden" id="reagendar_barbeiro_id"><input type="hidden" id="reagendar_servicos_ids"><div class="form-group"><label>Nova Data</label><input type="date" name="reagendar_data" id="reagendar_data" min="<?= date('Y-m-d') ?>" required></div><div class="form-group"><label>Novo Horário</label><div class="horario-grid" id="reagendar_horarios-container"></div><input type="hidden" name="reagendar_horario" id="reagendar_horario" required><div class="erro" id="reagendar_erro_horario"></div></div><button type="submit" class="btn-primary">Salvar Novo Horário</button></form></div></div>
<div id="modal-avaliacao" class="modal-overlay"><div class="modal-content"><button class="modal-close">&times;</button><h3>Avaliar</h3><form id="form-avaliacao" method="post" action="salvar_avaliacao.php"><input type="hidden" name="agendamento_id" id="avaliacao_agendamento_id"><input type="hidden" name="barbeiro_id" id="avaliacao_barbeiro_id"><div class="form-group"><div class="rating-stars"><input type="radio" name="rating" id="star5" value="5"><label for="star5" class="fa fa-star"></label><input type="radio" name="rating" id="star4" value="4"><label for="star4" class="fa fa-star"></label><input type="radio" name="rating" id="star3" value="3"><label for="star3" class="fa fa-star"></label><input type="radio" name="rating" id="star2" value="2"><label for="star2" class="fa fa-star"></label><input type="radio" name="rating" id="star1" value="1"><label for="star1" class="fa fa-star"></label></div></div><div class="form-group"><label>Comentário</label><textarea name="comment" rows="3"></textarea></div><button type="submit" class="btn-primary">Enviar</button></form></div></div>
<div id="modal-alterar-senha" class="modal-overlay"><div class="modal-content"><button class="modal-close">&times;</button><h3>Alterar Senha</h3><form method="POST"><input type="hidden" name="action" value="alterar_senha"><div class="form-group"><label>Senha Atual</label><input type="password" name="senha_atual" required></div><div class="form-group"><label>Nova Senha</label><input type="password" name="nova_senha" required></div><div class="form-group"><label>Confirmar</label><input type="password" name="confirma_nova_senha" required></div><button type="submit" class="btn-primary">Salvar</button></form></div></div>

<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://npmcdn.com/flatpickr/dist/l10n/pt.js"></script>
<script>
    const agendamentosDataById = <?= json_encode(array_reduce(array_merge($agendamentosAtivos, $agendamentosHistorico), function($acc, $ag){ $acc[$ag['id']] = $ag; return $acc; }, [])) ?> || {};
    const barbeirosData = <?= json_encode($barbeirosArr) ?> || {};
    const servicosData = <?= json_encode($servicosArr) ?> || {};
    const combosData = <?= json_encode($combosArr) ?> || {};
    // Removida a constante favoritosData que não é mais usada
    const favoritosData = []; 
</script>
<script src="js/minha_conta.js"></script>

</body>
</html>