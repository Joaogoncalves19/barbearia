<?php
// index.php
// Carrega as funções e as configurações gerais da barbearia
require_once 'functions.php';
$configGeral = carregarConfigGeral();
$landingConfig = carregarLandingPageConfig(); // Carrega as novas configurações da Landing Page

// Carrega dados dinâmicos para a página
$barbeirosArr = lerDados('barbeiros.txt', ['id', 'nome', 'foto', 'username', 'password', 'status']);
$servicosArr = lerDados('servicos.txt', ['id', 'nome', 'valor']);
$avaliacoesArr = lerDados('avaliacoes.txt', ['id', 'agendamento_id', 'cliente_id', 'barbeiro_id', 'rating', 'comment', 'timestamp']);
$clientesArr = lerDados('clientes.txt', ['id', 'nome', 'email', 'telefone', 'password_hash', 'data_nascimento', 'foto_perfil']);

// --- NOVO: Carrega os Planos para a seção VIP ---
$planosArr = lerDados('planos.txt', ['id', 'nome', 'valor', 'servicos_ids']);

// --- Leitura Segura de Horários de Trabalho ---
$horariosTrabalhoRaw = [];
$horariosFilePath = DATA_DIR . 'horarios_trabalho.txt';
if (file_exists($horariosFilePath)) {
    $fp = fopen($horariosFilePath, 'r');
    if ($fp && flock($fp, LOCK_SH)) {
        while (($linha = fgets($fp)) !== false) {
            $linhaLimpa = trim($linha);
            if (!empty($linhaLimpa)) {
                $horariosTrabalhoRaw[] = $linhaLimpa;
            }
        }
        flock($fp, LOCK_UN);
        fclose($fp);
    }
}
// --- FIM DA LEITURA SEGURA ---

// Filtra para criar um array APENAS com barbeiros ativos
$barbeirosAtivosArr = array_filter($barbeirosArr, function($barbeiro) {
    $status = $barbeiro['status'] ?? 'ativo';
    if(empty($status)) $status = 'ativo';
    return $status === 'ativo';
});

// --- Lógica de Avaliações (Destacadas ou Fallback) ---
$avaliacoesDestacadasIDs = lerDados('avaliacoes_destacadas.txt', ['id_avaliacao']);
$avaliacoesParaExibir = [];
if (!empty($avaliacoesDestacadasIDs)) {
    foreach ($avaliacoesDestacadasIDs as $id_destacado => $data) {
        if (isset($avaliacoesArr[$id_destacado])) {
            $avaliacoesParaExibir[$id_destacado] = $avaliacoesArr[$id_destacado];
        }
    }
    shuffle($avaliacoesParaExibir);
} else {
    $avaliacoesBoas = array_filter($avaliacoesArr, fn($av) => (int)($av['rating'] ?? 0) >= 4);
    shuffle($avaliacoesBoas);
    $avaliacoesParaExibir = array_slice($avaliacoesBoas, 0, 2);
}
// --- FIM AVALIAÇÕES ---

// Calcula a média de avaliações para cada barbeiro
$mediaAvaliacoesBarbeiros = [];
foreach ($barbeirosAtivosArr as $barbeiroId => $barbeiro) {
    $avaliacoesDoBarbeiro = array_filter($avaliacoesArr, fn($av) => $av['barbeiro_id'] === $barbeiroId);
    if (count($avaliacoesDoBarbeiro) > 0) {
        $somaNotas = array_sum(array_column($avaliacoesDoBarbeiro, 'rating'));
        $mediaAvaliacoesBarbeiros[$barbeiroId] = round($somaNotas / count($avaliacoesDoBarbeiro), 1);
    } else {
        $mediaAvaliacoesBarbeiros[$barbeiroId] = 0;
    }
}

// Determina o Barbeiro em Destaque
$barbeiroDoMesId = null;
if (!empty($mediaAvaliacoesBarbeiros)) {
    $barbeiroDoMesId = array_keys($mediaAvaliacoesBarbeiros, max($mediaAvaliacoesBarbeiros))[0];
}

// --- LÓGICA ATUALIZADA: Consolidação de Horários ---
// Calcula o horário geral da Barbearia (Abertura mais cedo até Fechamento mais tarde)
$horariosConsolidadosPorDia = []; 

foreach ($horariosTrabalhoRaw as $linha) {
    $partes = explode('|', $linha);
    if(count($partes) < 4) continue;
    
    $barbeiro_id_horario = $partes[0];
    $dia = (int)$partes[1];
    $inicio = $partes[2];
    $fim = $partes[3];
    
    // Só considera horários de barbeiros que estão ativos
    if (isset($barbeirosAtivosArr[$barbeiro_id_horario])) {
        if (!isset($horariosConsolidadosPorDia[$dia])) {
            // Se for o primeiro registro do dia, define como inicial
            $horariosConsolidadosPorDia[$dia] = ['inicio' => $inicio, 'fim' => $fim];
        } else {
            // Se já existe, compara para expandir o horário da loja
            
            // Pega a abertura mais cedo
            if ($inicio < $horariosConsolidadosPorDia[$dia]['inicio']) {
                $horariosConsolidadosPorDia[$dia]['inicio'] = $inicio;
            }
            // Pega o fechamento mais tarde
            if ($fim > $horariosConsolidadosPorDia[$dia]['fim']) {
                $horariosConsolidadosPorDia[$dia]['fim'] = $fim;
            }
        }
    }
}

// Prepara o array final para o HTML ($horariosPorDia), agrupando dias com horários iguais
$horariosPorDia = [];
$dias_semana_texto = ['1' => 'Segunda-feira', '2' => 'Terça-feira', '3' => 'Quarta-feira', '4' => 'Quinta-feira', '5' => 'Sexta-feira', '6' => 'Sábado', '0' => 'Domingo'];

foreach ($horariosConsolidadosPorDia as $dia => $horas) {
    // Formata string (ex: "09:00 às 19:00")
    $horarioKey = $horas['inicio'] . ' às ' . $horas['fim'];
    $horariosPorDia[$horarioKey][] = $dia;
}
// --- FIM DA LÓGICA ATUALIZADA ---
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($configGeral['nome_barbearia']) ?> - Bem-vindo</title>
    
    <link rel="stylesheet" href="css/landing_style.css">
    <link rel="stylesheet" href="css/custom_theme.css.php"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

    </head>
<body>

    <a href="agendamento" class="floating-cta" id="floating-cta-btn">
        <i class="fas fa-calendar-alt"></i> <?= htmlspecialchars($landingConfig['hero_cta_button']) ?>
    </a>

    <header class="header" id="main-header">
        <a href="index" class="header-logo-link">
            <img src="<?= htmlspecialchars($configGeral['logo_path']) ?>" alt="Logo <?= htmlspecialchars($configGeral['nome_barbearia']) ?>" class="logo logo-xlarge">
        </a>
        
        <nav class="main-nav" id="main-nav">
            <a href="#sobre">Sobre</a>
            <a href="#servicos">Serviços</a>
            <?php if (!empty($planosArr)): ?>
                <a href="#planos">Clube VIP</a>
            <?php endif; ?>
            <a href="#equipe">Equipe</a>
            <a href="#contato">Contato</a>
            <a href="minha_conta" class="nav-cta-button">Área do Cliente</a>
        </nav>
    </header>

    <div class="page-wrapper">

        <main class="main-content">
            <section class="hero" id="hero">
                
                <?php if (!empty($landingConfig['hero_video_path']) && file_exists($landingConfig['hero_video_path'])): 
                    $video_path = htmlspecialchars($landingConfig['hero_video_path']);
                    $file_info = pathinfo($video_path);
                    $video_type = 'video/mp4'; 
                    if (isset($file_info['extension']) && $file_info['extension'] === 'webm') {
                        $video_type = 'video/webm';
                    }
                ?>
                <video class="hero-video" autoplay loop muted playsinline preload="auto">
                    <source src="<?= $video_path ?>" type="<?= $video_type ?>">
                    Seu navegador não suporta vídeos de fundo.
                </video>
                <?php endif; ?>

                <div class="hero-content-box animate-on-scroll is-visible">
                    <h1 class="hero-title"><?= htmlspecialchars($landingConfig['hero_title']) ?></h1>
                    <p class="hero-subtitle"><?= htmlspecialchars($landingConfig['hero_subtitle']) ?></p>
                    <div class="hero-buttons-wrapper">
                        <a href="agendamento" class="hero-cta-button"><?= htmlspecialchars($landingConfig['hero_cta_button']) ?></a>
                        <a href="#equipe" class="hero-secondary-button"><?= htmlspecialchars($landingConfig['hero_secondary_button']) ?></a>
                    </div>
                </div>
            </section>

            <section id="sobre" class="content-section animate-on-scroll">
                <div class="section-container">
                    <div class="about-image">
                        <img src="<?= htmlspecialchars($configGeral['logo_path']) ?>" alt="Logo da Barbearia">
                    </div>
                    <div class="about-text">
                        <h2 class="section-title"><?= htmlspecialchars($landingConfig['about_title']) ?></h2>
                        <p><?= nl2br(htmlspecialchars($landingConfig['about_text'])) ?></p>
                        <div class="stats-container">
                            <div class="stat-item"><div class="stat-number" data-target="<?= htmlspecialchars($landingConfig['stat1_number']) ?>">0</div><div class="stat-label"><?= htmlspecialchars($landingConfig['stat1_label']) ?></div></div>
                            <div class="stat-item"><div class="stat-number" data-target="<?= htmlspecialchars($landingConfig['stat2_number']) ?>">0</div><div class="stat-label"><?= htmlspecialchars($landingConfig['stat2_label']) ?></div></div>
                            <div class="stat-item"><div class="stat-number" data-target="<?= htmlspecialchars($landingConfig['stat3_number']) ?>">0</div><div class="stat-label"><?= htmlspecialchars($landingConfig['stat3_label']) ?></div></div>
                        </div>
                    </div>
                </div>
            </section>

            <section id="servicos" class="content-section animate-on-scroll">
                <div class="section-container text-center">
                    <h2 class="section-title"><?= htmlspecialchars($landingConfig['services_title']) ?></h2>
                    <div class="services-grid">
                        <?php 
                        $servicosExibicao = $servicosArr;
                        shuffle($servicosExibicao);
                        foreach (array_slice($servicosExibicao, 0, 3) as $servico): 
                        ?>
                        <div class="service-card">
                            <div class="service-icon"><i class="fas fa-cut"></i></div>
                            <h3><?= htmlspecialchars($servico['nome']) ?></h3>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php if (count($servicosArr) > 3): ?>
                        <a href="agendamento" class="view-more-button">Ver todos os serviços</a>
                    <?php endif; ?>
                </div>
            </section>

            <?php if (!empty($planosArr)): ?>
            <section id="planos" class="content-section animate-on-scroll" style="background-color: var(--dark-card-bg);">
                <div class="section-container text-center">
                    <h2 class="section-title">Clube VIP</h2>
                    <p style="color: #ccc; margin-bottom: 40px; font-size: 1.1rem;">Tenha acesso exclusivo e ilimitado aos nossos melhores serviços por um valor fixo mensal.</p>
                    
                    <div class="services-grid"> <?php foreach ($planosArr as $plano): ?>
                        <div class="service-card" style="border: 1px solid #6f42c1; position: relative; overflow: hidden; display: flex; flex-direction: column; justify-content: space-between;">
                            <div style="position: absolute; top: 0; right: 0; background: #6f42c1; color: white; padding: 5px 10px; border-bottom-left-radius: 10px; font-size: 0.8em; font-weight: bold; z-index: 2;">VIP</div>
                            
                            <div>
                                <div class="service-icon" style="color: #6f42c1;"><i class="fas fa-crown"></i></div>
                                <h3 style="color: var(--light-text);"><?= htmlspecialchars($plano['nome']) ?></h3>
                                <div style="margin: 20px 0;">
                                    <span style="font-size: 2.5rem; font-weight: 700; color: var(--light-text);">R$ <?= number_format((float)$plano['valor'], 2, ',', '.') ?></span>
                                    <span style="color: #aaa;">/mês</span>
                                </div>
                                
                                <ul style="list-style: none; padding: 0; color: #ccc; margin-bottom: 25px; text-align: left; border-top: 1px solid #333; padding-top: 15px;">
                                    <?php 
                                    $idsServicos = explode(',', $plano['servicos_ids']);
                                    foreach($idsServicos as $sid):
                                        $nomeServico = '';
                                        $sid = trim($sid);
                                        if(isset($servicosArr[$sid])) $nomeServico = $servicosArr[$sid]['nome'];
                                        
                                        if($nomeServico):
                                    ?>
                                    <li style="margin-bottom: 8px; display: flex; align-items: center;">
                                        <i class="fas fa-check" style="color: #6f42c1; margin-right: 10px;"></i> 
                                        <?= htmlspecialchars($nomeServico) ?> 
                                    </li>
                                    <?php endif; endforeach; ?>
                                </ul>
                            </div>
                            
                            <a href="agendamento" class="view-more-button" style="border-color: #6f42c1; color: #fff; background-color: #6f42c1; margin-top: auto;">Assinar Agora</a>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </section>
            <?php endif; ?>
            <section id="equipe" class="content-section animate-on-scroll">
                <div class="section-container text-center">
                    <h2 class="section-title"><?= htmlspecialchars($landingConfig['team_title']) ?></h2>
                    <div class="team-grid">
                        <?php 
                        foreach ($barbeirosAtivosArr as $id => $barbeiro): 
                        ?>
                        <div class="team-card">
                            <img src="<?= htmlspecialchars($barbeiro['foto']) ?>" alt="Foto de <?= htmlspecialchars($barbeiro['nome']) ?>">
                            <h3><?= strtoupper(htmlspecialchars($barbeiro['nome'])) ?></h3>
                            <div class="barber-rating-label">Média de Avaliação</div>
                            <div class="barber-rating">
                                <?= str_repeat('★', floor($mediaAvaliacoesBarbeiros[$id])) . str_repeat('☆', 5 - floor($mediaAvaliacoesBarbeiros[$id])) ?>
                                <span>(<?= $mediaAvaliacoesBarbeiros[$id] ?>)</span>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </section>
            
            <?php 
            if($barbeiroDoMesId && isset($barbeirosAtivosArr[$barbeiroDoMesId])): 
                $barbeiroDestaque = $barbeirosAtivosArr[$barbeiroDoMesId];
            ?>
            <section id="destaque" class="hero featured-section animate-on-scroll">
                 <div class="hero-content-box">
                    <h2 class="section-title"><?= htmlspecialchars($landingConfig['featured_title']) ?></h2>
                    <p class="hero-subtitle" style="font-size: 1rem; margin-bottom: 25px;"><?= htmlspecialchars($landingConfig['featured_subtitle']) ?></p>
                    <div class="featured-barber-highlight">
                        <img src="<?= htmlspecialchars($barbeiroDestaque['foto']) ?>" alt="Foto de <?= htmlspecialchars($barbeiroDestaque['nome']) ?>">
                        <h3><?= strtoupper(htmlspecialchars($barbeiroDestaque['nome'])) ?></h3>
                        <div class="barber-rating">
                            <?= str_repeat('★', floor($mediaAvaliacoesBarbeiros[$barbeiroDoMesId])) . str_repeat('☆', 5 - floor($mediaAvaliacoesBarbeiros[$barbeiroDoMesId])) ?>
                            <span>(<?= $mediaAvaliacoesBarbeiros[$barbeiroDoMesId] ?> de média)</span>
                        </div>
                        <a href="agendamento?barbeiro=<?= $barbeiroDoMesId ?>" class="hero-cta-button" style="margin-top: 20px;">Agendar com <?= htmlspecialchars(explode(' ', $barbeiroDestaque['nome'])[0]) ?></a>
                    </div>
                 </div>
            </section>
            <?php endif; ?>
            
            <?php if(!empty($avaliacoesParaExibir)): ?>
            <section id="avaliacoes" class="content-section animate-on-scroll">
                <div class="section-container text-center">
                    <h2 class="section-title"><?= htmlspecialchars($landingConfig['testimonials_title']) ?></h2>
                    <div class="testimonials-grid">
                        <?php 
                        foreach ($avaliacoesParaExibir as $avaliacao): 
                            $cliente = $clientesArr[$avaliacao['cliente_id']] ?? null;
                            $nomeCliente = $cliente['nome'] ?? 'Anônimo';
                            $fotoCliente = ($cliente && !empty($cliente['foto_perfil']) && file_exists($cliente['foto_perfil'])) ? $cliente['foto_perfil'] : 'uploads/default-profile.jpg';
                            $nomeBarbeiro = $barbeirosArr[$avaliacao['barbeiro_id']]['nome'] ?? 'Nosso Time';
                        ?>
                        <div class="testimonial-card">
                            <div class="testimonial-header">
                                <img src="<?= htmlspecialchars($fotoCliente) ?>" alt="Foto de <?= htmlspecialchars($nomeCliente) ?>" class="client-photo">
                                <div class="rating">
                                    <?= str_repeat('★', (int)$avaliacao['rating']) . str_repeat('☆', 5 - (int)$avaliacao['rating']) ?>
                                </div>
                            </div>
                            <p class="comment">"<?= htmlspecialchars($avaliacao['comment']) ?>"</p>
                            <p class="client-name">- <?= htmlspecialchars($nomeCliente) ?> (atendido por <?= htmlspecialchars($nomeBarbeiro) ?>)</p>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </section>
            <?php endif; ?>
            
             <section id="cta" class="content-section cta-section animate-on-scroll">
                <div class="section-container text-center">
                    <h2 class="section-title"><?= htmlspecialchars($landingConfig['cta_title']) ?></h2>
                    <p><?= htmlspecialchars($landingConfig['cta_text']) ?></p>
                    <a href="agendamento" class="hero-cta-button"><?= htmlspecialchars($landingConfig['cta_button']) ?></a>
                </div>
            </section>
            
            <section id="contato" class="content-section bg-dark animate-on-scroll">
                 <div class="section-container contact-container">
                    <div class="contact-info">
                        <h2 class="section-title"><?= htmlspecialchars($landingConfig['contact_title']) ?></h2>
                        <p><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($configGeral['endereco']) ?></p>
                        <p><i class="fas fa-phone"></i> <?= htmlspecialchars($configGeral['telefone_contato']) ?></p>
                         <div class="footer-social-links">
                             <?php if (!empty($configGeral['link_instagram'])): ?><a href="<?= htmlspecialchars($configGeral['link_instagram']) ?>" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a><?php endif; ?>
                             <?php if (!empty($configGeral['link_facebook'])): ?><a href="<?= htmlspecialchars($configGeral['link_facebook']) ?>" target="_blank" title="Facebook"><i class="fab fa-facebook"></i></a><?php endif; ?>
                             <?php if (!empty($configGeral['link_whatsapp'])): 
                                 $whatsapp_number = preg_replace('/\D/', '', $configGeral['link_whatsapp']);
                             ?><a href="https://wa.me/<?= htmlspecialchars($whatsapp_number) ?>" target="_blank" title="WhatsApp"><i class="fab fa-whatsapp"></i></a><?php endif; ?>
                        </div>
                        
                        <div class="horarios-funcionamento">
                            <h4>Horário de Funcionamento</h4>
                            <ul>
                                <?php foreach($horariosPorDia as $horario => $dias):
                                    sort($dias);
                                    $dia_str = '';
                                    if(count($dias) > 1) {
                                        $dia_str = $dias_semana_texto[$dias[0]] . ' a ' . $dias_semana_texto[end($dias)];
                                    } else {
                                        $dia_str = $dias_semana_texto[$dias[0]];
                                    }
                                ?>
                                <li><strong><?= $dia_str ?>:</strong> <?= $horario ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                    <?php if(!empty($configGeral['geofence_lat']) && !empty($configGeral['geofence_lon'])): ?>
                    <div id="map"></div>
                    <?php endif; ?>
                </div>
            </section>

        </main>

        <footer class="footer">
            <div class="footer-links">
                <a href="#" data-modal-target="#modal-termos">Termos de Uso</a> | 
                <a href="#" data-modal-target="#modal-privacidade">Política de Privacidade</a>
            </div>
            <div class="footer-admin-links">
                <a href="minha_conta" cite="uploaded:barbearia/index.php">Área do Cliente</a> | 
                <a href="admin" cite="uploaded:barbearia/index.php">Admin</a>
            </div>
            <div class="footer-bottom">
                 &copy; <?= date("Y") ?> <?= htmlspecialchars($configGeral['nome_barbearia']) ?> &ndash; Todos os direitos reservados.
            </div>
        </footer>

    </div>
    
    <div id="modal-termos" class="legal-modal">
        <div class="legal-modal-content">
            <span class="legal-modal-close">&times;</span>
            <h2>Termos de Uso</h2>
            <div class="legal-text">
                <?= $landingConfig['terms_of_use'] ?>
            </div>
        </div>
    </div>

    <div id="modal-privacidade" class="legal-modal">
        <div class="legal-modal-content">
            <span class="legal-modal-close">&times;</span>
            <h2>Política de Privacidade</h2>
             <div class="legal-text">
                <?= $landingConfig['privacy_policy'] ?>
            </div>
        </div>
    </div>


    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // --- Botão Flutuante ---
            const floatingBtn = document.getElementById('floating-cta-btn');
            window.addEventListener('scroll', () => {
                if (window.scrollY > 400) {
                    floatingBtn.classList.add('visible');
                } else {
                    floatingBtn.classList.remove('visible');
                }
            });

            // --- Mapa ---
            <?php if(!empty($configGeral['geofence_lat']) && !empty($configGeral['geofence_lon'])): ?>
            var map = L.map('map').setView([<?= $configGeral['geofence_lat'] ?>, <?= $configGeral['geofence_lon'] ?>], 17);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            }).addTo(map);
            L.marker([<?= $configGeral['geofence_lat'] ?>, <?= $configGeral['geofence_lon'] ?>]).addTo(map)
                .bindPopup('<?= htmlspecialchars($configGeral['nome_barbearia']) ?>')
                .openPopup();
            <?php endif; ?>

            // --- Animação dos Contadores ---
            const counters = document.querySelectorAll('.stat-number');
            const speed = 200; 
            const counterObserver = new IntersectionObserver(entries => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const counter = entry.target;
                        const updateCount = () => {
                            const target = +counter.getAttribute('data-target');
                            const count = +counter.innerText;
                            const inc = target / speed;

                            if (count < target) {
                                counter.innerText = Math.ceil(count + inc);
                                setTimeout(updateCount, 1);
                            } else {
                                counter.innerText = target;
                            }
                        };
                        updateCount();
                        counterObserver.unobserve(counter);
                    }
                });
            }, { threshold: 0.5 });
            counters.forEach(counter => {
                counterObserver.observe(counter);
            });

            // --- Animação de Scroll (Fade In) ---
            const animatedSections = document.querySelectorAll('.animate-on-scroll');
            const sectionObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('is-visible');
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.1 }); 
            animatedSections.forEach(section => {
                sectionObserver.observe(section);
            });

            // --- Lógica para Modais de Termos e Privacidade ---
            const modalButtons = document.querySelectorAll('[data-modal-target]');
            const closeButtons = document.querySelectorAll('.legal-modal-close');
            const modals = document.querySelectorAll('.legal-modal');
            modalButtons.forEach(button => {
                button.addEventListener('click', (e) => {
                    e.preventDefault();
                    const modal = document.querySelector(button.dataset.modalTarget);
                    modal.style.display = "flex";
                });
            });
            closeButtons.forEach(button => {
                button.addEventListener('click', () => {
                    const modal = button.closest('.legal-modal');
                    modal.style.display = "none";
                });
            });
            window.addEventListener('click', (event) => {
                modals.forEach(modal => {
                    if (event.target == modal) {
                        modal.style.display = "none";
                    }
                });
            });
            
            // --- Lógica do Header Fixo ---
            const header = document.getElementById('main-header');
            
            window.addEventListener('scroll', () => {
                if (window.scrollY > 50) { 
                    header.classList.add('scrolled');
                } else {
                    header.classList.remove('scrolled');
                }
            });

            // --- Lógica de Rolagem Suave (corrigida para header fixo) ---
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();
                    const targetId = this.getAttribute('href');
                    if (!targetId || targetId === "#") return; 

                    const targetElement = document.querySelector(targetId);
                    if (targetElement) {
                        const headerOffset = document.getElementById('main-header').offsetHeight; 
                        let elementPosition = targetElement.getBoundingClientRect().top;
                        
                        if(targetId === '#hero') {
                            elementPosition = 0;
                        }
                        
                        const offsetPosition = (targetId === '#hero') ? 0 : (elementPosition + window.pageYOffset - headerOffset);

                        window.scrollTo({
                            top: offsetPosition,
                            behavior: "smooth"
                        });
                    }
                });
            });
        });
    </script>

</body>
</html>