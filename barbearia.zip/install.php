<?php
// install.php
// Página de verificação de sistema, permissões e instalação do admin.

// Define o fuso horário e carrega as funções (apenas para o logo)
date_default_timezone_set('America/Sao_Paulo');
if (file_exists('functions.php')) {
    require_once 'functions.php';
    $configGeral = carregarConfigGeral();
} else {
    // Fallback se functions.php não for encontrado
    $configGeral = ['nome_barbearia' => 'Sistema de Barbearia', 'logo_path' => ''];
}

$basePath = __DIR__ . DIRECTORY_SEPARATOR;
$dadosDir = $basePath . '_dados';
$logsDir = $basePath . '_logs';
$uploadsDir = $basePath . 'uploads';
$usersFile = $dadosDir . DIRECTORY_SEPARATOR . 'users.txt';

$resultados_servidor = [];
$resultados_arquivos = [];
$todosRequisitosOK = true;
$admin_setup_error = '';
$admin_setup_success = '';

// --- DEFINIÇÃO DO QUE CHECAR ---

// 1. Requisitos do Servidor (PHP)
$minPHPVersion = '7.4.0';
$requiredExtensions = [
    'json' => 'Necessária para ler arquivos de configuração (ex: landing_page.json)',
    'mbstring' => 'Necessária para manipulação correta de nomes e textos (caracteres especiais)',
    'gd' => 'Necessária para processar uploads de imagens (fotos de perfil, logo)',
    'zip' => 'Necessária para a função de backup do sistema',
    'openssl' => 'Essencial para o PHPMailer enviar e-mails via SMTP seguro (ex: Gmail)'
];
$iniSettings = [
    'file_uploads' => 'Permite que o sistema aceite uploads (fotos, logo)',
    'upload_max_filesize' => 'Tamanho máximo de cada arquivo de upload',
    'post_max_size' => 'Tamanho máximo de dados de formulário (deve ser > upload_max_filesize)',
    'memory_limit' => 'Memória disponível para o script (útil para imagens grandes)'
];

// 2. Diretórios que devem existir
$diretoriosObrigatorios = [
    '_dados', '_logs', 'uploads', 'lib', 'PHPMailer', 'css', 'js', 'email_templates', 'admin_tabs'
];

// 3. Arquivos críticos que devem existir
$arquivosObrigatorios = [
    'functions.php', 'admin.php', 'index.php', 'agendamento.php', 'login.php'
];

// 4. Diretórios que DEVEM ter permissão de escrita
$diretoriosEscrita = [
    '_dados', '_logs', 'uploads'
];

// --- FIM DA DEFINIÇÃO ---


// --- Executando as Verificações ---

// 1. Checar Requisitos do Servidor
$phpVersionOK = version_compare(PHP_VERSION, $minPHPVersion, '>=');
$resultados_servidor[] = ['nome' => 'Versão do PHP (>= ' . $minPHPVersion . ')', 'status' => $phpVersionOK, 'valor' => PHP_VERSION, 'tipo' => 'PHP'];
if (!$phpVersionOK) $todosRequisitosOK = false;

foreach ($requiredExtensions as $ext => $descricao) {
    $status = extension_loaded($ext);
    $resultados_servidor[] = ['nome' => 'Extensão PHP: ' . $ext, 'status' => $status, 'valor' => ($status ? 'Ativada' : 'Ausente'), 'tipo' => 'Extensão', 'descricao' => $descricao];
    if (!$status) $todosRequisitosOK = false;
}

foreach ($iniSettings as $setting => $descricao) {
    $valor = ini_get($setting);
    $status = true; // Apenas informativo, exceto file_uploads
    if ($setting === 'file_uploads' && !in_array($valor, ['1', 'On', 'on'])) {
        $status = false;
        $todosRequisitosOK = false;
    }
    $resultados_servidor[] = ['nome' => 'Configuração PHP: ' . $setting, 'status' => $status, 'valor' => ($valor), 'tipo' => 'Config', 'descricao' => $descricao];
}


// 2. Checar diretórios
foreach ($diretoriosObrigatorios as $dir) {
    $path = $basePath . $dir;
    $status = is_dir($path);
    $resultados_arquivos[] = ['nome' => $dir . '/', 'status' => $status, 'tipo' => 'Diretório'];
    if (!$status) $todosRequisitosOK = false;
}

// 3. Checar arquivos
foreach ($arquivosObrigatorios as $file) {
    $path = $basePath . $file;
    $status = file_exists($path);
    $resultados_arquivos[] = ['nome' => $file, 'status' => $status, 'tipo' => 'Arquivo'];
    if (!$status) $todosRequisitosOK = false;
}

// 4. Checar permissões de escrita (MÉTODO CORRIGIDO)
$permissao_dados_ok = false; // Flag especial para a aba de Admin
clearstatcache(); // Limpa o cache de status de arquivos do PHP

foreach ($diretoriosEscrita as $dir) {
    $path = $basePath . $dir;
    
    // O teste CORRETO: 
    // 1. Verifica se é um diretório
    // 2. Verifica se o PHP tem permissão de escrita (is_writable)
    $status = (is_dir($path) && is_writable($path));
    
    // Se is_writable() for verdadeiro, fazemos um teste real
    if ($status) {
        $testFile = $path . DIRECTORY_SEPARATOR . 'writable_test.tmp';
        // Se não conseguir criar o arquivo (ex: restrições de safe_mode), falha.
        if (@file_put_contents($testFile, 'teste') === false) {
            $status = false; 
        } else {
            @unlink($testFile); // Limpa o teste
        }
    }
    
    if ($dir === '_dados' && $status) {
        $permissao_dados_ok = true;
    }
    
    $resultados_arquivos[] = ['nome' => $dir . '/', 'status' => $status, 'tipo' => 'Permissão de Escrita'];
    if (!$status) $todosRequisitosOK = false;
}

// --- Processar Criação do Admin ---
$users_file_exists = file_exists($usersFile);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'criar_admin') {
    if ($users_file_exists) {
        $admin_setup_error = "Erro: O arquivo de administradores (users.txt) já existe. Por segurança, este instalador não pode modificá-lo.";
    } elseif (!$permissao_dados_ok) { // Usa a flag que checamos
        $admin_setup_error = "Erro: O diretório '_dados' não existe ou não tem permissão de escrita. Verifique o 'Status do Sistema' e o 'Guia de Permissões'.";
    } else {
        $username = trim($_POST['username']);
        $senha = $_POST['password'];
        $confirma_senha = $_POST['confirm_password'];

        if (empty($username) || empty($senha)) {
            $admin_setup_error = "Usuário e senha são obrigatórios.";
        } elseif ($senha !== $confirma_senha) {
            $admin_setup_error = "As senhas não coincidem.";
        } elseif (strlen($senha) < 6) {
             $admin_setup_error = "A senha deve ter no mínimo 6 caracteres.";
        } else {
            $password_hash = password_hash($senha, PASSWORD_DEFAULT);
            $linha = "$username:$password_hash\n";
            
            if (file_put_contents($usersFile, $linha, LOCK_EX) !== false) {
                $admin_setup_success = "Administrador criado com sucesso! Você já pode fazer login no painel de admin.";
                $users_file_exists = true; 
            } else {
                $admin_setup_error = "Falha ao salvar o arquivo users.txt. Verifique as permissões.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instalação e Verificação - <?= htmlspecialchars($configGeral['nome_barbearia']) ?></title>
    
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/custom_theme.css.php">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        .container { max-width: 800px; margin-top: 50px; }
        
        .check-list-container {
            background-color: var(--card-background);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            padding: 25px 35px;
            margin-top: 0; 
        }
        .check-list { 
            list-style: none; 
            padding: 0; 
            margin: 0;
            max-height: 400px;
            overflow-y: auto;
            border: 1px solid var(--border-color);
            border-radius: 8px;
        }
        .check-list li { 
            display: flex; 
            justify-content: space-between; 
            align-items: center;
            padding: 15px; 
            border-bottom: 1px solid var(--border-color);
            background-color: #fff;
        }
        .check-list li:last-child { border-bottom: none; }
        .check-list code { 
            background: #e9ecef; 
            padding: 3px 6px; 
            border-radius: 4px; 
            font-size: 0.9rem;
            color: #333;
        }
        .check-list strong {
            font-size: 0.8rem;
            color: #6c757d;
            text-transform: uppercase;
        }
        .check-list .descricao {
            font-size: 0.85rem;
            color: #6c757d;
            margin-top: 5px;
        }
        .status-badge { 
            font-weight: bold; 
            padding: 5px 10px; 
            border-radius: 20px; 
            color: white;
            font-size: 0.9rem;
            flex-shrink: 0; 
            margin-left: 10px;
        }
        .status-info {
            background-color: #6c757d;
            min-width: 60px;
            text-align: center;
        }
        .status-ok { background-color: var(--success-color); }
        .status-fail { background-color: var(--error-color); }
        
        .instrucoes { 
            background: #fffbe6; 
            border: 1px solid #ffe58f; 
            padding: 20px; 
            border-radius: 8px; 
            margin-top: 25px; 
            line-height: 1.6;
        }
        .instrucoes h3 { margin-top: 0; }
        .instrucoes ul { padding-left: 20px; margin-bottom: 0; }
        
        .sucesso-box {
            background: #d4edda;
            border: 1px solid #c3e6cb;
            padding: 20px;
            border-radius: 8px;
            margin-top: 25px;
            text-align: center;
        }
        .sucesso-box h3 { margin-top: 0; color: #155724; }
        
        /* Estilos das Abas */
        .sub-tab { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 20px; background-color: #e9ecef; padding: 5px; border-radius: 8px; }
        .sub-tab-btn { flex-grow: 1; padding: 10px; background: transparent; border: none; border-radius: 6px; cursor: pointer; font-weight: bold; color: #495057; }
        .sub-tab-btn.active { background: var(--card-background); color: var(--secondary-color); box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .sub-tabcontent { display: none; }
        .sub-tabcontent.active { display: block; }
        
        .section-title {
            font-size: 1.2rem;
            font-weight: bold;
            color: var(--primary-color);
            margin-top: 25px;
            margin-bottom: 15px; 
            padding-bottom: 8px;
            border-bottom: 2px solid var(--border-color);
        }
        .section-title:first-of-type {
            margin-top: 0;
        }
    </style>
</head>
<body class="admin-page" style="background-color: #f8f9fa;">
    <div class="container">
        <div style="text-align: center;">
            <?php if (!empty($configGeral['logo_path']) && file_exists($configGeral['logo_path'])): ?>
                <a href="index.php"><img src="<?= htmlspecialchars($configGeral['logo_path']) ?>" alt="Logo" style="max-height: 100px; margin-bottom: 20px;"></a>
            <?php endif; ?>
            <h2>Instalação e Verificação do Sistema</h2>
        </div>
        
        <div class="sub-tab">
            <button class="sub-tab-btn active" data-tab="status"><i class="fa fa-tasks"></i> Status do Sistema</button>
            <button class="sub-tab-btn" data-tab="permissoes"><i class="fa fa-key"></i> Guia de Permissões</button>
            <button class="sub-tab-btn" data-tab="instalar"><i class="fa fa-user-shield"></i> Criar Administrador</button>
            <?php if ($users_file_exists): // Só mostra esta aba se o admin já foi criado ?>
            <button class="sub-tab-btn" data-tab="proximos" style="color: var(--error-color); font-weight: bold;">
                <i class="fa fa-exclamation-triangle"></i> Próximos Passos
            </button>
            <?php endif; ?>
        </div>

        <div id="status" class="sub-tabcontent active">
            <div class="check-list-container">
                <p style="text-align: center; margin-top: 0;">Diagnóstico do ambiente do servidor e dos arquivos do sistema.</p>
                
                <h3 class="section-title">Requisitos do Servidor</h3>
                <ul class="check-list">
                    <?php foreach ($resultados_servidor as $item): ?>
                        <li>
                            <div>
                                <strong><?= htmlspecialchars($item['tipo']) ?></strong><br>
                                <code><?= htmlspecialchars($item['nome']) ?></code>
                                <div class="descricao"><?= htmlspecialchars($item['descricao'] ?? '') ?></div>
                            </div>
                            
                            <?php if ($item['tipo'] === 'Config'): ?>
                                <span class="status-badge status-info" title="<?= htmlspecialchars($item['valor']) ?>">
                                    <?= htmlspecialchars($item['status'] ? $item['valor'] : 'Desativado') ?>
                                </span>
                            <?php elseif ($item['status']): ?>
                                <span class="status-badge status-ok" title="<?= htmlspecialchars($item['valor']) ?>">OK</span>
                            <?php else: ?>
                                <span class="status-badge status-fail" title="<?= htmlspecialchars($item['valor']) ?>">FALHA</span>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
                
                <h3 class="section-title">Arquivos e Permissões de Escrita</h3>
                 <ul class="check-list">
                    <?php foreach ($resultados_arquivos as $item): ?>
                        <li>
                            <div>
                                <strong><?= htmlspecialchars($item['tipo']) ?></strong><br>
                                <code><?= htmlspecialchars($item['nome']) ?></code>
                            </div>
                            <?php if ($item['status']): ?>
                                <span class="status-badge status-ok">OK</span>
                            <?php else: ?>
                                <span class="status-badge status-fail">FALHA</span>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>

                <?php if ($todosRequisitosOK): ?>
                    <div class="sucesso-box">
                        <h3><i class="fa fa-check-circle"></i> Sucesso!</h3>
                        <p>Todos os requisitos do servidor e permissões estão corretos.</p>
                    </div>
                <?php else: ?>
                    <div class="mensagem erro instrucoes" style="background-color: #f8d7da; border-color: #f5c6cb;">
                        <h3><i class="fa fa-exclamation-triangle"></i> Atenção: Falha na Verificação!</h3>
                        <p>Um ou mais requisitos não foram atendidos. O sistema pode não funcionar corretamente. Consulte o <strong>Guia de Permissões</strong>.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <div id="permissoes" class="sub-tabcontent">
            <div class="check-list-container">
                <h3 class="section-title" style="text-align: left; margin-top: 0;">Guia Rápido de Permissões (chmod)</h3>
                <p>Para o sistema funcionar corretamente, seus arquivos e pastas precisam das permissões certas no servidor.</p>
                
                <div class="instrucoes" style="background-color: #e9f0f6; border-color: #d1e3f1; color: #333;">
                    <h3 style="color: var(--primary-color);">Regra 1: Padrão de Segurança (Maioria dos arquivos)</h3>
                    <p>A maioria dos seus arquivos e pastas deve ser "somente leitura" para o público.</p>
                    <ul>
                        <li><strong>TODAS AS PASTAS:</strong> <code>755</code><br>
                            (Ex: <code>lib/</code>, <code>css/</code>, <code>js/</code>, <code>admin_tabs/</code>, <code>PHPMailer/</code>)</li>
                        <li><strong>TODOS OS ARQUIVOS:</strong> <code>644</code><br>
                            (Ex: <code>index.php</code>, <code>admin.php</code>, <code>functions.php</code>, <code>css/style.css</code>)</li>
                    </ul>
                </div>
                
                <div class="instrucoes" style="background-color: #fffbe6; border-color: #ffe58f; margin-top: 15px; color: #664d03;">
                    <h3 style="color: #856404;">Regra 2: Pastas de Escrita (Exceções Críticas)</h3>
                    <p>Estas 3 pastas <strong>PRECISAM</strong> de permissão de escrita para o PHP salvar dados. Use <code>775</code>.</p>
                    <ul>
                        <li><code>_dados/</code> (Para salvar agendamentos, clientes, configs)</li>
                        <li><code>_logs/</code> (Para salvar o <code>app_log.txt</code>)</li>
                        <li><code>uploads/</code> (Para salvar fotos de perfil e o logo)</li>
                    </ul>
                    <p><strong>Obs:</strong> Se <code>775</code> não funcionar (o teste na aba "Status" falhar), tente <code>777</code> <strong>apenas nestas 3 pastas</strong>.</p>
                </div>
                
                <div class="instrucoes" style="background-color: #f8d7da; border-color: #f5c6cb; margin-top: 15px; color: #721c24;">
                    <h3 style="color: #721c24;">Regra 3: Arquivo de Instalação (Segurança)</h3>
                    <p>Este arquivo (<code>install.php</code>) é um risco de segurança se deixado no servidor.</p>
                    <ul>
                        <li><strong>AÇÃO OBRIGATÓRIA:</strong> Assim que o sistema estiver funcionando, <strong>DELETE ESTE ARQUIVO</strong> do servidor.</li>
                    </ul>
                </div>

            </div>
        </div>

        <div id="instalar" class="sub-tabcontent">
             <div class="check-list-container">
                <h3 class="section-title" style="text-align: left; margin-top: 0;">Criar Primeiro Administrador</h3>

                <?php if ($admin_setup_error): ?>
                    <p class="mensagem erro" style="background-color: #f8d7da; border-color: #f5c6cb;"><?= htmlspecialchars($admin_setup_error) ?></p>
                <?php endif; ?>
                <?php if ($admin_setup_success): ?>
                    <p class="mensagem" style="background-color: #d4edda; border-color: #c3e6cb;"><?= htmlspecialchars($admin_setup_success) ?></p>
                <?php endif; ?>

                <?php if ($users_file_exists): ?>
                    <div class="mensagem instrucoes" style="background-color: #d1ecf1; border-color: #bee5eb; color: #0c5460;">
                        <h3><i class="fa fa-lock"></i> Administrador Já Existe</h3>
                        <p>O arquivo <code>_dados/users.txt</code> já existe. Por segurança, este instalador não pode modificá-lo.</p>
                        <p>Se você precisa redefinir sua senha, deve fazê-lo manually no servidor.</p>
                    </div>
                <?php else: ?>
                    
                    <div class="mensagem instrucoes" style="background-color: #e9f0f6; border-color: #d1e3f1; color: #333; margin-bottom: 20px;">
                        <p style="margin: 0;"><strong>Nota:</strong> Você pode criar o administrador mesmo que a aba "Status do Sistema" mostre falhas (ex: Extensão <code>zip</code> faltando).</p>
                        <p style="margin: 0; font-weight: bold;">O único requisito para esta etapa é a "Permissão de Escrita" na pasta <code>_dados/</code> estar OK.</p>
                    </div>
                
                    <form method="POST">
                        <input type="hidden" name="action" value="criar_admin">
                        <p>Crie o primeiro usuário administrador do sistema. Esta ação só pode ser executada uma vez.</p>
                        <div class="form-group">
                            <label for="username">Usuário Admin</label>
                            <input type="text" name="username" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Senha (mínimo 6 caracteres)</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="confirm_password">Confirmar Senha</label>
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>
                        <button type="submit" class="btn-primary" style="width: 100%;" <?= $permissao_dados_ok ? '' : 'disabled' ?>>
                            <?= $permissao_dados_ok ? 'Criar Administrador' : 'Corrija a permissão de _dados/' ?>
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
        
        <?php if ($users_file_exists): ?>
        <div id="proximos" class="sub-tabcontent">
            <div class="check-list-container">
                <div class="mensagem erro instrucoes" style="background-color: #f8d7da; border-color: #f5c6cb;">
                    <h3 style="color: #721c24;"><i class="fa fa-exclamation-triangle"></i> AÇÃO DE SEGURANÇA CRÍTICA</h3>
                    <p>O seu sistema já está instalado e possui um administrador cadastrado.</p>
                    <p>Por favor, por motivos de segurança, <strong>DELETE ESTE ARQUIVO (<code>install.php</code>)</strong> do seu servidor imediatamente.</p>
                    <p>Manter este arquivo no servidor representa um risco de segurança, pois ele expõe informações sobre a estrutura de arquivos e permissões.</p>
                    
                    <div class="btn-group" style="justify-content: center; margin-top: 20px;">
                        <a href="admin.php" class="btn-primary">Ir para o Painel Admin</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
    </div>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Lógica das Abas
        const tabs = document.querySelectorAll('.sub-tab-btn');
        const contents = document.querySelectorAll('.sub-tabcontent');
        
        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                // Remove 'active' de todos
                tabs.forEach(t => t.classList.remove('active'));
                contents.forEach(c => c.classList.remove('active'));
                
                // Adiciona 'active' ao clicado
                tab.classList.add('active');
                document.getElementById(tab.dataset.tab).classList.add('active');
            });
        });

        <?php if ($admin_setup_error || $admin_setup_success): ?>
        // Se houver uma mensagem de erro ou sucesso do admin, muda para a aba de "Instalar"
        document.querySelector('.sub-tab-btn[data-tab="status"]').classList.remove('active');
        document.querySelector('#status').classList.remove('active');
        document.querySelector('.sub-tab-btn[data-tab="instalar"]').classList.add('active');
        document.querySelector('#instalar').classList.add('active');
        <?php endif; ?>
        
        <?php if ($users_file_exists && !($admin_setup_error || $admin_setup_success)): ?>
        // Se o admin já existe E não acabamos de criá-lo, foca na aba de "Próximos Passos"
        document.querySelector('.sub-tab-btn[data-tab="status"]').classList.remove('active');
        document.querySelector('#status').classList.remove('active');
        document.querySelector('.sub-tab-btn[data-tab="proximos"]').classList.add('active');
        document.querySelector('#proximos').classList.add('active');
        <?php endif; ?>
    });
    </script>
</body>
</html>