<?php
// lib/relatorio_functions.php
// Contém todas as funções de cálculo para o Dashboard e a aba de Relatórios.

/**
 * Analisa as vendas de produtos em agendamentos concluídos.
 * @param array $agendamentos_filtrados
 * @return array
 */
function getVendasProdutosNoPeriodo($agendamentos_filtrados) {
    $vendas = [];
    foreach ($agendamentos_filtrados as $ag) {
        if ($ag['status'] === 'concluido' && !empty($ag['produtos_vendidos'])) {
            $produtos = json_decode($ag['produtos_vendidos'], true);
            if (is_array($produtos)) {
                foreach ($produtos as $produto) {
                    if (!isset($vendas[$produto['nome']])) {
                        $vendas[$produto['nome']] = ['quantidade' => 0, 'receita' => 0];
                    }
                    $vendas[$produto['nome']]['quantidade']++;
                    $vendas[$produto['nome']]['receita'] += (float)$produto['valor'];
                }
            }
        }
    }
    arsort($vendas);
    return $vendas;
}

/**
 * Analisa o total e a quantidade de descontos por tipo.
 * ATUALIZADO: Inclui suporte para Adesão de Plano e Assinatura VIP.
 * @param array $agendamentos_filtrados
 * @return array
 */
function getAnaliseDescontos($agendamentos_filtrados) {
    $descontos = [
        'cupom' => ['total' => 0, 'quantidade' => 0, 'label' => 'Cupons'],
        'voucher' => ['total' => 0, 'quantidade' => 0, 'label' => 'Vouchers'],
        'fidelidade' => ['total' => 0, 'quantidade' => 0, 'label' => 'Fidelidade'],
        'aniversario' => ['total' => 0, 'quantidade' => 0, 'label' => 'Aniversário'],
        'indicacao' => ['total' => 0, 'quantidade' => 0, 'label' => 'Indicação'],
        'adesao_plano' => ['total' => 0, 'quantidade' => 0, 'label' => 'Ajuste Adesão'],
        'assinatura_vip' => ['total' => 0, 'quantidade' => 0, 'label' => 'Benefício VIP'],
        'outro' => ['total' => 0, 'quantidade' => 0, 'label' => 'Outros']
    ];
    
    foreach ($agendamentos_filtrados as $ag) {
        $valor_desconto = (float)($ag['desconto_aplicado'] ?? 0);
        
        // Considera descontos positivos OU negativos (no caso de adesão onde o plano é mais caro que o serviço)
        if ($valor_desconto != 0) {
            $tipo = $ag['tipo_desconto'] ?? 'outro';
            
            if (isset($descontos[$tipo])) {
                $descontos[$tipo]['total'] += $valor_desconto;
                $descontos[$tipo]['quantidade']++;
            } else {
                $descontos['outro']['total'] += $valor_desconto;
                $descontos['outro']['quantidade']++;
            }
        }
    }
    
    // Retorna apenas os que tiveram alguma movimentação
    return array_filter($descontos, fn($d) => $d['quantidade'] > 0);
}

/**
 * Calcula a taxa de ocupação de um barbeiro em um período.
 * @param string $barbeiro_id
 * @param string $data_inicio
 * @param string $data_fim
 * @param array $agendamentos (Todos os agendamentos)
 * @param array $horarios_trabalho (Horários de trabalho brutos)
 * @return float
 */
function getTaxaOcupacaoBarbeiro($barbeiro_id, $data_inicio, $data_fim, $agendamentos, $horarios_trabalho) {
    $total_minutos_trabalhados = 0;
    $total_minutos_disponiveis = 0;

    $agendamentos_barbeiro = array_filter($agendamentos, fn($ag) => $ag['barbeiro_id'] === $barbeiro_id && $ag['data'] >= $data_inicio && $ag['data'] <= $data_fim);

    foreach ($agendamentos_barbeiro as $ag) {
        if ($ag['status'] !== 'cancelado' && $ag['status'] !== 'cancelado_pelo_cliente') {
            $duracao = count(explode(',', $ag['servicos_ids'])) * 30;
            $total_minutos_trabalhados += $duracao;
        }
    }
    
    $start = new DateTime($data_inicio);
    $end = new DateTime($data_fim);
    $interval = new DateInterval('P1D');
    $period = new DatePeriod($start, $interval, $end->modify('+1 day'));

    foreach ($period as $date) {
        $dia_semana = $date->format('w');
        foreach ($horarios_trabalho as $ht) {
            $partes = explode('|', $ht);
            if(count($partes) < 4) continue;
            if ($partes[0] === $barbeiro_id && $partes[1] == $dia_semana) {
                $inicio = new DateTime($partes[2]);
                $fim = new DateTime($partes[3]);
                $diff = $fim->getTimestamp() - $inicio->getTimestamp();
                $total_minutos_disponiveis += $diff / 60;
            }
        }
    }

    if ($total_minutos_disponiveis == 0) return 0;
    return round(($total_minutos_trabalhados / $total_minutos_disponiveis) * 100, 2);
}

/**
 * Calcula a frequência média (em dias) entre visitas de clientes recorrentes.
 * @param array $agendamentos_filtrados
 * @return string
 */
function getFrequenciaMediaVisitas($agendamentos_filtrados) {
    $visitas_por_cliente = [];
    foreach ($agendamentos_filtrados as $ag) {
        if ($ag['status'] === 'concluido') {
            $cliente_identificador = $ag['email'] . '|' . $ag['telefone'];
            $visitas_por_cliente[$cliente_identificador][] = strtotime($ag['data']);
        }
    }

    $soma_diferencas_dias = 0;
    $total_intervalos = 0;

    foreach ($visitas_por_cliente as $datas) {
        if (count($datas) > 1) {
            sort($datas);
            for ($i = 1; $i < count($datas); $i++) {
                $diferenca = $datas[$i] - $datas[$i-1];
                $soma_diferencas_dias += $diferenca / (60 * 60 * 24);
                $total_intervalos++;
            }
        }
    }
    
    if ($total_intervalos == 0) return "N/D";
    return round($soma_diferencas_dias / $total_intervalos);
}

/**
 * Encontra clientes recorrentes que não agendam há um tempo (em risco de churn).
 * Depende de: limparTelefone()
 * @param array $agendamentos (Todos os agendamentos)
 * @param array $clientes (Todos os clientes)
 * @param int $dias_limite (Padrão: 90 dias)
 * @return array
 */
function getClientesEmRisco($agendamentos, $clientes, $dias_limite = 90) {
    $clientes_em_risco = [];
    $limite = time() - ($dias_limite * 24 * 60 * 60);

    foreach ($clientes as $id => $cliente) {
        $agendamentos_cliente = array_filter($agendamentos, fn($ag) => ($ag['email'] === $cliente['email'] || limparTelefone($ag['telefone']) === limparTelefone($cliente['telefone'])) && $ag['status'] === 'concluido');
        
        if (count($agendamentos_cliente) >= 2) { // Considera apenas clientes recorrentes
            $ultimo_agendamento = null;
            $ultima_data = 0;
            foreach($agendamentos_cliente as $ag) {
                $data_ts = strtotime($ag['data']);
                if ($data_ts > $ultima_data) {
                    $ultima_data = $data_ts;
                    $ultimo_agendamento = $ag;
                }
            }
            if ($ultima_data < $limite && $ultima_data > 0) { 
                $clientes_em_risco[$id] = $cliente;
                $clientes_em_risco[$id]['ultimo_agendamento'] = date('d/m/Y', $ultima_data);
            }
        }
    }
    return $clientes_em_risco;
}

/**
 * Encontra as combinações de serviços mais populares.
 * @param array $agendamentos_filtrados
 * @param array $servicos (Array de todos os serviços)
 * @return array
 */
function getServicosMaisCombinados($agendamentos_filtrados, $servicos) {
    $combinacoes = [];
    foreach ($agendamentos_filtrados as $ag) {
        $sids = explode(',', $ag['servicos_ids']);
        if (count($sids) > 1) {
            sort($sids);
            $key = implode('-', $sids);
            if (!isset($combinacoes[$key])) {
                $combinacoes[$key] = ['count' => 0, 'sids' => $sids];
            }
            $combinacoes[$key]['count']++;
        }
    }
    uasort($combinacoes, fn($a, $b) => $b['count'] <=> $a['count']);
    
    $resultado = [];
    foreach (array_slice($combinacoes, 0, 5) as $combo) {
        $nomes = array_map(fn($sid) => $servicos[trim($sid)]['nome'] ?? '?', $combo['sids']);
        $resultado[] = ['combinacao' => implode(' + ', $nomes), 'ocorrencias' => $combo['count']];
    }
    return $resultado;
}

/**
 * Calcula a divisão entre novos clientes e recorrentes em um período.
 * @param array $agendamentos_filtrados
 * @return array
 */
function getNovosVsRecorrentes($agendamentos_filtrados) {
    $clientes_atendidos = [];
    foreach ($agendamentos_filtrados as $ag) {
        if ($ag['status'] === 'concluido') {
            $cliente_id = strtolower(trim($ag['email'])) ?: limparTelefone($ag['telefone']);
            if (!isset($clientes_atendidos[$cliente_id])) {
                $clientes_atendidos[$cliente_id] = 0;
            }
            $clientes_atendidos[$cliente_id]++;
        }
    }

    $novos = 0;
    $recorrentes = 0;
    foreach ($clientes_atendidos as $count) {
        if ($count === 1) {
            $novos++;
        } else {
            $recorrentes++;
        }
    }
    return ['novos' => $novos, 'recorrentes' => $recorrentes];
}

/**
 * Retorna o ranking dos serviços mais realizados.
 * @param array $agendamentos_concluidos
 * @param array $servicosArr
 * @return array
 */
function getRankingServicos($agendamentos_concluidos, $servicosArr) {
    $contagem = [];
    foreach ($agendamentos_concluidos as $ag) {
        $sids = explode(',', $ag['servicos_ids']);
        foreach ($sids as $sid) {
            $sid = trim($sid);
            if (isset($servicosArr[$sid])) {
                if (!isset($contagem[$sid])) {
                    $contagem[$sid] = 0;
                }
                $contagem[$sid]++;
            }
        }
    }
    arsort($contagem);
    return array_slice($contagem, 0, 5, true);
}

/**
 * Retorna a lista de clientes que fazem aniversário no mês atual.
 * @param array $clientesArr
 * @return array
 */
function getAniversariantesDoMes($clientesArr) {
    $aniversariantes = [];
    $mes_atual = date('m');
    foreach ($clientesArr as $cliente) {
        if (!empty($cliente['data_nascimento'])) {
            $mes_nascimento = date('m', strtotime($cliente['data_nascimento']));
            if ($mes_nascimento === $mes_atual) {
                $aniversariantes[] = $cliente;
            }
        }
    }
    usort($aniversariantes, function($a, $b) {
        return date('d', strtotime($a['data_nascimento'])) <=> date('d', strtotime($b['data_nascimento']));
    });
    return $aniversariantes;
}

/**
 * Retorna a contagem de agendamentos por status.
 * @param array $agendamentos_filtrados
 * @return array
 */
function getContagemStatusAgendamentos($agendamentos_filtrados) {
    $contagem = ['concluido' => 0, 'cancelado' => 0, 'pendente' => 0, 'total' => 0];
    
    if (empty($agendamentos_filtrados)) {
        return $contagem;
    }

    foreach ($agendamentos_filtrados as $ag) {
        $status = $ag['status'] ?? 'pendente';
        if (array_key_exists($status, $contagem)) {
            $contagem[$status]++;
        } elseif ($status === 'cancelado_pelo_cliente') {
             $contagem['cancelado']++; 
        }
        $contagem['total']++;
    }
    return $contagem;
}

/**
 * Encontra o barbeiro com maior receita no período.
 * @param array $agendamentos_concluidos
 * @param array $barbeirosArr
 * @param array $servicosArr
 * @return array ['nome' => string, 'valor' => float]
 */
function getMelhorBarbeiro($agendamentos_concluidos, $barbeirosArr, $servicosArr) {
    $receitaPorBarbeiro = [];
    
    foreach ($agendamentos_concluidos as $ag) {
        $barbeiro_id = $ag['barbeiro_id'];
        if (!isset($receitaPorBarbeiro[$barbeiro_id])) {
            $receitaPorBarbeiro[$barbeiro_id] = 0;
        }
        
        $valor_servicos_ag = 0;
        $sids = explode(',', $ag['servicos_ids']);
        foreach($sids as $sid) {
            if(isset($servicosArr[trim($sid)])) {
                $valor_servicos_ag += (float)$servicosArr[trim($sid)]['valor'];
            }
        }

        $produtos_vendidos = !empty($ag['produtos_vendidos']) ? json_decode($ag['produtos_vendidos'], true) : [];
        foreach($produtos_vendidos as $produto) { 
            $valor_servicos_ag += (float)$produto['valor'];
        }

        $valor_servicos_ag -= (float)($ag['desconto_aplicado'] ?? 0);
        
        $receitaPorBarbeiro[$barbeiro_id] += $valor_servicos_ag;
    }
    
    if (empty($receitaPorBarbeiro)) {
        return ['nome' => 'N/A', 'valor' => 0];
    }
    
    arsort($receitaPorBarbeiro);
    $melhor_id = key($receitaPorBarbeiro);
    $melhor_valor = $receitaPorBarbeiro[$melhor_id];
    $melhor_nome = $barbeirosArr[$melhor_id]['nome'] ?? 'Desconhecido';
    
    return ['nome' => $melhor_nome, 'valor' => $melhor_valor];
}

/**
 * Contabiliza agendamentos por hora do dia.
 * @param array $agendamentos_filtrados
 * @return array
 */
function getHorariosDePico($agendamentos_filtrados) {
    $contagem_por_hora = [];
    for ($i = 0; $i < 24; $i++) {
        $hora_label = str_pad($i, 2, '0', STR_PAD_LEFT) . ':00';
        $contagem_por_hora[$hora_label] = 0;
    }

    foreach ($agendamentos_filtrados as $ag) {
        if ($ag['status'] === 'concluido' || $ag['status'] === 'aprovado') {
            $hora = date('H:00', strtotime($ag['hora'])); 
            if (isset($contagem_por_hora[$hora])) {
                $contagem_por_hora[$hora]++;
            }
        }
    }
    return $contagem_por_hora;
}

/**
 * Retorna os top 5 clientes por gasto total no período.
 * @param array $agendamentos_concluidos
 * @param array $servicosArr
 * @return array
 */
function getTopClientesPorGasto($agendamentos_concluidos, $servicosArr) {
    $gasto_por_cliente = [];

    foreach ($agendamentos_concluidos as $ag) {
        $cliente_id = trim($ag['nome']) . ' (' . substr($ag['telefone'], -4) . ')';
        if (!isset($gasto_por_cliente[$cliente_id])) {
            $gasto_por_cliente[$cliente_id] = 0;
        }

        $valor_servicos_ag = 0;
        $sids = explode(',', $ag['servicos_ids']);
        foreach($sids as $sid) {
            if(isset($servicosArr[trim($sid)])) {
                $valor_servicos_ag += (float)$servicosArr[trim($sid)]['valor'];
            }
        }
        $produtos_vendidos = !empty($ag['produtos_vendidos']) ? json_decode($ag['produtos_vendidos'], true) : [];
        foreach($produtos_vendidos as $produto) { 
            $valor_servicos_ag += (float)$produto['valor'];
        }
        $valor_servicos_ag -= (float)($ag['desconto_aplicado'] ?? 0);

        $gasto_por_cliente[$cliente_id] += $valor_servicos_ag;
    }

    arsort($gasto_por_cliente);
    return array_slice($gasto_por_cliente, 0, 5, true);
}

/**
 * (NOVO) Calcula a popularidade dos planos com base nas assinaturas ativas.
 * @param array $assinaturas
 * @param array $planos
 * @return array
 */
function getPopularidadePlanos($assinaturas, $planos) {
    $stats = [];
    foreach ($assinaturas as $sub) {
        if ($sub['status'] === 'ativo') {
            $planoNome = $planos[$sub['plano_id']]['nome'] ?? 'Plano Removido';
            if (!isset($stats[$planoNome])) {
                $stats[$planoNome] = 0;
            }
            $stats[$planoNome]++;
        }
    }
    arsort($stats);
    return $stats;
}
?>