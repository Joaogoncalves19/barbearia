<?php
// lib/email_functions.php
// Contém a lógica de envio de e-mail usando a biblioteca PHPMailer.

// Importa as classes do PHPMailer para o namespace global
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Carrega os arquivos da biblioteca PHPMailer
require __DIR__ . '/../PHPMailer/Exception.php';
require __DIR__ . '/../PHPMailer/PHPMailer.php';
require __DIR__ . '/../PHPMailer/SMTP.php';

/**
 * Envia um e-mail transacional usando PHPMailer.
 * Depende de: carregarConfigEmail(), carregarConfigGeral(), log_activity()
 *
 * @param string $para_email O e-mail do destinatário.
 * @param string $assunto O assunto do e-mail.
 * @param string $template O nome do arquivo de template (ex: 'confirmacao').
 * @param array $dados Um array de dados para popular o template.
 * @return bool True se o e-mail foi enviado, False caso contrário.
 */
function enviarEmail($para_email, $assunto, $template, $dados) {
    // Carrega as configurações (funções que vêm de config_functions.php)
    $configEmail = carregarConfigEmail();
    $configGeral = carregarConfigGeral();

    // Validação básica para evitar erros se o e-mail não estiver configurado
    if (empty($configEmail['username']) || empty($configEmail['password'])) {
        log_activity("FALHA (PHPMailer): E-mail de remetente não configurado em config_email.txt.");
        return false;
    }

    $mail = new PHPMailer(true);

    try {
        // --- CONFIGURAÇÕES DO SERVIDOR (lidas do arquivo) ---
        $mail->isSMTP();
        $mail->Host       = $configEmail['host'];
        $mail->SMTPAuth   = true;
        $mail->Username   = $configEmail['username'];
        $mail->Password   = $configEmail['password'];
        $mail->SMTPSecure = $configEmail['smtp_secure'];
        $mail->Port       = $configEmail['port'];
        $mail->CharSet    = 'UTF-8';

        //Remetente e Destinatário
        $mail->setFrom($configEmail['username'], $configGeral['nome_barbearia']);
        $mail->addAddress($para_email);
        $mail->addReplyTo($configEmail['username'], $configGeral['nome_barbearia']);

        // --- INÍCIO DA CORREÇÃO (Embed da Logo) ---
        $logo_url = ''; // Deixa vazio por padrão (caso a imagem não exista)
        $logo_path_local = __DIR__ . '/../' . $configGeral['logo_path'];

        if (!empty($configGeral['logo_path']) && file_exists($logo_path_local)) {
            try {
                // Adiciona a imagem como um anexo "embutido"
                // O 'logo_cid' é o ID que usaremos no HTML (cid:logo_cid)
                $mail->addEmbeddedImage($logo_path_local, 'logo_cid');
                
                // Agora, a URL do logo para o template é o Content-ID (CID)
                $logo_url = 'cid:logo_cid';

            } catch (Exception $e) {
                // Se falhar em anexar, apenas loga, mas não para o e-mail
                log_activity("FALHA (PHPMailer): Não foi possível embutir a imagem do logo. " . $e->getMessage());
                $logo_url = ''; // Garante que a URL fique vazia se falhar
            }
        }
        // --- FIM DA CORREÇÃO ---

        // Monta a mensagem baseada no template
        ob_start();
        // Usa __DIR__ . '/../' para voltar do diretório 'lib' para a raiz
        include __DIR__ . '/../email_templates/' . $template . '.php';
        $mensagem = ob_get_clean();

        //Conteúdo do E-mail
        $mail->isHTML(true);
        $mail->Subject = $assunto;
        $mail->Body    = $mensagem;
        $mail->AltBody = 'Para visualizar esta mensagem, por favor, use um cliente de e-mail compatível com HTML.';

        $mail->send();
        log_activity("Email (PHPMailer) enviado para $para_email, assunto: $assunto");
        return true;
    } catch (Exception $e) {
        log_activity("FALHA (PHPMailer) ao enviar email para $para_email: {$mail->ErrorInfo}");
        return false;
    }
}
?>