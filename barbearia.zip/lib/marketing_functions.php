<?php
// lib/marketing_functions.php
// Contém funções relacionadas a Fidelidade, Cupons, Vouchers, Indicações e PLANOS DE ASSINATURA.

// ==========================================================================
// FUNÇÕES DE FIDELIDADE
// ==========================================================================

function getAllFidelityPoints() {
    $fidelityFile = DATA_DIR . 'fidelidade.txt';
    if (!file_exists($fidelityFile)) {
        return [];
    }

    $pointsData = [];
    $fp = fopen($fidelityFile, 'r');
    if (!$fp) {
        return [];
    }

    if (flock($fp, LOCK_SH)) {
        while (($line = fgets($fp)) !== false) {
            $line = trim($line);
            if (empty($line)) continue;
            
            $parts = explode('|', $line);
            if (count($parts) === 2) {
                $pointsData[$parts[0]] = (int)$parts[1];
            }
        }
        flock($fp, LOCK_UN);
    }
    fclose($fp);

    return $pointsData;
}

function getClientFidelityPoints($cliente_id) {
    $allPoints = getAllFidelityPoints();
    return $allPoints[$cliente_id] ?? 0;
}

function updateClientFidelityPoints($cliente_id, $points, $descricao = '') {
    $fidelityFile = DATA_DIR . 'fidelidade.txt';
    $allPoints = getAllFidelityPoints();
    
    $pontos_anteriores = $allPoints[$cliente_id] ?? 0;
    $allPoints[$cliente_id] = $points;

    $lines = [];
    foreach ($allPoints as $id => $p) {
        $lines[] = "$id|$p";
    }

    file_put_contents($fidelityFile, implode("\n", $lines) . "\n", LOCK_EX);

    // Registra no histórico se houve mudança e tem descrição
    if ($descricao && ($points != $pontos_anteriores)) {
        addFidelityHistory($cliente_id, $points - $pontos_anteriores, $descricao);
    }
}

function addFidelityHistory($cliente_id, $pontos, $descricao) {
    $historyFile = DATA_DIR . 'fidelidade_historico.txt';
    $timestamp = date('Y-m-d H:i:s');
    $linha = "$cliente_id|$pontos|$descricao|$timestamp\n";
    file_put_contents($historyFile, $linha, FILE_APPEND | LOCK_EX);
}

function getFidelityHistory($cliente_id) {
    $historyFile = DATA_DIR . 'fidelidade_historico.txt';
    if (!file_exists($historyFile)) {
        return [];
    }

    $history = [];
    $fp = fopen($historyFile, 'r');
    if (!$fp) {
        return [];
    }

    // Lê todas as linhas
    $lines = [];
    if (flock($fp, LOCK_SH)) {
        while (($line = fgets($fp)) !== false) {
            $lines[] = trim($line);
        }
        flock($fp, LOCK_UN);
    }
    fclose($fp);

    // Processa do mais recente para o mais antigo
    foreach (array_reverse($lines) as $line) {
        if (empty($line)) continue;
        
        $parts = explode('|', $line);
        if (count($parts) === 4 && $parts[0] === $cliente_id) {
            $history[] = [
                'cliente_id' => $parts[0],
                'pontos' => (int)$parts[1],
                'descricao' => $parts[2],
                'timestamp' => $parts[3]
            ];
        }
    }

    return $history;
}

// ==========================================================================
// FUNÇÕES DE CUPONS
// ==========================================================================

function getCouponByCode($codigo) {
    $cupoesFile = DATA_DIR . 'cupoes.txt';
    if (!file_exists($cupoesFile)) {
        return null;
    }

    $fp = fopen($cupoesFile, 'r');
    if (!$fp) return null;

    $hoje = date('Y-m-d');
    $resultado = null;

    if (flock($fp, LOCK_SH)) {
        while (($c = fgets($fp)) !== false) {
            $c = trim($c);
            if (empty($c)) continue;
            
            $partes = explode('|', $c);
            if (count($partes) < 6) continue;

            list($id, $cod, $desconto, $usos_max, $validade, $usos_atuais) = $partes;

            if ($cod === $codigo) {
                // Validações
                if ($hoje > $validade) {
                    $resultado = ['error' => 'Cupom expirado.'];
                } elseif ((int)$usos_atuais >= (int)$usos_max) {
                    $resultado = ['error' => 'Limite de usos atingido.'];
                } else {
                    $resultado = [
                        'id' => $id,
                        'codigo' => $cod,
                        'desconto_percentual' => $desconto,
                        'usos_maximos' => $usos_max,
                        'data_validade' => $validade,
                        'usos_atuais' => $usos_atuais
                    ];
                }
                break; // Encontrou, para o loop
            }
        }
        flock($fp, LOCK_UN);
    }
    fclose($fp);

    return $resultado;
}

function incrementarUsoCupom($cupom_id) {
    $cupoesFile = 'cupoes.txt';
    $keys = ['id', 'codigo', 'desconto_percentual', 'usos_maximos', 'data_validade', 'usos_atuais'];
    $cupoesArr = lerDados($cupoesFile, $keys);

    if (isset($cupoesArr[$cupom_id])) {
        $cupoesArr[$cupom_id]['usos_atuais'] = (int)$cupoesArr[$cupom_id]['usos_atuais'] + 1;
        salvarDados($cupoesFile, $cupoesArr, $keys);
    }
}

function checkIfUserUsedCoupon($cupom_id, $cliente_id) {
    $usosFile = DATA_DIR . 'cupom_usos.txt';
    if (!file_exists($usosFile)) {
        return false;
    }

    $fp = fopen($usosFile, 'r');
    if (!$fp) return false;

    $encontrado = false;
    if (flock($fp, LOCK_SH)) {
        while (($uso = fgets($fp)) !== false) {
            $partes = explode('|', trim($uso));
            if (count($partes) === 2 && $partes[0] === $cupom_id && $partes[1] === $cliente_id) {
                $encontrado = true;
                break;
            }
        }
        flock($fp, LOCK_UN);
    }
    fclose($fp);

    return $encontrado;
}

function logCouponUsage($cupom_id, $cliente_id) {
    file_put_contents(DATA_DIR . 'cupom_usos.txt', "$cupom_id|$cliente_id\n", FILE_APPEND | LOCK_EX);
}

// ==========================================================================
// FUNÇÕES DE VOUCHERS
// ==========================================================================

function getVoucherByCode($codigo) {
    $vouchersFile = DATA_DIR . 'vouchers.txt';
    if (!file_exists($vouchersFile)) {
        return null;
    }

    $fp = fopen($vouchersFile, 'r');
    if (!$fp) return null;

    $resultado = null;

    if (flock($fp, LOCK_SH)) {
        while (($v = fgets($fp)) !== false) {
            $partes = explode('|', trim($v));
            if (count($partes) < 4) continue;

            // Estrutura: id|codigo|valor|status|data_criacao|agendamento_id_uso|data_validade
            if ($partes[1] === $codigo) {
                if ($partes[3] !== 'disponivel') {
                    $resultado = ['error' => 'Voucher inválido ou já utilizado.'];
                } elseif (!empty($partes[6]) && date('Y-m-d') > $partes[6]) {
                    $resultado = ['error' => 'Voucher expirado.'];
                } else {
                    $resultado = [
                        'id' => $partes[0],
                        'codigo' => $partes[1],
                        'valor' => (float)$partes[2],
                        'status' => $partes[3],
                        'data_validade' => $partes[6] ?? ''
                    ];
                }
                break;
            }
        }
        flock($fp, LOCK_UN);
    }
    fclose($fp);

    return $resultado;
}

function marcarVoucherComoUtilizado($voucher_id, $agendamento_id) {
    $vouchersFile = 'vouchers.txt';
    $keys = ['id', 'codigo', 'valor', 'status', 'data_criacao', 'agendamento_id_uso', 'data_validade'];
    $vouchersArr = lerDados($vouchersFile, $keys);

    if (isset($vouchersArr[$voucher_id])) {
        $vouchersArr[$voucher_id]['status'] = 'utilizado';
        $vouchersArr[$voucher_id]['agendamento_id_uso'] = $agendamento_id;
        salvarDados($vouchersFile, $vouchersArr, $keys);
    }
}

// ==========================================================================
// FUNÇÕES DE ASSINATURA (PLANOS VIP)
// ==========================================================================

/**
 * Carrega todos os planos de assinatura disponíveis.
 */
function getPlanos() {
    return lerDados('planos.txt', ['id', 'nome', 'valor', 'servicos_ids']);
}

/**
 * Retorna a assinatura ATIVA de um cliente, se houver, estiver no prazo e com status 'ativo'.
 */
function getAssinaturaCliente($cliente_id) {
    $dados = lerDados('clientes_assinaturas.txt', ['cliente_id', 'plano_id', 'data_inicio', 'data_fim', 'status']);
    
    if (isset($dados[$cliente_id])) {
        $assinatura = $dados[$cliente_id];
        // Verifica se o status é 'ativo' E se a data de validade ainda não expirou
        if (($assinatura['status'] ?? 'ativo') === 'ativo' && $assinatura['data_fim'] >= date('Y-m-d')) {
            return $assinatura;
        }
    }
    return null;
}

/**
 * Salva, renova ou altera o status de uma assinatura.
 * * @param string $cliente_id ID do cliente.
 * @param string $plano_id ID do plano escolhido.
 * @param string $duracao_str String de duração para strtotime (ex: '+30 days').
 * @param string|null $data_inicio_base Data base para o cálculo (opcional).
 * @param string $status Status da assinatura ('ativo' ou 'inativo').
 */
function salvarAssinaturaCliente($cliente_id, $plano_id, $duracao_str = '+1 month', $data_inicio_base = null, $status = 'ativo') {
    
    // Se não for fornecida data base, usa a data de hoje
    $data_inicio = $data_inicio_base ? $data_inicio_base : date('Y-m-d');
    
    // Calcula a data final somando a duração à data de início
    $data_fim = date('Y-m-d', strtotime($data_inicio . ' ' . $duracao_str));
    
    // Carrega assinaturas existentes
    $todasAssinaturas = lerDados('clientes_assinaturas.txt', ['cliente_id', 'plano_id', 'data_inicio', 'data_fim', 'status']);
    
    // Atualiza ou cria a assinatura do cliente
    $todasAssinaturas[$cliente_id] = [
        'cliente_id' => $cliente_id,
        'plano_id' => $plano_id,
        'data_inicio' => $data_inicio,
        'data_fim' => $data_fim,
        'status' => $status
    ];
    
    // Salva no arquivo
    salvarDados('clientes_assinaturas.txt', $todasAssinaturas, ['cliente_id', 'plano_id', 'data_inicio', 'data_fim', 'status']);
}

// ==========================================================================
// FUNÇÕES DE INDICAÇÃO (NOVO)
// ==========================================================================

/**
 * Processa a recompensa de quem indicou APÓS a conclusão do primeiro serviço do indicado.
 * @param string $indicador_id ID de quem fez a indicação (o padrinho).
 * @param string $nome_novo_cliente Nome do cliente que foi indicado (o afilhado).
 */
function processarRecompensaIndicacao($indicador_id, $nome_novo_cliente) {
    // Carrega configuração de indicação
    $configIndicacao = getIndicacaoConfig();
    
    // Verifica se o sistema de indicação está ativo
    if (!($configIndicacao['ativado'] ?? 0)) {
        return;
    }
    
    $pontos_indicacao = (int)($configIndicacao['pontos_indicacao'] ?? 1);
    
    if ($pontos_indicacao > 0) {
        $pontos_atuais = getClientFidelityPoints($indicador_id);
        
        // Atualiza pontos do indicador
        updateClientFidelityPoints($indicador_id, $pontos_atuais + $pontos_indicacao, "Amigo indicado visitou: $nome_novo_cliente");
        
        // Envia notificação interna para quem indicou
        // Verifica se a função existe para evitar erros caso `notificacao_functions.php` não esteja carregado (embora deva estar via functions.php)
        if (function_exists('criarNotificacao')) {
            criarNotificacao($indicador_id, "Parabéns! Seu amigo $nome_novo_cliente completou a primeira visita. Você ganhou $pontos_indicacao ponto(s) de fidelidade!");
        }
    }
}
?>