<?php
// lib/config_functions.php
// Contém todas as funções para carregar e salvar os arquivos de configuração do sistema.

/**
 * ATUALIZADO: Helper interno para ler arquivos .ini/.txt de configuração com bloqueio (LOCK_SH).
 * @param string $configFile Caminho completo para o arquivo
 * @param array $defaults Array de valores padrão
 * @return array
 */
function _lerConfigSeguroINI($configFile, $defaults) {
    if (!file_exists($configFile)) {
        return $defaults;
    }
    
    $fp = fopen($configFile, 'r');
    if (!$fp) {
        log_activity("FALHA: Não foi possível abrir o arquivo de config $configFile para leitura.");
        return $defaults;
    }
    
    $configData = [];
    // Solicita bloqueio de leitura
    if (flock($fp, LOCK_SH)) {
        $contents = '';
        // Lê o arquivo em partes
        while (!feof($fp)) {
            $contents .= fread($fp, 8192);
        }
        
        if (!empty($contents)) {
            // parse_ini_string é mais seguro após a leitura completa
            $configData = parse_ini_string($contents);
        }
        
        flock($fp, LOCK_UN); // Libera o bloqueio
    } else {
        log_activity("FALHA: Não foi possível obter LOCK_SH no arquivo $configFile.");
    }
    fclose($fp);

    // Mescla os padrões com os dados lidos
    return array_merge($defaults, $configData);
}

/**
 * ATUALIZADO: Carrega as configurações de E-mail (SMTP) de forma segura.
 * @return array
 */
function carregarConfigEmail() {
    $configFile = DATA_DIR . 'config_email.txt';
    $defaults = [
        'host' => 'smtp.gmail.com',
        'username' => '',
        'password' => '',
        'port' => 465,
        'smtp_secure' => 'ssl',
        'nome_remetente' => 'Barbearia'
    ];
    if (!file_exists($configFile)) {
        $conteudo = ''; foreach ($defaults as $key => $value) { $conteudo .= "$key=\"$value\"\n"; }
        file_put_contents($configFile, $conteudo, LOCK_EX); // Salva com bloqueio
    }
    return _lerConfigSeguroINI($configFile, $defaults); // Lê com bloqueio
}

/**
 * ATUALIZADO: Carrega as configurações do programa de Fidelidade de forma segura.
 * @return array
 */
function getFidelityConfig() { 
    $configFile = DATA_DIR . 'fidelidade_config.txt'; 
    $defaults = [ 'ativado' => 1, 'pontos_necessarios' => 10, 'desconto_percentual' => 50 ]; 
    if (!file_exists($configFile)) { 
        $conteudo = "ativado=1\npontos_necessarios=10\ndesconto_percentual=50"; 
        file_put_contents($configFile, $conteudo, LOCK_EX); // Salva com bloqueio
    } 
    return _lerConfigSeguroINI($configFile, $defaults); // Lê com bloqueio
}

/**
 * ATUALIZADO: Carrega as configurações da promoção de Aniversário de forma segura.
 * @return array
 */
function getAniversarioConfig() { 
    $configFile = DATA_DIR . 'config_aniversario.txt'; 
    $defaults = [ 'ativado' => 0, 'desconto_percentual' => 15 ]; 
    if (!file_exists($configFile)) { 
        $conteudo = "ativado=0\ndesconto_percentual=15"; 
        file_put_contents($configFile, $conteudo, LOCK_EX); // Salva com bloqueio
    } 
    return _lerConfigSeguroINI($configFile, $defaults); // Lê com bloqueio
}

/**
 * ATUALIZADO: Carrega as configurações do programa de Indicação de forma segura.
 * @return array
 */
function getIndicacaoConfig() { 
    $configFile = DATA_DIR . 'config_indicacao.txt'; 
    $defaults = [ 'ativado' => 0, 'pontos_indicacao' => 1, 'desconto_novo_cliente' => 10 ]; 
    if (!file_exists($configFile)) { 
        file_put_contents($configFile, "ativado=0\npontos_indicacao=1\ndesconto_novo_cliente=10", LOCK_EX); // Salva com bloqueio
        return $defaults; // Retorna os padrões na primeira vez
    } 
    return _lerConfigSeguroINI($configFile, $defaults); // Lê com bloqueio
}

/**
 * ATUALIZADO: Carrega as configurações Gerais da barbearia de forma segura.
 * @return array
 */
function carregarConfigGeral() {
    $configFile = DATA_DIR . 'config_geral.txt';
    $defaults = [
        'nome_barbearia' => 'Minha Barbearia',
        'telefone_contato' => '(00) 00000-0000',
        'endereco' => 'Seu Endereço Aqui',
        'link_instagram' => '',
        'link_facebook' => '',
        'link_whatsapp' => '',
        'logo_path' => 'uploads/logo.png'
    ];
    if (!file_exists($configFile)) {
        $conteudo = ''; foreach ($defaults as $key => $value) { $conteudo .= "$key=\"$value\"\n"; }
        file_put_contents($configFile, $conteudo, LOCK_EX); // Salva com bloqueio
    }
    return _lerConfigSeguroINI($configFile, $defaults); // Lê com bloqueio
}

/**
 * ATUALIZADO: Carrega as configurações de regras de Agendamento de forma segura.
 * @return array
 */
function carregarConfigAgendamento() {
    $configFile = DATA_DIR . 'config_agendamento.txt';
    $defaults = [
        'antecedencia_minima_minutos' => 120,
        'antecedencia_maxima' => 30,
        'max_servicos' => 4,
        'notif_confirmacao' => 1,
        'notif_aprovacao' => 1,
        'notif_lembrete' => 1
    ];
    if (!file_exists($configFile)) {
        $conteudo = ''; foreach ($defaults as $key => $value) { $conteudo .= "$key=$value\n"; }
        file_put_contents($configFile, $conteudo, LOCK_EX); // Salva com bloqueio
    }
    return _lerConfigSeguroINI($configFile, $defaults); // Lê com bloqueio
}

/**
 * ATUALIZADO: Carrega os textos e configurações da Landing Page (JSON) de forma segura.
 * @return array
 */
function carregarLandingPageConfig() {
    $configFile = DATA_DIR . 'landing_page.json';
    $defaults = [
        "hero_title" => "NOME DA SUA BARBEARIA",
        "hero_subtitle" => "Barba, cabelo e amigos.",
        "hero_cta_button" => "Agendar seu Horário",
        "hero_secondary_button" => "Conheça nossos Barbeiros",
        "about_title" => "Nossa História",
        "about_text" => "Fundada com a paixão pela arte da barbearia clássica, a NOME DA SUA BARBEARIA é mais do que um lugar para cortar o cabelo e fazer a barba. É um refúgio para o homem moderno que valoriza o cuidado pessoal, a boa conversa e um ambiente acolhedor. Nossos profissionais são mestres em suas áreas, dedicados a oferecer um atendimento personalizado e de excelência.",
        "stat1_number" => "1500",
        "stat1_label" => "Clientes Satisfeitos",
        "stat2_number" => "10",
        "stat2_label" => "Anos de Experiência",
        "stat3_number" => "5000",
        "stat3_label" => "Cortes Realizados",
        "services_title" => "Nossos Serviços",
        "team_title" => "Nossa Equipe",
        "featured_title" => "Barbeiro em Destaque",
        "featured_subtitle" => "Nosso profissional com a maior média de avaliações até o momento.",
        "testimonials_title" => "O que dizem nossos clientes",
        "cta_title" => "Pronto para o Próximo Nível?",
        "cta_text" => "Sua cadeira está esperando por você. Transforme seu visual e sua confiança hoje mesmo.",
        "cta_button" => "Agendar Meu Horário",
        "contact_title" => "Venha nos Visitar",
        "terms_of_use" => "<h3>1. Aceitação dos Termos...</h3><p>Texto padrão dos termos de uso.</p>",
        "privacy_policy" => "<h3>1. Política de Privacidade...</h3><p>Texto padrão da política de privacidade.</p>",
        
        // **** ATUALIZAÇÃO: Cor dourada removida ****
        // "gold_accent_color" => "#f2a900", // REMOVIDO
        
        "hero_video_path" => "" // Caminho do vídeo de fundo (upload)
    ];

    if (!file_exists($configFile)) {
        file_put_contents($configFile, json_encode($defaults, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX); // Salva com bloqueio
        return $defaults;
    }

    // Leitura segura (LOCK_SH) do JSON
    $fp = fopen($configFile, 'r');
    if (!$fp) {
        log_activity("FALHA: Não foi possível abrir $configFile (carregarLandingPageConfig).");
        return $defaults;
    }

    $config = $defaults;
    if (flock($fp, LOCK_SH)) {
        $contents = '';
        while (!feof($fp)) {
            $contents .= fread($fp, 8192);
        }
        
        if(!empty($contents)) {
            $decoded = json_decode($contents, true);
            if(is_array($decoded)) {
                $config = array_merge($defaults, $decoded);
            }
        }
        flock($fp, LOCK_UN);
    } else {
         log_activity("FALHA: Não foi possível obter LOCK_SH no $configFile.");
    }
    fclose($fp);
    
    return $config;
}

/**
 * ATUALIZADO: Salva as configurações da Landing Page (JSON) de forma segura.
 * @param array $data O array de dados a ser salvo.
 */
function salvarLandingPageConfig($data) {
    $configFile = DATA_DIR . 'landing_page.json';
    
    // **** ATUALIZAÇÃO: Garante que a cor dourada não seja salva ****
    if (isset($data['gold_accent_color'])) {
        unset($data['gold_accent_color']);
    }
    
    foreach($data as &$value) {
        // Remove barras invertidas que podem ter sido adicionadas por formulários
        $value = stripslashes($value);
    }
    
    // Salva o JSON com bloqueio exclusivo (LOCK_EX)
    file_put_contents($configFile, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
}

?>