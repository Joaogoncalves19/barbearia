<?php
// lib/agendamento_functions.php
// Contém a lógica de agendamento, verificação de horários e disponibilidade.

/**
 * ATUALIZADO: Retorna um array com todos os slots de 30 minutos já ocupados (com LOCK_SH).
 * Depende de: getHorariosBloqueados(), getHorariosAlmocoBloqueados()
 *
 * @param string $barbeiro_id O ID do barbeiro.
 * @param string $data A data no formato 'Y-m-d'.
 * @return array Um array de horários 'H:i' ocupados.
 */
function getHorariosOcupados($barbeiro_id, $data) {
    $agendamentosFile = DATA_DIR . 'agendamentos.txt';
    $horariosOcupados = [];

    // --- INÍCIO DA ATUALIZAÇÃO (Funcionalidade 1: Duração do Serviço) ---
    // Carrega os serviços com a nova estrutura para saber a duração (slots) de cada um
    $servicosArr = lerDados('servicos.txt', ['id', 'nome', 'valor', 'slots']); // (Esta função já é segura)
    // --- FIM DA ATUALIZAÇÃO ---

    if (file_exists($agendamentosFile)) {
        
        $fp = fopen($agendamentosFile, 'r');
        if (!$fp) {
            log_activity("FALHA: Não foi possível abrir o arquivo $agendamentosFile para leitura (getHorariosOcupados).");
        } else {
            // Solicita bloqueio de leitura
            if (flock($fp, LOCK_SH)) {
                
                while (($a = fgets($fp)) !== false) {
                    $a = trim($a);
                    if (empty($a)) continue;
            
                    $partes = explode('|', $a);
                    if (count($partes) < 9) continue;
                    list($id, $nome, $email, $telefone, $agendamento_barbeiro_id, $servicos_ids, $agendamento_data, $hora, $status) = $partes;
                    
                    // Verifica se é no mesmo dia, mesmo barbeiro, e não está cancelado
                    if ($agendamento_data === $data && $agendamento_barbeiro_id === $barbeiro_id && $status !== 'cancelado' && $status !== 'cancelado_pelo_cliente') {
                        
                        // --- INÍCIO DA ATUALIZAÇÃO (Funcionalidade 1: Duração do Serviço) ---
                        // Calcula o total de slots REAIS baseado nos serviços do agendamento
                        $totalSlots = 0;
                        $ids = explode(',', $servicos_ids);
                        foreach ($ids as $sid) {
                            $sid_limpo = trim($sid);
                            if (isset($servicosArr[$sid_limpo]) && !empty($servicosArr[$sid_limpo]['slots'])) {
                                $totalSlots += (int)$servicosArr[$sid_limpo]['slots'];
                            } else {
                                // Fallback: Se um serviço não for encontrado ou não tiver slots definidos, assume 1 slot (30 min)
                                $totalSlots += 1; 
                            }
                        }

                        // Adiciona os slots ocupados com base na duração total (totalSlots)
                        $timeParts = explode(':', $hora);
                        $startMinutes = (intval($timeParts[0]) * 60) + intval($timeParts[1]);
                        
                        for ($i = 0; $i < $totalSlots; $i++) {
                            $minutes = $startMinutes + ($i * 30);
                            $formatted = sprintf('%02d:%02d', floor($minutes / 60), $minutes % 60);
                            $horariosOcupados[] = $formatted;
                        }
                        // --- FIM DA ATUALIZAÇÃO ---
                    }
                } // Fim do while
                
                flock($fp, LOCK_UN); // Libera o bloqueio
            } else {
                log_activity("FALHA: Não foi possível obter LOCK_SH no arquivo $agendamentosFile (getHorariosOcupados).");
            }
            fclose($fp);
        }
    }

    // Adiciona bloqueios manuais e horários de almoço à lista de ocupados
    $horariosOcupados = array_merge($horariosOcupados, getHorariosBloqueados($barbeiro_id, $data)); // (Agora é seguro)
    $horariosOcupados = array_merge($horariosOcupados, getHorariosAlmocoBloqueados($barbeiro_id)); // (Agora é seguro)
    
    return array_unique($horariosOcupados);
}

/**
 * ATUALIZADO: Retorna um array de horários bloqueados manualmente (com LOCK_SH).
 *
 * @param string $barbeiro_id O ID do barbeiro.
 * @param string $data A data no formato 'Y-m-d'.
 * @return array Um array de horários 'H:i' bloqueados.
 */
function getHorariosBloqueados($barbeiro_id, $data) {
    $bloqueiosFile = DATA_DIR . 'horarios_bloqueados.txt';
    $horariosBloqueados = [];
    if (!file_exists($bloqueiosFile)) {
        return [];
    }

    $fp = fopen($bloqueiosFile, 'r');
    if (!$fp) {
        log_activity("FALHA: Não foi possível abrir o arquivo $bloqueiosFile para leitura (getHorariosBloqueados).");
        return [];
    }

    if (flock($fp, LOCK_SH)) {
        while (($b = fgets($fp)) !== false) {
            $b = trim($b);
            if (empty($b)) continue;
            
            $partes = explode('|', $b);
            if (count($partes) === 3) {
                list($b_barbeiro_id, $b_data, $b_hora) = $partes;
                if ($b_data === $data && $b_barbeiro_id === $barbeiro_id) {
                    $horariosBloqueados[] = $b_hora;
                }
            }
        }
        flock($fp, LOCK_UN);
    } else {
        log_activity("FALHA: Não foi possível obter LOCK_SH no arquivo $bloqueiosFile (getHorariosBloqueados).");
    }
    fclose($fp);
    
    return $horariosBloqueados;
}

/**
 * ATUALIZADO: Retorna os slots (1 hora = 2 slots) bloqueados para o almoço (com LOCK_SH).
 *
 * @param string $barbeiro_id O ID do barbeiro.
 * @return array Um array de 2 horários 'H:i' bloqueados para almoço.
 */
function getHorariosAlmocoBloqueados($barbeiro_id) {
    $almocoFile = DATA_DIR . 'config_almoco_barbeiro.txt';
    if (!file_exists($almocoFile)) {
        return [];
    }
    
    $horariosAlmoco = [];
    $fp = fopen($almocoFile, 'r');
    if (!$fp) {
        log_activity("FALHA: Não foi possível abrir o arquivo $almocoFile para leitura (getHorariosAlmocoBloqueados).");
        return [];
    }

    if (flock($fp, LOCK_SH)) {
        while (($linha = fgets($fp)) !== false) {
            $linha = trim($linha);
            if (empty($linha)) continue;
            
            $partes = explode('|', $linha);
            if (count($partes) === 3 && $partes[0] === $barbeiro_id && $partes[1] === 'ativo') {
                $horario_inicio = $partes[2];
                $horariosAlmoco[] = $horario_inicio;
                // Bloqueia 1 hora (2 slots de 30 min)
                $horariosAlmoco[] = date('H:i', strtotime($horario_inicio . ' +30 minutes'));
                break; 
            }
        }
        flock($fp, LOCK_UN);
    } else {
        log_activity("FALHA: Não foi possível obter LOCK_SH no arquivo $almocoFile (getHorariosAlmocoBloqueados).");
    }
    fclose($fp);
    
    return $horariosAlmoco;
}

/**
 * ATUALIZADO: Retorna o horário de início e fim de trabalho (com LOCK_SH).
 *
 * @param string $barbeiroId O ID do barbeiro.
 * @param int $diaSemana O dia da semana (0 = Domingo, 1 = Segunda, ...).
 * @return array|null ['inicio' => 'H:i', 'fim' => 'H:i'] ou null se não houver.
 */
function getHorarioDeTrabalho($barbeiroId, $diaSemana) {
    $horariosFile = DATA_DIR . 'horarios_trabalho.txt';
    if (!file_exists($horariosFile)) { return null; }
    
    $horarioEncontrado = null;
    $fp = fopen($horariosFile, 'r');
    if (!$fp) {
        log_activity("FALHA: Não foi possível abrir o arquivo $horariosFile para leitura (getHorarioDeTrabalho).");
        return null;
    }

    if (flock($fp, LOCK_SH)) {
        while (($h = fgets($fp)) !== false) {
            $h = trim($h);
            if (empty($h)) continue;
            
            $partes = explode('|', $h);
            if(count($partes) < 4) continue;
            list($id, $dia, $inicio, $fim) = $partes;
            if ($id == $barbeiroId && $dia == $diaSemana) {
                $horarioEncontrado = ['inicio' => $inicio, 'fim' => $fim];
                break; // Encontrou o horário, pode parar
            }
        }
        flock($fp, LOCK_UN);
    } else {
        log_activity("FALHA: Não foi possível obter LOCK_SH no arquivo $horariosFile (getHorarioDeTrabalho).");
    }
    fclose($fp);
    
    return $horarioEncontrado;
}

/**
 * Adiciona um produto vendido a um agendamento existente.
 * (Esta função já é segura, pois usa lerDados() e salvarDados())
 * Depende de: lerDados(), salvarDados()
 *
 * @param string $agendamento_id O ID do agendamento.
 * @param string $nome_produto O nome do produto.
 * @param float $valor_produto O valor do produto.
 * @return bool True se foi salvo com sucesso.
 */
function adicionarProdutoAoAgendamento($agendamento_id, $nome_produto, $valor_produto) {
    $keys_agendamentos = ['id', 'nome', 'email', 'telefone', 'barbeiro_id', 'servicos_ids', 'data', 'hora', 'status', 'desconto_aplicado', 'tipo_desconto', 'observacoes', 'produtos_vendidos'];
    $agendamentosArr = lerDados('agendamentos.txt', $keys_agendamentos); // (Seguro)

    if (isset($agendamentosArr[$agendamento_id])) {
        $produtos = !empty($agendamentosArr[$agendamento_id]['produtos_vendidos']) ? json_decode($agendamentosArr[$agendamento_id]['produtos_vendidos'], true) : [];
        $produtos[] = ['nome' => $nome_produto, 'valor' => $valor_produto];
        $agendamentosArr[$agendamento_id]['produtos_vendidos'] = json_encode($produtos);
        salvarDados('agendamentos.txt', $agendamentosArr, $keys_agendamentos); // (Seguro)
        return true;
    }
    return false;
}

// --- INÍCIO DA FUNÇÃO ADICIONADA (ESSENCIAL) ---

/**
 * Verifica se é o primeiro agendamento de um cliente (não cancelado).
 * Usa o ID do cliente para a verificação.
 * @param string $cliente_id O ID do cliente (ex: 'cl-xxxxx')
 * @return bool True se for o primeiro agendamento, False caso contrário.
 */
function isPrimeiroAgendamento($cliente_id) {
    $cliente = getClientById($cliente_id); // Pega dados do cliente (email/telefone)
    if (!$cliente) {
        // Se não achar o cliente, não pode verificar. Assume que NÃO é o primeiro.
        return false;
    }

    $agendamentosFile = DATA_DIR . 'agendamentos.txt';
    if (!file_exists($agendamentosFile)) {
        return true; // Arquivo não existe, com certeza é o primeiro.
    }

    // --- Leitura segura ---
    $fp = fopen($agendamentosFile, 'r');
    if (!$fp) {
        log_activity("FALHA: isPrimeiroAgendamento não conseguiu abrir agendamentos.txt");
        return false; // Falha na leitura, assume que não é o primeiro.
    }
    
    flock($fp, LOCK_SH); // Bloqueio de leitura
    $encontrado = false;
    
    while (($linha = fgets($fp)) !== false) {
        $linhaLimpa = trim($linha);
        if (empty($linhaLimpa)) continue;
        
        $partes = explode('|', $linhaLimpa);
        if (count($partes) < 9) continue; // Linha mal formatada
        
        // Colunas: 2:email, 3:telefone, 8:status
        $email_linha = $partes[2];
        $telefone_linha = limparTelefone($partes[3]);
        $status_linha = $partes[8];

        // Verifica se a linha pertence ao cliente E não está cancelada
        if (($email_linha === $cliente['email'] || $telefone_linha === $cliente['telefone']) && 
            $status_linha !== 'cancelado' && 
            $status_linha !== 'cancelado_pelo_cliente' &&
            $status_linha !== 'reprovado' &&
            $status_linha !== 'nao_compareceu') 
        {
            $encontrado = true;
            break;
        }
    }
    flock($fp, LOCK_UN); // Libera o bloqueio
    fclose($fp);
    
    // Retorna TRUE se NENHUM agendamento foi encontrado
    return !$encontrado;
}
// --- FIM DA FUNÇÃO ADICIONADA ---

?>