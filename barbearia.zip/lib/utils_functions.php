<?php
// lib/utils_functions.php
// Contém funções utilitárias gerais usadas em todo o sistema.

/**
 * Registra uma mensagem no arquivo de log global.
 * @param string $message A mensagem a ser registrada.
 */
function log_activity($message) {
    if (!file_exists(dirname(LOG_FILE))) {
        mkdir(dirname(LOG_FILE), 0755, true);
    }
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents(LOG_FILE, "[$timestamp] $message\n", FILE_APPEND);
}

/**
 * Remove todos os caracteres não numéricos de uma string.
 * @param string $telefone O número de telefone ou CPF a ser limpo.
 * @return string A string contendo apenas números.
 */
function limparTelefone($telefone) {
    return preg_replace('/\D/', '', $telefone);
}

/**
 * Valida um número de CPF brasileiro.
 * @param string $cpf O CPF (pode conter máscara).
 * @return bool True se o CPF for válido, False caso contrário.
 */
function validarCPF($cpf) {
    $cpf = preg_replace('/[^0-9]/is', '', $cpf);
    if (strlen($cpf) != 11) { return false; }
    if (preg_match('/(\d)\1{10}/', $cpf)) { return false; }
    for ($t = 9; $t < 11; $t++) {
        for ($d = 0, $c = 0; $c < $t; $c++) {
            $d += $cpf[$c] * (($t + 1) - $c);
        }
        $d = ((10 * $d) % 11) % 10;
        if ($cpf[$c] != $d) {
            return false;
        }
    }
    return true;
}

/**
 * Obtém os detalhes dos serviços de um combo.
 * @param array $combo O array do combo.
 * @param array $servicosArr O array de todos os serviços.
 * @return array Um array contendo os serviços do combo.
 */
function getServicesFromCombo($combo, $servicosArr) { 
    $services = []; 
    if (!isset($combo['servicos_ids'])) return $services; 
    $service_ids = explode(',', $combo['servicos_ids']); 
    foreach ($service_ids as $sid) { 
        $sid = trim($sid); 
        if (isset($servicosArr[$sid])) { 
            $services[] = $servicosArr[$sid]; 
        } 
    } 
    return $services; 
}
?>