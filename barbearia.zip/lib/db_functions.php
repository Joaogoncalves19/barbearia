<?php
// lib/db_functions.php
// Contém as funções principais de interação com o "banco de dados" (arquivos .txt).

/**
 * LÊ DADOS COM BLOQUEIO (LOCK_SH)
 * Lê dados de um arquivo .txt de forma segura, impedindo a leitura durante uma escrita.
 * @param string $fileName O nome do arquivo (ex: 'barbeiros.txt').
 * @param array $keys Um array com os nomes das colunas (ex: ['id', 'nome', 'foto']).
 * @return array Um array associativo onde a chave é o ID (primeira coluna).
 */
function lerDados($fileName, $keys) {
    $filePath = DATA_DIR . $fileName;
    if (!file_exists($filePath)) { return []; }

    $fp = fopen($filePath, 'r');
    if (!$fp) {
        log_activity("FALHA: Não foi possível abrir o arquivo $fileName para leitura.");
        return [];
    }
    
    $dados = [];
    // Solicita um bloqueio de LEITURA (LOCK_SH).
    // Se um processo de escrita (LOCK_EX) estiver ativo, esta linha irá esperar.
    if (flock($fp, LOCK_SH)) {
        while (($linha = fgets($fp)) !== false) {
            $linha = trim($linha);
            if (empty($linha)) continue;

            $partes = explode('|', $linha);
            $item = [];
            foreach ($partes as $i => $parte) {
                if (isset($keys[$i])) {
                    $item[$keys[$i]] = $parte;
                }
            }
            if (isset($partes[0]) && !empty($partes[0])) {
                $dados[$partes[0]] = $item;
            }
        }
        flock($fp, LOCK_UN); // Libera o bloqueio
    } else {
         log_activity("FALHA: Não foi possível obter LOCK_SH no arquivo $fileName.");
    }
    
    fclose($fp);
    return $dados;
}

/**
 * SALVA DADOS COM BLOQUEIO (LOCK_EX)
 * Salva um array associativo de volta em um arquivo .txt de forma segura.
 * @param string $fileName O nome do arquivo (ex: 'barbeiros.txt').
 * @param array $dados O array associativo de dados a ser salvo.
 * @param array $keys Um array com os nomes das colunas na ordem correta.
 */
function salvarDados($fileName, $dados, $keys) {
    $filePath = DATA_DIR . $fileName;
    $linhas = [];
    foreach ($dados as $item) {
        $linha = [];
        foreach ($keys as $key) {
            $linha[] = $item[$key] ?? '';
        }
        $linhas[] = implode('|', $linha);
    }
    
    // Usa file_put_contents com a flag LOCK_EX para escrita atômica e segura.
    file_put_contents($filePath, implode("\n", $linhas) . "\n", LOCK_EX);
}

/**
 * SALVA DADOS DO CLIENTE COM BLOQUEIO (LOCK_EX)
 * Função específica para salvar o arquivo de clientes (que tem uma ordem de chaves diferente).
 * @param array $clientesArr O array de clientes para salvar.
 */
function salvarDadosCliente($clientesArr) { 
    $clientesFile = DATA_DIR . 'clientes.txt'; 
    $linhas = []; 
    
    // --- INÍCIO DA CORREÇÃO ---
    // Adicionada a coluna 'indicado_por_id' na ordem correta
    $keys_clientes_completo = [
        'id', 'nome', 'email', 'telefone', 'password_hash', 
        'data_nascimento', 'foto_perfil', 'codigo_indicacao', 'cpf', 
        'indicado_por_id', // <-- CORREÇÃO
        'status', 'confirmation_token'
    ];
    // --- FIM DA CORREÇÃO ---

    foreach ($clientesArr as $item) { 
        $linha = []; 
        foreach ($keys_clientes_completo as $key) { 
            $linha[] = $item[$key] ?? ''; 
        } 
        $linhas[] = implode('|', $linha); 
    } 
    
    // Usa file_put_contents com a flag LOCK_EX para escrita atômica e segura.
    file_put_contents($clientesFile, implode("\n", $linhas) . "\n", LOCK_EX); 
}

/**
 * Lê o arquivo de anotações e retorna um array [cliente_id => anotacao].
 * (Usa a função lerDados() que já é segura)
 * @return array
 */
function lerAnotacoesTodosClientes() { 
    $anotacoesFile = 'anotacoes_clientes.txt'; 
    // Esta função já usa lerDados(), que agora tem LOCK_SH, então está segura.
    $anotacoesRaw = lerDados($anotacoesFile, ['id', 'anotacao']);
    
    $anotacoes = [];
    foreach ($anotacoesRaw as $id => $data) {
        if(isset($data['anotacao'])) {
            $anotacoes[$id] = $data['anotacao'];
        }
    }
    return $anotacoes;
}


/**
 * SALVA ANOTAÇÃO DO CLIENTE COM BLOQUEIO (LOCK_EX)
 * Salva (ou atualiza) a anotação de um cliente específico.
 * @param string $cliente_id ID do cliente.
 * @param string $anotacao Texto da anotação.
 */
function salvarAnotacaoCliente($cliente_id, $anotacao) { 
    $anotacoesFile = DATA_DIR . 'anotacoes_clientes.txt'; 
    $anotacoes = lerAnotacoesTodosClientes(); // Leitura segura
    
    $anotacaoLimpa = str_replace(["\r", "\n"], ' ', $anotacao);
    
    // Se a anotação estiver vazia, remove a entrada
    if (empty($anotacaoLimpa)) {
        unset($anotacoes[$cliente_id]);
    } else {
        $anotacoes[$cliente_id] = $anotacaoLimpa;
    }
    
    $linhas = []; 
    foreach ($anotacoes as $id => $texto) { 
        $linhas[] = "$id|$texto"; // Recria no formato simples de 2 colunas
    } 
    
    // Usa file_put_contents com a flag LOCK_EX para escrita atômica e segura.
    file_put_contents($anotacoesFile, implode("\n", $linhas) . "\n", LOCK_EX); 
}

?>