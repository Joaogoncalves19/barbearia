<?php
// lib/notificacao_functions.php
// Contém funções para criar, ler e gerenciar as notificações internas dos clientes.

/**
 * ATUALIZADO: Cria uma nova notificação (com FILE_APPEND | LOCK_EX).
 * @param string $cliente_id O ID do cliente.
 * @param string $mensagem A mensagem da notificação.
 */
function criarNotificacao($cliente_id, $mensagem) { 
    $notificacoesFile = DATA_DIR . 'notificacoes.txt'; 
    $id_notificacao = uniqid('notif-'); 
    $timestamp = date('Y-m-d H:i:s'); 
    $status = 'nao_lida'; 
    $linha = "$id_notificacao|$cliente_id|$mensagem|$timestamp|$status\n"; 
    
    // Adiciona ao arquivo com bloqueio exclusivo (LOCK_EX)
    file_put_contents($notificacoesFile, $linha, FILE_APPEND | LOCK_EX); 
}

/**
 * ATUALIZADO: Lê todas as notificações de um cliente (com LOCK_SH).
 * @param string $cliente_id O ID do cliente.
 * @return array
 */
function lerNotificacoesCliente($cliente_id) { 
    $notificacoesFile = DATA_DIR . 'notificacoes.txt'; 
    if (!file_exists($notificacoesFile)) { return []; } 
    
    $notificacoes = []; 
    $linhas = [];

    $fp = fopen($notificacoesFile, 'r');
    if (!$fp) {
        log_activity("FALHA: Não foi possível abrir o arquivo $notificacoesFile (lerNotificacoesCliente).");
        return [];
    }

    // Solicita bloqueio de leitura
    if (flock($fp, LOCK_SH)) {
        while (($linha = fgets($fp)) !== false) {
            $linhas[] = trim($linha);
        }
        flock($fp, LOCK_UN); // Libera o bloqueio
    } else {
        log_activity("FALHA: Não foi possível obter LOCK_SH no arquivo $notificacoesFile (lerNotificacoesCliente).");
    }
    fclose($fp);

    foreach (array_reverse($linhas) as $linha) { 
        if (empty($linha)) continue;
        
        $partes = explode('|', $linha); 
        if (count($partes) === 5 && $partes[1] === $cliente_id) { 
            $notificacoes[] = [ 
                'id' => $partes[0], 
                'cliente_id' => $partes[1], 
                'mensagem' => $partes[2], 
                'timestamp' => $partes[3], 
                'status' => $partes[4] 
            ]; 
        } 
    } 
    return $notificacoes; 
}

/**
 * ATUALIZADO: Marca todas as notificações de um cliente como 'lida' (com LOCK_EX).
 * @param string $cliente_id O ID do cliente.
 */
function marcarNotificacoesComoLidas($cliente_id) { 
    $notificacoesFile = DATA_DIR . 'notificacoes.txt'; 
    if (!file_exists($notificacoesFile)) { return; } 

    $fp = fopen($notificacoesFile, 'c+');
    if (!$fp) {
        log_activity("FALHA: Não foi possível abrir o arquivo $notificacoesFile (marcarNotificacoesComoLidas).");
        return;
    }

    // Solicita bloqueio exclusivo para ler e depois escrever
    if (flock($fp, LOCK_EX)) {
        $linhas = [];
        while (($linha = fgets($fp)) !== false) {
            $linhas[] = trim($linha);
        }
        
        $novasLinhas = []; 
        $alterado = false;
        foreach ($linhas as $linha) { 
            if (empty($linha)) continue;
            
            $partes = explode('|', $linha); 
            if (count($partes) === 5 && $partes[1] === $cliente_id && $partes[4] === 'nao_lida') { 
                $partes[4] = 'lida'; 
                $novasLinhas[] = implode('|', $partes); 
                $alterado = true;
            } else { 
                $novasLinhas[] = $linha; 
            } 
        } 
        
        // Se alguma linha foi alterada, reescreve o arquivo
        if ($alterado) {
            ftruncate($fp, 0); // Limpa o arquivo
            rewind($fp); // Volta ao início
            fwrite($fp, implode("\n", $novasLinhas) . (empty($novasLinhas) ? "" : "\n"));
        }
        
        flock($fp, LOCK_UN); // Libera o bloqueio
    } else {
        log_activity("FALHA: Não foi possível obter LOCK_EX no arquivo $notificacoesFile (marcarNotificacoesComoLidas).");
    }
    
    fclose($fp);
}
?>