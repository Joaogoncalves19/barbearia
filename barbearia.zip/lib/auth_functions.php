<?php
// lib/auth_functions.php
// Contém funções de autenticação e gerenciamento de usuários (clientes, barbeiros).

/**
 * Busca um barbeiro pelo seu username.
 * Depende de: lerDados()
 * @param string $username O username do barbeiro.
 * @return array|null Os dados do barbeiro ou null se não encontrado.
 */
function getBarbeiroByUsername($username) {
    $barbeirosArr = lerDados('barbeiros.txt', ['id', 'nome', 'foto', 'username', 'password']); // (Seguro)
    foreach ($barbeirosArr as $barbeiro) {
        if (isset($barbeiro['username']) && $barbeiro['username'] === $username) {
            return $barbeiro;
        }
    }
    return null;
}

/**
 * ATUALIZADO: Busca um cliente pelo e-mail, telefone ou CPF (com LOCK_SH).
 * Esta é a ÚNICA versão desta função.
 * Depende de: limparTelefone(), getClientById()
 * @param string $identificador O e-mail, telefone ou CPF.
 * @return array|null Os dados do cliente ou null se não encontrado.
 */
function getClientePorEmailTelefoneOuCPF($identificador) {
    // --- INÍCIO DA CORREÇÃO ---
    // Define as chaves corretas e completas que 'lerDados' espera
    $keys = [
        'id', 'nome', 'email', 'telefone', 'password_hash', 
        'data_nascimento', 'foto_perfil', 'codigo_indicacao', 'cpf', 
        'indicado_por_id', 'status', 'confirmation_token'
    ];
    $clientesArr = lerDados('clientes.txt', $keys); // (Seguro)
    // --- FIM DA CORREÇÃO ---

    $telefoneLimpo = limparTelefone($identificador);
    $cpfLimpo = limparTelefone($identificador);

    foreach ($clientesArr as $cliente) {
        // Verifica se o e-mail bate
        if ($cliente['email'] === $identificador) {
            return $cliente; // Retorna o array completo
        }
        // Verifica se o telefone bate
        if (limparTelefone($cliente['telefone']) === $telefoneLimpo) {
             return $cliente; // Retorna o array completo
        }
        // Verifica se o CPF bate (e se o CPF foi fornecido na busca)
        if (!empty($cliente['cpf']) && !empty($cpfLimpo) && $cliente['cpf'] === $cpfLimpo) {
             return $cliente; // Retorna o array completo
        }
    }
    
    return null;
}


/**
 * Busca um cliente pelo seu ID.
 * Gera um código de indicação se o cliente não tiver um.
 * (Esta função já é segura, pois usa lerDados() e salvarDadosCliente())
 * Depende de: lerDados(), salvarDadosCliente()
 * @param string $cliente_id O ID do cliente.
 * @return array|null Os dados do cliente ou null se não encontrado.
 */
function getClientById($cliente_id) {
    // --- INÍCIO DA CORREÇÃO ---
    // Define as chaves corretas e completas que 'lerDados' espera
    $keys_clientes_completo = [
        'id', 'nome', 'email', 'telefone', 'password_hash', 
        'data_nascimento', 'foto_perfil', 'codigo_indicacao', 'cpf', 
        'indicado_por_id', 'status', 'confirmation_token'
    ];
    // --- FIM DA CORREÇÃO ---
    
    $clientesArr = lerDados('clientes.txt', $keys_clientes_completo); // (Seguro)
    
    if (isset($clientesArr[$cliente_id])) {
        $cliente = $clientesArr[$cliente_id];
        
        // Lógica de negócio: Gera um código de indicação se não existir
        if (empty($cliente['codigo_indicacao'])) {
            $cliente['codigo_indicacao'] = strtoupper(substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 6));
            $clientesArr[$cliente_id]['codigo_indicacao'] = $cliente['codigo_indicacao'];
            
            // Salva a alteração (salvarDadosCliente() é segura)
            salvarDadosCliente($clientesArr); 
        }
        
        // Garante que o status tenha um valor padrão se estiver faltando (para clientes antigos)
        if (empty($cliente['status'])) {
            $cliente['status'] = 'ativo';
        }

        return $cliente;
    }
    
    return null;
}

/**
 * ATUALIZADO: Busca um cliente pelo seu código de indicação (com LOCK_SH).
 * Depende de: getClientById()
 * @param string $code O código de indicação.
 * @return array|null Os dados do cliente ou null se não encontrado.
 */
function getClientByReferralCode($code) { 
    $clientesFile = DATA_DIR . 'clientes.txt'; 
    if (!file_exists($clientesFile)) return null; 

    $fp = fopen($clientesFile, 'r');
    if (!$fp) {
        log_activity("FALHA: Não foi possível abrir o arquivo clientes.txt (getClientByReferralCode).");
        return null;
    }
    
    $clienteEncontradoId = null;

    // Solicita bloqueio de leitura (LOCK_SH)
    if (flock($fp, LOCK_SH)) {
        while (($c = fgets($fp)) !== false) {
            $c = trim($c);
            if(empty($c)) continue;

            $parts = explode('|', $c); 
            // Estrutura esperada: 0:id ... 7:codigo_indicacao ...
            if (isset($parts[7]) && $parts[7] === $code) { 
                $clienteEncontradoId = $parts[0];
                break; 
            } 
        }
        flock($fp, LOCK_UN); // Libera o bloqueio
    } else {
         log_activity("FALHA: Não foi possível obter LOCK_SH no arquivo clientes.txt (getClientByReferralCode).");
    }
    fclose($fp);

    if ($clienteEncontradoId) {
        // getClientById já é segura
        return getClientById($clienteEncontradoId); 
    }
    
    return null; 
}
?>