<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seu Agendamento foi Aprovado!</title>
    <style>
        body { font-family: 'Poppins', sans-serif; margin: 0; padding: 0; background-color: #e9ecef; }
        .container { width: 100%; max-width: 600px; margin: 20px auto; background-color: #ffffff; padding: 0; border-radius: 15px; box-shadow: 0 8px 30px rgba(0,0,0,0.15); overflow: hidden; }
        .header { background-color: #212529; text-align: center; padding: 35px 20px; border-bottom: 5px solid #28a745; position: relative; }
        .header img { max-width: 180px; height: auto; display: block; margin: 0 auto; }
        .header h1 { color: #ffffff; font-size: 32px; margin: 10px 0 0; font-weight: 700; }
        .content { padding: 30px; line-height: 1.8; color: #495057; }
        .content h2 { color: #212529; font-size: 28px; margin-bottom: 20px; text-align: center; font-weight: 700; }
        .content p { margin-bottom: 25px; font-size: 17px; text-align: center; }
        .status-box { background-color: #28a745; color: #ffffff; padding: 18px; margin: 25px 0; border-radius: 10px; text-align: center; font-size: 1.4em; font-weight: bold; letter-spacing: 1px; box-shadow: 0 4px 10px rgba(40, 167, 69, 0.4); }
        .details-card { background-color: #f8f9fa; border-left: 5px solid #28a745; padding: 25px; margin: 30px 0; border-radius: 10px; }
        .details-card h3 { margin: 0 0 18px 0; font-size: 20px; color: #212529; border-bottom: 1px solid #dee2e6; padding-bottom: 12px; font-weight: 600; }
        .details-card p { margin: 12px 0; display: flex; justify-content: space-between; align-items: center; font-size: 16px; text-align: left;}
        .details-card strong { color: #212529; font-weight: 700; }
        
        .vip-info { background-color: #f3e5f5; border: 1px solid #e1bee7; color: #4a148c; padding: 12px; border-radius: 8px; margin-bottom: 20px; text-align: center; }
        
        .actions { text-align: center; margin-top: 40px; }
        .actions .btn { display: inline-block; padding: 14px 30px; background-color: #007bff; color: #ffffff; text-decoration: none; font-weight: bold; border-radius: 50px; transition: background-color 0.3s ease, transform 0.2s ease; font-size: 18px; box-shadow: 0 4px 15px rgba(0,123,255,0.3); }
        .actions .btn:hover { background-color: #0056b3; transform: translateY(-2px); }
        .footer { background-color: #212529; color: #adb5bd; text-align: center; padding: 30px; font-size: 14px; border-top: 5px solid #28a745; }
        .footer a { color: #007bff; text-decoration: none; transition: color 0.3s ease; }
        .footer a:hover { color: #0056b3; }
        .social-icons { margin-top: 20px; }
        .social-icons a { margin: 0 10px; display: inline-block; }
        .social-icons img { width: 30px; height: 30px; transition: transform 0.2s ease; }
        .social-icons img:hover { transform: scale(1.1); }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="header">
            <?php if (!empty($logo_url)): ?>
                <img src="<?= htmlspecialchars($logo_url) ?>" alt="<?= htmlspecialchars($configGeral['nome_barbearia']) ?>">
            <?php else: ?>
                <h1><?= htmlspecialchars($configGeral['nome_barbearia']) ?></h1>
            <?php endif; ?>
        </div>
        <div class="content">
            <h2>🎉 Boas notícias, <?= htmlspecialchars($dados['nome_cliente']) ?>! 🎉</h2>
            <p>Sua cadeira está reservada! Seu agendamento na <strong><?= htmlspecialchars($configGeral['nome_barbearia']) ?></strong> foi confirmado com sucesso.</p>
            
            <div class="status-box">
                AGENDAMENTO CONFIRMADO!
            </div>

            <?php if (($dados['tipo_desconto'] ?? '') === 'adesao_plano'): ?>
                <div class="vip-info">
                    <h3>👑 Bem-vindo ao Clube VIP!</h3>
                    <p style="margin-bottom: 0;">Este agendamento inclui a ativação da sua assinatura. Prepare-se para uma experiência exclusiva!</p>
                </div>
            <?php endif; ?>

            <div class="details-card">
                <h3>💈 Resumo do seu Agendamento</h3>
                <p><strong>Barbeiro:</strong> <span><?= htmlspecialchars($dados['barbeiro']) ?></span></p>
                <p><strong>Serviços:</strong> <span><?= htmlspecialchars(implode(', ', $dados['servicos'])) ?></span></p>
                <p><strong>Data:</strong> <span><?= htmlspecialchars($dados['data_agendamento']) ?></span></p>
                <p><strong>Hora:</strong> <span><?= htmlspecialchars($dados['hora_agendamento']) ?></span></p>
            </div>
            
            <p>Estamos ansiosos para te receber e garantir um visual impecável! Se precisar fazer qualquer alteração ou tiver dúvidas, acesse sua conta em nosso site.</p>

            <div class="actions">
                <a href="<?= rtrim((isset($_SERVER['HTTPS']) ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']), '/\\') . '/minha_conta.php' ?>" class="btn">Gerenciar Meu Agendamento</a>
            </div>
        </div>
        <div class="footer">
            <p><?= htmlspecialchars($configGeral['endereco']) ?></p>
            <p>Telefone: <?= htmlspecialchars($configGeral['telefone_contato']) ?></p>
            <div class="social-icons">
                 <?php if (!empty($configGeral['link_instagram'])): ?><a href="<?= htmlspecialchars($configGeral['link_instagram']) ?>" target="_blank"><img src="https://img.icons8.com/color/48/000000/instagram-new--v1.png" alt="Instagram"></a><?php endif; ?>
                 <?php if (!empty($configGeral['link_whatsapp'])): ?><a href="https://wa.me/<?= htmlspecialchars(preg_replace('/\D/', '', $configGeral['link_whatsapp'])) ?>" target="_blank"><img src="https://img.icons8.com/color/48/000000/whatsapp--v1.png" alt="WhatsApp"></a><?php endif; ?>
            </div>
            <p style="margin-top: 20px;">Seus amigos da <strong><?= htmlspecialchars($configGeral['nome_barbearia']) ?></strong></p>
        </div>
    </div>
</body>
</html>