<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($dados['assunto_email']) ?></title>
    <style>
        body { font-family: 'Poppins', sans-serif; margin: 0; padding: 0; background-color: #e9ecef; }
        .container { width: 100%; max-width: 600px; margin: 20px auto; background-color: #ffffff; padding: 0; border-radius: 15px; box-shadow: 0 8px 30px rgba(0,0,0,0.15); overflow: hidden; }
        .header { background-color: #212529; text-align: center; padding: 35px 20px; border-bottom: 5px solid #007bff; }
        .header img { max-width: 180px; height: auto; display: block; margin: 0 auto; }
        .header h1 { color: #ffffff; font-size: 32px; margin: 10px 0 0; font-weight: 700; }
        .content { padding: 30px; line-height: 1.8; color: #495057; }
        .content h2 { color: #212529; font-size: 28px; margin-bottom: 20px; text-align: left; font-weight: 700; }
        .content p { margin-bottom: 25px; font-size: 17px; text-align: left; }
        .footer { background-color: #212529; color: #adb5bd; text-align: center; padding: 30px; font-size: 14px; border-top: 5px solid #007bff; }
        .footer a { color: #007bff; text-decoration: none; transition: color 0.3s ease; }
        .footer a:hover { color: #0056b3; }
        .social-icons { margin-top: 20px; }
        .social-icons a { margin: 0 10px; display: inline-block; }
        .social-icons img { width: 30px; height: 30px; transition: transform 0.2s ease; }
        .social-icons img:hover { transform: scale(1.1); }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="header">
            <?php if (!empty($logo_url)): ?>
                <img src="<?= htmlspecialchars($logo_url) ?>" alt="<?= htmlspecialchars($configGeral['nome_barbearia']) ?>">
            <?php else: ?>
                <h1><?= htmlspecialchars($configGeral['nome_barbearia']) ?></h1>
            <?php endif; ?>
        </div>
        <div class="content">
            <h2>Olá, <?= htmlspecialchars($dados['nome_cliente']) ?>!</h2>
            
            <p><?= $dados['corpo_email'] ?></p>
            
            <p style="margin-top: 30px; font-size: 15px;">Atenciosamente,<br>Equipe <?= htmlspecialchars($configGeral['nome_barbearia']) ?></p>
        </div>
        <div class="footer">
            <p><?= htmlspecialchars($configGeral['endereco']) ?></p>
            <p>Telefone: <?= htmlspecialchars($configGeral['telefone_contato']) ?></p>
            <div class="social-icons">
                 <?php if (!empty($configGeral['link_instagram'])): ?><a href="<?= htmlspecialchars($configGeral['link_instagram']) ?>" target="_blank"><img src="https://img.icons8.com/color/48/000000/instagram-new--v1.png" alt="Instagram"></a><?php endif; ?>
                 <?php if (!empty($configGeral['link_whatsapp'])): ?><a href="https://wa.me/<?= htmlspecialchars(preg_replace('/\D/', '', $configGeral['link_whatsapp'])) ?>" target="_blank"><img src="https://img.icons8.com/color/48/000000/whatsapp--v1.png" alt="WhatsApp"></a><?php endif; ?>
            </div>
            <p style="margin-top: 20px;">Seus amigos da <strong><?= htmlspecialchars($configGeral['nome_barbearia']) ?></strong></p>
        </div>
    </div>
</body>
</html>