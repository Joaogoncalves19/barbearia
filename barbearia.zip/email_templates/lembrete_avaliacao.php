<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sua opinião é importante!</title>
    <style>
        body { font-family: 'Poppins', sans-serif; margin: 0; padding: 0; background-color: #e9ecef; }
        .container { width: 100%; max-width: 600px; margin: 20px auto; background-color: #ffffff; padding: 0; border-radius: 15px; box-shadow: 0 8px 30px rgba(0,0,0,0.15); overflow: hidden; }
        .header { background-color: #212529; text-align: center; padding: 35px 20px; border-bottom: 5px solid #ffc107; } /* Cor Amarela (avaliação) */
        .header img { max-width: 180px; height: auto; display: block; margin: 0 auto; }
        .header h1 { color: #ffffff; font-size: 32px; margin: 10px 0 0; font-weight: 700; }
        .content { padding: 30px; line-height: 1.8; color: #495057; }
        .content h2 { color: #212529; font-size: 28px; margin-bottom: 20px; text-align: center; font-weight: 700; }
        .content p { margin-bottom: 25px; font-size: 17px; text-align: center; }
        
        .details-card { background-color: #f8f9fa; border-left: 5px solid #ffc107; padding: 25px; margin: 30px 0; border-radius: 10px; }
        .details-card h3 { margin: 0 0 18px 0; font-size: 20px; color: #212529; border-bottom: 1px solid #dee2e6; padding-bottom: 12px; font-weight: 600; }
        .details-card p { margin: 12px 0; display: flex; justify-content: space-between; align-items: center; font-size: 16px; text-align: left;}
        .details-card strong { color: #212529; font-weight: 700; }
        
        .actions { text-align: center; margin-top: 40px; }
        .actions .btn { display: inline-block; padding: 14px 30px; background-color: #007bff; color: #ffffff; text-decoration: none; font-weight: bold; border-radius: 50px; transition: background-color 0.3s ease, transform 0.2s ease; font-size: 18px; box-shadow: 0 4px 15px rgba(0,123,255,0.3); }
        .actions .btn:hover { background-color: #0056b3; transform: translateY(-2px); }
        
        .footer { background-color: #212529; color: #adb5bd; text-align: center; padding: 30px; font-size: 14px; border-top: 5px solid #ffc107; }
        .footer a { color: #007bff; text-decoration: none; }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="header">
            <?php if (!empty($logo_url)): ?>
                <img src="<?= htmlspecialchars($logo_url) ?>" alt="<?= htmlspecialchars($configGeral['nome_barbearia']) ?>">
            <?php else: ?>
                <h1><?= htmlspecialchars($configGeral['nome_barbearia']) ?></h1>
            <?php endif; ?>
        </div>
        <div class="content">
            <h2>Obrigado, <?= htmlspecialchars($dados['nome_cliente']) ?>!</h2>
            <p>Agradecemos por sua visita à <strong><?= htmlspecialchars($configGeral['nome_barbearia']) ?></strong>. Sua opinião é muito importante para nós!</p>

            <div class="details-card">
                <h3>💈 Resumo do seu Atendimento</h3>
                <p><strong>Barbeiro:</strong> <span><?= htmlspecialchars($dados['barbeiro']) ?></span></p>
                <p><strong>Data:</strong> <span><?= htmlspecialchars($dados['data_agendamento']) ?></span></p>
            </div>
            
            <p>Que tal dedicar um minuto para nos dizer como foi sua experiência? Seu feedback nos ajuda a melhorar sempre.</p>

            <div class="actions">
                <a href="<?= rtrim((isset($_SERVER['HTTPS']) ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']), '/\\') . '/minha_conta.php' ?>" class="btn">Deixar minha Avaliação</a>
            </div>
        </div>
        <div class="footer">
            <p><?= htmlspecialchars($configGeral['endereco']) ?></p>
            <p>Telefone: <?= htmlspecialchars($configGeral['telefone_contato']) ?></p>
            <p style="margin-top: 20px;">Atenciosamente, <strong><?= htmlspecialchars($configGeral['nome_barbearia']) ?></strong></p>
        </div>
    </div>
</body>
</html>