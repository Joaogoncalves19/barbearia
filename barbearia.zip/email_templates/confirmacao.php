<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmação de Agendamento</title>
    <style>
        body { font-family: 'Poppins', sans-serif; margin: 0; padding: 0; background-color: #e9ecef; }
        .container { width: 100%; max-width: 600px; margin: 20px auto; background-color: #ffffff; padding: 0; border-radius: 15px; box-shadow: 0 8px 30px rgba(0,0,0,0.15); overflow: hidden; }
        .header { background-color: #212529; text-align: center; padding: 35px 20px; border-bottom: 5px solid #007bff; }
        .header img { max-width: 180px; height: auto; display: block; margin: 0 auto; }
        .header h1 { color: #ffffff; font-size: 32px; margin: 10px 0 0; font-weight: 700; }
        .content { padding: 30px; line-height: 1.8; color: #495057; }
        .content h2 { color: #212529; font-size: 28px; margin-bottom: 20px; text-align: center; font-weight: 700; }
        .content p { margin-bottom: 25px; font-size: 17px; text-align: center; }
        .status-box { padding: 18px; margin: 25px 0; border-radius: 10px; text-align: center; font-size: 1.4em; font-weight: bold; letter-spacing: 1px; color: #ffffff; }
        .status-pendente { background-color: #ffc107; box-shadow: 0 4px 10px rgba(255, 193, 7, 0.4); }
        .status-confirmado { background-color: #28a745; box-shadow: 0 4px 10px rgba(40, 167, 69, 0.4); }
        .details-card { background-color: #f8f9fa; border-left: 5px solid #007bff; padding: 25px; margin: 30px 0; border-radius: 10px; }
        .details-card h3 { margin: 0 0 18px 0; font-size: 20px; color: #212529; border-bottom: 1px solid #dee2e6; padding-bottom: 12px; font-weight: 600; }
        .details-card p { margin: 12px 0; display: flex; justify-content: space-between; align-items: center; font-size: 16px; text-align: left; }
        .details-card strong { color: #212529; font-weight: 700; }
        
        .vip-badge { background-color: #6f42c1; color: white; padding: 2px 8px; border-radius: 4px; font-size: 0.8em; font-weight: bold; display: inline-block; vertical-align: middle; margin-left: 5px; }
        .vip-info { background-color: #f3e5f5; border: 1px solid #e1bee7; color: #4a148c; padding: 10px; border-radius: 8px; margin-top: 15px; font-size: 0.9em; text-align: center; }

        .footer { background-color: #212529; color: #adb5bd; text-align: center; padding: 30px; font-size: 14px; border-top: 5px solid #007bff; }
        .footer a { color: #007bff; text-decoration: none; transition: color 0.3s ease; }
        .footer a:hover { color: #0056b3; }
        .social-icons { margin-top: 20px; }
        .social-icons a { margin: 0 10px; display: inline-block; }
        .social-icons img { width: 30px; height: 30px; transition: transform 0.2s ease; }
        .social-icons img:hover { transform: scale(1.1); }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="header">
            <?php if (!empty($logo_url)): ?>
                <img src="<?= htmlspecialchars($logo_url) ?>" alt="<?= htmlspecialchars($configGeral['nome_barbearia']) ?>">
            <?php else: ?>
                <h1><?= htmlspecialchars($configGeral['nome_barbearia']) ?></h1>
            <?php endif; ?>
        </div>
        <div class="content">
            <h2>Quase lá, <?= htmlspecialchars($dados['nome_cliente']) ?>!</h2>
            <p>Recebemos o seu pedido de agendamento! Confira os detalhes e o status atual abaixo.</p>
            
            <div class="details-card">
                <h3>💈 Resumo do Agendamento</h3>
                <p><strong>Barbeiro:</strong> <span><?= htmlspecialchars($dados['barbeiro']) ?></span></p>
                <p><strong>Serviços:</strong> <span><?= htmlspecialchars(implode(', ', $dados['servicos'])) ?></span></p>
                <p><strong>Data:</strong> <span><?= htmlspecialchars($dados['data_agendamento']) ?></span></p>
                <p><strong>Hora:</strong> <span><?= htmlspecialchars($dados['hora_agendamento']) ?></span></p>
                
                <?php if (($dados['tipo_desconto'] ?? '') === 'adesao_plano'): ?>
                    <div class="vip-info">
                        <strong><span style="font-size:1.2em">👑</span> Adesão de Plano VIP Inclusa!</strong><br>
                        Sua assinatura será ativada no momento do atendimento.
                    </div>
                <?php elseif (($dados['tipo_desconto'] ?? '') === 'assinatura_vip' || ($dados['tipo_desconto'] ?? '') === 'assinatura'): ?>
                    <div class="vip-info" style="background-color: #e8f5e9; border-color: #c3e6cb; color: #155724;">
                        <strong><span style="font-size:1.2em">✅</span> Benefício VIP Aplicado</strong><br>
                        Serviços inclusos no seu plano saíram com 100% de desconto.
                    </div>
                <?php endif; ?>
            </div>

            <?php if ($dados['status'] === 'pendente'): ?>
                <div class="status-box status-pendente">
                    STATUS: AGUARDANDO APROVAÇÃO
                </div>
                <p>Seu horário agora aguarda a confirmação da nossa equipe. Fique tranquilo, você receberá um novo e-mail assim que for aprovado!</p>
            <?php else: ?>
                <div class="status-box status-confirmado">
                    STATUS: AGENDAMENTO CONFIRMADO
                </div>
                <p>Seu horário já está confirmado em nossa agenda. Nos vemos em breve!</p>
            <?php endif; ?>
        </div>
        <div class="footer">
            <p><?= htmlspecialchars($configGeral['endereco']) ?></p>
            <p>Telefone: <?= htmlspecialchars($configGeral['telefone_contato']) ?></p>
             <div class="social-icons">
                 <?php if (!empty($configGeral['link_instagram'])): ?><a href="<?= htmlspecialchars($configGeral['link_instagram']) ?>" target="_blank"><img src="https://img.icons8.com/color/48/000000/instagram-new--v1.png" alt="Instagram"></a><?php endif; ?>
                 <?php if (!empty($configGeral['link_whatsapp'])): ?><a href="https://wa.me/<?= htmlspecialchars(preg_replace('/\D/', '', $configGeral['link_whatsapp'])) ?>" target="_blank"><img src="https://img.icons8.com/color/48/000000/whatsapp--v1.png" alt="WhatsApp"></a><?php endif; ?>
            </div>
            <p style="margin-top: 20px;">Seus amigos da <strong><?= htmlspecialchars($configGeral['nome_barbearia']) ?></strong></p>
        </div>
    </div>
</body>
</html>