<?php
session_start();
date_default_timezone_set('America/Sao_Paulo');

if (!isset($_SESSION['barbeiro_loggedin'])) {
    header('Location: login.php');
    exit;
}

require_once 'functions.php';

$agendamento_id = $_GET['id'] ?? null;
if (!$agendamento_id) {
    header('Location: painel_barbeiro.php?error=agendamento_invalido');
    exit;
}

// --- CORREÇÃO: Lê TODAS as colunas para não perder dados ao salvar ---
$keys_agendamentos = [
    'id', 'nome', 'email', 'telefone', 'barbeiro_id', 'servicos_ids', 
    'data', 'hora', 'status', 'desconto_aplicado', 'tipo_desconto', 
    'observacoes', 'produtos_vendidos', 'plano_provisorio'
];
$agendamentosArr = lerDados('agendamentos.txt', $keys_agendamentos);
// --- FIM DA CORREÇÃO ---

$agendamento_atual = $agendamentosArr[$agendamento_id] ?? null;
$barbeiro_id_logado = $_SESSION['barbeiro_id'];

if (!$agendamento_atual || $agendamento_atual['barbeiro_id'] !== $barbeiro_id_logado) {
    header('Location: painel_barbeiro.php?error=permissao_negada');
    exit;
}

$servicosArr = lerDados('servicos.txt', ['id', 'nome', 'valor']);
$combosArr = lerDados('combos.txt', ['id', 'nome']); 
$barbeirosArr = lerDados('barbeiros.txt', ['id', 'nome', 'foto']);

$servicos_agendamento_nomes = [];
$ids = explode(',', $agendamento_atual['servicos_ids']);
foreach ($ids as $sid) {
    $sid = trim($sid);
    if(isset($servicosArr[$sid])) $servicos_agendamento_nomes[] = $servicosArr[$sid]['nome'];
    elseif(isset($combosArr[$sid])) $servicos_agendamento_nomes[] = $combosArr[$sid]['nome'] . " (Combo)";
    else $servicos_agendamento_nomes[] = '?';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nova_data = $_POST['reagendar_data'];
    $novo_horario = $_POST['reagendar_horario'];

    $agendamento_original = $agendamentosArr[$agendamento_id];
    $agendamentosArr[$agendamento_id]['status'] = 'cancelado';
    
    $novo_agendamento_id = uniqid('ag-');
    $novo_agendamento = $agendamento_original; 
    $novo_agendamento['id'] = $novo_agendamento_id;
    $novo_agendamento['data'] = $nova_data;
    $novo_agendamento['hora'] = $novo_horario;
    $novo_agendamento['status'] = 'aprovado';
    
    $agendamentosArr[$novo_agendamento_id] = $novo_agendamento;

    salvarDados('agendamentos.txt', $agendamentosArr, $keys_agendamentos);

    $configAgendamentoEmail = carregarConfigAgendamento();
    if (filter_var($novo_agendamento['email'], FILTER_VALIDATE_EMAIL) && ($configAgendamentoEmail['notif_aprovacao'] ?? 0) == 1) {
        $dados_email = [
            'nome_cliente' => $novo_agendamento['nome'],
            'data_agendamento' => date('d/m/Y', strtotime($nova_data)),
            'hora_agendamento' => $novo_horario,
            'servicos' => $servicos_agendamento_nomes,
            'barbeiro' => $barbeirosArr[$novo_agendamento['barbeiro_id']]['nome'] ?? 'Não especificado',
            'tipo_desconto' => $novo_agendamento['tipo_desconto'] ?? '' // <--- CORREÇÃO APLICADA
        ];
        enviarEmail($novo_agendamento['email'], 'Seu Agendamento foi Reagendado!', 'aprovado', $dados_email);
    }
    
    $cliente = getClientePorEmailTelefoneOuCPF($agendamento_original['email']);
    if ($cliente) {
        criarNotificacao($cliente['id'], "Seu agendamento foi REAGENDADO para ".date('d/m/Y', strtotime($nova_data))." às ".$novo_horario.".");
    }
    
    $_SESSION['agendamento_sucesso'] = "Agendamento de ".htmlspecialchars($agendamento_original['nome'])." reagendado com sucesso!";
    header('Location: painel_barbeiro.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reagendar Horário - Desktop</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/custom_theme.css.php">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <style>
        .info-card { background: #f8f9fa; border: 1px solid var(--border-color); border-radius: 8px; padding: 20px; margin-bottom: 25px; }
        .alert-vip { color: #856404; background-color: #fff3cd; border-color: #ffeeba; padding: 10px; border-radius: 5px; margin-bottom: 15px; font-size: 0.9em; }
    </style>
</head>
<body class="admin-page">
    <div class="container" style="max-width: 600px;">
        <div class="header">
            <h2>Reagendar Horário</h2>
            <a href="painel_barbeiro.php" class="btn" style="background-color:#6c757d;"><i class="fa fa-arrow-left"></i> Voltar</a>
        </div>

        <div class="info-card">
            <p><strong>Cliente:</strong> <?= htmlspecialchars($agendamento_atual['nome']) ?></p>
            <p><strong>Horário Atual:</strong> <?= htmlspecialchars(date('d/m/Y', strtotime($agendamento_atual['data']))) ?> às <?= htmlspecialchars($agendamento_atual['hora']) ?></p>
            <p><strong>Serviços:</strong> <?= htmlspecialchars(implode(', ', $servicos_agendamento_nomes)) ?></p>
            
            <?php if (($agendamento_atual['tipo_desconto'] ?? '') === 'adesao_plano'): ?>
                <div class="alert-vip">
                    <i class="fa fa-crown"></i> <strong>Atenção:</strong> Este agendamento contém uma Adesão de Plano VIP. Ao reagendar, a adesão será mantida para a nova data.
                </div>
            <?php endif; ?>
        </div>

        <form id="form-reagendamento" method="POST">
            <div class="form-group">
                <label for="reagendar_data_flatpickr">Selecione a Nova Data</label>
                <input type="text" id="reagendar_data_flatpickr" placeholder="Clique para selecionar..." required>
                <input type="hidden" name="reagendar_data" id="reagendar_data">
            </div>
            <div class="form-group">
                <label>Selecione o Novo Horário</label>
                <div class="horario-grid" id="reagendar_horarios-container">Selecione uma data.</div>
                <input type="hidden" name="reagendar_horario" id="reagendar_horario" required>
            </div>
            <button type="submit" class="btn-primary" style="width:100%; margin-top: 20px;">Confirmar Reagendamento</button>
        </form>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://npmcdn.com/flatpickr/dist/l10n/pt.js"></script>
    <script>
        const barbeiroId = '<?= htmlspecialchars($barbeiro_id_logado) ?>';
        const servicosIds = '<?= htmlspecialchars($agendamento_atual['servicos_ids']) ?>';
    </script>
    <script src="js/reagendar_pc_script.js"></script>
</body>
</html>