<?php
// Proteção básica para garantir que as funções sejam carregadas
if (file_exists('functions.php')) {
    require_once 'functions.php';
} else {
    die('Erro: Arquivo de funções principal não encontrado.');
}

// Define o fuso horário
date_default_timezone_set('America/Sao_Paulo');

// --- CARREGAMENTO DE DADOS ---
$configGeral = carregarConfigGeral();
$barbeirosArr = lerDados('barbeiros.txt', ['id', 'nome', 'foto']);
$servicosArr = lerDados('servicos.txt', ['id', 'nome', 'valor']);
// [CORREÇÃO] Carrega combos para exibir nomes corretamente
$combosArr = lerDados('combos.txt', ['id', 'nome', 'servicos_ids', 'valor']); 
$planosArr = lerDados('planos.txt', ['id', 'nome', 'valor']);

$keys_agendamentos = ['id', 'nome', 'email', 'telefone', 'barbeiro_id', 'servicos_ids', 'data', 'hora', 'status', 'desconto_aplicado', 'tipo_desconto', 'observacoes', 'produtos_vendidos', 'plano_provisorio'];
$agendamentosArr = lerDados('agendamentos.txt', $keys_agendamentos);

// --- FILTRAGEM DOS DADOS ---
$data_filtro = $_GET['data'] ?? date('Y-m-d');
$data_formatada = date('d/m/Y', strtotime($data_filtro));

// Filtra agendamentos para o dia, que não estejam cancelados
$agendamentosDoDia = array_filter($agendamentosArr, function($ag) use ($data_filtro) {
    if (!isset($ag['data']) || !isset($ag['status'])) return false;
    return $ag['data'] === $data_filtro && 
           $ag['status'] !== 'cancelado' && 
           $ag['status'] !== 'cancelado_pelo_cliente';
});

// Agrupa por barbeiro
$agendamentosPorBarbeiro = [];
foreach ($agendamentosDoDia as $ag) {
    $agendamentosPorBarbeiro[$ag['barbeiro_id']][] = $ag;
}

// Ordena os barbeiros pelo nome
uksort($agendamentosPorBarbeiro, function($a_id, $b_id) use ($barbeirosArr) {
    $nome_a = $barbeirosArr[$a_id]['nome'] ?? 'N/A';
    $nome_b = $barbeirosArr[$b_id]['nome'] ?? 'N/A';
    return strnatcasecmp($nome_a, $nome_b);
});

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda do Dia - <?= htmlspecialchars($configGeral['nome_barbearia']) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: #fff;
            color: #333;
            line-height: 1.4;
            font-size: 12px;
        }
        .page {
            width: 100%;
            max-width: 21cm;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            text-align: center;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .header-info { text-align: left; }
        .header-title { text-align: right; }
        .header h1 { margin: 0; font-size: 24px; text-transform: uppercase; }
        .header h2 { margin: 5px 0 0; font-size: 16px; font-weight: normal; color: #555; }
        
        .barbeiro-section {
            margin-bottom: 30px;
            page-break-inside: avoid;
        }
        .barbeiro-header {
            background-color: #f0f0f0;
            padding: 8px 15px;
            border-left: 5px solid #333;
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            vertical-align: top;
        }
        th {
            background-color: #f9f9f9;
            font-weight: bold;
            text-transform: uppercase;
            font-size: 11px;
        }
        tr:nth-child(even) { background-color: #fdfdfd; }
        
        .hora-cell { font-weight: bold; font-size: 14px; width: 60px; text-align: center; }
        .status-badge {
            display: inline-block;
            padding: 2px 6px;
            border-radius: 4px;
            font-size: 10px;
            font-weight: bold;
            text-transform: uppercase;
            color: #fff;
        }
        .status-pendente { background-color: #ffc107; color: #333; }
        .status-aprovado { background-color: #28a745; }
        .status-concluido { background-color: #333; }
        
        .vip-badge {
            background-color: #6f42c1;
            color: white;
            padding: 2px 5px;
            border-radius: 3px;
            font-size: 10px;
            font-weight: bold;
            margin-left: 5px;
        }
        
        .obs-box {
            background-color: #fff3cd;
            padding: 3px 6px;
            border-radius: 3px;
            font-size: 11px;
            margin-top: 3px;
            display: inline-block;
            border: 1px solid #ffeeba;
        }
        
        .produtos-lista {
            font-size: 11px;
            color: #666;
            margin-top: 3px;
            font-style: italic;
        }

        .no-print {
            position: fixed; top: 20px; right: 20px;
            background: #333; color: white;
            padding: 10px 20px; border-radius: 5px;
            cursor: pointer; border: none; font-size: 14px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.3);
        }
        .no-print:hover { background: #555; }

        @media print {
            body { margin: 0; padding: 0; background: white; }
            .page { width: 100%; max-width: none; padding: 0; margin: 0; }
            .no-print { display: none; }
            .barbeiro-section { page-break-inside: avoid; }
        }
    </style>
</head>
<body>
    <button class="no-print" onclick="window.print()"><i class="fa fa-print"></i> Imprimir</button>

    <div class="page">
        <header class="header">
            <div class="header-info">
                <h1><?= htmlspecialchars($configGeral['nome_barbearia']) ?></h1>
                <div><?= htmlspecialchars($configGeral['endereco']) ?></div>
                <div><?= htmlspecialchars($configGeral['telefone_contato']) ?></div>
            </div>
            <div class="header-title">
                <h2 style="font-size: 20px; font-weight: bold; color: #000;">AGENDA DO DIA</h2>
                <div style="font-size: 18px;"><?= htmlspecialchars($data_formatada) ?></div>
            </div>
        </header>

        <?php if (empty($agendamentosPorBarbeiro)): ?>
            <p style="text-align:center; font-size: 16px; padding: 50px;">Nenhum agendamento encontrado para esta data.</p>
        <?php else: ?>
            <?php foreach ($agendamentosPorBarbeiro as $barbeiro_id => $agendamentos): ?>
                <?php
                // Ordena os agendamentos por hora
                usort($agendamentos, fn($a, $b) => strcmp($a['hora'], $b['hora']));
                $barbeiro = $barbeirosArr[$barbeiro_id] ?? ['nome' => 'N/A'];
                
                // Totais do Barbeiro
                $totalAgendamentos = count($agendamentos);
                $totalEstimado = 0;
                ?>
                
                <section class="barbeiro-section">
                    <div class="barbeiro-header">
                        <span><i class="fa fa-user"></i> <?= htmlspecialchars($barbeiro['nome']) ?></span>
                        <span style="font-weight: normal; font-size: 14px;"><?= $totalAgendamentos ?> atendimento(s)</span>
                    </div>
                    
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 60px;">Hora</th>
                                <th style="width: 25%;">Cliente / Contato</th>
                                <th style="width: 35%;">Serviços & Detalhes</th>
                                <th style="width: 20%;">Obs / Produtos</th>
                                <th style="width: 15%;">Financeiro</th>
                                <th style="width: 80px;">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($agendamentos as $ag): 
                                // Calcula valores
                                $valorTotal = 0;
                                $servicosTxt = [];
                                $servicosIds = explode(',', $ag['servicos_ids']);
                                
                                foreach ($servicosIds as $sid) {
                                    $sid = trim($sid);
                                    if (isset($servicosArr[$sid])) {
                                        $servicosTxt[] = $servicosArr[$sid]['nome'];
                                        $valorTotal += (float)$servicosArr[$sid]['valor'];
                                    } elseif (isset($combosArr[$sid])) {
                                        $servicosTxt[] = $combosArr[$sid]['nome'] . " (Combo)";
                                        $valorTotal += (float)$combosArr[$sid]['valor'];
                                    } else {
                                        $servicosTxt[] = "Item Removido";
                                    }
                                }
                                
                                // Produtos
                                $produtosTxt = [];
                                if (!empty($ag['produtos_vendidos'])) {
                                    $prods = json_decode($ag['produtos_vendidos'], true);
                                    if (is_array($prods)) {
                                        foreach ($prods as $p) {
                                            $produtosTxt[] = $p['nome'];
                                            $valorTotal += (float)$p['valor'];
                                        }
                                    }
                                }
                                
                                $desconto = (float)($ag['desconto_aplicado'] ?? 0);
                                $valorFinal = $valorTotal - $desconto;
                                $totalEstimado += $valorFinal;
                                
                                // Tags e Badges
                                $isVip = ($ag['tipo_desconto'] ?? '') === 'assinatura_vip';
                                $isAdesao = ($ag['tipo_desconto'] ?? '') === 'adesao_plano';
                            ?>
                                <tr>
                                    <td class="hora-cell"><?= htmlspecialchars($ag['hora']) ?></td>
                                    <td>
                                        <strong><?= htmlspecialchars($ag['nome']) ?></strong>
                                        <?php if ($isVip): ?><span class="vip-badge">VIP</span><?php endif; ?>
                                        <?php if ($isAdesao): ?><span class="vip-badge" style="background: #28a745;">ADESÃO</span><?php endif; ?>
                                        <div style="font-size: 11px; color: #666; margin-top: 2px;">
                                            <i class="fa fa-phone"></i> <?= htmlspecialchars($ag['telefone']) ?>
                                        </div>
                                    </td>
                                    <td>
                                        <ul style="margin: 0; padding-left: 15px; font-size: 11px;">
                                            <?php foreach($servicosTxt as $s): ?>
                                                <li><?= htmlspecialchars($s) ?></li>
                                            <?php endforeach; ?>
                                        </ul>
                                    </td>
                                    <td>
                                        <?php if (!empty($ag['observacoes'])): ?>
                                            <div class="obs-box"><i class="fa fa-comment"></i> <?= htmlspecialchars($ag['observacoes']) ?></div>
                                        <?php endif; ?>
                                        <?php if (!empty($produtosTxt)): ?>
                                            <div class="produtos-lista">
                                                <strong>Prod:</strong> <?= implode(', ', $produtosTxt) ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div style="font-weight: bold;">R$ <?= number_format($valorFinal, 2, ',', '.') ?></div>
                                        <?php if ($desconto > 0): ?>
                                            <div style="font-size: 10px; color: #dc3545;">Desc: -<?= number_format($desconto, 2, ',', '.') ?></div>
                                            <div style="font-size: 10px; color: #666;">(Total: <?= number_format($valorTotal, 2, ',', '.') ?>)</div>
                                        <?php endif; ?>
                                    </td>
                                    <td style="text-align: center;">
                                        <span class="status-badge status-<?= htmlspecialchars($ag['status']) ?>">
                                            <?= ucfirst(str_replace('_', ' ', $ag['status'])) ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="4" style="text-align: right; font-weight: bold; background: #fafafa;">TOTAL ESTIMADO (<?= htmlspecialchars($barbeiro['nome']) ?>):</td>
                                <td colspan="2" style="font-weight: bold; background: #fafafa;">R$ <?= number_format($totalEstimado, 2, ',', '.') ?></td>
                            </tr>
                        </tfoot>
                    </table>
                </section>
            <?php endforeach; ?>
            
            <div style="margin-top: 30px; border-top: 1px solid #ccc; padding-top: 10px; font-size: 10px; color: #777; text-align: center;">
                Relatório gerado em <?= date('d/m/Y H:i:s') ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>