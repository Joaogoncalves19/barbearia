<?php
session_start();
// Define o fuso horário no início do script para garantir consistência nas datas
date_default_timezone_set('America/Sao_Paulo');

require_once 'functions.php';

// Captura o ID do agendamento a ser reagendado e guarda na sessão
if (isset($_GET['reagendar_id'])) {
    $_SESSION['reagendar_id'] = $_GET['reagendar_id'];
}

$cliente_logado = isset($_SESSION['cliente_logado']) && $_SESSION['cliente_logado'];
$form_disabled_class = $cliente_logado ? '' : 'form-disabled';
$input_disabled_attr = $cliente_logado ? '' : 'disabled';

$configGeral = carregarConfigGeral();
$configAgendamento = carregarConfigAgendamento();

// 1. Carrega barbeiros (apenas ativos)
$barbeirosArr = lerDados('barbeiros.txt', ['id', 'nome', 'foto', 'username', 'password', 'status', 'servicos_ids']);
$barbeirosAtivosArr = array_filter($barbeirosArr, function($barbeiro) {
    $status = $barbeiro['status'] ?? 'ativo';
    if(empty($status)) $status = 'ativo';
    return $status === 'ativo';
});

// 2. Carrega serviços e combos
$servicosArr = lerDados('servicos.txt', ['id', 'nome', 'valor', 'slots', 'categoria_id']);
$combosArr = lerDados('combos.txt', ['id', 'nome', 'servicos_ids', 'valor', 'categoria_id']);
$categoriasArr = lerDados('categorias.txt', ['id', 'nome', 'ordem']);

// Carrega os Planos de Assinatura
$planosArr = lerDados('planos.txt', ['id', 'nome', 'valor', 'servicos_ids']);

// Adiciona a informação de 'slots' em cada combo
foreach ($combosArr as $comboId => &$combo) {
    $slots_combo = 0;
    $servicos_do_combo = explode(',', $combo['servicos_ids']);
    foreach ($servicos_do_combo as $sid_combo) {
        $sid_limpo = trim($sid_combo);
        if (isset($servicosArr[$sid_limpo])) {
            $slots = (int)($servicosArr[$sid_limpo]['slots'] ?? 1);
            $slots_combo += ($slots > 0) ? $slots : 1;
        } else {
            $slots_combo += 1; 
        }
    }
    $combo['slots'] = $slots_combo;
}
unset($combo); 


$avaliacoesArr = lerDados('avaliacoes.txt', ['id', 'agendamento_id', 'cliente_id', 'barbeiro_id', 'rating', 'comment', 'timestamp']);
$clientesArr = lerDados('clientes.txt', ['id', 'nome']);

// Verifica se o cliente já tem assinatura ativa
$assinaturaAtiva = null;
if ($cliente_logado) {
    $assinaturaAtiva = getAssinaturaCliente($_SESSION['cliente_id']);
}

$config_fidelidade = getFidelityConfig();
$config_aniversario = getAniversarioConfig();
$config = file_exists(DATA_DIR . 'config.txt') ? parse_ini_file(DATA_DIR . 'config.txt') : ['aprovar' => 'manual'];
$aprovarAutomatico = ($config['aprovar'] ?? 'manual') === 'automatico';

$mensagem = '';

if ($cliente_logado && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = trim(htmlspecialchars($_POST['nome']));
    $email = trim(htmlspecialchars($_POST['email']));
    $telefone = limparTelefone($_POST['telefone']);
    $barbeiro_id = $_POST['barbeiro'] ?? '';
    $servicos_ids = $_POST['servicos'] ?? ''; 
    $data = $_POST['data'] ?? '';
    $hora = $_POST['horario'] ?? '';
    $cupom_codigo = trim(strtoupper($_POST['cupom'] ?? ''));
    $observacoes = trim(htmlspecialchars($_POST['observacoes'] ?? ''));
    $plano_provisorio_id = $_POST['plano_escolhido_id'] ?? '';
    $usar_fidelidade = isset($_POST['usar_fidelidade']); // Captura a checkbox
    
    $servicosSelecionadosParaSalvar = $servicos_ids ? explode(',', $servicos_ids) : [];

    if(isset($_POST['horario_barbeiro_id']) && !empty($_POST['horario_barbeiro_id'])) {
        $barbeiro_id = $_POST['horario_barbeiro_id'];
    }
    
    // Calcula slots
    $totalSlots = 0;
    $combos_selecionados_ids_post = isset($_POST['combos_selecionados']) ? array_filter(explode(',', $_POST['combos_selecionados'])) : [];
    $servicos_ja_em_combo_post = [];

    foreach($combos_selecionados_ids_post as $combo_id) {
        $combo_id = trim($combo_id);
        if(isset($combosArr[$combo_id])) {
            $totalSlots += (int)$combosArr[$combo_id]['slots'];
            $servicos_do_combo = explode(',', $combosArr[$combo_id]['servicos_ids']);
            $servicos_do_combo = array_map('trim', $servicos_do_combo);
            $servicos_ja_em_combo_post = array_merge($servicos_ja_em_combo_post, $servicos_do_combo);
        }
    }
    
    foreach($servicosSelecionadosParaSalvar as $sid) {
        $sid_limpo = trim($sid);
        if(strpos($sid_limpo, 'sv-') === 0 && !in_array($sid_limpo, $servicos_ja_em_combo_post) && isset($servicosArr[$sid_limpo])) {
            $slots = (int)($servicosArr[$sid_limpo]['slots'] ?? 1);
            $totalSlots += ($slots > 0) ? $slots : 1;
        }
    }
    if ($totalSlots == 0 && !empty($servicosSelecionadosParaSalvar)) $totalSlots = 1;


    if (empty($nome) || empty($email) || empty($telefone) || empty($barbeiro_id) || empty($servicosSelecionadosParaSalvar) || empty($data) || empty($hora) || $totalSlots === 0) {
        $mensagem = "Por favor, preencha todos os campos do formulário.";
    } elseif (strtotime($data) < strtotime(date('Y-m-d'))) {
        $mensagem = "A data de agendamento não pode ser no passado.";
    } else {
        $horariosOcupados = getHorariosOcupados($barbeiro_id, $data);
        $conflito = false;
        $startMinutes = intval(explode(':', $hora)[0]) * 60 + intval(explode(':', $hora)[1]);
        
        for ($i = 0; $i < $totalSlots; $i++) {
            $minutes = $startMinutes + $i * 30;
            $formatted = sprintf('%02d:%02d', floor($minutes / 60), $minutes % 60);
            if (in_array($formatted, $horariosOcupados)) {
                $conflito = true;
                $mensagem = "Um ou mais horários selecionados já estão ocupados.";
                break;
            }
        }

        if (!$conflito) {
            $descontos = [];
            $tipo_desconto_aplicado = '';
            $id_cupom_usado = null;
            $voucher_usado = null;
            $cliente_id = $_SESSION['cliente_id'];
            
            // Calcula Valor Total Bruto
            $valor_total_servicos = 0;
            $servicos_ja_em_combo_calc = []; 
            
            foreach($combos_selecionados_ids_post as $combo_id) {
                $combo_id = trim($combo_id);
                if(isset($combosArr[$combo_id])) {
                    $valor_total_servicos += (float) $combosArr[$combo_id]['valor'];
                    $servicos_do_combo = explode(',', $combosArr[$combo_id]['servicos_ids']);
                    $servicos_do_combo = array_map('trim', $servicos_do_combo);
                    $servicos_ja_em_combo_calc = array_merge($servicos_ja_em_combo_calc, $servicos_do_combo);
                }
            }
            foreach($servicosSelecionadosParaSalvar as $sid) {
                 $sid_limpo = trim($sid);
                if(!in_array($sid_limpo, $servicos_ja_em_combo_calc) && isset($servicosArr[$sid_limpo])) {
                    $valor_total_servicos += (float) $servicosArr[$sid_limpo]['valor'];
                }
            }
            
            $desconto_aplicado = 0;

            // --- CÁLCULO PRÉVIO DE FIDELIDADE (Se marcado) ---
            $desconto_fidelidade_calc = 0;
            if ($usar_fidelidade && ($config_fidelidade['ativado'] ?? 0)) {
                $pontos_atuais = getClientFidelityPoints($cliente_id); 
                $pontos_necessarios = $config_fidelidade['pontos_necessarios'] ?? 10;
                
                if ($pontos_atuais >= $pontos_necessarios) {
                    $val_servicos_lista = []; 
                    foreach($servicosSelecionadosParaSalvar as $sid) { 
                        if(isset($servicosArr[trim($sid)])) { 
                            $val_servicos_lista[] = (float) $servicosArr[trim($sid)]['valor']; 
                        } 
                    }
                    $valor_minimo = !empty($val_servicos_lista) ? min($val_servicos_lista) : 0;
                    $desconto_fidelidade_calc = $valor_minimo * ($config_fidelidade['desconto_percentual'] / 100);
                }
            }

            // 1. Lógica de Adesão ao Plano
            if (!empty($plano_provisorio_id) && isset($planosArr[$plano_provisorio_id])) {
                $plano = $planosArr[$plano_provisorio_id];
                $valor_plano = (float)$plano['valor'];
                
                $servicosInclusosNoPlano = explode(',', $plano['servicos_ids']);
                $servicosInclusosNoPlano = array_map('trim', $servicosInclusosNoPlano);
                
                $total_a_pagar_itens = 0;

                foreach($combos_selecionados_ids_post as $combo_id) {
                    $combo_id = trim($combo_id);
                    if(isset($combosArr[$combo_id])) {
                        $combo = $combosArr[$combo_id];
                        $servicos_do_combo = explode(',', $combo['servicos_ids']);
                        $algum_coberto = false;
                        $valor_nao_cobertos = 0;

                        foreach($servicos_do_combo as $sid) {
                            $sid_limpo = trim($sid);
                            if (isset($servicosArr[$sid_limpo])) {
                                if (in_array($sid_limpo, $servicosInclusosNoPlano)) {
                                    $algum_coberto = true;
                                } else {
                                    $valor_nao_cobertos += (float)$servicosArr[$sid_limpo]['valor'];
                                }
                            }
                        }

                        if ($algum_coberto) {
                            $total_a_pagar_itens += $valor_nao_cobertos;
                        } else {
                            $total_a_pagar_itens += (float)$combo['valor'];
                        }
                    }
                }

                foreach($servicosSelecionadosParaSalvar as $sid) {
                    $sid_limpo = trim($sid);
                    if (!in_array($sid_limpo, $servicos_ja_em_combo_calc) && isset($servicosArr[$sid_limpo])) {
                        if (!in_array($sid_limpo, $servicosInclusosNoPlano)) {
                            $total_a_pagar_itens += (float)$servicosArr[$sid_limpo]['valor'];
                        }
                    }
                }

                $valor_final_esperado = $valor_plano + $total_a_pagar_itens;
                $desconto_aplicado = $valor_total_servicos - $valor_final_esperado;
                $tipo_desconto_aplicado = 'adesao_plano';
            
            } elseif ($assinaturaAtiva) {
                 // 2. Lógica para quem JÁ tem assinatura
                 $plano = $planosArr[$assinaturaAtiva['plano_id']] ?? null;
                 $desconto_total_assinatura = 0;
                 
                 if ($plano) {
                    $servicosInclusosNoPlano = explode(',', $plano['servicos_ids']);
                    $servicosInclusosNoPlano = array_map('trim', $servicosInclusosNoPlano);

                    // Combos
                    foreach($combos_selecionados_ids_post as $combo_id) {
                        $combo_id = trim($combo_id);
                        if(isset($combosArr[$combo_id])) {
                            $combo = $combosArr[$combo_id];
                            $servicos_do_combo = explode(',', $combo['servicos_ids']);
                            
                            $itens_cobertos_count = 0;
                            $custo_real_itens_nao_cobertos = 0;

                            foreach($servicos_do_combo as $sid) {
                                $sid_limpo = trim($sid);
                                if (isset($servicosArr[$sid_limpo])) {
                                    if (in_array($sid_limpo, $servicosInclusosNoPlano)) {
                                        $itens_cobertos_count++;
                                    } else {
                                        $custo_real_itens_nao_cobertos += (float)$servicosArr[$sid_limpo]['valor'];
                                    }
                                }
                            }

                            if ($itens_cobertos_count > 0) {
                                $valor_do_combo_bruto = (float)$combo['valor'];
                                $desconto_para_este_combo = $valor_do_combo_bruto - $custo_real_itens_nao_cobertos;
                                $desconto_total_assinatura += $desconto_para_este_combo;
                            }
                        }
                    }

                    // Serviços Individuais
                    foreach($servicosSelecionadosParaSalvar as $sid) {
                        $sid_limpo = trim($sid);
                        if (!in_array($sid_limpo, $servicos_ja_em_combo_calc) && isset($servicosArr[$sid_limpo])) {
                            if (in_array($sid_limpo, $servicosInclusosNoPlano)) {
                                $desconto_total_assinatura += (float)$servicosArr[$sid_limpo]['valor'];
                            }
                        }
                    }
                 }
                 
                 // --- DECISÃO: FIDELIDADE VS ASSINATURA ---
                 // Se o cliente escolheu usar fidelidade e o desconto dela for MAIOR que o desconto da assinatura, usa fidelidade.
                 if ($desconto_fidelidade_calc > $desconto_total_assinatura) {
                     $desconto_aplicado = $desconto_fidelidade_calc;
                     $tipo_desconto_aplicado = 'fidelidade';
                 } else {
                     // Caso contrário (ou se fidelidade não foi marcada), usa o desconto da assinatura
                     $desconto_aplicado = $desconto_total_assinatura;
                     $tipo_desconto_aplicado = ($desconto_total_assinatura != 0) ? 'assinatura_vip' : '';
                 }
            
            } else {
                // 3. Lógica de Descontos Padrão (Sem assinatura)
                
                // Se fidelidade foi calculada (checkbox marcado e validado), adiciona
                if ($desconto_fidelidade_calc > 0) {
                    $descontos['fidelidade'] = $desconto_fidelidade_calc;
                }

                if (!empty($cupom_codigo)) {
                    $cupom = getCouponByCode($cupom_codigo);
                    $voucher = getVoucherByCode($cupom_codigo);
                    if ($cupom && !isset($cupom['error'])) {
                        if (checkIfUserUsedCoupon($cupom['id'], $cliente_id)) { $mensagem = "Você já utilizou este cupom."; $conflito = true;
                        } else { $descontos['cupom'] = $valor_total_servicos * ($cupom['desconto_percentual'] / 100); $id_cupom_usado = $cupom['id']; }
                    } elseif ($voucher && !isset($voucher['error'])) {
                        $descontos['voucher'] = $voucher['valor']; $voucher_usado = $voucher;
                    } else { $mensagem = $cupom['error'] ?? ($voucher['error'] ?? "Cupom ou Voucher inválido."); $conflito = true; }
                }
                
                $cliente = getClientePorEmailTelefoneOuCPF($_SESSION['cliente_email']);
                
                // --- LÓGICA DE ANIVERSÁRIO ATUALIZADA (SÓ NO PRIMEIRO AGENDAMENTO DO MÊS) ---
                if (($config_aniversario['ativado'] ?? 0) && !empty($cliente['data_nascimento'])) { 
                    if (date('m', strtotime($cliente['data_nascimento'])) == date('m')) { 
                        
                        // Verifica se já agendou neste mês
                        $mes_atual = date('Y-m');
                        $ja_agendou_no_mes = false;
                        
                        // Define as chaves para leitura correta
                        $keys_agendamentos_check = ['id', 'nome', 'email', 'telefone', 'barbeiro_id', 'servicos_ids', 'data', 'hora', 'status'];
                        $todosAgendamentos = lerDados('agendamentos.txt', $keys_agendamentos_check);
                        
                        foreach ($todosAgendamentos as $ag) {
                            $email_ag = $ag['email'] ?? '';
                            $tel_ag = limparTelefone($ag['telefone'] ?? '');
                            $email_sessao = $_SESSION['cliente_email'] ?? '';
                            $tel_sessao = limparTelefone($_SESSION['cliente_telefone'] ?? '');
                            
                            // Verifica se o agendamento é do cliente
                            if ($email_ag === $email_sessao || $tel_ag === $tel_sessao) {
                                // Verifica se não está cancelado
                                $status_ag = $ag['status'] ?? '';
                                if ($status_ag !== 'cancelado' && $status_ag !== 'cancelado_pelo_cliente') {
                                    // Verifica se é no mês atual
                                    $data_ag = $ag['data'] ?? '';
                                    if (substr($data_ag, 0, 7) === $mes_atual) {
                                        $ja_agendou_no_mes = true;
                                        break; 
                                    }
                                }
                            }
                        }

                        // Aplica o desconto apenas se NÃO agendou no mês
                        if (!$ja_agendou_no_mes) {
                            $descontos['aniversario'] = $valor_total_servicos * ($config_aniversario['desconto_percentual'] / 100); 
                        }
                    } 
                }
                // --- FIM DA ATUALIZAÇÃO ---

                $config_indicacao = getIndicacaoConfig();
                if (($config_indicacao['ativado'] ?? 0) && $cliente && !empty($cliente['indicado_por_id'])) {
                    if (isPrimeiroAgendamento($cliente_id)) { 
                        $desconto_percentual = (float)($config_indicacao['desconto_novo_cliente'] ?? 0);
                        if ($desconto_percentual > 0) {
                            $descontos['indicacao'] = $valor_total_servicos * ($desconto_percentual / 100);
                        }
                    }
                }
                
                if (!empty($descontos)) {
                    $desconto_aplicado = max($descontos);
                    $tipo_desconto_aplicado = array_search($desconto_aplicado, $descontos);
                }
            }

            if (!$conflito) {
                $valor_final_pago = $valor_total_servicos - $desconto_aplicado;
                
                if ($tipo_desconto_aplicado !== 'adesao_plano' && $tipo_desconto_aplicado !== 'assinatura_vip' && $valor_final_pago < 0) { 
                    $desconto_aplicado = $valor_total_servicos; 
                }

                $id_agendamento = uniqid('ag-');
                $status = $aprovarAutomatico ? 'aprovado' : 'pendente';
                
                $linha = "$id_agendamento|$nome|$email|$telefone|$barbeiro_id|" . implode(',', $servicosSelecionadosParaSalvar) . "|$data|$hora|$status|$desconto_aplicado|$tipo_desconto_aplicado|$observacoes||$plano_provisorio_id\n";
                
                file_put_contents(DATA_DIR . 'agendamentos.txt', $linha, FILE_APPEND | LOCK_EX);
                
                $configAgendamentoEmail = carregarConfigAgendamento();
                if (($configAgendamentoEmail['notif_confirmacao'] ?? 0) == 1) {
                    $dados_email = [
                        'nome_cliente' => $nome,
                        'data_agendamento' => date('d/m/Y', strtotime($data)),
                        'hora_agendamento' => $hora,
                        'status' => $status,
                        'servicos' => array_map(function($sid) use ($servicosArr, $combosArr) {
                            $sid = trim($sid);
                            if (isset($servicosArr[$sid])) {
                                return $servicosArr[$sid]['nome'];
                            } elseif (isset($combosArr[$sid])) {
                                return $combosArr[$sid]['nome'] . " (Combo)";
                            }
                            return 'Serviço/Combo não encontrado';
                        }, $servicosSelecionadosParaSalvar),
                        'barbeiro' => $barbeirosArr[$barbeiro_id]['nome'] ?? 'Não especificado',
                        'tipo_desconto' => $tipo_desconto_aplicado
                    ];
                    enviarEmail($email, 'Confirmação de Agendamento', 'confirmacao', $dados_email);
                }

                if (isset($_SESSION['reagendar_id'])) {
                    $id_para_excluir = $_SESSION['reagendar_id']; 
                    $agendamentosFile = DATA_DIR . 'agendamentos.txt';
                    $fp = fopen($agendamentosFile, 'c+'); 
                    if ($fp && flock($fp, LOCK_EX)) {
                        $linhas = [];
                        while (($l = fgets($fp)) !== false) {
                            if(strpos(trim($l), $id_para_excluir . '|') !== 0) { $linhas[] = trim($l); }
                        }
                        ftruncate($fp, 0); rewind($fp);
                        fwrite($fp, implode("\n", $linhas) . (empty($linhas) ? "" : "\n"));
                        flock($fp, LOCK_UN);
                        unset($_SESSION['reagendar_id']);
                    }
                    if($fp) fclose($fp);
                }

                $mensagem_desconto = '';
                if ($tipo_desconto_aplicado === 'cupom' && $id_cupom_usado) { incrementarUsoCupom($id_cupom_usado); logCouponUsage($id_cupom_usado, $cliente_id); $mensagem_desconto = "Cupom aplicado! ";
                } elseif ($tipo_desconto_aplicado === 'voucher' && $voucher_usado) { marcarVoucherComoUtilizado($voucher_usado['id'], $id_agendamento); $mensagem_desconto = "Voucher aplicado! ";
                } elseif ($tipo_desconto_aplicado === 'fidelidade') { 
                    $pontos_atuais = getClientFidelityPoints($cliente_id); 
                    updateClientFidelityPoints($cliente_id, $pontos_atuais - $config_fidelidade['pontos_necessarios'], "Resgate de desconto"); 
                    $mensagem_desconto = "Desconto fidelidade aplicado! ";
                } elseif ($tipo_desconto_aplicado === 'adesao_plano') { $mensagem_desconto = "Plano selecionado! Sua assinatura será ativada no atendimento. "; }
                elseif ($tipo_desconto_aplicado === 'assinatura_vip') { $mensagem_desconto = "Desconto VIP aplicado! "; }
                
                $mensagem_status = $aprovarAutomatico ? "Seu agendamento foi confirmado!" : "Seu agendamento foi recebido.";
                $_SESSION['mensagem_sucesso'] = $mensagem_desconto . $mensagem_status . " Acompanhe em 'Minha Conta'.";
                header('Location: agendamento.php?success=1');
                exit;
            }
        }
    }
}
if (isset($_GET['success']) && $_GET['success'] == 1) {
    if (isset($_SESSION['mensagem_sucesso'])) {
        $mensagem = $_SESSION['mensagem_sucesso'];
        unset($_SESSION['mensagem_sucesso']);
    } else {
        $mensagem = "Agendamento recebido!";
    }
}

// Lógica de Agrupamento
$itensAgrupados = [];
foreach ($categoriasArr as $catId => $cat) { $itensAgrupados[$catId] = [ 'nome' => $cat['nome'], 'ordem' => (int)($cat['ordem'] ?? 99), 'servicos' => [], 'combos' => [] ]; }
$itensAgrupados['sem_categoria'] = [ 'nome' => 'Outros', 'ordem' => 999, 'servicos' => [], 'combos' => [] ];
foreach ($servicosArr as $servico) { $catId = $servico['categoria_id'] ?? 'sem_categoria'; if (empty($catId) || !isset($itensAgrupados[$catId])) $catId = 'sem_categoria'; $itensAgrupados[$catId]['servicos'][] = $servico; }
foreach ($combosArr as $combo) { $catId = $combo['categoria_id'] ?? 'sem_categoria'; if (empty($catId) || !isset($itensAgrupados[$catId])) $catId = 'sem_categoria'; $itensAgrupados[$catId]['combos'][] = $combo; }
$itensAgrupados = array_filter($itensAgrupados, function($cat) { return !empty($cat['servicos']) || !empty($cat['combos']); });
uasort($itensAgrupados, fn($a, $b) => $a['ordem'] <=> $b['ordem']);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendamento Barbearia</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/custom_theme.css.php">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <style>
        .login-prompt { padding: 20px; background-color: #e9f0f6; border: 1px solid #d1e3f1; border-radius: 10px; text-align: center; margin-bottom: 25px; }
        .login-prompt p { margin-bottom: 15px; }
        .login-prompt a { display: inline-block; padding: 10px 20px; background: var(--secondary-color); color: white; border-radius: 8px; text-decoration: none; margin: 0 5px; font-weight: bold; }
        .login-prompt a:hover { background: #0056b3; }
        
        /* Botão Minha Conta Estilizado e Centralizado */
        .minha-conta-topo { display: flex; justify-content: center; margin-bottom: 20px; }
        .btn-minha-conta { background-color: var(--secondary-color); color: white; padding: 10px 20px; border-radius: 8px; text-decoration: none; font-weight: bold; font-size: 0.95rem; display: flex; align-items: center; gap: 8px; transition: filter 0.2s; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .btn-minha-conta:hover { filter: brightness(1.1); }

        .pontos-fidelidade { text-align: center; margin-bottom: 20px; padding: 10px; background-color: var(--pending-bg-color); border: 1px solid var(--warning-color); border-radius: 8px; font-weight: bold; color: var(--primary-color); }
        .pontos-fidelidade .fa-star { color: var(--warning-color); }
        .combo-btn { border-color: var(--warning-color) !important; color: var(--warning-color) !important; }
        .combo-btn:hover, .combo-btn.selected { background: var(--warning-color) !important; color: var(--primary-color) !important; }
        .observacoes-container { display: none; margin-top: 15px; }
        .btn-observacao { background: none; border: 1px dashed #ccc; color: #555; padding: 8px 12px; cursor: pointer; border-radius: 6px; margin-top: 10px; width: 100%; text-align: center; }
        .btn-observacao:hover { background: #f5f5f5; }
        .horario-qualquer-barbeiro { font-size: 0.8em; color: #555; display: block; }
        .form-disabled { pointer-events: none; opacity: 0.5; user-select: none; }
        @media (max-width: 600px) { body { display: block; min-height: 100%; } .container { width: 100%; max-width: none; margin: 0; padding: 20px; box-shadow: none; border-radius: 0; } .header-links { justify-content: center; } h2 { font-size: 1.5rem; } .servico-btn { font-size: 0.8rem; } .horario-grid { grid-template-columns: repeat(auto-fill, minmax(80px, 1fr)); } .minha-conta-topo { justify-content: center; } }
        .servico-btn.disabled, .servico-btn-modal.disabled { opacity: 0.4; cursor: not-allowed; background: #f8f9fa !important; border-color: #e0e0e0 !important; color: #aaa !important; }
        .custom-option-wrapper.disabled { opacity: 0.4; cursor: not-allowed; background: #f8f9fa; }
        .custom-option-wrapper.custom-option { cursor: not-allowed; }
        .custom-option-wrapper.disabled .btn-detalhes-barbeiro { display: none; }
        #servicos-container { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 10px; margin-top: 10px; }
        .servico-btn { flex-grow: 0; min-width: auto; font-size: 0.85rem; padding: 10px; text-align: left; display: flex; flex-direction: column; justify-content: space-between; line-height: 1.3; }
        .servico-btn .duracao { font-size: 0.8em; color: #6c757d; font-weight: normal; margin-top: 5px; pointer-events: none; }
        .combo-btn .duracao { color: var(--primary-color); opacity: 0.7; }
        .servico-btn span:first-child { font-weight: bold; font-size: 1.1em; pointer-events: none; }
        .categoria-titulo { font-size: 1.2rem; font-weight: bold; color: var(--primary-color); margin-top: 25px; margin-bottom: 10px; padding-bottom: 8px; border-bottom: 2px solid var(--border-color); text-align: left; grid-column: 1 / -1; }
        #servicos-container .categoria-titulo:first-of-type { margin-top: 0; }
    </style>
</head>
<body>
<?php 
    $pageTitle = 'Agendar Horário';
    require_once 'header_app.php'; 
?>
<div class="container">

    <?php if ($cliente_logado): ?>
    <div class="minha-conta-topo">
        <a href="minha_conta.php" class="btn-minha-conta">
            <i class="fa fa-user-circle"></i> Minha Conta
        </a>
    </div>
    <?php endif; ?>
    
    <?php if ($mensagem) echo "<p class='mensagem'>" . htmlspecialchars($mensagem) . "</p>"; ?>

    <?php if ($cliente_logado && ($config_fidelidade['ativado'] ?? 0)): 
        $pontos_cliente = getClientFidelityPoints($_SESSION['cliente_id']);
    ?>
    <div class="pontos-fidelidade"><i class="fa fa-star"></i> Seus pontos de fidelidade: <strong><?= $pontos_cliente ?></strong></div>
    <?php endif; ?>

    <?php if (!$cliente_logado): ?>
    <div class="login-prompt"><p>Para agendar um horário, você precisa entrar na sua conta.</p><div><a href="login_cliente.php">Fazer Login</a><a href="registro.php">Criar Conta</a></div></div>
    <?php endif; ?>

    <form method="POST" id="form-agendamento" class="<?= $form_disabled_class ?>">
        <div class="form-group">
            <label for="nome">Nome e Sobrenome</label>
            <div class="input-icon"><i class="fa fa-user"></i><input type="text" name="nome" id="nome" placeholder="Seu nome e sobrenome" value="<?= $_SESSION['cliente_nome'] ?? '' ?>" required <?= $input_disabled_attr ?>></div>
        </div>
        <div class="form-group">
            <label for="email">E-mail</label>
            <div class="input-icon"><i class="fa fa-envelope"></i><input type="email" name="email" id="email" placeholder="seu-email@dominio.com" value="<?= $_SESSION['cliente_email'] ?? '' ?>" required <?= $input_disabled_attr ?>></div>
        </div>
        <div class="form-group">
            <label for="telefone">Telefone</label>
            <div class="input-icon"><i class="fa fa-phone"></i><input type="tel" name="telefone" id="telefone" placeholder="(99) 99999-9999" value="<?= $_SESSION['cliente_telefone'] ?? '' ?>" required <?= $input_disabled_attr ?>></div>
        </div>
        <div class="form-group">
            <label>Barbeiro</label>
            <div class="custom-select-container">
                <div class="custom-select-selected">Selecione um barbeiro</div>
                <div class="custom-select-items">
                    <div class="custom-option" data-value="qualquer"><img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath fill='%236c757d' d='M12 2a10 10 0 1010 10A10 10 0 0012 2zm0 18a8 8 0 118-8 8 8 0 01-8 8zm-1-6h2v-2h-2zm0-4h2V7h-2z'/%3E%3C/svg%3E" alt="Qualquer Barbeiro"> Qualquer Barbeiro</div>
                    <?php foreach ($barbeirosAtivosArr as $id => $b): ?>
                        <div class="custom-option-wrapper">
                           <div class="custom-option" data-value="<?= htmlspecialchars($id) ?>"><img src="<?= htmlspecialchars($b['foto']) ?>" alt="<?= htmlspecialchars($b['nome']) ?>"> <?= htmlspecialchars($b['nome']) ?></div>
                           <button type="button" class="btn-detalhes-barbeiro" data-barbeiro-id="<?= htmlspecialchars($id) ?>">Detalhes</button>
                        </div>
                    <?php endforeach; ?>
                    </div>
                <input type="hidden" name="barbeiro" id="barbeiro" required>
            </div>
        </div>
        <div class="form-group">
            <label>Serviços e Combos</label>
            <div id="servicos-container">
                <?php foreach ($itensAgrupados as $categoria): ?>
                    <h4 class="categoria-titulo"><?= htmlspecialchars($categoria['nome']) ?></h4>
                    <?php foreach ($categoria['combos'] as $c): ?>
                        <button type="button" class="servico-btn combo-btn" data-id="<?= htmlspecialchars($c['id']) ?>" data-servicos-ids="<?= htmlspecialchars($c['servicos_ids']) ?>" data-valor="<?= htmlspecialchars($c['valor']) ?>" data-slots="<?= htmlspecialchars($c['slots']) ?>">
                            <span><?= htmlspecialchars($c['nome']) ?> - R$<?= htmlspecialchars($c['valor']) ?></span>
                            <span class="duracao"><i class="fa fa-clock"></i> <?= htmlspecialchars($c['slots'] * 30) ?> min</span>
                        </button>
                    <?php endforeach; ?>
                    <?php foreach ($categoria['servicos'] as $s): $slots_servico = (int)($s['slots'] ?? 1); if ($slots_servico <= 0) $slots_servico = 1; ?>
                        <button type="button" class="servico-btn" data-id="<?= htmlspecialchars($s['id']) ?>" data-valor="<?= htmlspecialchars($s['valor']) ?>" data-slots="<?= $slots_servico ?>">
                            <span><?= htmlspecialchars($s['nome']) ?> - R$<?= htmlspecialchars($s['valor']) ?></span>
                            <span class="duracao"><i class="fa fa-clock"></i> <?= $slots_servico * 30 ?> min</span>
                        </button>
                    <?php endforeach; ?>
                <?php endforeach; ?>
            </div>
            <input type="hidden" name="servicos" id="servicos">
            <input type="hidden" name="combos_selecionados" id="combos_selecionados">
        </div>

        <?php 
        // Exibir informações do Plano VIP Ativo
        if ($cliente_logado && $assinaturaAtiva): 
            $planoAtual = $planosArr[$assinaturaAtiva['plano_id']] ?? null;
            $dataVencimento = date('d/m/Y', strtotime($assinaturaAtiva['data_fim']));
            
            // Calcula dias restantes
            $diasRestantes = ceil((strtotime($assinaturaAtiva['data_fim']) - time()) / (60 * 60 * 24));
            $corStatus = ($diasRestantes <= 5) ? '#ffc107' : '#28a745'; // Amarelo se perto de vencer, verde se ok
            $textoCor = ($diasRestantes <= 5) ? '#856404' : '#155724';
        ?>
        <div class="form-group" style="background: #e8f5e9; padding: 15px; border: 1px solid <?= $corStatus ?>; border-radius: 8px; margin-bottom: 20px;">
            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                <i class="fa fa-crown" style="font-size: 1.5rem; color: #ffc107; text-shadow: 1px 1px 2px #aaa;"></i>
                <div>
                    <h4 style="margin: 0; color: #155724;">Cliente VIP Ativo</h4>
                    <span style="font-size: 0.9em; color: #666;">Aproveite seus benefícios exclusivos!</span>
                </div>
            </div>
            
            <div style="background: rgba(255,255,255,0.6); padding: 10px; border-radius: 6px;">
                <p style="margin: 5px 0; color: #333;"><strong>Plano:</strong> <?= htmlspecialchars($planoAtual['nome'] ?? 'Plano Personalizado') ?></p>
                <p style="margin: 5px 0; color: <?= $textoCor ?>;">
                    <strong>Vencimento:</strong> <?= $dataVencimento ?> 
                    <small>(Restam <?= $diasRestantes ?> dias)</small>
                </p>
            </div>
            
            <p style="font-size: 0.85em; color: #155724; margin-top: 10px; margin-bottom: 0;">
                <i class="fa fa-check-circle"></i> Seus serviços inclusos sairão com <strong>100% de desconto</strong> automaticamente ao agendar.
            </p>
        </div>
        <?php endif; ?>

        <?php if (!empty($planosArr) && !$assinaturaAtiva && $cliente_logado): ?>
        <div class="form-group" style="background: #e9f7ef; padding: 15px; border: 1px solid #28a745; border-radius: 8px;">
            <label style="color: #155724; display: flex; align-items: center; cursor: pointer; font-weight: bold; font-size: 1.1em;">
                <input type="checkbox" name="aderir_plano" id="aderir_plano" value="1" style="width: 20px; height: 20px; margin-right: 10px;">
                <span><i class="fa fa-crown"></i> Quero ser VIP e ter serviços ilimitados!</span>
            </label>
            
            <div id="selecao-plano-container" style="display: none; margin-top: 15px;">
                <select name="plano_escolhido_id" id="plano_escolhido_id" style="width: 100%; padding: 10px; border-radius: 5px; border: 1px solid #28a745; font-size: 1em;">
                    <option value="">Selecione um Plano...</option>
                    <?php foreach ($planosArr as $p): ?>
                        <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['nome']) ?> - R$ <?= number_format((float)$p['valor'], 2, ',', '.') ?>/mês</option>
                    <?php endforeach; ?>
                </select>
                
                <div style="margin-top: 15px; font-size: 0.9em; color: #155724; line-height: 1.5;">
                    <p><strong><i class="fa fa-check"></i> Benefício VIP:</strong> Com este plano, você pode realizar os serviços inclusos <strong>quantas vezes quiser</strong> durante a validade.</p>
                    
                    <p><strong><i class="fa fa-calendar-check"></i> Validade:</strong> <span id="texto-validade-plano">1 Mês (a partir da data do pagamento)</span>.</p>
                    
                    <p><strong><i class="fa fa-hand-holding-usd"></i> Pagamento:</strong> O valor do plano será cobrado presencialmente no seu atendimento.</p>
                    <p style="margin-top: 10px; font-style: italic;">* Ao marcar esta opção, o valor deste agendamento será ajustado para corresponder à adesão/renovação do plano.</p>
                </div>
            </div>
        </div>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const checkbox = document.getElementById('aderir_plano');
                const container = document.getElementById('selecao-plano-container');
                const select = document.getElementById('plano_escolhido_id');
                const textoValidade = document.getElementById('texto-validade-plano'); 

                if (checkbox) {
                    checkbox.addEventListener('change', function() {
                        container.style.display = this.checked ? 'block' : 'none';
                        select.required = this.checked;
                        if (!this.checked) { select.value = ""; }
                        
                        // Lógica de Data (Hoje até Hoje + 1 Mês)
                        if (this.checked) {
                            const hoje = new Date();
                            const mesQueVem = new Date(hoje);
                            mesQueVem.setMonth(hoje.getMonth() + 1);
                            
                            const options = { day: '2-digit', month: '2-digit', year: 'numeric' };
                            const dataInicio = hoje.toLocaleDateString('pt-BR', options);
                            const dataFim = mesQueVem.toLocaleDateString('pt-BR', options);
                            
                            if(textoValidade) textoValidade.textContent = `${dataInicio} a ${dataFim} (1 Mês)`;
                        }

                        // Dispara evento customizado para atualizar resumo
                        document.dispatchEvent(new Event('updateResumoNeeded'));
                    });
                }
                if (select) {
                    select.addEventListener('change', function() {
                         document.dispatchEvent(new Event('updateResumoNeeded'));
                    });
                }
            });
        </script>
        <?php endif; ?>

        <div class="form-group">
            <label for="data">Data</label>
            <div class="input-icon"><i class="fa fa-calendar"></i><input type="text" name="data" id="data" required <?= $input_disabled_attr ?> placeholder="Selecione a data"></div>
            <div id="dias-disponiveis-info" class="info-calendario"></div>
        </div>
        <div class="form-group">
            <label>Horário</label>
            <div id="horarios-container" class="horario-grid"></div>
            <input type="hidden" name="horario" id="horario" required>
            <input type="hidden" name="horario_barbeiro_id" id="horario_barbeiro_id">
        </div>
        <div class="form-group">
            <label for="cupom">Cupom ou Voucher (Opcional)</label>
            <div class="input-icon"><i class="fa fa-tag"></i><input type="text" name="cupom" id="cupom" placeholder="Insira seu código" <?= $input_disabled_attr ?>></div>
        </div>

        <?php 
        if ($cliente_logado && ($config_fidelidade['ativado'] ?? 0)): 
            $pontos_atuais = getClientFidelityPoints($_SESSION['cliente_id']);
            $pontos_necessarios = $config_fidelidade['pontos_necessarios'] ?? 10;
            $percentual_desc = $config_fidelidade['desconto_percentual'] ?? 0;
            
            // Correção: Removemos a restrição !$assinaturaAtiva. Agora aparece se tiver pontos.
            if ($pontos_atuais >= $pontos_necessarios):
        ?>
            <div class="form-group" style="background-color: #fff3cd; padding: 15px; border: 1px solid #ffeeba; border-radius: 8px;">
                <label style="color: #856404; display: flex; align-items: center; cursor: pointer; font-weight: bold; margin-bottom: 0;">
                    <input type="checkbox" name="usar_fidelidade" value="1" style="width: 20px; height: 20px; margin-right: 10px;" <?= $input_disabled_attr ?>>
                    <span>
                        <i class="fa fa-star"></i> Usar <strong><?= $pontos_necessarios ?> pontos</strong> para ganhar <strong><?= $percentual_desc ?>% de desconto</strong>?
                    </span>
                </label>
                <small style="display: block; margin-top: 5px; color: #856404; margin-left: 30px;">
                    Você tem <?= $pontos_atuais ?> pontos acumulados.
                </small>
            </div>
        <?php 
            endif; 
        endif; 
        ?>
        <button type="button" id="btn-toggle-observacoes" class="btn-observacao"><i class="fa fa-plus"></i> Adicionar Observação</button>
        <div id="observacoes-container" class="form-group observacoes-container">
            <label for="observacoes">Observações (opcional)</label>
            <textarea name="observacoes" id="observacoes" rows="3" placeholder="Ex: Alergia a algum produto, preferência de corte, etc." <?= $input_disabled_attr ?>></textarea>
        </div>

        <button type="submit" class="btn-primary" <?= $input_disabled_attr ?>>Agendar</button>
    </form>
    <div id="resumo"></div>
</div>

<div id="modal-barbeiro-detalhes" class="modal-overlay"><div class="modal-content"><button class="modal-close">&times;</button><div id="barbeiro-detalhes-content"></div></div></div>

<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://npmcdn.com/flatpickr/dist/l10n/pt.js"></script>
<script>
    const agendamentoConfig = { antecedencia_maxima: <?= (int)($configAgendamento['antecedencia_maxima'] ?? 30) ?>, max_servicos: <?= (int)($configAgendamento['max_servicos'] ?? 4) ?> };
    let barbeirosData = <?= json_encode(array_values($barbeirosAtivosArr)) ?>; 
    const todosBarbeirosData = <?= json_encode(array_values($barbeirosArr)) ?>;
    const servicosData = <?= json_encode($servicosArr) ?>;
    const combosData = <?= json_encode($combosArr) ?>;
    const avaliacoesData = <?= json_encode(array_values($avaliacoesArr)) ?>; 
    const clientesData = <?= json_encode($clientesArr) ?>;
    const planosData = <?= json_encode($planosArr) ?>;
    
    // Passar a assinatura ativa para o JS
    const clienteAssinaturaAtiva = <?= json_encode($assinaturaAtiva) ?>; 
</script>
<script src="js/script.js"></script>
<script>
// Script adicional para integrar o evento 'updateResumoNeeded' ao script principal
document.addEventListener('updateResumoNeeded', function() {
    if (typeof updateResumo === 'function') {
        updateResumo();
    }
});

document.addEventListener('DOMContentLoaded', function() {
    if (typeof todosBarbeirosData !== 'undefined') { barbeirosData = todosBarbeirosData; }
    const barbeiroPreselecionado = '<?= $barbeiro_preselecionado ?? "" ?>';
    const servicosPreselecionados = <?= json_encode($servicos_preselecionados ?? []) ?>;
    if (barbeiroPreselecionado) { const barbeiroOption = document.querySelector(`.custom-option[data-value="${barbeiroPreselecionado}"]`); if (barbeiroOption) { setTimeout(() => { barbeiroOption.click(); }, 100); } }
    if (servicosPreselecionados.length > 0 && servicosPreselecionados[0] !== '') { setTimeout(() => { servicosPreselecionados.forEach(servicoId => { const servicoBtn = document.querySelector(`.servico-btn[data-id="${servicoId}"]`); if (servicoBtn && !servicoBtn.classList.contains('selected')) { servicoBtn.click(); } }); }, 200); }
});
</script>
</body>
</html>